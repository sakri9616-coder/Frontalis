import re


def internal_leakage(text):
    # ASCII boundaries catch candidate letters directly adjacent to Japanese.
    return re.findall(r'(?<![A-Za-z0-9_])(?:(?:train|added|irrelevant)-\d+|p\d-s\d|NPN|[abc])(?![A-Za-z0-9_])|[-+]?\d+\.\d+', text, re.I)
