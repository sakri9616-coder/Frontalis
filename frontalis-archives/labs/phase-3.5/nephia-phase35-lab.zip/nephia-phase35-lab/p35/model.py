"""CPU training and portable NumPy inference with independent personal heads."""
import copy
import hashlib
import json
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT.parent / 'nephia-phase3-lab'))
from p3.runtime import features as old_features, Phase2Runtime


def digest(v):
    return hashlib.sha256(json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def arrays(rows):
    return np.array([e['x'] for e in rows]), np.array([e['domain'] for e in rows]), np.array([e['y'] for e in rows])


def accepted(rows):
    ids = set()
    for e in rows:
        if e.get('inputSchema') != 'p35.context.v1' or e.get('owner') != 'nephia' or e.get('origin') not in ('synthetic', 'human', 'observation') or not e.get('accepted') or e.get('signal') != 'observed' or e.get('confidence', 0) < .5:
            raise ValueError('Only accepted, attributed observations can train a personality.')
        if e['id'] in ids:
            raise ValueError('Duplicate experience.')
        ids.add(e['id'])
        if np.asarray(e['x']).shape != (6,) or np.asarray(e['y']).shape != (5,) or not 0 <= e['domain'] < 4 or not np.isfinite(e['x'] + e['y']).all() or np.max(np.abs(e['x'] + e['y'])) > 1:
            raise ValueError('Invalid observations.')
    return rows


def shared_train(seed, latent_dim=16):
    import torch
    from torch import nn
    torch.set_num_threads(2)
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed + 91000)
    raw = rng.uniform(-1, 1, (2048, 6)).astype('float32')
    pairs = [(i, j) for i in range(6) for j in range(i, 6)]
    target = np.column_stack([raw] + [raw[:, i] * raw[:, j] for i, j in pairs]).astype('float32')
    encoder = nn.Sequential(nn.Linear(6, 32), nn.Tanh(), nn.Linear(32, latent_dim))
    decoder = nn.Linear(latent_dim, target.shape[1])
    opt = torch.optim.Adam(list(encoder.parameters()) + list(decoder.parameters()), lr=.012)
    x = torch.tensor(raw[:1792]); y = torch.tensor(target[:1792])
    vx = torch.tensor(raw[1792:]); vy = torch.tensor(target[1792:])
    best = None; best_loss = float('inf')
    for step in range(450):
        opt.zero_grad(); loss = (decoder(encoder(x)) - y).square().mean(); loss.backward(); opt.step()
        if step % 25 == 0 or step == 449:
            with torch.no_grad():
                validation = float((decoder(encoder(vx)) - vy).square().mean())
            if validation < best_loss:
                best_loss = validation; best = copy.deepcopy(encoder.state_dict())
    weights = {k: v.tolist() for k, v in best.items()}
    return {'formatVersion': 1, 'weights': weights, 'parameters': sum(v.numel() for v in best.values()), 'latentDim': latent_dim,
            'pretraining': {'seed': seed, 'trainInputs': 1792, 'validationInputs': 256, 'personLabelsUsed': False, 'reconstructionMSE': best_loss}}


def encoded(shared, x):
    w = shared['weights']
    return np.tanh(x @ np.asarray(w['0.weight']).T + w['0.bias']) @ np.asarray(w['2.weight']).T + w['2.bias']


def representation(kind, shared, x, d, old):
    if kind == 'linear':
        phi = x
    elif kind == 'quadratic':
        phi = np.column_stack([x] + [x[:, i] * x[:, j] for i in range(6) for j in range(i, 6)])
    elif kind == 'frozen':
        phi = old_features(Phase2Runtime(old), x)
    else:
        phi = encoded(shared, x)
    phi = np.column_stack([phi, np.ones(len(x))])
    return (phi[:, None, :] * np.eye(4)[d, :, None]).reshape(len(x), -1)


def recovery(rows):
    values = [[], []]
    for e in rows:
        for obs in e['recovery']:
            for j in range(2):
                b, a = obs['before'][j], obs['after'][j]
                if abs(b) > .02 and 0 < a / b < 1 and obs['elapsed'] > 0:
                    values[j].append(np.log(a / b) / obs['elapsed'])
    return [float(np.exp(np.mean(v))) if v else .5 for v in values]


def fit(rows, kind, shared, old, regularization=.03, coupling=0, k=7):
    rows = accepted(rows); x, d, y = arrays(rows)
    if kind == 'memory':
        model = {'kind': kind, 'k': k}
    else:
        phi = representation(kind, shared, x, d, old)
        target = np.arctanh(np.clip(y, -.98, .98))
        gram = phi.T @ phi + regularization * np.eye(phi.shape[1])
        rhs = phi.T @ target
        weights = np.linalg.solve(gram, rhs)
        if coupling:
            plus = np.linalg.solve(gram, rhs[:, 0] + rhs[:, 1]) / 2
            minus = np.linalg.solve(gram + 2 * coupling * np.eye(len(gram)), rhs[:, 0] - rhs[:, 1]) / 2
            weights[:, 0] = plus + minus; weights[:, 1] = plus - minus
        model = {'kind': kind, 'weights': weights.tolist(), 'regularization': regularization, 'coupling': coupling, 'initialWeights': 'all-zero', 'learnedParameters': weights.size}
    return {**model, 'formatVersion': 1, 'inputSchema': 'p35.context.v1', 'shared': shared if kind == 'adapted' else None,
            'old': old if kind == 'frozen' else None, 'decay': recovery(rows), 'shortState': [0, 0], 'time': 0,
            'experienceIds': [e['id'] for e in rows], 'experienceHash': digest(rows), 'experiences': copy.deepcopy(rows), 'owner': 'nephia'}


def predict(model, x, d):
    x = np.asarray(x); d = np.asarray(d, dtype=int)
    if x.ndim != 2 or x.shape[1] != 6 or d.shape != (len(x),) or not np.isfinite(x).all() or np.any(np.abs(x) > 1) or np.any((d < 0) | (d > 3)):
        raise ValueError('Invalid query input.')
    if model['kind'] == 'legacy':
        sys.path.insert(0, str(ROOT.parent / 'nephia-phase3-lab'))
        from p3.runtime import Personality
        p = Personality(model['legacy']); score = p.score(x); force = p.force(x)
        return np.column_stack([score, score, score, force])
    if model['kind'] == 'memory':
        hx, hd, hy = arrays(model['experiences']); output = []
        for v, domain in zip(x, d):
            available = np.flatnonzero(hd == domain)
            nearest = available[np.argsort(np.sum((hx[available] - v)**2, axis=1))[:model['k']]]
            if not len(nearest):
                output.append(np.zeros(5)); continue
            dist = np.sum((hx[nearest] - v)**2, axis=1)
            weights = 1 / (dist + .2)
            output.append(np.average(hy[nearest], axis=0, weights=weights))
        return np.array(output)
    phi = representation(model['kind'], model['shared'], x, d, model['old'])
    return np.tanh(phi @ np.asarray(model['weights']))


def select(train, validation, kind, shared, old, coupled=False):
    vx, vd, vy = arrays(validation); candidates = []
    if kind == 'memory':
        configs = [{'k': k} for k in (3, 7, 15)]
    else:
        configs = [{'regularization': r, 'coupling': c} for r in (.003, .03, .3) for c in ((0, .03, .3) if coupled else (0,))]
    for config in configs:
        model = fit(train, kind, shared, old, **config)
        loss = float(np.mean((predict(model, vx, vd) - vy)**2)); candidates.append((loss, config, model))
    loss, config, model = min(candidates, key=lambda v: v[0])
    model['validationSelection'] = {'mse': loss, 'config': config, 'candidates': [{'mse': a, 'config': b} for a, b, _ in candidates]}
    return model


def legacy_fit(rows, old):
    accepted(rows)
    from p3.train import train
    converted = [{'schema': 'p3.experience.v1', 'inputSchema': 'structured-context6-v1', 'id': e['id'], 'owner': 'nephia',
                  'signal': 'self_report', 'text': e['text'], 'features': e['x'], 'evaluation': e['y'][0], 'activation': e['y'][4],
                  'confidence': 1, 'gap': 1, 'reactionObserved': e['y'][3:5], 'evidence': {'origin': 'synthetic'}} for e in rows]
    return {'kind': 'legacy', 'legacy': train(old, converted), 'formatVersion': 1, 'inputSchema': 'p35.context.v1',
            'experiences': rows, 'experienceIds': [e['id'] for e in rows], 'experienceHash': digest(rows),
            'decay': [.5, .5], 'shortState': [0, 0], 'time': 0, 'owner': 'nephia'}


def transition(model, x=None, domain=None, elapsed=1):
    if not np.isfinite(elapsed) or elapsed < 0:
        raise ValueError('Invalid elapsed time.')
    m = copy.deepcopy(model); factor = np.array(m['decay']) ** elapsed
    short = np.array(m['shortState']) * factor
    if x is not None:
        short += (1 - factor) * predict(m, [x], [domain])[0, 3:5]
    m['shortState'] = short.tolist(); m['time'] += elapsed
    m.setdefault('transitions', []).append({'kind': 'event' if x is not None else 'elapse', 'x': x, 'domain': domain,
                                            'elapsed': elapsed, 'owner': model['owner'], 'longStateHash': digest(model.get('weights', model.get('legacy')))})
    return m


def refit(model, rows):
    if model['kind'] == 'legacy':
        new = legacy_fit(rows, model['legacy']['payload']['model'])
    else:
        new = fit(rows, model['kind'], model.get('shared'), model.get('old'), model.get('regularization', .03), model.get('coupling', 0), model.get('k', 7))
    new['shortState'] = copy.deepcopy(model['shortState']); new['time'] = model['time']
    if 'transitions' in model:
        new['transitions'] = copy.deepcopy(model['transitions'])
    return new
