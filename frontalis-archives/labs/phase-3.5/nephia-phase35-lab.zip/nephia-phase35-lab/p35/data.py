"""Synthetic environment; hidden teacher parameters never enter the learner."""
import numpy as np

DOMAINS = ('音楽', '共同制作', '探究', '約束')
FUNCTIONS = ('選好', '好奇心', '価値判断', '反応方向', '反応強度')


def contexts(seed, n):
    rng = np.random.default_rng(seed)
    x = rng.uniform(-1, 1, (n, 6))
    d = np.arange(n) % 4
    return x, d


def teacher(seed, person, condition, x, d, updated=False):
    rng = np.random.default_rng(seed + 997 * person)
    w = rng.normal(0, .48, (4, 6, 5))
    # These coefficients belong only to the environment, never to a saved learner.
    w[0, 0, 0] += (-1, 1, .5, -.5)[person]
    w[0, 0, 1] += (1.6, -.8, .6, 1)[person]
    w[1, 5, 2] += (-1.4, .8, -1, 1.2)[person]
    w[2, 0, 2] += (-1.2, 1, -.8, .7)[person]
    w[3, 5, 2] += (-1.8, -.8, -1.2, -.2)[person]
    if updated:
        w[2, 0, 2] += 2.8
    linear = np.einsum('ni,nij->nj', x, w[d])
    if condition != 'linear':
        a = rng.normal(0, 1.3, (4, 5))
        b = rng.normal(0, .9, (4, 5))
        linear += a[d] * (x[:, 0] * x[:, 4])[:, None] + b[d] * (x[:, 2] * x[:, 5])[:, None]
    if condition == 'context':
        c = rng.normal(0, .65, (4, 5))
        linear += c[d] * np.sin(2.2 * x[:, 1])[:, None]
        linear[:, 1] += .45 * np.tanh(linear[:, 0]) * x[:, 3]
    y = np.tanh(linear)
    y[:, 4] = .1 + .8 * (y[:, 4] + 1) / 2
    return y


def narrative(x, domain, y):
    novelty = '初めての方法' if x[0] > 0 else '慣れた方法'
    public = '人前で' if x[1] > 0 else '手元で'
    team = '仲間と' if x[2] > 0 else '一人で'
    reflection = '記録を見直しながら' if x[3] > 0 else 'その場で試しながら'
    sensory = '刺激の強い' if x[4] > 0 else '静かな'
    flexible = '途中で変更できる' if x[5] > 0 else '先に決めた手順を守る'
    result = ('響きの作り方に気づいた', '役割のずれを相談できた', '予定外の手がかりを見つけた', '相手の見通しを確かめた')[domain]
    like = 'また選びたいと感じた' if y[0] > .15 else '自分には合わないと感じた' if y[0] < -.15 else '好みはまだ決めきれなかった'
    curious = '仕組みをさらに調べたくなった' if y[1] > .15 else '続けて調べる関心は薄かった' if y[1] < -.15 else '知りたいかどうかは迷った'
    value = '次もこの判断を重視したいと思った' if y[2] > .15 else '次は別の優先順位にしたいと思った' if y[2] < -.15 else '判断には両方の重みがあると感じた'
    return f'{DOMAINS[domain]}で{novelty}を選び、{public}{team}{reflection}、{sensory}状況で{flexible}進め方を試した。結果として{result}。当時は{like}が、{curious}。{value}。'


def records(seed, person, condition, split, n, updated=False, domain_only=None):
    offset = {'train': 11, 'validation': 31, 'test': 71, 'added': 131, 'irrelevant': 191}[split]
    x, d = contexts(seed + offset, n)
    if domain_only is not None:
        d[:] = domain_only
    y = teacher(seed, person, condition, x, d, updated)
    rng = np.random.default_rng(seed + offset + 313 * person)
    observed = np.clip(y + rng.normal(0, .025, y.shape), -.98, .98)
    decay = np.array((.45, .65)) + person * .07
    out = []
    for i in range(n):
        out.append({'id': f'{split}-{i:03d}', 'inputSchema': 'p35.context.v1', 'x': x[i].tolist(), 'domain': int(d[i]),
                    'y': (observed[i] if split != 'test' else y[i]).tolist(),
                    'text': narrative(x[i], d[i], observed[i]), 'owner': 'nephia', 'origin': 'synthetic',
                    'accepted': True, 'signal': 'observed', 'confidence': 1,
                    'recovery': [{'elapsed': t, 'before': observed[i, 3:5].tolist(),
                                  'after': (observed[i, 3:5] * decay ** t).tolist()} for t in (1, 3)]})
    return out
