# Claude Codeへの引き継ぎ — Phase 3-A / 3.5

本フォルダーは独立研究。ASISTへは統合していない。Phase 4へ進まない。無料OpenCodeを利用し、今回Claude CLIは一度も呼ばない。

## コードの入口

- `p35/data.py`：隠れた合成環境。係数・人物の目標をlearnerへ渡さない。
- `p35/model.py`：共有NNのCPU学習、凍結/適応特徴、線形/記憶/部分結合、個人head更新、短期反応。
- `p35/store.py`：受理経験とstateのhash、世代保存、空領域restore、新世代rollback。
- `experiments/evaluate.py`：事前計画の6方式・3条件・3seed・4系列、全介入。
- `experiments/exploratory.py`：結果確認後の8次元適応・二次特徴回帰。主結果に混ぜない。
- `scripts/prepare_live.py`：形成前/後/追加後を含む元の全履歴会話入力。
- `scripts/controls.py`：状態readoutのみ交換、同点の曖昧な相談。
- `scripts/domain_live.py`：同じ領域の経験検索。B/D/Eの提示経験を揃える。
- `scripts/reaction_live.py`：現在の短期反応の意味を明示した0/出来事後/経過後の探索対照。
- `scripts/numeric_summary.py` / `summarize.py` / `report.py`：全数値、実会話、重点20例、Q1〜Q8の報告生成。
- `scripts/opencode.mjs` / `experiments/live.mjs`：既存CLI呼び出し・ツール利用拒否検査・JSON/ID検査。モデルの実体/重み版の証明ではなく、CLIへ指定した無料モデルIDを記録。
- `scripts/infer.py`：保存stateの新OSプロセス参照。JSON標準入力、owner一致必須。

既存参考：Phase 1 `src/core.mjs` の台帳/restore/rollback、Phase 2 `npn/runtime.py` の共有特徴、Phase 3 `p3/train.py`/`runtime.py` の旧評価/反応、ASIST `src/shared/agent-cli.ts` のOpenCode引数。全て読み取り参照。旧版の書換は不要。

## 再現

既存環境のPythonを使い、インストールしない。結果を再生成するときは研究フォルダー全体を新しい独立場所へコピーし、元の成果を保存してから実行する。demoは既存runtime履歴の上書きを拒否する。

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
$env:PYTHONUTF8='1'
$npnPython='C:\Users\sakur\AppData\Local\hermes\jef\venv\Scripts\python.exe'
& $npnPython -m unittest discover -s tests -v
& $npnPython experiments/evaluate.py
& $npnPython experiments/exploratory.py
& $npnPython scripts/prepare_live.py
& $npnPython scripts/controls.py
& $npnPython scripts/domain_live.py
& $npnPython scripts/reaction_live.py
& $npnPython scripts/numeric_summary.py
& $npnPython scripts/summarize.py
& $npnPython scripts/report.py
```

会話実行はオフラインテストと分離。既存設定を変更せず、実データは送らない。対象の無料モデルがなくなったら、有料モデルへfallbackしない。完了済みの有効chunkは再生成せず、失敗の同名入力も勝手に上書きしない。

```powershell
$env:NEPHIA_LIVE_PLAN='domain'
$env:NEPHIA_TIMEOUT_MS='300000'
node experiments/live.mjs opencode/nemotron-3-ultra-free D B E A T S U R
node experiments/live.mjs opencode/mimo-v2.6-flash-free D B E A T S U R
```

CLIが設定した無料モデルIDは `reports/free-models.json` と各raw結果に記録。週次上限に達したClaudeの代替であり、過去Haiku/Sonnet結果との改善率を算出しない。大きな全履歴バッチの失敗は `reports/live` / `live-small` に保持し、最終の領域検索条件と混合しない。
現在の保存hashはPythonのJSON数値表現に依存する。snapshotのJSONを別言語でparse/stringifyして丸ごと書き直す移植は未検証で、整数/浮動小数表現の違いでhashが変わり得る。保存ファイルはraw文字列/バイトのまま保ち、Node側は予測照会を送るだけにする。別言語がstate正本を再構成する版を作るなら、Phase 2の `npn/canonical.py` の数値正規化を参考に、新しい保存版・移行・往復テストを追加する。旧研究成果を書き換えない。

## 次に必要な作業

1. 20応答の人間評価を受け、自然さ・具体的根拠・内容の分化を会話の機械欄との一致と区別する。
2. 反応強度decoderの範囲制約、曖昧な注釈、自己報告の検証、欠測機能を扱う訓練、回復ラベルのノイズを別実験で修正・比較する。未検証自己申告を自動受理しない。
3. 二次特徴線形がNN以上だった条件を引き継ぎ、NN採用を先に決めない。少量/ノイズ/非定常/領域横断で強い単純方式との差を再検証する。
4. 実際のNephia本人の経験について、owner・source・受理・修正・除外の運用を決め、本人/ユーザーの評価を分ける。me.md原文の廃棄や自動取込はしない。
5. 統合の許可が別途出た後に初めて、最新ASISTの実行前参照→会話後の提案→信頼するホストで受理→日次再学習→世代checkpointを実装する。会話エンジンにはaccept/rollbackを書かせない。

今の段階で本体へ常時学習を入れない。実経験の教師信頼性、文脈意味、情動範囲、長期保持、人間評価、書込排他/クラッシュ復元を満たすまで統合を保留する。Claude上限の回復を待つ作業はない。

合成経験から育てた4系列の個人headを、Nephia本人の初期人格としてコピーしない。本人の既存記憶と研究用教師を混同しない。
会話結果の再利用はモデル・方式・入力プロンプト・ケースの完全一致を検査する。変わった入力に以前の有効出力を当て直さず、新しい実験保存領域を作る。`NEPHIA_VERIFY_CACHE_ONLY=1` は外部呼び出しを禁止して照合だけ行う。最終90例の全入力をこの方法で照合済み。
