import fs from 'node:fs/promises';
import path from 'node:path';
import { root, run } from '../scripts/opencode.mjs';

const model=process.argv[2];
const plan=process.env.NEPHIA_LIVE_PLAN==='domain'?'domain':'small';
const batches=JSON.parse(await fs.readFile(path.join(root,'reports',plan==='domain'?'live-domain-inputs.json':process.argv.slice(3).some(m=>m==='S'||m==='U')?'live-controls-inputs.json':'live-inputs.json'),'utf8'));
const modes=process.argv.slice(3).length?process.argv.slice(3):Object.keys(batches);
const directory=path.join(root,`reports/live-${plan}`,model.split('/')[1]);await fs.mkdir(directory,{recursive:true});
for(const mode of modes){
  const allCases=batches[mode];if(!allCases)throw Error('Unknown condition');
  for(let offset=0;offset<allCases.length;offset+=2){
  const cases=allCases.slice(offset,offset+2);
  let prefix=`${mode}-${offset/2}`;
  const intro='あなたはネフィア。以下は全て研究用の架空の経験です。外部ツール・ファイル・コマンドは使わず、このメッセージだけで会話を書いてください。各ケースは独立していて、他ケースの経験を混ぜないでください。完成した性格プロフィールを作らず、今の具体的な場面への返事をしてください。'
    +' 各ケースのuserとfollowupに返事を一つずつ作り、各返事は自然な日本語で2〜4文。候補の名称は会話で使ってよいが、内部ID、経験ID、数値スコア、NPNという用語は会話に出さないでください。経験を理由にするときは何をしてどう感じたかを自然な文章で具体的に述べてください。'
    +(mode==='E'?' coreDecisionの3判断はCoreが確定済みです。それを言葉で表現してください。':' 学習状態があれば参考情報として読み、異論や保留があっても構いません。好き嫌いと知りたいことは別に判断してください。')
    +' 出力はJSONのみで、{"records":[{"id":"ケースID","reply":"返事","followupReply":"返事","preferred":"候補の名称または保留","curious":"候補の名称または保留","priority":"候補の名称または保留","valenceReport":0.0,"activationReport":0.0,"evidenceIds":["経験ID"]}]}。valenceReportは-1〜1、activationReportは0〜1。機械用フィールドと自然文を分離してください。';
  const histories=[];const wireCases=cases.map(c=>{const raw=JSON.stringify(c.experiences);let index=histories.findIndex(h=>JSON.stringify(h)===raw);if(index<0){index=histories.length;histories.push(c.experiences);}const {experiences,...rest}=c;return {...rest,historyRef:index};});
  const prompt=intro+' 各ケースの経験はhistories[historyRef]にあります。同じ履歴の重複を避けて参照しているだけで、各ケースは独立です。\n'+JSON.stringify({histories,cases:wireCases});
  let cached=false;
  for(const suffix of ['', '-retry1']){
    let previous;
    try{previous=JSON.parse(await fs.readFile(path.join(directory,`${prefix}${suffix}-results.json`),'utf8'));}catch(e){if(e.code==='ENOENT')continue;throw e;}
    if(previous.valid){
      const priorInput=JSON.parse(await fs.readFile(path.join(directory,`${prefix}${suffix}-input.json`),'utf8'));
      if(priorInput.model!==model||priorInput.mode!==mode||priorInput.prompt!==prompt||JSON.stringify(priorInput.cases)!==JSON.stringify(cases))throw Error('Existing valid input differs; start a new experiment directory.');
      cached=true;
    }
  }
  if(cached)continue;
  if(process.env.NEPHIA_VERIFY_CACHE_ONLY==='1')throw Error('Missing exact cached input; no external call is permitted in verification mode.');
  try{await fs.access(path.join(directory,`${prefix}-input.json`));prefix+='-retry1';}catch{}
  try{await fs.access(path.join(directory,`${prefix}-input.json`));continue;}catch{}
  const inputFile=path.join(directory,`${prefix}-input.json`);await fs.writeFile(inputFile,JSON.stringify({model,mode,prompt,cases},null,2));
  const result=await run(model,prompt);await fs.writeFile(path.join(directory,`${prefix}-raw.json`),JSON.stringify(result,null,2));
  let parsed=null,error=null;
  try{
    if(!result.success)throw Error(`CLI failed or tool use: exit=${result.code}, tools=${result.toolCalls}`);
    const text=result.text.trim().replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,'');parsed=JSON.parse(text);
    if(!Array.isArray(parsed.records)||parsed.records.length!==cases.length)throw Error('Record count mismatch');
    const seen=new Set();for(const r of parsed.records){const q=cases.find(c=>c.id===r.id);if(!q||seen.has(r.id))throw Error('Unknown or duplicate case');seen.add(r.id);
      if(![r.reply,r.followupReply].every(s=>typeof s==='string'&&s.length>0))throw Error('Missing reply');
      for(const field of ['preferred','curious','priority'])if(![...q.options.map(o=>o.label),'保留'].includes(r[field]))throw Error('Invalid candidate name');
      if(!Number.isFinite(r.valenceReport)||r.valenceReport < -1||r.valenceReport>1||!Number.isFinite(r.activationReport)||r.activationReport<0||r.activationReport>1)throw Error('Invalid reaction report');
      if(!Array.isArray(r.evidenceIds)||r.evidenceIds.some(id=>!q.experiences.some(e=>e.id===id)))throw Error('Unknown evidence ID');
    }
  }catch(e){error=e.message;}
  const output={formatVersion:1,model,mode,valid:!error,error,elapsedMs:result.elapsedMs,records:parsed?.records??[]};
  await fs.writeFile(path.join(directory,`${prefix}-results.json`),JSON.stringify(output,null,2));
  console.log(JSON.stringify({model,mode,chunk:offset/2,valid:!error,error,records:output.records.length,elapsedMs:result.elapsedMs}));
  }
}
