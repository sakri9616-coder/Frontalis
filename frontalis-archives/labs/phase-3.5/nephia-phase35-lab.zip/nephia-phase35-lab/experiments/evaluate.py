import copy
import json
import sys
import time
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from p35.data import records, teacher, FUNCTIONS
from p35.model import arrays, shared_train, select, predict, legacy_fit, refit, digest, representation


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8')


def metrics(pred, actual):
    opposite = (actual[:, 0] < -.15) & (actual[:, 1] > .15)
    return {'mse': float(np.mean((pred - actual)**2)), 'functionMSE': np.mean((pred - actual)**2, axis=0).tolist(),
            'oppositeCases': int(opposite.sum()), 'oppositeSignAccuracy': float(np.mean((pred[opposite, 0] < 0) & (pred[opposite, 1] > 0))) if opposite.any() else None,
            'pairRankAgreement': [float(np.mean((pred[::2, j] > pred[1::2, j]) == (actual[::2, j] > actual[1::2, j]))) for j in range(3)]}


def main():
    start = time.perf_counter()
    old = json.loads((ROOT.parent / 'nephia-npn-lab/models/trained.json').read_text(encoding='utf8'))
    rows = []; saved = {}; information = []
    for seed in (3501, 3502, 3503):
        shared = shared_train(seed); save(ROOT / f'models/shared-{seed}.json', shared)
        for condition in ('linear', 'nonlinear', 'context'):
            for person in range(4):
                train = records(seed, person, condition, 'train', 48)
                val = records(seed, person, condition, 'validation', 16)
                test = records(seed, person, condition, 'test', 96)
                folder = ROOT / f'data/{seed}-{condition}/series-{person}'
                save(folder / 'train.json', train); save(folder / 'validation.json', val); save(folder / 'evaluation-only.json', test)
                assert not set(e['id'] for e in train) & set(e['id'] for e in val + test)
                x, d, y = arrays(test)
                models = {'P3_legacy': legacy_fit(train, old),
                          'P2_frozen_multi': select(train, val, 'frozen', shared, old),
                          'NPN_adapted': select(train, val, 'adapted', shared, old),
                          'NPN_coupled': select(train, val, 'adapted', shared, old, coupled=True),
                          'linear_multi': select(train, val, 'linear', shared, old),
                          'memory': select(train, val, 'memory', shared, old)}
                for name, model in models.items():
                    p = predict(model, x, d)
                    save(ROOT / f'models/{seed}-{condition}-p{person}-{name}.json', model)
                    rows.append({'seed': seed, 'condition': condition, 'person': person, 'method': name,
                                 **metrics(p, y), 'prediction': p.tolist(), 'config': model.get('validationSelection')})
                if person == 0:
                    for name in ('P2_frozen_multi', 'NPN_adapted'):
                        model = models[name]; hx, hd, _ = arrays(train)
                        h = representation(model['kind'], model.get('shared'), hx, hd, model.get('old'))
                        q = representation(model['kind'], model.get('shared'), x, d, model.get('old'))
                        decoder = np.linalg.solve(h.T @ h + .03 * np.eye(h.shape[1]), h.T @ hx)
                        information.append({'seed': seed, 'condition': condition, 'method': name,
                                            'unseenInputReconstructionMSE': float(np.mean((q @ decoder - x)**2))})
                if seed == 3501 and condition == 'context':
                    saved[person] = models
            print(json.dumps({'seed': seed, 'condition': condition, 'complete': True}), flush=True)
    summary = {}
    for condition in ('linear', 'nonlinear', 'context'):
        summary[condition] = {}
        for method in saved[0]:
            items = [r for r in rows if r['condition'] == condition and r['method'] == method]
            summary[condition][method] = {'mse': float(np.mean([r['mse'] for r in items])),
                                         'functionMSE': np.mean([r['functionMSE'] for r in items], axis=0).tolist(),
                                         'oppositeCases': sum(r['oppositeCases'] for r in items),
                                         'oppositeSignAccuracy': float(sum(r['oppositeCases'] * (r['oppositeSignAccuracy'] or 0) for r in items) / max(1, sum(r['oppositeCases'] for r in items)))}
    interventions = []; causal = []; formation = []; baseline_predictions = []
    for person in range(4):
        models = saved[person]; original = models['NPN_adapted']['experiences']
        tx, td, ty = arrays(records(3501, person, 'context', 'test', 96))
        baseline_predictions.append(predict(models['NPN_adapted'], tx, td).tolist())
        music_ids = [i for i, e in enumerate(original) if e['domain'] == 0][:4]
        remove = [e for i, e in enumerate(original) if i not in music_ids]
        flipped = copy.deepcopy(original)
        for i in music_ids:
            flipped[i]['y'][0] *= -1
            flipped[i]['text'] += '研究用介入：この出来事に対する好き嫌いの評価だけを訂正した。'
        swapped = copy.deepcopy(original)
        other = saved[(person + 1) % 4]['NPN_adapted']['experiences']
        for i in music_ids:
            swapped[i] = copy.deepcopy(other[i])
            swapped[i]['sourceIntervention'] = 'experience-exchange'
        reversed_rows = list(reversed(original))
        added = records(3501, person, 'context', 'added', 12, updated=True, domain_only=2)
        irrelevant = records(3501, person, 'context', 'irrelevant', 12, domain_only=0)
        variants = {'remove_music': remove, 'flip_preference_only': flipped, 'swap_music': swapped,
                    'reverse_order': reversed_rows, 'add_exploration': original + added, 'add_music': original + irrelevant}
        updated_truth = teacher(3501, person, 'context', tx, td, updated=True)
        for name, model in models.items():
            before = predict(model, tx, td)
            for intervention, experiences in variants.items():
                new = refit(model, experiences); after = predict(new, tx, td); delta = after - before
                changed = np.abs(updated_truth - ty) > .15
                values = {'person': person, 'method': name, 'intervention': intervention,
                          'beforeStateHash': digest(model), 'afterStateHash': digest(new), 'stateParameterChange': None,
                          'meanAbsoluteChange': float(np.mean(np.abs(delta))),
                          'domainFunctionChange': {str(i): np.mean(np.abs(delta[td == i]), axis=0).tolist() for i in range(4)},
                          'predictionDelta': delta.tolist()}
                if 'weights' in model:
                    values['stateParameterChange'] = float(np.linalg.norm(np.array(new['weights']) - model['weights']))
                if intervention == 'add_exploration':
                    values.update({'changedTargetBeforeMSE': float(np.mean((before[changed] - updated_truth[changed])**2)),
                                   'changedTargetAfterMSE': float(np.mean((after[changed] - updated_truth[changed])**2)),
                                   'retainedMeanChange': float(np.mean(np.abs(delta[~changed]))),
                                   'correctDeltaDirection': float(np.mean(np.sign(delta[changed]) == np.sign((updated_truth - ty)[changed])))})
                interventions.append(values)
                if name == 'NPN_adapted':
                    save(ROOT / f'models/interventions/p{person}-{intervention}.json', new)
        model = models['NPN_adapted']; before = predict(model, tx, td)
        for count in (0, 8, 24, 48):
            p = np.zeros_like(ty) if count == 0 else predict(refit(model, original[:count]), tx, td)
            formation.append({'person': person, 'experienceCount': count, **metrics(p, ty)})
        if person == 0:
            probe = np.array([[.8, -.3, -.6, .4, .8, .5]])
            original_probe = predict(model, probe, [0])[0]
            for i, e in enumerate(original):
                new = refit(model, original[:i] + original[i + 1:])
                effect = original_probe - predict(new, probe, [0])[0]
                causal.append({'experienceId': e['id'], 'featureDistance': float(np.linalg.norm(probe[0] - e['x'])),
                              'sameDomain': e['domain'] == 0, 'leaveOneOutEffect': effect.tolist(),
                              'effectNorm': float(np.linalg.norm(effect))})
    save(ROOT / 'reports/offline.json', {'summary': summary, 'rows': rows, 'informationRetention': information,
                                         'formation': formation, 'interventions': interventions, 'causalContributions': causal,
                                         'interPersonaMeanDistance': float(np.mean([np.mean(np.abs(np.array(baseline_predictions[i]) - baseline_predictions[j])) for i in range(4) for j in range(i)])),
                                         'elapsedSeconds': time.perf_counter() - start,
                                         'scope': 'Synthetic 4 series repeated under 3 teacher families and 3 seeds; not 36 independent people.'})
    print(json.dumps({'summary': summary, 'seconds': time.perf_counter() - start}), flush=True)


if __name__ == '__main__':
    main()
