import json
import sys
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from p35.model import shared_train, select, predict, arrays
sys.path.insert(0, str(ROOT / 'experiments'))
from evaluate import metrics, save

rows=[]
for seed in (3501,3502,3503):
    shared=shared_train(seed,8); save(ROOT / f'models/exploratory-shared8-{seed}.json',shared)
    for condition in ('linear','nonlinear','context'):
        for person in range(4):
            folder=ROOT / f'data/{seed}-{condition}/series-{person}'
            train=json.loads((folder/'train.json').read_text(encoding='utf8'))
            val=json.loads((folder/'validation.json').read_text(encoding='utf8'))
            test=json.loads((folder/'evaluation-only.json').read_text(encoding='utf8')); x,d,y=arrays(test)
            for name,kind in [('adapted8','adapted'),('quadratic_linear','quadratic')]:
                model=select(train,val,kind,shared,None); p=predict(model,x,d)
                rows.append({'seed':seed,'condition':condition,'person':person,'method':name,**metrics(p,y),'config':model['validationSelection']})
                save(ROOT / f'models/exploratory-{seed}-{condition}-p{person}-{name}.json',model)
summary={c:{m:float(np.mean([r['mse'] for r in rows if r['condition']==c and r['method']==m])) for m in ('adapted8','quadratic_linear')} for c in ('linear','nonlinear','context')}
save(ROOT/'reports/exploratory.json',{'summary':summary,'rows':rows,'exploratory':True,'reason':'After primary numeric results, add an equal latent dimension adaptation and explicit quadratic baseline.'})
print(json.dumps(summary))
