import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from p35.data import records
from p35.model import fit, predict, refit, transition, digest
from p35.store import Store, validate
from p35.review import internal_leakage


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.rows = records(3501, 0, 'linear', 'train', 48)
        self.model = fit(self.rows, 'linear', None, None)
        self.temp = tempfile.TemporaryDirectory(dir=ROOT / 'runtime')
        self.addCleanup(self.temp.cleanup)

    def test_training_rejects_unverified_sources(self):
        for field, value in [('origin', 'model'), ('signal', 'generated_choice'), ('signal', 'praise'), ('owner', 'user'), ('confidence', .1), ('accepted', False)]:
            rows = copy.deepcopy(self.rows); rows[0][field] = value
            with self.subTest(field=field, value=value), self.assertRaises(ValueError): fit(rows, 'linear', None, None)

    def test_duplicate_experience_rejected(self):
        with self.assertRaises(ValueError): fit(self.rows + self.rows[:1], 'linear', None, None)

    def test_nonfinite_observation_rejected(self):
        self.rows[0]['y'][0] = float('nan')
        with self.assertRaises(ValueError): fit(self.rows, 'linear', None, None)

    def test_person_name_and_text_do_not_set_weights(self):
        rows = copy.deepcopy(self.rows)
        for e in rows: e['id'] += '-renamed'; e['text'] = '別の文'; e['hiddenLabel'] = 'ignored'
        self.assertEqual(self.model['weights'], refit(self.model, rows)['weights'])

    def test_preference_change_preserves_other_heads(self):
        rows = copy.deepcopy(self.rows); rows[0]['y'][0] *= -1
        new = refit(self.model, rows)
        np.testing.assert_array_equal(np.asarray(new['weights'])[:, 1:], np.asarray(self.model['weights'])[:, 1:])

    def test_unrelated_domain_preserved(self):
        new = refit(self.model, self.rows + records(3501, 0, 'linear', 'added', 12, domain_only=0))
        np.testing.assert_allclose(predict(new, [[.5]*6], [3]), predict(self.model, [[.5]*6], [3]), atol=1e-12)

    def test_order_independent_long_heads(self):
        np.testing.assert_allclose(refit(self.model, self.rows[::-1])['weights'], self.model['weights'], atol=1e-12)

    def test_short_state_is_separate_and_recovers(self):
        m = transition(self.model, [.7]*6, 0, 1); decayed = transition(m, elapsed=10)
        self.assertEqual(m['weights'], decayed['weights'])
        self.assertLess(np.linalg.norm(decayed['shortState']), np.linalg.norm(m['shortState']))

    def test_negative_elapsed_rejected(self):
        with self.assertRaises(ValueError): transition(self.model, elapsed=-1)

    def test_learning_preserves_current_short_state(self):
        m = transition(self.model, [.7]*6, 0, 1)
        updated = refit(m, self.rows + records(3501, 0, 'linear', 'added', 12, domain_only=0))
        self.assertEqual(updated['shortState'], m['shortState'])
        self.assertEqual(updated['time'], m['time'])
        self.assertEqual(updated['transitions'], m['transitions'])

    def test_actual_neural_snapshot_inference(self):
        model = json.loads((ROOT / 'models/3501-context-p0-NPN_adapted.json').read_text(encoding='utf8'))
        validate(model)
        self.assertEqual(predict(model, [[.4]*6], [0]).shape, (1, 5))

    def test_shared_initial_neural_heads_have_same_output(self):
        initial = json.loads((ROOT / 'models/initial-common.json').read_text(encoding='utf8'))
        validate(initial)
        self.assertEqual(initial['experiences'], [])
        for domain in range(4): np.testing.assert_array_equal(predict(initial, [[.8]*6], [domain]), [[0]*5])

    def test_internal_candidate_letters_next_to_japanese_are_flagged(self):
        self.assertEqual(internal_leakage('私はaに傾く。bの案もある。'), ['a', 'b'])
        self.assertEqual(internal_leakage('慣れた静かな弦の曲を聴きたい。'), [])

    def test_save_restart_restore_rollback(self):
        store = Store(Path(self.temp.name) / 'a'); store.commit(self.model)
        m = transition(self.model, [.7]*6, 0, 1); store.commit(m, 'reaction', 0)
        restarted = Store(Path(self.temp.name) / 'a'); self.assertEqual(restarted.load(), m)
        restored = Store(Path(self.temp.name) / 'b'); restored.restore(restarted.export()); self.assertEqual(restored.load(), m)
        self.assertEqual(restored.rollback(0, 1), 2); self.assertEqual(restored.load(), self.model)
        self.assertEqual(restored._read()['generations'][2]['parent'], 1)

    def test_restore_does_not_overwrite_existing(self):
        store = Store(Path(self.temp.name) / 'a'); store.commit(self.model)
        with self.assertRaises(ValueError): store.restore(store.export())

    def test_stale_update_rejected(self):
        store = Store(Path(self.temp.name) / 'a'); store.commit(self.model)
        with self.assertRaises(ValueError): store.commit(self.model, expected_head=None)

    def test_hash_corruption_rejected(self):
        store = Store(Path(self.temp.name) / 'a'); store.commit(self.model)
        file = store.directory / (digest(self.model) + '.json')
        value = json.loads(file.read_text()); value['payload']['shortState'][0] = .7
        file.write_text(json.dumps(value))
        with self.assertRaises(ValueError): store.load()

    def test_provenance_corruption_rejected(self):
        m = copy.deepcopy(self.model); m['experiences'][0]['text'] = 'changed'
        with self.assertRaises(ValueError): validate(m)

    def test_parameter_shape_corruption_rejected(self):
        m = copy.deepcopy(self.model); m['weights'] = [[0]*5]
        with self.assertRaises(ValueError): validate(m)

    def test_invalid_query_rejected(self):
        with self.assertRaises(ValueError): predict(self.model, [[2]*6], [0])

    def test_new_os_process_prediction(self):
        file = Path(self.temp.name) / 'state.json'; file.write_text(json.dumps(self.model), encoding='utf8')
        query = {'owner': 'nephia', 'x': [[.4]*6], 'domain': [0]}
        env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONUTF8': '1'}
        p = subprocess.run([sys.executable, str(ROOT / 'scripts/infer.py'), str(file)], input=json.dumps(query), capture_output=True, text=True, encoding='utf8', env=env, check=True)
        np.testing.assert_array_equal(json.loads(p.stdout)['prediction'], predict(self.model, query['x'], query['domain']))


if __name__ == '__main__':
    (ROOT / 'runtime').mkdir(exist_ok=True)
    unittest.main()
