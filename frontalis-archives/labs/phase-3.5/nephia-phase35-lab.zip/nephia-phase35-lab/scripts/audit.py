import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
def capture():
    folders = ('nephia-core-lab', 'nephia-npn-lab', 'nephia-phase3-lab')
    files = [p for f in folders for p in (ROOT.parent / f).rglob('*') if p.is_file() and '__pycache__' not in p.parts and 'node_modules' not in p.parts]
    files += [ROOT.parent / 'asist/src/shared/agent-cli.ts', ROOT.parent / 'asist/src/main/services/opencode-models.ts']
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
phase = sys.argv[1]
value = {'hashes': capture()}
if phase == 'after':
    before = json.loads((ROOT / 'reports/audit-before.json').read_text(encoding='utf8'))['hashes']
    value['changed'] = [p for p in set(before) | set(value['hashes']) if before.get(p) != value['hashes'].get(p)]
(ROOT / f'reports/audit-{phase}.json').write_text(json.dumps(value, indent=2), encoding='utf8')
print(json.dumps({'phase': phase, 'files': len(value['hashes']), 'changed': value.get('changed')}))
