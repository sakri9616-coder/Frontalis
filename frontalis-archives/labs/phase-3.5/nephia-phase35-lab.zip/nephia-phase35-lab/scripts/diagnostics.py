import json
import sys
import time
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from p35.model import predict, transition, digest, refit, arrays
from p35.store import Store

model = json.loads((ROOT / 'models/3501-context-p0-NPN_adapted.json').read_text(encoding='utf8'))
initial = json.loads((ROOT / 'models/initial-common.json').read_text(encoding='utf8'))
store = Store(ROOT / 'runtime/demo')
if store._read()['head'] is not None:
    raise ValueError('Demo output already exists; use a fresh directory instead of overwriting history.')
store.commit(initial, 'initial')
store.commit(model, 'learn', 0)
active = transition(model, [.8, -.3, -.6, .4, .8, .5], 0, 1)
store.commit(active, 'reaction', 1)
decayed = transition(active, elapsed=10); store.commit(decayed, 'elapse', 2)
bundle = store.export()
(ROOT / 'reports/portable-export.json').write_text(json.dumps(bundle, ensure_ascii=False, indent=2), encoding='utf8')
restored = Store(ROOT / 'runtime/restored'); restored.restore(bundle)
exact = restored.load() == decayed
restored.rollback(1, 3)
rollback_exact = restored.load() == model

timings = []
for i in range(1000):
    start = time.perf_counter(); predict(model, [[.4]*6], [0]); timings.append((time.perf_counter() - start)*1000)
all_rows = json.loads((ROOT / 'reports/offline.json').read_text(encoding='utf8'))['rows']
invalid_intensity = sum(np.sum(np.array(r['prediction'])[:, 4] < 0) for r in all_rows if r['method'] == 'NPN_adapted')
total_intensity = sum(len(r['prediction']) for r in all_rows if r['method'] == 'NPN_adapted')
points = model['experiences']
first = transition(transition(model, points[0]['x'], points[0]['domain']), points[4]['x'], points[4]['domain'])
second = transition(transition(model, points[4]['x'], points[4]['domain']), points[0]['x'], points[0]['domain'])
function_correlation = np.corrcoef(np.array(next(r['prediction'] for r in all_rows if r['seed']==3501 and r['condition']=='context' and r['person']==0 and r['method']=='NPN_adapted')).T).tolist()
report = {'restoreExact': exact, 'rollbackExact': rollback_exact, 'shortInitial': model['shortState'],
          'shortAfterEvent': active['shortState'], 'shortAfterElapsed': decayed['shortState'],
          'longWeightsUnchangedDuringRecovery': digest(model['weights']) == digest(decayed['weights']),
          'learnedDecay': model['decay'], 'shortOrderDifference': float(np.linalg.norm(np.array(first['shortState'])-second['shortState'])),
          'inferenceMsMedian': float(np.median(timings)), 'inferenceMsP95': float(np.percentile(timings,95)),
          'modelFileBytes': (ROOT / 'models/3501-context-p0-NPN_adapted.json').stat().st_size,
          'sharedParameters': model['shared']['parameters'], 'learnedHeadParameters': model['learnedParameters'], 'learnedRecoveryParameters': 2,
          'negativeIntensityPredictions': int(invalid_intensity), 'totalIntensityPredictions': total_intensity,
          'functionCorrelationOneSeries': function_correlation,
          'caveat': 'Reaction intensity decoder is not range constrained; negative extrapolations remain a known defect. Timing excludes CLI, loading, training, and disk.'}
(ROOT / 'reports/diagnostics.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
print(json.dumps(report))
