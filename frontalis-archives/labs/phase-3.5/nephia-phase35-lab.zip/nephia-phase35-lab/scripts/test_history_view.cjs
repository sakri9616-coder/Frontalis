// UI-only regression check: use the actual page's saved-score handlers.
const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const path = require('path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'reports/shortlist-review.html'), 'utf8');
const groups = JSON.parse(html.slice(html.indexOf('const groups=') + 13, html.indexOf(';const data=')));
assert.deepStrictEqual(groups, JSON.parse(fs.readFileSync(path.join(root, 'reports/shortlist-cards.json'), 'utf8')));
const prior = fs.readFileSync(path.join(root, '../nephia-phase3-lab/reports/shortlist-review.html'), 'utf8')
  .replaceAll('phase3-diagnostic20-20261014', 'phase35-diagnostic20-20261014')
  .replaceAll('nephia-human-review-20.json', 'nephia-phase35-human-review-20.json')
  .replaceAll(' / 20応答', ' / 20例');
assert.strictEqual(html.slice(html.indexOf('const ratings=')), prior.slice(prior.indexOf('const ratings=')));
const data = groups.flatMap(g => g.cards);
const names = ['経験との対応', '会話の自然さ', '内容に表れる個性', '理由の一貫性', '維持と変化の説明'];
const start = html.indexOf("document.querySelector('#save').onclick=");
const handlers = html.slice(start, html.indexOf('</script>', start)).replace(/;render\(\);\s*$/, ';');
const controls = { '#save': {}, '#load': {}, '#message': {} };
let blob, renderCount = 0, filename;
const context = {
  data, names, scores: {}, Blob, Date, JSON, Error, setTimeout: () => {},
  render: () => renderCount++,
  document: { querySelector: s => controls[s], createElement: () => ({ set download(v) { filename = v; }, click() {} }) },
  URL: { createObjectURL: b => { blob = b; return 'blob:test'; }, revokeObjectURL() {} }
};
vm.createContext(context);
vm.runInContext(handlers, context);
(async () => {
  const legacy = { formatVersion: 1, scores: { V009: { '経験との対応': '4', '会話の自然さ': '3', memo: 'UI test only' } } };
  const load = value => controls['#load'].onchange({ target: { files: [{ text: async () => JSON.stringify(value) }] } });
  await load(legacy);
  assert.strictEqual(controls['#message'].textContent, '採点を読み込みました。');
  assert.strictEqual(renderCount, 1);
  assert.deepStrictEqual(JSON.parse(JSON.stringify(context.scores)), legacy.scores);
  controls['#save'].onclick();
  const saved = JSON.parse(await blob.text());
  assert.strictEqual(saved.formatVersion, 1);
  assert.strictEqual(saved.selectionId, 'phase35-diagnostic20-20261014');
  assert.strictEqual(filename, 'nephia-phase35-human-review-20.json');
  assert.deepStrictEqual(saved.scores, legacy.scores);
  context.scores = {};
  await load(saved);
  assert.deepStrictEqual(JSON.parse(JSON.stringify(context.scores)), saved.scores);
  await load({ formatVersion: 2, scores: {} });
  assert(controls['#message'].textContent.startsWith('読み込めません：'));
  console.log('PASS: unchanged answers/comparisons/scoring; legacy import; scores and memo; save/reload roundtrip; invalid file rejection.');
})().catch(e => { console.error(e); process.exitCode = 1; });
