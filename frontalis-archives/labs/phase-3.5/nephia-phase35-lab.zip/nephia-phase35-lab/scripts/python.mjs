import { spawn } from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const config=JSON.parse(await fs.readFile(path.join(root,'runtime-paths.json'),'utf8'));
await fs.mkdir(path.join(root,'runtime'),{recursive:true});
const names={test:['-m','unittest','discover','-s','tests','-v'],evaluate:['experiments/evaluate.py'],
  exploratory:['experiments/exploratory.py'],prepare:['scripts/prepare_live.py'],controls:['scripts/controls.py'],
  domain:['scripts/domain_live.py'],reaction:['scripts/reaction_live.py'],summary:['scripts/summarize.py'],
  numeric:['scripts/numeric_summary.py']};
const args=names[process.argv[2]];if(!args)throw Error('Unknown experiment command.');
const child=spawn(config.trainingPython,args,{cwd:root,windowsHide:true,stdio:'inherit',env:{...process.env,PYTHONDONTWRITEBYTECODE:'1',PYTHONUTF8:'1'}});
child.on('error',e=>{console.error(e.message);process.exitCode=1;});child.on('exit',code=>process.exitCode=code??1);
