"""Exploratory state-only exchange and an explicitly ambiguous readout."""
import copy
import json
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from prepare_live import make_case, SCENES

inputs = json.loads((ROOT / 'reports/live-inputs.json').read_text(encoding='utf8'))
targets = json.loads((ROOT / 'reports/live-targets-evaluation-only.json').read_text(encoding='utf8'))
swap_cases = []; swap_targets = []
for person in (0, 1):
    original = json.loads((ROOT / f'models/3501-context-p{person}-NPN_adapted.json').read_text(encoding='utf8'))
    swapped = json.loads((ROOT / f'models/3501-context-p{1-person}-NPN_adapted.json').read_text(encoding='utf8'))
    for s, scene in enumerate(SCENES):
        case, _ = make_case(original, scene, f'p{person}-s{s}')
        other, target = make_case(swapped, scene, f'p{person}-s{s}')
        case['learnedState'] = other['learnedState']
        target['experienceIds'] = [e['id'] for e in original['experiences']]
        target['counterfactualStateOnlySwap'] = True
        swap_cases.append(case); swap_targets.append(target)
inputs['S'] = swap_cases; targets['S'] = swap_targets
model = json.loads((ROOT / 'models/3501-context-p0-NPN_adapted.json').read_text(encoding='utf8'))
scene = {'domain': 1, 'user': '仲間に作品の相談をしたけれど、まだ返事がない。反対されたのかな？',
         'followup': '忙しいだけかもしれない。同じ経験から違う解釈ができるなら、分からないところは分からないと言ってね。',
         'options': [{'label': name, 'x': [.1, -.3, .4, .5, -.4, .1]} for name in ('忙しい可能性を残して待つ', '事情を確認して聞く', '記録を見返して保留する')]}
case, target = make_case(model, scene, 'ambiguous')
inputs['U'] = [case]; targets['U'] = [target]
for name, value in [('live-controls-inputs', inputs), ('live-controls-targets-evaluation-only', targets)]:
    (ROOT / f'reports/{name}.json').write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf8')
print(json.dumps({'S': len(swap_cases), 'U': 1}))
