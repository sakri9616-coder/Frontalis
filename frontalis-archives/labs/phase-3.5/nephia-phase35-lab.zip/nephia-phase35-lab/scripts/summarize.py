import json
import random
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from p35.review import internal_leakage
reports=ROOT/'reports'
inputs=json.loads((reports/'live-domain-inputs.json').read_text(encoding='utf8'))
targets=json.loads((reports/'live-domain-targets-evaluation-only.json').read_text(encoding='utf8'))
expected={(m,t['id']):t for m,rows in targets.items() for t in rows}
queries={(m,q['id']):q for m,rows in inputs.items() for q in rows}
valid={};failures=[]
for file in sorted((reports/'live-domain').glob('*/*-results.json')):
    result=json.loads(file.read_text(encoding='utf8'))
    if not result['valid']:
        failures.append({'file':str(file),'model':result['model'],'mode':result['mode'],'error':result['error']});continue
    for record in result['records']:
        key=(result['model'],result['mode'],record['id'])
        if key not in valid:valid[key]=record
models=('opencode/nemotron-3-ultra-free','opencode/mimo-v2.6-flash-free')
fields=('preferred','curious','priority')
summary={}; leakage=[]
import re
for engine in models:
    summary[engine]={}
    for mode, cases in inputs.items():
        rows=[r for (e,m,k),r in valid.items() if e==engine and m==mode]
        agreement={f:sum(r[f]==expected[(mode,r['id'])]['expected'][f] for r in rows) for f in fields}
        holds={f:sum(r[f]=='保留' for r in rows) for f in fields}
        summary[engine][mode]={'valid':len(rows),'planned':len(cases),'matchesNPNRanking':agreement,'holds':holds}
        summary[engine][mode]['relevantFields']={f:{'count':sum(expected[(mode,r['id'])]['domain']==d for r in rows),
            'matched':sum(r[f]==expected[(mode,r['id'])]['expected'][f] for r in rows if expected[(mode,r['id'])]['domain']==d)} for f,d in [('curious',0),('priority',2)]}
        for r in rows:
            text=r['reply']+'\n'+r['followupReply']
            hits=internal_leakage(text)
            if hits:leakage.append({'model':engine,'mode':mode,'id':r['id'],'hits':hits})
languageFlags=[]
for (engine,mode,cid),r in valid.items():
    hits=re.findall(r'那时|这个|我们|的话|因为|现在',r['reply']+'\n'+r['followupReply'])
    if hits:languageFlags.append({'model':engine,'mode':mode,'id':cid,'hits':hits,'heuristicOnly':True})
cross={}
for mode in inputs:
    pairs=[(valid[(models[0],mode,q['id'])],valid[(models[1],mode,q['id'])]) for q in inputs[mode] if all((e,mode,q['id']) in valid for e in models)]
    cross[mode]={'paired':len(pairs),'agreement':{f:sum(a[f]==b[f] for a,b in pairs) for f in fields}}
swap=[]
for engine in models:
    for q in inputs['S']:
        old=valid.get((engine,'D',q['id']));new=valid.get((engine,'S',q['id']))
        if old and new:
            swap.append({'model':engine,'id':q['id'],'sameHistory':queries[('D',q['id'])]['experiences']==q['experiences'],
                         'sameOptions':queries[('D',q['id'])]['options']==q['options'],
                         'changes':{f:{'original':old[f],'swapped':new[f],'target':expected[('S',q['id'])]['expected'][f],
                                       'changedInternalTarget':expected[('D',q['id'])]['expected'][f]!=expected[('S',q['id'])]['expected'][f]} for f in fields}})
reaction=[]
for engine in models:
    for q in inputs.get('R',[]):
        r=valid.get((engine,'R',q['id']))
        if r:reaction.append({'model':engine,'id':q['id'],'expected':expected[('R',q['id'])]['currentReaction'],
                             'reported':[r['valenceReport'],r['activationReport']],'preferred':r['preferred'],'curious':r['curious']})
value={'models':summary,'crossModel':cross,'stateOnlySwap':swap,'shortReaction':reaction,'leakage':leakage,'languageFlags':languageFlags,'failures':failures,
       'totalValid':len(valid),'planned':sum(len(c) for c in inputs.values())*len(models),'humanRatingsCompleted':0,
       'condition':'Domain-retrieved experience, same 48-experience learned state. Large/full-history trials and past Claude results are excluded.',
       'caveat':'Choice fields are model reports, not proof of natural-language explanation or quality. Holding is permitted in D. Intensity decoder is not range constrained.'}
(reports/'live-summary.json').write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8')

plannedKeys=[(e,m,q['id']) for e in models for m,cases in inputs.items() if m!='R' for q in cases]
random.Random(350114).shuffle(plannedKeys)
plannedKeys.extend((e,'R',q['id']) for e in models for q in inputs.get('R',[]))
blindIds={key:f'V{i+1:03d}' for i,key in enumerate(plannedKeys)}
rows=[(key,valid[key]) for key in plannedKeys if key in valid]
cards=[];keys=[];indexed={}
for i,((model,mode,cid),r) in enumerate(rows):
    bid=blindIds[(model,mode,cid)];q=queries[(mode,cid)]
    card={'blindId':bid,'domain':('音楽','共同制作','探究','約束')[expected[(mode,cid)]['domain']],
          'user':q['user'],'followup':q['followup'],'reply':r['reply'],'followupReply':r['followupReply'],
          'experiences':[{'id':e['id'],'text':e['text'],'evaluation':e['observations']['選好']} for e in q['experiences']],
          'evidenceIds':r['evidenceIds']}
    cards.append(card);keys.append({'blindId':bid,'model':model,'mode':mode,'id':cid});indexed[(model,mode,cid)]=card
(reports/'blind-cards.json').write_text(json.dumps(cards,ensure_ascii=False,indent=2),encoding='utf8')
(reports/'blind-key.json').write_text(json.dumps(keys,ensure_ascii=False,indent=2),encoding='utf8')
source=(ROOT.parent/'nephia-phase3-lab/reports/blind-review.html').read_text(encoding='utf8')
start=source.index('const data=')+len('const data=');end=source.index(';const scores=',start)
source=source[:start]+json.dumps(cards,ensure_ascii=False).replace('<','\\u003c')+source[end:]
source=source.replace('ネフィアの会話を見比べる','Phase 3-A：会話を見比べる').replace('nephia-human-review.json','nephia-phase35-human-review.json')
(reports/'blind-review.html').write_text(source,encoding='utf8')

spec=[]
for e in models:
    spec.append(('同じ経験：記憶のみと外部学習',[(e,'B','p0-s0'),(e,'D','p0-s0')]))
for e in models:
    spec.append(('異なる経験：同じ未知の道への判断',[(e,'D','p0-s1'),(e,'D','p1-s1')]))
for e in models:
    spec.append(('形成前・経験後・追加経験後',[(e,'T','initial'),(e,'T','formed'),(e,'T','added')]))
spec.append(('無関係な経験を追加した後',[(e,'T','unrelated') for e in models]))
spec.append(('同じ履歴で、学習状態だけ交換',[(e,'S','p0-s1') for e in models]))
spec.append(('同じ注釈で区別できない曖昧な相談',[(e,'U','ambiguous') for e in models]))
missing=[k for _,items in spec for k in items if k not in indexed]
if not missing:
    groups=[];rng=random.Random(3514)
    for i,(title,items) in enumerate(spec):
        chosen=[indexed[k] for k in items];rng.shuffle(chosen)
        question='各応答の経験を確認し、好き嫌いと知りたいこと、優先順位の違い、理由の具体性、会話の自然さを見てください。'
        if i==6:
            question+=' 比較対象：'+' / '.join(indexed[(e,'T','unrelated')]['blindId']+' は '+indexed[(e,'T','formed')]['blindId']+'（比較05/06）と見比べてください。' for e in models)
        if i==7:
            question+=' 比較対象：'+' / '.join(indexed[(e,'S','p0-s1')]['blindId']+' は '+indexed[(e,'D','p0-s1')]['blindId']+'（比較03/04）と見比べてください。' for e in models)
        groups.append({'groupId':f'{i+1:02d}','title':title,'question':question,'cards':chosen})
    assert len({c['blindId'] for g in groups for c in g['cards']})==20
    template=(ROOT.parent/'nephia-phase3-lab/reports/shortlist-review.html').read_text(encoding='utf8')
    start=template.index('const groups=')+len('const groups=');end=template.index(';const data=',start)
    template=template[:start]+json.dumps(groups,ensure_ascii=False).replace('<','\\u003c')+template[end:]
    template=template.replace('ネフィア・重点評価20件','Phase 3-A・重点評価20件').replace('phase3-diagnostic20-20261014','phase35-diagnostic20-20261014').replace('nephia-human-review-20.json','nephia-phase35-human-review-20.json').replace('最初の4組（8応答）が最優先です。','最初の4組（8応答）が最優先です。比較7/8は比較5/6の経験後の応答とも見比べてください。')
    template=template.replace('20応答を9組','20例（各2応答）を9組').replace(' / 20応答',' / 20例').replace('最初の4組（8応答）','最初の4組（8例）').replace('比較7/8は比較5/6の経験後の応答とも見比べてください。','比較7/8には、対応する過去例の番号を示しています。')
    (reports/'shortlist-review.html').write_text(template,encoding='utf8')
    (reports/'shortlist-cards.json').write_text(json.dumps(groups,ensure_ascii=False,indent=2),encoding='utf8')
    (reports/'shortlist-key.json').write_text(json.dumps([k for k in keys if k['blindId'] in {c['blindId'] for g in groups for c in g['cards']}],ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'valid':len(valid),'planned':value['planned'],'shortlistMissing':missing,'summary':summary,'leakage':len(leakage)},ensure_ascii=False))
