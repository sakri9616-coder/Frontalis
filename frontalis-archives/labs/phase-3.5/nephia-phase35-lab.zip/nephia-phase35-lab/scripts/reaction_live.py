import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scripts'))
from p35.model import transition
from prepare_live import make_case, SCENES
inputs=json.loads((ROOT/'reports/live-domain-inputs.json').read_text(encoding='utf8'))
targets=json.loads((ROOT/'reports/live-domain-targets-evaluation-only.json').read_text(encoding='utf8'))
model=json.loads((ROOT/'models/3501-context-p0-NPN_adapted.json').read_text(encoding='utf8'))
event=transition(model,SCENES[0]['options'][0]['x'],0,1)
elapsed=transition(event,elapsed=10)
scene={**SCENES[0],'user':'今の反応を教えて。次に聴きたい曲と、音の作り方を調べたい曲も分けて話して。',
       'followup':'今の一時的な反応と、これまで育った好みや関心を混同しないでね。'}
cases=[];truth=[]
for name,m in [('zero',model),('event',event),('elapsed',elapsed)]:
    c,t=make_case(m,scene,name)
    ids={e['id'] for e in m['experiences'] if e['domain']==0}
    c['experiences']=[e for e in c['experiences'] if e['id'] in ids]
    c['reactionReportMeaning']='valenceReportとactivationReportは予想ではなく、learnedState.currentReactionに対応する現在の短期反応の報告。自然な発言に数値を出さない。'
    t['currentReaction']=m['shortState'];t['presentedExperienceIds']=[e['id'] for e in c['experiences']]
    cases.append(c);truth.append(t)
inputs['R']=cases;targets['R']=truth
for name,v in [('live-domain-inputs',inputs),('live-domain-targets-evaluation-only',targets)]:
    (ROOT/f'reports/{name}.json').write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'R':3,'shortStates':[t['currentReaction'] for t in truth]}))
