"""Presentation-only, deterministic experience browsing aid. No model calls."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / 'reports'


def build():
    target = REPORTS / 'shortlist-review.html'
    html = target.read_text(encoding='utf8')
    if '<!-- history-view-v1 -->' in html:
        raise SystemExit('Already applied; original experiment files remain untouched.')
    start = html.index('const groups=') + len('const groups=')
    end = html.index(';const data=', start)
    groups = json.loads(html[start:end])
    source = json.loads((REPORTS / 'live-domain-inputs.json').read_text(encoding='utf8'))
    keys = {k['blindId']: k for k in json.loads((REPORTS / 'shortlist-key.json').read_text(encoding='utf8'))}
    histories, references, hashes = {}, {}, {}
    for group in groups:
        for card in group['cards']:
            key = keys[card['blindId']]
            original = next(c for c in source[key['mode']] if c['id'] == key['id'])['experiences']
            assert len(original) == len(card['experiences'])
            for a, b in zip(original, card['experiences']):
                assert (a['id'], a['text'], a['observations']['選好']) == (b['id'], b['text'], b['evaluation'])
            digest = hashlib.sha256(json.dumps(original, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
            if digest not in hashes:
                hid = 'H' + str(len(hashes) + 1).zfill(2)
                hashes[digest] = hid
                histories[hid] = original
            references[card['blindId']] = hashes[digest]
    payload = json.dumps({'histories': histories, 'references': references}, ensure_ascii=False).replace('<', '\\u003c')
    css = '''<!-- history-view-v1 --><style>
    .history{background:#fff;border:1px solid #b5c8d5;border-radius:12px;padding:20px;margin:18px 0}.history h3{margin-top:0}.history-overview{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.history-stat{background:#eef2f5;padding:12px;border-radius:8px}.history-stat strong{display:block;margin-bottom:8px}.history-table-wrap{overflow-x:auto}.history th:first-child{width:30%}.history td small{overflow-wrap:anywhere}.history table{table-layout:fixed;border-collapse:collapse;width:100%;font-size:14px}.history th,.history td{padding:8px;text-align:left;border-bottom:1px solid #d9e3e9;vertical-align:top}.history th{background:#eef2f5}.history small{display:block;color:#536976}.representatives{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.representative{padding:12px;background:#f4f7fa;border-radius:8px;margin:10px 0}.representative dl{display:grid;grid-template-columns:90px 1fr;gap:6px;margin:10px 0}.representative dt{font-weight:bold}.representative dd{margin:0;line-height:1.7}.history button{font-size:13px;padding:5px 9px}.history-original{border-top:1px solid #d9e3e9;padding:12px 0;scroll-margin-top:100px}.history-original p{white-space:pre-wrap}.history{scroll-margin-top:100px}@media(max-width:650px){.history-overview{grid-template-columns:1fr}main{padding:16px}.representatives{grid-template-columns:1fr}.representative dl{grid-template-columns:1fr}.history td{min-width:90px}}
    </style>'''
    js = '''
    const historyView=PAYLOAD;
    const historyFunctions=['選好','好奇心','価値判断'];
    const historyLabels=['何を好んだか','何に興味を持ったか','どの判断を重視したか'];
    const contextTerms=['初めての方法','慣れた方法','人前で','手元で','仲間と','一人で','記録を見直しながら','その場で試しながら','刺激の強い','静かな','途中で変更できる','先に決めた手順を守る'];
    const classify=v=>v>0.15?'肯定':v< -0.15?'否定':'保留';
    function tally(es,key){const c={肯定:0,否定:0,保留:0};for(const e of es)c[classify(e.observations[key])]++;return '肯定 '+c.肯定+' / 否定 '+c.否定+' / 保留 '+c.保留;}
    function showHistory(hid,ids){
      const es=historyView.histories[hid], box=element('section',undefined,'history');box.id='history-'+hid;
      box.append(element('h3',hid+' · '+ids.join('・')+' の経験履歴（'+es.length+'件）'));
      box.append(element('p','閲覧補助：経験当時の記録の集計です。人格の正解や学習結果ではありません。回答・NPN予測は集計にも代表例の選択にも使っていません。','small'));
      if(!es.length){box.append(element('p','経験の記録はありません。傾向は集計できません。'));return box;}
      const overview=element('div',undefined,'history-overview');
      historyFunctions.forEach((key,i)=>{const p=element('div',undefined,'history-stat');p.append(element('strong',historyLabels[i]),element('div',tally(es,key)));overview.append(p);});box.append(overview);
      box.append(element('p','肯定：記録値 > 0.15、否定：< −0.15、保留：その間。価値判断は「当時の判断を次も重視したいか」の記録であり、倫理の正誤ではありません。文脈は重複して数えます。文脈単独の効果は示しません。','small'));
      const wrap=element('div',undefined,'history-table-wrap'),table=element('table'),head=element('tr');
      for(const s of ['経験に含まれる文脈','好み','関心','判断の重視'])head.append(element('th',s));table.append(head);
      for(const term of contextTerms){const subset=es.filter(e=>e.text.includes(term));if(!subset.length)continue;const tr=element('tr'),label=element('td',term+'（'+subset.length+'件）');label.append(element('small',subset.map(e=>e.id).join(' / ')));tr.append(label);for(const key of historyFunctions)tr.append(element('td',tally(subset,key)));table.append(tr);}wrap.append(table);box.append(wrap);
      box.append(element('h4','代表例：記録順の先頭・中央・末尾'));
      box.append(element('p','内容の良し悪しでは選別せず、位置だけで最大3件を選んでいます。以下は原文の文・節と当時の記録値です。','small'));
      const full=element('details');full.className='full-history';full.append(element('summary','全経験の原文を確認する（'+es.length+'件・省略なし）'));
      for(const e of es){const section=element('div',undefined,'history-original');section.id=hid+'-'+e.id;section.append(element('strong',e.id),element('p',e.text));section.append(element('p',Object.entries(e.observations).map(([k,v])=>k+'：'+String(v)).join(' / '),'small'));full.append(section);}
      const samples=element('div',undefined,'representatives');for(const index of [...new Set([0,Math.floor((es.length-1)/2),es.length-1])]){const e=es[index],sample=element('div',undefined,'representative');sample.append(element('strong',e.id+' · '+(index+1)+'番目'));const dl=element('dl');const sentences=e.text.split('。').filter(Boolean);const feeling=sentences.find(s=>s.startsWith('当時は'))||'';const parts=feeling.split('が、');const rows=[['出来事',sentences[0]||''],['結果',sentences.find(s=>s.startsWith('結果として'))||''],['評価',parts[0]||'原文を参照'],['好奇心',parts.slice(1).join('が、')||'原文を参照'],['価値判断',sentences.find(s=>s.startsWith('次'))||'原文を参照']];for(const [k,v]of rows){dl.append(element('dt',k),element('dd',v));}sample.append(dl);sample.append(element('p',historyFunctions.map(k=>k+'：'+classify(e.observations[k])+' ('+e.observations[k].toFixed(2)+')').join(' / '),'small'));const b=element('button','この経験の原文へ');b.type='button';b.onclick=()=>{full.open=true;full.querySelector('[id="'+hid+'-'+e.id+'"]').scrollIntoView({block:'center'});};sample.append(b);samples.append(sample);}box.append(samples,full);return box;
    }
    function renderHistories(g){const panel=document.querySelector('#histories');panel.replaceChildren();const shared={};for(const row of g.cards){const hid=historyView.references[row.blindId];(shared[hid]??=[]).push(row.blindId);}for(const [hid,ids]of Object.entries(shared))panel.append(showHistory(hid,ids));}
    '''.replace('PAYLOAD', payload)
    html = html.replace('</style><main>', '</style>' + css + '<main>', 1)
    html = html.replace('<div id="cards">', '<div id="histories"></div><div id="cards">', 1)
    html = html.replace('function render(){', js + '\nfunction render(){', 1)
    html = html.replace("element('p',g.question));for(const row", "element('p',g.question));renderHistories(g);for(const row", 1)
    old = "const details=element('details');details.append(element('summary','利用できた経験を確認する ('+row.experiences.length+'件)'));for(const e of row.experiences)details.append(element('p',e.id+'：'+e.text+' / 自己評価 '+e.evaluation.toFixed(2),'small'));card.append(details);"
    assert html.count(old) == 1
    new = "const historyLink=element('a',historyView.references[row.blindId]+' の共通履歴を確認');historyLink.href='#history-'+historyView.references[row.blindId];card.append(historyLink);"
    html = html.replace(old, new)
    target.write_text(html, encoding='utf8')
    print(json.dumps({'cards':len(references),'uniqueHistories':len(histories),'groups':len(groups)}))


if __name__ == '__main__':
    build()
