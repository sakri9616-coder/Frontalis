import json
import sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from p35.model import predict, representation

r=json.loads((ROOT/'reports/offline.json').read_text(encoding='utf8'))
explore=json.loads((ROOT/'reports/exploratory.json').read_text(encoding='utf8'))
methods=('P3_legacy','P2_frozen_multi','linear_multi','memory','NPN_adapted','NPN_coupled')
interventions={}
for method in methods:
    interventions[method]={}
    for kind in ('remove_music','flip_preference_only','swap_music','reverse_order','add_exploration','add_music'):
        items=[a for a in r['interventions'] if a['method']==method and a['intervention']==kind]
        v={'meanAbsoluteChange':float(np.mean([a['meanAbsoluteChange'] for a in items])),
           'unrelatedDomainsMeanChange':float(np.mean([a['domainFunctionChange'][str(d)] for a in items for d in ((0,1,3) if kind=='add_exploration' else (1,2,3))])),
           'otherFunctionChangeOnPreferenceFlip':float(np.mean([np.abs(np.array(a['predictionDelta'])[:,1:]) for a in items])) if kind=='flip_preference_only' else None}
        if kind=='add_exploration':
            v.update({k:float(np.mean([a[k] for a in items])) for k in ('changedTargetBeforeMSE','changedTargetAfterMSE','retainedMeanChange','correctDeltaDirection')})
        interventions[method][kind]=v
matched=[]
for seed in (3501,3502,3503):
    shared=json.loads((ROOT/f'models/exploratory-shared8-{seed}.json').read_text(encoding='utf8'))
    folder=ROOT/f'data/{seed}-context/series-0'
    train=json.loads((folder/'train.json').read_text(encoding='utf8'));test=json.loads((folder/'evaluation-only.json').read_text(encoding='utf8'))
    hx=np.array([e['x'] for e in train]);hd=np.array([e['domain'] for e in train]);x=np.array([e['x'] for e in test]);d=np.array([e['domain'] for e in test])
    h=representation('adapted',shared,hx,hd,None);q=representation('adapted',shared,x,d,None)
    decoder=np.linalg.solve(h.T@h+.03*np.eye(h.shape[1]),h.T@hx)
    matched.append(float(np.mean((q@decoder-x)**2)))
opposite_examples=[]
for person in range(4):
    model=json.loads((ROOT/f'models/3501-context-p{person}-NPN_adapted.json').read_text(encoding='utf8'))
    test=json.loads((ROOT/f'data/3501-context/series-{person}/evaluation-only.json').read_text(encoding='utf8'))
    p=predict(model,[e['x'] for e in test],[e['domain'] for e in test])
    for e,y in zip(test,p):
        if e['y'][0]<-.15 and e['y'][1]>.15 and y[0]<0 and y[1]>0:
            opposite_examples.append({'person':person,'id':e['id'],'text':e['text'],'truth':e['y'],'prediction':y.tolist()});break
summary={'methods':r['summary'],'exploratory':explore['summary'],'interventions':interventions,
         'inputRecoveryMSE':{'old8':float(np.mean([x['unseenInputReconstructionMSE'] for x in r['informationRetention'] if x['method']=='P2_frozen_multi'])),
                             'adapted16':float(np.mean([x['unseenInputReconstructionMSE'] for x in r['informationRetention'] if x['method']=='NPN_adapted'])),
                             'adapted8Exploratory':float(np.mean(matched))},
         'oppositeExamples':opposite_examples,'interPersonaMeanDistance':r['interPersonaMeanDistance']}
(ROOT/'reports/numeric-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'inputRecoveryMSE':summary['inputRecoveryMSE'],'npnInterventions':interventions['NPN_adapted']}))
