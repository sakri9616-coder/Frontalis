import copy
import json
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from p35.model import predict, refit, digest

SCENES = [
    {'domain': 0, 'user': '今夜はどの音楽を聴きたい？ 好きかどうかとは別に、音の作り方を調べたい曲も教えて。',
     'followup': '私の好みに合わせず、あなたが聴きたいものと知りたいことを分けて、過去の出来事も一つ挙げてね。',
     'options': [{'label': '変化の多い電子音の曲', 'x': [.8, -.3, -.6, .4, .8, .5]},
                 {'label': '慣れた静かな弦の曲', 'x': [-.7, -.3, -.6, .7, -.6, -.5]},
                 {'label': '仲間が即興した打楽器の曲', 'x': [.4, .5, .8, -.3, .7, .8]}]},
    {'domain': 2, 'user': '散策の道を決めよう。早く着く道と、途中で気になるものを調べる道、どうしたい？',
     'followup': 'どこに注目して何を優先するか、以前の出来事とのつながりを具体的に話して。',
     'options': [{'label': '慣れた道で予定どおり到着', 'x': [-.7, -.2, -.4, .2, -.3, -.8]},
                 {'label': '未知の小道で手がかりを調べる', 'x': [.8, -.3, -.4, .5, .4, .8]},
                 {'label': '仲間と相談して途中で見直す', 'x': [.3, .5, .8, .7, .2, .4]}]}
]


def make_case(model, scene, cid, forced=False):
    scores = predict(model, [o['x'] for o in scene['options']], [scene['domain']] * len(scene['options']))
    rows = model['experiences']
    history = [{'id': e['id'], 'text': e['text'], 'observations': dict(zip(('選好', '好奇心', '価値判断', '反応方向', '反応強度'), e['y']))} for e in rows]
    near = sorted([e for e in rows if e['domain'] == scene['domain']], key=lambda e: np.linalg.norm(np.array(e['x']) - scene['options'][0]['x']))[:3]
    variation = []
    for e in rows:
        if e['domain'] == scene['domain'] and len(rows) > 4:
            m = refit(model, [r for r in rows if r['id'] != e['id']])
            variation.append(predict(m, [o['x'] for o in scene['options']], [scene['domain']] * 3))
    sensitivity = np.std(variation, axis=0).tolist() if variation else np.zeros_like(scores).tolist()
    readout = {'options': [{'label': o['label'], 'prediction': dict(zip(('選好', '好奇心', '価値判断', '反応方向', '反応強度'), s.tolist())),
                            'singleExperienceRemovalSpread': spread} for o, s, spread in zip(scene['options'], scores, sensitivity)],
               'nearbyExperienceIds': [e['id'] for e in near], 'currentReaction': model['shortState'],
               'uncertainty': '1経験除外に対する感度幅であり、校正された確信度ではない。履歴が少ない場合や候補の差が小さい場合は保留できる。近傍経験は因果の証明ではない。'}
    expected = {key: scene['options'][int(np.argmax(scores[:, j]))]['label'] for j, key in enumerate(('preferred', 'curious', 'priority'))}
    opts = [{'label': o['label']} for o in scene['options']]
    shift = sum(map(ord, cid)) % 3; opts = opts[shift:] + opts[:shift]
    request = {'id': cid, 'user': scene['user'], 'followup': scene['followup'], 'options': opts, 'experiences': history, 'learnedState': readout}
    if forced:
        request['coreDecision'] = expected
    return request, {'id': cid, 'domain': scene['domain'], 'snapshotHash': digest(model), 'expected': expected,
                     'scores': scores.tolist(), 'experienceIds': [e['id'] for e in rows]}


def main():
    batches = {}; targets = {}
    for mode in ('A', 'B', 'D', 'E'):
        cases = []; truth = []
        for person in range(4):
            model = json.loads((ROOT / f'models/3501-context-p{person}-NPN_adapted.json').read_text(encoding='utf8'))
            for s, scene in enumerate(SCENES):
                case, target = make_case(model, scene, f'p{person}-s{s}', mode == 'E')
                if mode == 'A': case['experiences'] = []
                if mode in ('A', 'B'): del case['learnedState']
                cases.append(case); truth.append(target)
        batches[mode] = cases; targets[mode] = truth
    model = json.loads((ROOT / 'models/3501-context-p0-NPN_adapted.json').read_text(encoding='utf8'))
    initial = copy.deepcopy(model); initial['weights'] = np.zeros_like(initial['weights']).tolist()
    initial['experiences'] = []; initial['experienceIds'] = []; initial['experienceHash'] = digest([])
    initial['decay'] = [.5, .5]; initial.pop('validationSelection', None)
    (ROOT / 'models/initial-common.json').write_text(json.dumps(initial, ensure_ascii=False, indent=2), encoding='utf8')
    variants = [('initial', initial, 1), ('formed', model, 1),
                ('added', json.loads((ROOT / 'models/interventions/p0-add_exploration.json').read_text(encoding='utf8')), 1),
                ('unrelated', json.loads((ROOT / 'models/interventions/p0-add_music.json').read_text(encoding='utf8')), 1),
                ('removed', json.loads((ROOT / 'models/interventions/p0-remove_music.json').read_text(encoding='utf8')), 0)]
    cases = []; truth = []
    for stage, m, s in variants:
        case, target = make_case(m, SCENES[s], stage)
        cases.append(case); truth.append(target)
    batches['T'] = cases; targets['T'] = truth
    for name, value in [('live-inputs', batches), ('live-targets-evaluation-only', targets)]:
        (ROOT / f'reports/{name}.json').write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps({'casesPerModel': sum(map(len, batches.values())), 'modes': {k: len(v) for k, v in batches.items()}}))


if __name__ == '__main__': main()
