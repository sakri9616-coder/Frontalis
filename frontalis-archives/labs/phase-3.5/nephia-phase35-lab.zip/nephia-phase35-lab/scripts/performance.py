import ctypes
import json
import sys
import time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from p35.model import predict
model=json.loads((ROOT/'models/3501-context-p0-NPN_adapted.json').read_text(encoding='utf8'))
timings=[]
for _ in range(1000):
    t=time.perf_counter();predict(model,[[.4]*6],[0]);timings.append((time.perf_counter()-t)*1000)
class Counters(ctypes.Structure):
    _fields_=[('cb',ctypes.c_ulong),('PageFaultCount',ctypes.c_ulong)]+[(n,ctypes.c_size_t) for n in (
        'PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage',
        'QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage','PrivateUsage')]
c=Counters();c.cb=ctypes.sizeof(c)
kernel=ctypes.windll.kernel32;kernel.GetCurrentProcess.restype=ctypes.c_void_p
psapi=ctypes.windll.psapi;psapi.GetProcessMemoryInfo.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_ulong]
if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(),ctypes.byref(c),c.cb):raise OSError('Own process memory measurement failed.')
r={'python':sys.executable,'numpy':np.__version__,'workingSetMiB':c.WorkingSetSize/1048576,'privateCommitMiB':c.PrivateUsage/1048576,
   'predictionMedianMs':float(np.median(timings)),'predictionP95Ms':float(np.percentile(timings,95)),
   'scope':'One loaded NumPy inference process. Excludes PyTorch training, OpenCode, ASIST, and other applications.'}
(ROOT/'reports/inference-performance.json').write_text(json.dumps(r,indent=2),encoding='utf8');print(json.dumps(r))
