import copy
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
inputs = json.loads((ROOT / 'reports/live-controls-inputs.json').read_text(encoding='utf8'))
targets = json.loads((ROOT / 'reports/live-controls-targets-evaluation-only.json').read_text(encoding='utf8'))
domains = {}
for file in (ROOT / 'models').rglob('*.json'):
    model = json.loads(file.read_text(encoding='utf8'))
    for e in model.get('experiences', []):
        if e['id'] in domains and domains[e['id']] != e['domain']:
            raise ValueError('Source domain mapping conflict.')
        domains[e['id']] = e['domain']
for mode, cases in inputs.items():
    by_id = {t['id']: t for t in targets[mode]}
    for c in cases:
        d = by_id[c['id']]['domain']; before = len(c['experiences'])
        c['experiences'] = [e for e in c['experiences'] if domains[e['id']] == d]
        by_id[c['id']]['presentedExperienceIds'] = [e['id'] for e in c['experiences']]
        by_id[c['id']]['fullExperienceCount'] = before
        related = c.get('learnedState', {}).get('nearbyExperienceIds', [])
        assert all(i in by_id[c['id']]['presentedExperienceIds'] for i in related)
for name, value in [('live-domain-inputs', inputs), ('live-domain-targets-evaluation-only', targets)]:
    (ROOT / f'reports/{name}.json').write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf8')
print('Domain retrieval is identical for B/D/E; training and learned states are unchanged.')
