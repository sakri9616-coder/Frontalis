# Claude Code引き継ぎ — Project frontalis Phase 3-C

## 読む順と結論

まず `REPORT.md`、`docs/03-design.md`、`docs/04-numeric.md`、`docs/05-conversations.md`、`docs/13-plasticity-results.md` を読む。自己評価→更新→次評価の循環は合成8軸の範囲で成立した。NNの一般的優位、自然文経験の受理、感情・意欲の忠実な表出、長期可塑性は未確立。本体へ統合せず、次の独立研究へ引き継ぐ。

現ラボ: `C:\Users\sakur\AppData\Local\asist-shisa\frontalis-phase3c-lab`。旧Phase、ASIST、実記憶、OpenCode設定は編集しない。Claude CLI、有料API、GPU学習、Push・公開、Phase4を呼び出さない。単なる賞賛・未確認のLLM評価を本人の教師にしない。嫌悪や頑固さを穏健な正解へ戻す改造を目的にしない。

## 実装の入口

|ファイル|責務|
|---|---|
|`npn/model.py`|8事実軸→7主観評価。旧observed評価から自己教師、cue連合と自己増幅、4方式。|
|`npn/store.py`|wrapper hash検証、状態shape・自己教師・台帳検証、世代commit、rollback。|
|`npn/logit_variant.py`|主結果後の独立損失空間探索。主状態と混ぜない。|
|`npn/data.py`|合成の客観的出来事・結末。感情gold／人格目標なし。|
|`tools/evaluate.py`|独立評価APIとstdio MCPサーバ。読み取り専用、実行・学習権限なし。|
|`tools/dispatch.py`|実際の会話で使用。LLMのJSON要求をホストが評価する。|
|`scripts/opencode.mjs`|既存CLIの通常plan呼出し。既存認証、standalone、新sandbox、APIキー等の環境変数を除外。|
|`experiments/live.mjs`|注釈付き／自然文構造化、ローカル評価、言語化。成功cacheは再生成しない。|
|`scripts/build_review.py`・`review.mjs`|固定20ペア、原文照合、匿名表示、保存・復元。|

主NNは各枝8→16→7、2枝で526学習値＋56固定base値。初期readoutは全方式・同一seedの全系列で同じ。対人と音響を別branchにする。意欲・反抗はaffinityの固定decodeであり、独立に学んだheadではない。

結果予測は各0.5の固定guardで、正確な予測器ではない。主観評価へ予測の学習を混ぜずに循環を検証した。LLMへ渡す人格プロフィールは生成せず、数値・候補判断を返す。会話中のLLM出力からNPNを更新しない。

## 追加LLMなしの点検

```powershell
Set-Location 'C:\Users\sakur\AppData\Local\asist-shisa\frontalis-phase3c-lab'
$frontalisPython = 'C:\Users\sakur\AppData\Local\hermes\jef\venv\Scripts\python.exe'
$env:PYTHONUTF8 = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
& $frontalisPython scripts\verify_all.py
& $frontalisPython scripts\analyze_live.py
& $frontalisPython scripts\build_review.py
& 'D:\node.exe' scripts\review.mjs
```

期待: 新ラボ83 Python／25 UI／12 builder、旧自己評価版31試験合格。旧研究2531ファイルの変更・欠落0。探索4方式のcontrolは主数値の1000回／12追加のreadoutと完全一致。主104、自然文補助16、初期感度40、履歴訂正16の176発言。人間採点は0件。`reports/verification.json`、`browser-checks.json`、`live-analysis.json` が証拠。

キャッシュのLLM呼出し禁止を明示して全pipelineを点検する場合:

```powershell
$env:FRONTALIS_VERIFY_ONLY = '1'
& 'D:\node.exe' experiments\live.mjs 'opencode/nemotron-3-ultra-free'
& 'D:\node.exe' experiments\live.mjs 'opencode/mimo-v2.6-flash-free'
& 'D:\node.exe' experiments\seed_sensitivity.mjs 'opencode/nemotron-3-ultra-free'
& 'D:\node.exe' experiments\seed_sensitivity.mjs 'opencode/mimo-v2.6-flash-free'
& 'D:\node.exe' experiments\history_correction.mjs 'opencode/nemotron-3-ultra-free'
& 'D:\node.exe' experiments\history_correction.mjs 'opencode/mimo-v2.6-flash-free'
Remove-Item Env:FRONTALIS_VERIFY_ONLY
```

不足cacheなら停止する。状態を読み直すローカル評価は行うが、外部モデルを呼ばない。

上記のcache専用pipelineは両モデルで実行し、全て終了0を確認した。`reports/offline-cache-verification.json` に記録した。研究の固定原本は `scripts/freeze_artifacts.py verify` でSHA照合できる。再検証の実行時刻を含む一部の検証ログは固定原本から除外している。

## ローカル評価を1件試す

```powershell
'{"calls":[{"name":"frontalis_evaluate","arguments":{"query_id":"demo","space":"relational","features":[0.4,0.7,0.6,0.3,0.5,0.4,0.6,0.8],"basis":"affinity"}}]}' | & $frontalisPython tools\dispatch.py models\nonlinear\seed-4311\nn-p0.json
& $frontalisPython examples\learn_once.py
```

前者は読み取りだけ。後者は新しいUUID付きruntimeへ1経験の自己更新、保存・復元、rollbackを実行する。現modelを上書きしない。storeの世代番号と、状態内の経験数generationは別で、rollbackも新しいstore世代を追加する。

MCPのtool名は`evaluate`、ホストJSON要求のtool名は`frontalis_evaluate`。MCPはstdio試験で境界を検証済みだが、無料CLIへのネイティブ追加は403で二度失敗した。quota・認証の原因とは断定しない。既存設定を直す作業やヘッダー偽装を始めない。今回成功したのは、標準CLIが要求JSONを作り、ホストがこの独立ツールを実行し、標準CLIへ返却する方式。

## 数値実験を最初から再現する

現reports/models/dataを上書きしない。別の空ラボへsourceだけをコピーする。

```powershell
& $frontalisPython scripts\reproduction_copy.py --destination 'C:\Users\sakur\AppData\Local\asist-shisa\frontalis-phase3c-repro-20261015'
Set-Location 'C:\Users\sakur\AppData\Local\asist-shisa\frontalis-phase3c-repro-20261015'
& $frontalisPython scripts\preserve.py snapshot
& $frontalisPython experiments\numeric.py
& $frontalisPython scripts\prepare_live.py
& $frontalisPython scripts\materialize_sensitivity.py
& $frontalisPython scripts\build_review.py --freeze-only
& $frontalisPython experiments\plasticity_exploration.py
```

destinationが存在したら停止する。numericは216条件、物理環境3×初期3×系列4×方式6。NN off/gain1対照、経験介入、共通教師容量診断、1000自己強化を含む。会話前に20ペア選択を固定する。可塑性探索は主結果後の追加条件で、主学習を置き換えない。

主numericはseed4311だけsnapshotを保存する。初期感度用の4312/4313はmaterializeで同じコード・経験を再生し、主数値にある8検査場面のreadoutとparameter normの完全一致を確認して保存する。途中で未保存stateを想定した呼出しはファイル不足で停止したが、成功回答は取り直していない。

自然言語を再取得する場合は、別コピー内で `live.mjs`→`seed_sensitivity.mjs`→`history_correction.mjs` を各無料モデルIDで実行し、最後にanalyze→build_review→review.mjsを行う。これは外部呼出しを伴う。モデル更新や生成の確率性により文章の完全一致は保証しない。同じモデル名でも将来同じ実装とは限らない。現在成果は保存した原出力で評価する。

## 解釈してはいけないもの

1. JSON stance16/16一致を本文・感情の成功にしない。Nemotronの制約制作はapprove欄と明確な拒絶本文が矛盾する。
2. 候補のないselection=holdを倫理一致の分母へ入れない。倫理候補とscene affinityは別。
3. 主Hには初期authority拘束が残る。主Hを上書きせず、H2/H3の事後訂正と分ける。H3は当時の自己評価まで渡す強い履歴対照で、NNの一般的優位を断言しない。
4. 初期→形成・状態交換の倫理選択が本文へ反映されても、「自分の手」「責任」というLLMの理由が学習されたとは言わない。候補はchange/lossの差で、責任・同意の軸はない。
5. 自然文0.5補完を正確な意味抽出にしない。主会話は注釈統制、自然文補助では16件中3stance・2候補判断が変わった。
6. parameter-swapは因果診断用。自分の履歴と別系列のbranchを持つ矛盾stateを通常の保存世代として採用しない。
7. 強い偏愛や嫌悪を数値発散と混同しない。一方、12追加でほぼ学習しない可塑性問題を「頑固な個性だから成功」と片付けない。
8. matchedTargetは凍結した主観関数の近似で、客観予測や人格の正しさではない。教師originの全結果を報告する。

## 次の改良と、条件を満たした後の統合手順

最優先は、事実観測の確認・欠損と解釈候補の扱い、同じ意味の言い換えへの構造化再現性、領域内の関連／無関係な判断への波及、飽和後の可塑性を複数seedで調べること。logit損失と±6capを別々に比較し、どちらが効いたかを分ける。NNのheadを増やすだけの改良を成功としない。

次に、本文が方向を置き換える欠陥を、NPN信号・伝達・言語化のどこで起こしたか点検する。文章を自動採点して理想の感情へNPNを矯正しない。正式な人間20ペアの結果を別ファイルとして収集する。

本人への統合を将来承認されたら、段階は次の順にする。

1. 原本me.md/user.mdを保全し、合成ラボのrandom人格を本人へ採用しない。過去経験の候補抽出と確認済み観測の区分を作る。
2. 本体へ返答を変えないshadow評価を接続し、構造化候補とNPN判断を記録する。LLM解釈・本人評価・ユーザー評価を分ける。
3. 本体から渡すsnapshotをホストが固定して、独立evaluateへ問い合わせる。モデルごとのCLIセッションと学習世代を分離する。
4. 言語表出だけを限定試行し、NPNと本文の改変を記録する。反抗の表現と実行権限は別にする。
5. 単一writerのStoreから、実際の並行処理に耐える排他・原子的世代更新へ改修してからオンライン更新を試す。expected_headはプロセスlockではない。

これらは今回未実装の統合計画であり、本体を変える指示ではない。SHAは偶発的破損の検出で、観測の真実性・認証・悪意ある再hashを防ぐものではない。状態は保存・復元・rollbackできるが、本体運用の安全性まで検証済みとは報告しない。
