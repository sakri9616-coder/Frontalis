"""Freeze or verify this lab's deliverables; ignores all runtime test caches."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
manifest=ROOT/'reports/artifact-sha256.json'
MUTABLE={'verification.json','preservation.json','all-python-tests.txt','all-ui-tests.txt',
 'all-builder-tests.txt','prior-regression-tests.txt','review-ui-tests.json','review-builder-tests.json',
 'review-build-validation.json','core-tests.json','tool-tests.json','logit-tests.json'}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
if sys.argv[1:]==['verify']:
    rows=json.loads(manifest.read_text(encoding='utf8'))
    missing=[r['path'] for r in rows if not (ROOT/r['path']).is_file()]
    changed=[r['path'] for r in rows if (ROOT/r['path']).is_file() and sha(ROOT/r['path'])!=r['sha256']]
    print(json.dumps({'checkedFiles':len(rows),'changed':changed,'missing':missing}))
    assert not changed and not missing
else:
    files=[]
    for folder in ['npn','tools','scripts','experiments','tests','docs','examples','data','models','exploration','reports']:
        files.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p!=manifest
            and not (p.parent==ROOT/'reports' and p.name in MUTABLE))
    files.extend(ROOT/name for name in ['README.md','REPORT.md','CLAUDE_HANDOFF.md'])
    rows=[{'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p)} for p in sorted(set(files))]
    with manifest.open('x',encoding='utf8') as f:json.dump(rows,f,ensure_ascii=False,indent=2)
    print(json.dumps({'frozenFiles':len(rows),'scope':'This independent lab; runtime/sandbox excluded.'}))
