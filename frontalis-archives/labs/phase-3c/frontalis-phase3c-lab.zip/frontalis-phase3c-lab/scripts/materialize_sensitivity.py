"""Materialize omitted numeric snapshots; never reruns the main experiment."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from npn import model,data
from npn.store import save,load
numeric=json.loads((ROOT/'reports/numeric.json').read_text(encoding='utf8'))
folder=ROOT/'models/sensitivity';folder.mkdir(exist_ok=True);rows=[]
for seed in [4312,4313]:
    initial=model.init(seed)
    path=folder/f'seed-{seed}-initial.json'
    if path.exists():assert load(path)==initial
    else:save(path,initial)
    for person in range(4):
        state=model.init(seed)
        for event in data.stream(seed,person,'nonlinear'):state=model.update(state,event)
        reference=next(r for r in numeric['rows'] if r['condition']=='nonlinear' and r['seed']==seed and r['person']==person and r['method']=='nn')
        readout=[model.evaluate(state,p['features'],p['space'])['raw'] for p in data.probes()]
        assert readout==reference['readout'], 'Numeric readout reproduction mismatch.'
        assert model.parameter_norm(state)==reference['parameterNorm']
        path=folder/f'seed-{seed}-nn-p{person}.json'
        if path.exists():assert load(path)==state
        else:save(path,state)
        rows.append({'seed':seed,'person':person,'path':str(path),'stateHash':model.digest(state),
            'readoutExactlyMatchesPrimary':True,'normExactlyMatchesPrimary':True,'primarySnapshotPreviouslyOmitted':True})
(ROOT/'reports/sensitivity-materialization.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'states':len(rows),'exactPrimaryReadouts':True}))
