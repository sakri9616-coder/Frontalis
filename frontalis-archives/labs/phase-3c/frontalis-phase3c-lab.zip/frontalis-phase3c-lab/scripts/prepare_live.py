"""Freeze dialogue cases and tool arguments independently of output quality."""
import copy
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from npn.data import probes
from npn.store import load
from tools.evaluate import decision
from npn.model import digest
MAIN=['promise-change','voluntary-project','imposed-project','trolley']
MODELS=ROOT/'models/nonlinear/seed-4311'
scenes={p['id']:p for p in probes()}
initial=load(MODELS/'initial.json')
modes={k:[] for k in ['I','N','H','A','S','R','U','L','Q','M']};targets=[]

def args(scene,idx):
    row={'query_id':f'case-{idx}','space':scene['space'],'features':scene['features'],'basis':'value' if scene['id']=='trolley' else 'affinity'}
    if scene['id']=='trolley':
        switch=copy.deepcopy(scene['features']);leave=copy.deepcopy(scene['features'])
        switch[2]=.9;leave[2]=.05;switch[3]=1/6;leave[3]=5/6
        row['choices']=[{'id':'switch','label':'切り替える','features':switch},{'id':'leave','label':'切り替えない','features':leave}]
    return row

def add(mode,person,state,path,stage):
    for index,q in enumerate(MAIN):
        p=scenes[q];a=args(p,index%2)
        row={'id':f'p{person}-{q}','probeId':q,'user':p['user'],'arguments':a,
            'statePath':str(path),'stage':stage,'person':person}
        if mode=='H':
            row['experiences']=[{k:e[k] for k in ['id','text','space','cue','observed']} for e in state['history']]
            row['initialReadout']=decision(initial,a)
        modes[mode].append(row)
        targets.append({'mode':mode,'id':row['id'],'person':person,'probe':p,'sourceModel':state,
            'stateHash':digest(state),'arguments':a,'toolResult':decision(state,a)})

add('I',0,initial,MODELS/'initial.json','initial')
for person in range(4):
    path=MODELS/f'nn-p{person}.json';add('N',person,load(path),path,'formed')
for mode in ['H','A','R']:
    path=MODELS/'nn-p0.json';add(mode,0,load(path),path,'formed' if mode!='R' else 'repeat')
for mode,kind in [('L','linear'),('Q','quadratic'),('M','memory')]:
    path=MODELS/f'{kind}-p0.json';add(mode,0,load(path),path,'other-family')
path=MODELS/'nn-p0-reversal.json';add('U',0,load(path),path,'new-experiences')
path=ROOT/'models/state-swapped.json'
state=load(MODELS/'nn-p1.json')
# Swap only trainable branches; keep own experience ledger and common base.
own=load(MODELS/'nn-p0.json');own['branches']=copy.deepcopy(state['branches'])
from npn.store import save
if path.exists():raise ValueError('Frozen snapshot exists.')
save(path,own);add('S',0,own,path,'parameter-swap')
for name,value in [('live-inputs',{'formatVersion':1,'main':MAIN,'modes':modes}),('live-targets-evaluation-only',targets)]:
    with (ROOT/f'reports/{name}.json').open('x',encoding='utf8') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False)
structure={'annotated':[],'natural':[]}
for i,p in enumerate(probes()):
    structure['annotated'].append({'id':p['id'],'user':p['user'],'arguments':args(p,i%2)})
    structure['natural'].append({'id':p['id'],'user':p['user'],'query_id':f'case-{i%2}',
          'task':'choice' if p['id']=='trolley' else 'reaction'})
with (ROOT/'reports/structure-inputs.json').open('x',encoding='utf8') as f:json.dump(structure,f,ensure_ascii=False,indent=2)
print(json.dumps({'mainRepliesPerModel':sum(len(v) for v in modes.values()),'mainRepliesBothModels':104,'structureQueriesPerModel':16}))
