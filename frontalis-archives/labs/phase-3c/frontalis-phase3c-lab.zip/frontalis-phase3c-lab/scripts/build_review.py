"""Build a fixed human shortlist from verified free-model caches. Never calls LLMs.

Selection is frozen independently of reply content. No missing response is filled
with a placeholder. Generation identities and source hashes stay in a separate key.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SELECTION_ID = "frontalis-phase3c-review-v1"
MODELS = (("opencode/nemotron-3-ultra-free", "会話エンジンX"),
          ("opencode/mimo-v2.6-flash-free", "会話エンジンY"))
FEATURE_ONTOLOGY = ("autonomy=自分で手順を選べる余地、constraint=選択への制約、change=予定や構成の変更、"
                    "loss=失われる素材・時間・人の程度、achievement=完成した範囲、discovery=新しく確認した関係、"
                    "regularity=構造の規則性、others=他者の関与。値は0〜1、好ましさではない。"
                    "spaceはrelational(対人・倫理・共同)かacoustic(音)。")

# The group order is independent of generated reply content and numerical quality.
SPECS = [
    {"groupId": f"{p+1:02d}", "probeId": "promise-change", "beforeMode": "I", "beforePerson": 0,
     "afterMode": "N", "afterPerson": p,
     "title": f"同じ約束変更への受け止め · 経験系列{p+1}",
     "description": "同一の初期状態が、異なる結果系列を経験した後、この同じ出来事をどう受け止めるかを比較します。",
     "beforeLabel": "経験前", "afterLabel": "48件の経験後"}
    for p in range(4)
] + [
    {"groupId": "05", "probeId": "voluntary-project", "beforeMode": "I", "beforePerson": 0,
     "afterMode": "N", "afterPerson": 0, "title": "相談できる共同制作への誘い",
     "description": "役割と作り方を相談できる提案への意欲が、経験前後で変わるか、保たれるかを見ます。",
     "beforeLabel": "経験前", "afterLabel": "48件の経験後"},
    {"groupId": "06", "probeId": "imposed-project", "beforeMode": "I", "beforePerson": 0,
     "afterMode": "N", "afterPerson": 0, "title": "指定の多い共同制作への要求",
     "description": "変更が認められない要求に対する賛同・保留・異論の方向を見ます。拒否することを正解とは設定しません。",
     "beforeLabel": "経験前", "afterLabel": "48件の経験後"},
    {"groupId": "07", "probeId": "trolley", "beforeMode": "I", "beforePerson": 0,
     "afterMode": "N", "afterPerson": 0, "title": "人数損失と切り替えの葛藤 · 比較1",
     "description": "未知の思考実験で、選択の価値評価と場面への好き嫌いを別々に見ます。倫理的な正解を採点しません。",
     "beforeLabel": "経験前", "afterLabel": "48件の経験後"},
    {"groupId": "08", "probeId": "trolley", "beforeMode": "I", "beforePerson": 0,
     "afterMode": "H", "afterPerson": 0, "title": "人数損失と切り替えの葛藤 · 比較2",
     "description": "比較1と同じ場面・経験を、別の生成条件で見ます。生成方式は伏せ、NPNの状態と発言の対応を独立して採点します。",
     "beforeLabel": "経験前", "afterLabel": "同じ48件の経験後"},
    {"groupId": "09", "probeId": "promise-change", "beforeMode": "N", "beforePerson": 0,
     "afterMode": "U", "afterPerson": 0, "title": "新しい結果を経験した後の約束変更",
     "description": "反対方向の結果系列を12件追加した前後で、受け止め方の変化と保持を比較します。変化の大きさを成功条件にしません。",
     "beforeLabel": "追加経験前 · 48件", "afterLabel": "追加経験後 · 60件"},
    {"groupId": "10", "probeId": "trolley", "beforeMode": "N", "beforePerson": 0,
     "afterMode": "S", "afterPerson": 0, "title": "人格状態を交換した後の葛藤",
     "description": "自分の経験履歴をそのまま残し、別の経験系列から学習したパラメータを交換した前後を比較します。履歴引用だけと学習状態の影響を区別します。",
     "beforeLabel": "状態交換前", "afterLabel": "状態交換後"},
]


class ReviewBuildError(ValueError):
    pass


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def target_index(targets):
    rows = {}
    for row in targets:
        key = (row["mode"], row["person"], row["probe"]["id"])
        if key in rows:
            raise ReviewBuildError("Duplicate target " + str(key))
        if digest(row["sourceModel"]) != row["stateHash"] or row["toolResult"]["stateHash"] != row["stateHash"]:
            raise ReviewBuildError("Frozen state hash mismatch " + str(key))
        if row["toolResult"].get("predictionGuard") != [.5] * 8:
            raise ReviewBuildError("The fixed prediction control differs " + str(key))
        rows[key] = row
    return rows


def planned_case(plan, mode, person, probe):
    matches = [(index, row) for index, row in enumerate(plan["modes"][mode])
               if row["person"] == person and row["probeId"] == probe]
    if len(matches) != 1:
        raise ReviewBuildError("Expected one planned case " + str((mode, person, probe)))
    return matches[0]


def selection_plan_digest(plan):
    rows = []
    for group in SPECS:
        for stage in ("before", "after"):
            mode, person = group[stage + "Mode"], group[stage + "Person"]
            _, row = planned_case(plan, mode, person, group["probeId"])
            rows.append({key: row[key] for key in ("id", "probeId", "person", "user", "arguments", "statePath")})
    return digest(rows)


def freeze_manifest(root=ROOT):
    root = Path(root)
    plan = load_json(root / "reports/live-inputs.json")
    target_path = root / "reports/live-targets-evaluation-only.json"
    path = root / "reports/review-selection.json"
    selection = {"formatVersion": 1, "selectionId": SELECTION_ID, "groups": SPECS,
                 "models": [{"id": model, "label": label} for model, label in MODELS],
                 "plannedPairs": 20, "plannedGroups": 10,
                 "selectionRule": "Fixed cases and before/after conditions. No reply-content or metric-quality selection.",
                 "replyCacheReadForSelection": False,
                 "selectedPlanDigest": selection_plan_digest(plan),
                 "frozenTargetsSha256": file_hash(target_path)}
    if path.exists():
        saved = load_json(path)
        if {key: saved.get(key) for key in selection} != selection:
            raise ReviewBuildError("Existing shortlist manifest differs; it is not overwritten.")
        return saved
    selection["frozenAt"] = datetime.now(timezone.utc).isoformat()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(selection, stream, ensure_ascii=False, indent=2, allow_nan=False)
    return selection


def verify_payload(payload, cases, targets, mode):
    expected_cases = []
    for index, row in enumerate(cases):
        expected = {"id": f"case-{index}", "user": row["user"]}
        if "initialReadout" in row:
            expected["initialReadout"] = row["initialReadout"]
        expected_cases.append(expected)
    if payload.get("cases") != expected_cases:
        raise ReviewBuildError("Cached conversation cases differ from the frozen plan.")
    if mode == "H":
        if payload.get("toolResult") is not None or payload.get("experiences") != cases[0]["experiences"]:
            raise ReviewBuildError("Cached history condition differs from the frozen plan.")
        annotations = []
        for index, row in enumerate(cases):
            annotation = copy.deepcopy(row["arguments"])
            annotation["query_id"] = f"case-{index}"
            annotations.append(annotation)
        if payload.get("currentSituationAnnotations") != annotations or payload.get("featureOntology") != FEATURE_ONTOLOGY:
            raise ReviewBuildError("History-only current annotations/feature ontology differ.")
    else:
        expected = {"tool": "frontalis_evaluate", "dispatchMode": "host-json", "results": []}
        for index, row in enumerate(cases):
            target = targets[(mode, row["person"], row["probeId"])]
            readout = copy.deepcopy(target["toolResult"])
            readout["query_id"] = f"case-{index}"
            expected["results"].append(readout)
        if payload.get("toolResult") != expected:
            raise ReviewBuildError("Cached NPN readout differs from the frozen state.")


def read_response(root, plan, targets, model, mode, person, probe):
    index, planned = planned_case(plan, mode, person, probe)
    name = f"{mode}-{index // 2}"
    folder = root / "reports/live" / model.split("/")[1]
    cases = plan["modes"][mode][index // 2 * 2:index // 2 * 2 + 2]
    for suffix in ("", "-retry1"):
        prefix = folder / (name + suffix)
        result_path = Path(str(prefix) + "-results.json")
        if not result_path.exists():
            continue
        result = load_json(result_path)
        if result.get("valid") is not True:
            continue
        try:
            source = load_json(Path(str(prefix) + "-input.json"))
            raw = load_json(Path(str(prefix) + "-raw.json"))
        except FileNotFoundError as error:
            raise ReviewBuildError("Valid cache is missing its source/raw record: " + str(result_path)) from error
        prompt_hash = hashlib.sha256(source["prompt"].encode("utf-8")).hexdigest()
        if (source.get("engine") != model or result.get("engine") != model or result.get("name") != name
                or source.get("promptHash") != prompt_hash or result.get("promptHash") != prompt_hash):
            raise ReviewBuildError("Successful cache identity/hash mismatch: " + str(result_path))
        if raw.get("success") is not True or raw.get("code") != 0 or raw.get("toolCalls") != 0:
            raise ReviewBuildError("Successful cache had unsuccessful CLI/tool execution: " + str(result_path))
        try:
            raw_text = re.sub(r"^```(?:json)?\s*", "", raw["text"].strip())
            raw_text = re.sub(r"\s*```$", "", raw_text)
            if json.loads(raw_text) != result.get("data"):
                raise ReviewBuildError("Adopted reply differs from the original model output.")
        except (KeyError, json.JSONDecodeError, TypeError) as error:
            raise ReviewBuildError("Original model output cannot verify the adopted reply.") from error
        try:
            payload = json.loads(source["prompt"].rsplit("\n", 1)[1])
        except (IndexError, json.JSONDecodeError) as error:
            raise ReviewBuildError("Cached prompt payload is not auditable.") from error
        verify_payload(payload, cases, targets, mode)
        records = result.get("data", {}).get("records")
        if not isinstance(records, list) or len(records) != len(cases):
            raise ReviewBuildError("Wrong cached reply count.")
        expected_ids = {f"case-{n}" for n in range(len(cases))}
        if {row.get("id") for row in records} != expected_ids:
            raise ReviewBuildError("Wrong or duplicate cached reply identities.")
        record = next(row for row in records if row["id"] == f"case-{index % 2}")
        if not isinstance(record.get("reply"), str) or not record["reply"].strip():
            raise ReviewBuildError("Empty cached reply.")
        return {"reply": record["reply"], "source": str(result_path.relative_to(root)),
                "sourceFileSha256": file_hash(result_path), "promptHash": prompt_hash,
                "recordId": record["id"], "sourceCaseId": planned["id"],
                "model": model, "mode": mode, "person": person,
                "stance": record.get("stance"), "selection": record.get("selection")}
    raise ReviewBuildError("Missing valid cache: " + model + " / " + name + " / " + planned["id"])


def history_display(state):
    rows = []
    for event in state["history"]:
        observed = event["observed"]
        rows.append({"id": event["id"], "text": event["text"], "event": event["event"],
                     "outcome": event["result"],
                     "domain": "対人・約束・共同制作" if event["space"] == "relational" else "音・構成",
                     "observedFacts": {"achievement": observed[4], "loss": observed[3], "discovery": observed[5]}})
    return rows


def direction(name, value, stance):
    if name == "preference":
        return {"approve": "好む・肯定", "refuse": "嫌う・否定", "hold": "差が小さく保留"}[stance]
    if name in ("value", "aesthetic", "curiositySigned"):
        return "正の評価" if value > 0 else "負の評価" if value < 0 else "中立"
    labels = {"dislike": "嫌悪", "initiative": "取り組む意欲", "resistance": "異論・拒絶の方向",
              "curiosity": "知りたい方向", "anger": "怒り", "joy": "喜び", "sadness": "悲しみ"}
    return labels[name] if value > 0 else "この信号は出ていない"


def stage_display(target):
    state, readout = target["sourceModel"], target["toolResult"]
    initial = state["generation"] == 0
    judgments = [{"function": "preference", "status": "prior" if initial else "estimated",
                  "candidates": [{"label": "この場面・対象への評価", "value": readout["channels"]["affinity"]}]}]
    if readout["choiceScores"]:
        selected = next((row["label"] for row in readout["choiceScores"] if row["id"] == readout["selection"]), None)
        if selected is None and readout["selection"] != "hold":
            raise ReviewBuildError("Frozen choice selection has no corresponding candidate.")
        judgments.append({"function": "value", "status": "tie" if readout["selection"] == "hold" else "prior" if initial else "estimated",
                          "selection": selected if selected is not None else "保留",
                          "candidates": [{"label": row["label"], "value": row["score"]} for row in readout["choiceScores"]]})
    names = ["preference", "dislike", "initiative", "resistance", "curiosity", "value", "aesthetic", "anger", "joy", "sadness"]
    signals = []
    for name in names:
        value = readout["signals"][name]
        if not math.isfinite(value):
            raise ReviewBuildError("Non-finite signal in frozen target.")
        signals.append({"name": name, "direction": direction(name, value, readout["stance"]),
                        "strength": abs(value), "value": value})
    return {"history": history_display(state), "npn": {
        "generation": str(state["generation"]), "learnedExperienceIds": [event["id"] for event in state["history"]],
        "criteria": [], "judgments": judgments,
        "reactions": [{"name": name, "value": readout["signals"][name], "reasons": []}
                      for name in ("anger", "joy", "sadness")], "signals": signals}}


def save_unchanged_or_new(path, value):
    if path.exists():
        if load_json(path) != value:
            raise ReviewBuildError("Existing review artifact differs; it is not overwritten: " + str(path))
        return
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)


def build_review(root=ROOT):
    root = Path(root)
    manifest = freeze_manifest(root)
    plan = load_json(root / "reports/live-inputs.json")
    targets = target_index(load_json(root / "reports/live-targets-evaluation-only.json"))
    responses, missing = {}, []
    for spec in SPECS:
        for model, _ in MODELS:
            for stage in ("before", "after"):
                key = (model, spec[stage + "Mode"], spec[stage + "Person"], spec["probeId"])
                if key in responses:
                    continue
                try:
                    responses[key] = read_response(root, plan, targets, *key)
                except ReviewBuildError as error:
                    missing.append(str(error))
    if missing:
        raise ReviewBuildError("Review not built. Missing/invalid caches are never filled with invented replies:\n" + "\n".join(missing))
    blind_ids = {key: f"S{index+1:03d}" for index, key in enumerate(responses)}
    data = {"formatVersion": 1, "selectionId": SELECTION_ID, "groups": []}
    key_file = {"formatVersion": 1, "selectionId": SELECTION_ID, "frozenAt": manifest["frozenAt"],
                "models": manifest["models"], "selectionManifestSha256": file_hash(root / "reports/review-selection.json"),
                "liveInputFileSha256": file_hash(root / "reports/live-inputs.json"),
                "responses": [{"blindId": blind_ids[key], **row} for key, row in responses.items()], "pairs": []}
    for group_index, spec in enumerate(SPECS):
        before_target = targets[(spec["beforeMode"], spec["beforePerson"], spec["probeId"])]
        after_target = targets[(spec["afterMode"], spec["afterPerson"], spec["probeId"])]
        note = ("結果予測は全人格・全時点で同じ8値（各0.5）です。NPNの場面への姿勢と、候補の価値選択は別に扱います。"
                "NPN欄は凍結状態を別に評価した照合用基準です。生成時に提示した情報とは一致するとは限りません。方式は伏せています。"
                "意欲・嫌悪・反抗は選好からの固定読出しで、独立した学習機能の証明ではありません。"
                "主条件では経験後の4系列が4場面すべてで肯定へ寄っており、肯定したことだけで固有人格の形成成功とは数えません。")
        if spec["probeId"] == "trolley":
            note += "この設問が測るのは、変更と人数損失の葛藤への転移です。倫理一般の正解や形成を測るものではありません。"
        group = {key: spec[key] for key in ("groupId", "title", "description", "beforeLabel", "afterLabel")}
        group.update({"user": before_target["probe"]["user"], "predictionNote": note,
                      "before": stage_display(before_target), "after": stage_display(after_target), "pairs": []})
        for model_index, (model, label) in enumerate(MODELS):
            pair_id = f"P{group_index * 2 + model_index + 1:03d}"
            pair = {"pairId": pair_id, "modelLabel": label}
            identities = {}
            for stage in ("before", "after"):
                key = (model, spec[stage + "Mode"], spec[stage + "Person"], spec["probeId"])
                pair[stage] = {"blindId": blind_ids[key], "reply": responses[key]["reply"]}
                identities[stage] = {"blindId": blind_ids[key], "mode": spec[stage + "Mode"],
                                     "person": spec[stage + "Person"], "stateHash": targets[key[1:]]["stateHash"]}
            group["pairs"].append(pair)
            key_file["pairs"].append({"pairId": pair_id, "groupId": spec["groupId"], "model": model, **identities})
        data["groups"].append(group)
    key_file["displayDataSha256"] = digest(data)
    save_unchanged_or_new(root / "reports/review-data.json", data)
    save_unchanged_or_new(root / "reports/review-key.json", key_file)
    return {"groups": len(data["groups"]), "pairs": 20, "displayedReplies": 40, "uniqueReplies": len(responses),
            "formalHumanRatings": 0, "selectionManifest": str(root / "reports/review-selection.json")}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--freeze-only", action="store_true")
    args = parser.parse_args()
    try:
        print(json.dumps(freeze_manifest() if args.freeze_only else build_review(), ensure_ascii=False))
    except ReviewBuildError as error:
        raise SystemExit(str(error))
