"""Copy source only to a new sibling lab. No experiments or external calls."""
import argparse,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--destination',required=True)
args=parser.parse_args()
dest=Path(args.destination).resolve()
if dest.parent!=ROOT.parent or not dest.name.startswith('frontalis-phase3c-repro-'):
    raise ValueError('Use a new frontalis-phase3c-repro-* sibling directory inside the workspace.')
if dest.exists():raise ValueError('Destination exists; no overwrite or deletion.')
dest.mkdir()
for name in ['npn','tools','scripts','experiments','tests','docs','examples']:
    shutil.copytree(ROOT/name,dest/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for name in ['README.md','REPORT.md','CLAUDE_HANDOFF.md']:
    shutil.copy2(ROOT/name,dest/name)
(dest/'REPRODUCTION_CONTEXT.md').write_text(
    '# 再現コピーの状態\n\nこのコピーはsourceだけで、実験・LLM呼出しはまだ実行していません。'
    '\nREPORT.mdとdocs内の結果は元ラボの参照資料であり、このコピーで得た結果ではありません。'
    '\n再実行後は、このコピーのreports内の実数値・原出力に基づいて新しい報告を作成してください。'
    '\n元ラボ: '+str(ROOT)+'\n',encoding='utf8')
for name in ['reports','models','data','runtime','exploration','sandbox']:(dest/name).mkdir()
print(json.dumps({'directory':str(dest),'copied':'source only','executedExperiments':0,'externalCalls':0},ensure_ascii=False))
