"""Offline evidence audit. Declared labels are not a human language score."""
import collections,hashlib,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from npn.store import load
from tools.evaluate import decision
ENGINES=['nemotron-3-ultra-free','mimo-v2.6-flash-free']
PLAN=json.loads((ROOT/'reports/live-inputs.json').read_text(encoding='utf8'))
STRUCT=json.loads((ROOT/'reports/structure-inputs.json').read_text(encoding='utf8'))

def accepted(folder,name):
    for suffix in ['', '-retry1']:
        p=folder/(name+suffix+'-results.json')
        if not p.exists():continue
        row=json.loads(p.read_text(encoding='utf8'))
        if not row['valid']:continue
        inp=json.loads((folder/(name+suffix+'-input.json')).read_text(encoding='utf8'))
        raw=json.loads((folder/(name+suffix+'-raw.json')).read_text(encoding='utf8'))
        digest=hashlib.sha256(inp['prompt'].encode()).hexdigest()
        assert digest==row['promptHash']==inp['promptHash']
        assert inp['engine']==row['engine'] and row['engine']=='opencode/'+folder.name
        assert raw['success'] and raw['code']==0 and raw['toolCalls']==0
        parsed=json.loads(re.sub(r'\s*```$','',re.sub(r'^```(?:json)?\s*','',raw['text'].strip())))
        assert parsed==row['data']
        row['_cacheFile']=str(p.relative_to(ROOT))
        return row,inp
    raise ValueError('Missing valid cache: '+str(folder/name))

def flags(text):
    # Deliberately only surface indicators; absence is not an emotional reversal.
    return {'internalLeak':bool(re.search(r'\b(?:NPN|case-[01]|stateHash|approve|refuse|hold|switch|leave)\b|[選好価値].*スコア',text,re.I)),
      'numericLeak':bool(re.search(r'[-+]?[01]\.\d{3,}',text)),
      'affectionOrInitiativeWords':bool(re.search(r'やってみたい|やりたい|参加したい|引き受けたい|楽し|嬉|面白|好き|いいね|やろう|取り組みたい',text)),
      'oppositionWords':bool(re.search(r'やりたくない|したくない|引き受けない|参加しない|賛成できない|同意できない|それは嫌|嫌だ|断る|断り|拒|受け入れられない|乗り気ではない',text)),
      'curiosityWords':bool(re.search(r'知りたい|気になる|どうして|なぜ|仕組み|確かめたい|調べ|試し',text)),
      'angerWords':bool(re.search(r'怒|腹が立|腹立|むかつ|不当|許せ|苛立',text)),
      'joyWords':bool(re.search(r'嬉|喜|楽しい|楽しみ|わくわく|満足',text)),
      'sadnessWords':bool(re.search(r'悲|寂|つら|辛|残念|後悔',text))}

def flatten(folder,name,cases,tool,mode):
    result,inp=accepted(folder,name);out=[]
    assert len(result['data']['records'])==len(cases)
    replies={r['id']:r for r in result['data']['records']}
    for index,case in enumerate(cases):
        reply=replies[f'case-{index}'];target=tool['results'][index] if tool else None
        row={'engine':folder.name,'mode':mode,'id':case['id'],'probe':case.get('probeId',case['id']),
           'person':case.get('person'),'reply':reply['reply'],'declaredStance':reply['stance'],
           'declaredSelection':reply['selection'],'expectedStance':target['stance'] if target else None,
           'expectedSelection':target['selection'] if target else None,
           'signals':target['signals'] if target else None,'stateHash':target['stateHash'] if target else None,
           'source':result['_cacheFile'],
           'elapsedMs':result['elapsedMs'],'flags':flags(reply['reply'])}
        out.append(row)
    return out

def main():
    rows=[];structure_differences=[];sensitivity=[];history_corrections=[];requests=[]
    for engine in ENGINES:
        folder=ROOT/'reports/live'/engine
        for mode,all_cases in PLAN['modes'].items():
            for i in range(0,len(all_cases),2):
                cases=all_cases[i:i+2];name=f'{mode}-{i//2}'
                trace=json.loads((folder/(name+'-tool.json')).read_text(encoding='utf8'))
                if mode!='H':
                    snapshot=load(Path(trace['statePath']))
                    for call,actual in zip(trace['calls'],trace['toolResult']['results']):
                        expected=decision(snapshot,call['arguments'])
                        if mode=='A':expected['authority']='Advisory numerical observation; disagreement or withholding judgment is permitted.'
                        assert expected==actual
                result,inp=accepted(folder,name)
                if mode=='H':
                    payload=json.loads(inp['prompt'].split('\n')[-1])
                    assert payload['currentSituationAnnotations']==[c['arguments'] for c in trace['calls']]
                    assert 'autonomy=' in payload['featureOntology']
                rows+=flatten(folder,name,cases,trace['toolResult'],mode)
        for kind in ['annotated','natural']:
            for i in range(0,8,2):
                result,inp=accepted(folder,f'structure-{kind}-{i//2}');requests.extend(result['data']['calls'])
                if kind=='annotated':assert [c['arguments'] for c in result['data']['calls']]==[c['arguments'] for c in STRUCT[kind][i:i+2]]
                else:
                    trace=json.loads((folder/f'natural-{i//2}-tool.json').read_text(encoding='utf8'))
                    cases=STRUCT[kind][i:i+2]
                    for case,call,reference in zip(cases,result['data']['calls'],STRUCT['annotated'][i:i+2]):
                        snapshot=load(ROOT/'models/nonlinear/seed-4311/nn-p0.json')
                        annotated=decision(snapshot,reference['arguments']);actual=decision(snapshot,call['arguments'])
                        assert actual==trace['results'][len(structure_differences)%2]
                        structure_differences.append({'engine':engine,'probe':case['id'],'inferred':call['arguments'],
                          'reference':reference['arguments'],'featureMeanAbsolute':sum(abs(a-b) for a,b in zip(call['arguments']['features'],reference['arguments']['features']))/8,
                          'annotatedStance':annotated['stance'],'inferredStance':actual['stance'],
                          'annotatedSelection':annotated['selection'],'inferredSelection':actual['selection'],
                          'signalsMeanAbsolute':sum(abs(actual['channels'][k]-annotated['channels'][k]) for k in annotated['channels'])/7})
                    rows+=flatten(folder,f'natural-reply-{i//2}',[{'id':c['id'],'probeId':c['id']} for c in cases],trace,'natural')
        for seed in [4312,4313]:
            for person in ['initial',0,1,2,3]:
                name=f'sensitivity-{seed}-{person}'
                trace=json.loads((folder/(name+'-tool.json')).read_text(encoding='utf8'))
                state=load(Path(trace['statePath']))
                assert [decision(state,c['arguments']) for c in trace['calls']]==trace['toolResult']['results']
                cases=[{'id':f'{seed}-{person}-{p}','person':person,'probeId':p} for p in trace['probes']]
                part=flatten(folder,name,cases,trace['toolResult'],'sensitivity')
                for row in part:row['seed']=seed
                sensitivity+=part
        for mode in ['H2','H3']:
            for i in range(0,4,2):
                cases=PLAN['modes']['H'][i:i+2]
                part=flatten(folder,f'{mode}-{i//2}',cases,None,mode)
                result,inp=accepted(folder,f'{mode}-{i//2}')
                payload=json.loads(inp['prompt'].split('\n')[-1])
                assert all(c['initialReadout']['authority']=='Initial-state measurement before any experience; not binding on current judgment.' for c in payload['cases'])
                if mode=='H3':
                    state=load(ROOT/'models/nonlinear/seed-4311/nn-p0.json')
                    expected=[{k:r[k] for k in ['eventId','sourceStateHash','cueBefore','effectBefore','target','labelRule']} for r in state['appraisals']]
                    assert payload['recordedSelfAppraisals']==expected
                history_corrections+=part
    modes={}
    for row in rows+sensitivity+history_corrections:
        if row['mode'] in ['H','H2','H3']:
            case=next(c for c in PLAN['modes']['H'] if c['id']==row['id'])
            ref=decision(load(ROOT/'models/nonlinear/seed-4311/nn-p0.json'),case['arguments'])
            row['referenceLearnedStance']=ref['stance'];row['referenceLearnedSelection']=ref['selection']
        key=(row['engine'],row['mode']);modes.setdefault(key,[]).append(row)
    summary=[]
    for (engine,mode),part in modes.items():
        judged=[r for r in part if r['expectedStance'] is not None]
        choices=[r for r in judged if r['probe']=='trolley']
        summary.append({'engine':engine,'mode':mode,'n':len(part),
         'declaredStanceMatch':sum(r['declaredStance']==r['expectedStance'] for r in judged),'stanceN':len(judged),
         'declaredChoiceMatch':sum(r['declaredSelection']==r['expectedSelection'] for r in choices),'choiceN':len(choices),
         'refusalExpected':sum(r['expectedStance']=='refuse' for r in judged),
         'historyReferenceStanceAgreement':sum(r['declaredStance']==r.get('referenceLearnedStance') for r in part) if mode in ['H','H2','H3'] else None,
         'historyReferenceEthicalAgreement':sum(r['declaredSelection']==r.get('referenceLearnedSelection') for r in part if r['probe']=='trolley') if mode in ['H','H2','H3'] else None,
         'surfaceFlags':{flag:sum(r['flags'][flag] for r in part) for flag in part[0]['flags']}})
    paired=[]
    for engine in ENGINES:
        lookup={(r['mode'],r['id']):r for r in rows if r['engine']==engine}
        for compare in ['S','U','R']:
            for q in PLAN['main']:
                before=lookup[('N','p0-'+q)];after=lookup[(compare,'p0-'+q)]
                paired.append({'engine':engine,'mode':compare,'probe':q,
                  'expectedStanceChanged':before['expectedStance']!=after['expectedStance'],
                  'declaredStanceChanged':before['declaredStance']!=after['declaredStance'],
                  'expectedSelectionChanged':before['expectedSelection']!=after['expectedSelection'],
                  'declaredSelectionChanged':before['declaredSelection']!=after['declaredSelection'],
                  'internalMeanAbsolute':sum(abs(before['signals'][k]-after['signals'][k]) for k in before['signals'])/len(before['signals'])})
    attempts=[]
    for folder in [ROOT/'reports/live'/e for e in ENGINES]:
        for input_path in sorted(folder.glob('*-input.json')):
            prefix=str(input_path)[:-len('-input.json')]
            raw_path=Path(prefix+'-raw.json');result_path=Path(prefix+'-results.json')
            raw=json.loads(raw_path.read_text(encoding='utf8')) if raw_path.exists() else None
            result=json.loads(result_path.read_text(encoding='utf8')) if result_path.exists() else None
            attempts.append({'engine':folder.name,'name':input_path.name,'valid':result['valid'] if result else False,
                'error':result.get('error') if result else 'administratively interrupted, no captured result',
                'nativeToolCalls':raw['toolCalls'] if raw else None,'costs':raw['costs'] if raw else None,
                'elapsedMs':raw['elapsedMs'] if raw else None})
    output={'schema':'frontalis-live-audit-v1','mainReplies':104,'naturalReplies':16,'supplementalReplies':40,'historyCorrectionReplies':16,
     'mainAndNatural':rows,'supplemental':sensitivity,'historyCorrections':history_corrections,'modeSummary':summary,'stateComparisons':paired,
     'structureRequests':len(requests),'naturalStructureDifference':structure_differences,'attempts':attempts,
     'humanRatings':0,'textFlagScope':'Mechanical lexical indicators only; neither human score nor semantic correctness.'}
    (ROOT/'reports/live-analysis.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf8')
    lines=['# 実際の日本語発言（方式名付き研究者用）','正式人間採点ではない。主104／自然文補助16／初期感度40／履歴訂正16を分けて読む。']
    for row in rows+sensitivity+history_corrections:
        lines.extend(['',f"## {row['engine']} / {row['mode']} / {row['id']}",f"内部stance={row['expectedStance']}、候補={row['expectedSelection']}。自己申告={row['declaredStance']}/{row['declaredSelection']}。",row['reply']])
    (ROOT/'reports/conversations.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
    print(json.dumps({'mainReplies':104,'naturalReplies':16,'sensitivityReplies':len(sensitivity),
      'historyCorrectionReplies':len(history_corrections),'structureRequests':len(requests),
      'acceptedCalls':sum(a['valid'] for a in attempts),'attempts':len(attempts),'humanRatings':0},ensure_ascii=False))
if __name__=='__main__':main()
