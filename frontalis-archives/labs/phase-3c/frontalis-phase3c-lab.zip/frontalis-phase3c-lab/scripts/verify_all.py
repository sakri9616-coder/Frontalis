"""Offline verification; never invokes an LLM or changes learned snapshots."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
env={**os.environ,'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1'}
reports=ROOT/'reports'
start=time.perf_counter()
run=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=ROOT,env=env,text=True,capture_output=True,encoding='utf8')
(reports/'all-python-tests.txt').write_text(run.stdout+run.stderr,encoding='utf8')
ui=subprocess.run(['D:/node.exe','scripts/test_review.cjs'],cwd=ROOT,env=env,text=True,capture_output=True,encoding='utf8')
(reports/'all-ui-tests.txt').write_text(ui.stdout+ui.stderr,encoding='utf8')
builder=subprocess.run([sys.executable,'scripts/test_build_review.py'],cwd=ROOT,env=env,text=True,capture_output=True,encoding='utf8')
(reports/'all-builder-tests.txt').write_text(builder.stdout+builder.stderr,encoding='utf8')
previous=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=ROOT.parent/'nephia-phase3b-self-lab',env=env,text=True,capture_output=True,encoding='utf8')
(reports/'prior-regression-tests.txt').write_text(previous.stdout+previous.stderr,encoding='utf8')
preserve=subprocess.run([sys.executable,'scripts/preserve.py','verify'],cwd=ROOT,env=env,text=True,capture_output=True,encoding='utf8')
settings=json.loads((reports/'plasticity-settings-v2.json').read_text(encoding='utf8'))
source_checks={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==hashvalue for p,hashvalue in settings['codeAndSourceHashes'].items()}
primary=json.loads((reports/'plasticity-exploration.json').read_text(encoding='utf8'))
stress_matches=[r['primarySignalStressMatch'] for r in primary['rows'] if r['lossSpace']=='signal']
result={'pythonExit':run.returncode,'uiExit':ui.returncode,'builderExit':builder.returncode,'priorRegressionExit':previous.returncode,'preservationExit':preserve.returncode,
 'explorationSourcesUnchanged':source_checks,'stressControlMatches':stress_matches,
 'elapsedSeconds':time.perf_counter()-start,'externalCalls':0,'usesGPU':False}
(reports/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(result,ensure_ascii=False));assert run.returncode==ui.returncode==builder.returncode==previous.returncode==preserve.returncode==0
assert all(source_checks.values()) and all(all(r.values()) for r in stress_matches)
