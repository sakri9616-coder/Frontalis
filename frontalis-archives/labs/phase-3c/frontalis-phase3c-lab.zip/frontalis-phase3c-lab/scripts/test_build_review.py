"""Synthetic cache tests. No model, API, training, or formal human rating."""
import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

import build_review as review


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def fixture(root, with_caches=True):
    probes = list(dict.fromkeys(group["probeId"] for group in review.SPECS))
    plan = {"formatVersion": 1, "modes": {mode: [] for mode in ("I", "N", "H", "U", "S")}}
    targets = []
    for mode, rows in plan["modes"].items():
        for person in range(4 if mode == "N" else 1):
            history = [] if mode == "I" else [{
                "id": "fixture-experience", "text": "UI試験用の原文。出来事と結果だけを残す。",
                "event": "UI試験用の出来事。", "result": "UI試験用の客観結果。",
                "space": "relational", "cue": [.5] * 8, "observed": [.2, .3, .4, .7, .8, .9, .2, .3],
            }]
            state = {"generation": len(history), "history": history, "kind": "nn", "fixturePerson": person}
            for index, probe in enumerate(probes):
                args = {"query_id": f"case-{index % 2}", "space": "relational", "features": [.5] * 8, "basis": "affinity"}
                tool = {"stateHash": review.digest(state), "generation": len(history), "query_id": args["query_id"],
                        "channels": {"affinity": .2}, "signals": {name: .2 for name in (
                            "preference", "dislike", "initiative", "resistance", "curiosity", "value", "aesthetic", "anger", "joy", "sadness")},
                        "stance": "approve", "choiceScores": [], "selection": "hold", "predictionGuard": [.5] * 8}
                row = {"id": f"p{person}-{probe}", "person": person, "probeId": probe, "user": "UI試験用の問い：" + probe,
                       "arguments": args, "statePath": str(root / "models" / (mode + str(person) + ".json"))}
                if mode == "H":
                    row["experiences"] = history
                    row["initialReadout"] = {"fixture": "common-initial"}
                rows.append(row)
                targets.append({"mode": mode, "person": person, "probe": {"id": probe, "user": row["user"]},
                                "sourceModel": copy.deepcopy(state), "stateHash": review.digest(state), "toolResult": tool})
    write(root / "reports/live-inputs.json", plan)
    write(root / "reports/live-targets-evaluation-only.json", targets)
    review.freeze_manifest(root)
    if with_caches:
        target_map = review.target_index(targets)
        for model, _ in review.MODELS:
            folder = root / "reports/live" / model.split("/")[1]
            for mode, rows in plan["modes"].items():
                for index in range(0, len(rows), 2):
                    cases = rows[index:index + 2]
                    payload = {"cases": [{"id": f"case-{n}", "user": row["user"],
                               **({"initialReadout": row["initialReadout"]} if "initialReadout" in row else {})}
                                         for n, row in enumerate(cases)], "toolResult": None}
                    if mode == "H":
                        payload.update(experiences=cases[0]["experiences"], featureOntology=review.FEATURE_ONTOLOGY,
                                       currentSituationAnnotations=[row["arguments"] for row in cases])
                    else:
                        payload["toolResult"] = {"tool": "frontalis_evaluate", "dispatchMode": "host-json", "results": [
                            target_map[(mode, row["person"], row["probeId"])]["toolResult"] for row in cases]}
                    data = {"records": [{"id": f"case-{n}", "reply": "UI試験用の架空発言：" + row["user"],
                                         "stance": "approve", "selection": "hold"} for n, row in enumerate(cases)]}
                    prompt = "UI試験用。外部呼び出しなし。\n" + json.dumps(payload, ensure_ascii=False)
                    prompt_hash = hashlib.sha256(prompt.encode("utf-8")).hexdigest()
                    name = f"{mode}-{index // 2}"
                    write(folder / (name + "-input.json"), {"engine": model, "prompt": prompt, "promptHash": prompt_hash})
                    write(folder / (name + "-raw.json"), {"success": True, "code": 0, "toolCalls": 0, "text": json.dumps(data, ensure_ascii=False)})
                    write(folder / (name + "-results.json"), {"engine": model, "name": name, "valid": True,
                                                           "promptHash": prompt_hash, "data": data})
    return plan, targets


class BuilderTests(unittest.TestCase):
    def setUp(self):
        runtime = review.ROOT / "runtime/review-builder-tests"
        runtime.mkdir(parents=True, exist_ok=True)
        self.root = Path(tempfile.mkdtemp(prefix="fixture-", dir=runtime)).resolve()
        self.assertTrue(self.root.is_relative_to(runtime.resolve()))
        self.plan, self.targets = fixture(self.root)

    def cache_path(self, suffix):
        return self.root / "reports/live/nemotron-3-ultra-free" / ("N-0-" + suffix + ".json")

    def test_fixed_manifest_does_not_read_reply_caches(self):
        manifest = review.freeze_manifest(self.root)
        self.assertFalse(manifest["replyCacheReadForSelection"])
        self.assertEqual(manifest["plannedPairs"], 20)
        self.assertEqual(manifest["plannedGroups"], 10)
        before = (self.root / "reports/review-selection.json").read_bytes()
        review.freeze_manifest(self.root)
        self.assertEqual(before, (self.root / "reports/review-selection.json").read_bytes())

    def test_complete_cache_builds_twenty_pairs_and_twenty_eight_unique_replies(self):
        result = review.build_review(self.root)
        self.assertEqual((result["groups"], result["pairs"], result["uniqueReplies"]), (10, 20, 28))
        data = review.load_json(self.root / "reports/review-data.json")
        self.assertEqual(sum(len(group["pairs"]) for group in data["groups"]), 20)
        self.assertEqual(data["groups"][0]["pairs"][0]["before"], data["groups"][1]["pairs"][0]["before"])

    def test_missing_cache_refuses_without_creating_review(self):
        self.cache_path("results").unlink()
        with self.assertRaisesRegex(review.ReviewBuildError, "Missing valid cache"):
            review.build_review(self.root)
        self.assertFalse((self.root / "reports/review-data.json").exists())

    def test_source_prompt_hash_must_match(self):
        path = self.cache_path("input")
        data = review.load_json(path)
        data["prompt"] += " changed"
        write(path, data)
        with self.assertRaisesRegex(review.ReviewBuildError, "hash mismatch"):
            review.build_review(self.root)

    def test_original_model_output_must_match_adopted_reply(self):
        path = self.cache_path("results")
        data = review.load_json(path)
        data["data"]["records"][0]["reply"] = "改変した発言。"
        write(path, data)
        with self.assertRaisesRegex(review.ReviewBuildError, "original model output"):
            review.build_review(self.root)

    def test_tool_attempt_is_not_a_successful_cache(self):
        path = self.cache_path("raw")
        data = review.load_json(path)
        data["toolCalls"] = 1
        write(path, data)
        with self.assertRaisesRegex(review.ReviewBuildError, "CLI/tool execution"):
            review.build_review(self.root)

    def test_npn_readout_cannot_be_replaced(self):
        path = self.cache_path("input")
        source = review.load_json(path)
        payload = json.loads(source["prompt"].rsplit("\n", 1)[1])
        payload["toolResult"]["results"][0]["signals"]["preference"] = -.9
        source["prompt"] = "UI試験用。\n" + json.dumps(payload, ensure_ascii=False)
        source["promptHash"] = hashlib.sha256(source["prompt"].encode("utf-8")).hexdigest()
        write(path, source)
        result_path = self.cache_path("results")
        result = review.load_json(result_path)
        result["promptHash"] = source["promptHash"]
        write(result_path, result)
        with self.assertRaisesRegex(review.ReviewBuildError, "NPN readout differs"):
            review.build_review(self.root)

    def test_history_annotations_are_required(self):
        cases = self.plan["modes"]["H"][:2]
        target_map = review.target_index(self.targets)
        payload = {"cases": [{"id": f"case-{n}", "user": row["user"], "initialReadout": row["initialReadout"]}
                             for n, row in enumerate(cases)], "toolResult": None, "experiences": cases[0]["experiences"]}
        with self.assertRaisesRegex(review.ReviewBuildError, "current annotations"):
            review.verify_payload(payload, cases, target_map, "H")

    def test_model_and_generation_metadata_are_only_in_separate_key(self):
        review.build_review(self.root)
        data = review.load_json(self.root / "reports/review-data.json")
        key = review.load_json(self.root / "reports/review-key.json")
        encoded = json.dumps(data, ensure_ascii=False)
        self.assertNotIn("nemotron", encoded)
        self.assertNotIn("mimo", encoded)
        self.assertNotIn('"mode"', encoded)
        self.assertEqual(len(key["pairs"]), 20)
        self.assertEqual(len(key["responses"]), 28)
        self.assertTrue(all(row["sourceFileSha256"] for row in key["responses"]))

    def test_history_maps_only_actual_achievement_loss_discovery(self):
        target = review.target_index(self.targets)[("N", 0, "promise-change")]
        shown = review.stage_display(target)
        self.assertEqual(shown["history"][0]["observedFacts"], {"achievement": .8, "loss": .7, "discovery": .9})
        self.assertEqual(shown["history"][0]["text"], target["sourceModel"]["history"][0]["text"])

    def test_parameter_swap_keeps_history_and_intervention_labels(self):
        review.build_review(self.root)
        data = review.load_json(self.root / "reports/review-data.json")
        group = data["groups"][-1]
        self.assertEqual(group["before"]["history"], group["after"]["history"])
        self.assertEqual(group["beforeLabel"], "状態交換前")
        self.assertEqual(group["afterLabel"], "状態交換後")

    def test_output_is_idempotent_and_cannot_silently_overwrite_different_data(self):
        review.build_review(self.root)
        first = (self.root / "reports/review-data.json").read_bytes()
        review.build_review(self.root)
        self.assertEqual(first, (self.root / "reports/review-data.json").read_bytes())
        write(self.root / "reports/review-data.json", {"different": True})
        with self.assertRaisesRegex(review.ReviewBuildError, "not overwritten"):
            review.build_review(self.root)


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(BuilderTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    write(review.ROOT / "reports/review-builder-tests.json", {
        "tests": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
        "scope": "Synthetic cache integrity/build tests; no LLM calls and no formal human evaluation.",
        "formalHumanRatings": 0,
    })
    raise SystemExit(0 if result.wasSuccessful() else 1)
