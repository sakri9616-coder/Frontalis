"""Read-only original artifact manifest; runtime caches are excluded."""
import hashlib
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
manifest=ROOT/'reports/prior-sha256.json'
if sys.argv[1:]==['snapshot']:
    rows=[]
    for lab in ['nephia-core-lab','nephia-npn-lab','nephia-phase3-lab','nephia-phase35-lab','nephia-phase3b-lab','nephia-phase3b-self-lab']:
        for p in sorted((ROOT.parent/lab).rglob('*')):
            if p.is_file() and not set(p.relative_to(ROOT.parent/lab).parts)&{'runtime','sandbox','__pycache__','.git'}:
                rows.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    with manifest.open('x',encoding='utf8') as f:json.dump(rows,f,ensure_ascii=False,indent=2)
    print(json.dumps({'snapshotFiles':len(rows)}))
else:
    rows=json.loads(manifest.read_text(encoding='utf8'));changed=[];missing=[]
    for row in rows:
        p=Path(row['path'])
        if not p.exists():missing.append(str(p))
        elif hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:changed.append(str(p))
    result={'checkedFiles':len(rows),'changed':changed,'missing':missing,'scope':'Original six research labs, excludes runtime/sandbox/cache; not a full ASIST filesystem snapshot.'}
    (ROOT/'reports/preservation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(result));assert not changed and not missing
