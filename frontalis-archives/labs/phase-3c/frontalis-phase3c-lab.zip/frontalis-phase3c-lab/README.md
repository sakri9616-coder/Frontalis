# Project frontalis — Phase 3-C

結果予測を固定し、旧NPN自身の主観評価から学習する、CPU主体の独立研究ラボ。

**合成経験による自己評価・自己更新の循環は確認。感情・意欲の忠実な表出、長期可塑性、NN固有の必要性は未確立。本人の本体・実記憶へ未統合。**

- [人間向け成果報告](REPORT.md)
- [重点20ペアのブラインド評価画面](reports/review.html) — 正式人間採点0件
- [Claude Code引き継ぎ・再現方法](CLAUDE_HANDOFF.md)
- [実際の176発言](reports/conversations.md) — 主104／自然文補助16／初期感度40／履歴訂正16

|資料|内容|
|---|---|
|[根拠](docs/00-research-basis.md)・[事前計画](docs/01-protocol.md)|採用技術、初期基準、対照、判定の境界|
|[経験](docs/02-experiences.md)・[設計](docs/03-design.md)|8事実軸、7評価、自己教師、状態・保存|
|[数値](docs/04-numeric.md)・[会話](docs/05-conversations.md)|216条件、強い単純方式、成功と失敗|
|[評価画面](docs/06-review.md)・[データ監査](docs/07-data-audit.md)|元原文・注釈差、人間20ペア、保存互換性|
|[接続変更](docs/08-live-amendment.md)・[ツール境界](docs/10-tool-boundary-review.md)|MCP失敗、ホスト実行、読み取り専用|
|[本文監査](docs/11-language-audit.md)|自己申告と本文の違い、AI観察、人間未採点|
|[可塑性計画](docs/09-plasticity-plan.md)・[結果](docs/13-plasticity-results.md)|事後探索、勾配消失の診断、主版保全|
|[初期感度](docs/12-seed-sensitivity-plan.md)・[履歴訂正](docs/15-history-correction-plan.md)|結果後の補助条件、元回答保全|
|[本人の経験への境界](docs/14-real-experience-boundary.md)|未確認解釈、賞賛、移行、保留理由|

実装は `npn`、独立評価ツールは `tools`、実験は `experiments`、補助・オフライン検証は `scripts`。元データは `data`、主状態は `models`、探索版は `exploration`、実出力は `reports`。旧研究と本体は編集しない。

新規83 Python＋25 UI＋12 builder試験、既存31試験が合格。追加LLMなしの確認は `scripts/verify_all.py` と `scripts/analyze_live.py`。実画面の証拠は `reports/browser-checks.json` と `reports/review-preview.png`。数値・会話の再取得は別コピーへ出力し、既存の成功結果や状態を上書きしない。
