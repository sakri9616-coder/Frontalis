"""Predeclared synthetic value-formation comparisons. No desired affect target."""
from __future__ import annotations
import copy
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from npn import data, model
from npn.store import save

METHODS = ('nn', 'linear', 'quadratic', 'memory', 'nn-off', 'nn-gain1')


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf8') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)


def state_for(method, seed):
    return model.init(seed, kind='nn' if method.startswith('nn') else method,
                      gain=1. if method == 'nn-gain1' else 1.25,
                      learning=method != 'nn-off')


def readout(state, probes=None):
    return np.asarray([model.evaluate(state, p['features'], p['space'])['raw'] for p in (data.probes() if probes is None else probes)])


def difference(a, b):
    delta = np.asarray(b) - np.asarray(a)
    return {'meanAbsolute': float(np.abs(delta).mean()),
            'rms': float(np.sqrt((delta ** 2).mean())),
            'maxAbsolute': float(np.abs(delta).max()),
            'channelMeanAbsolute': dict(zip(model.CHANNELS, np.abs(delta).mean(axis=0).tolist()))}


def train(events, state):
    checkpoints = []
    before = readout(state)
    for index, event in enumerate(events, 1):
        state = model.update(state, event)
        if index in (8, 24, 48):
            checkpoints.append({'count': index, 'parameterHash': model.parameter_digest(state),
                                'fromInitial': difference(before, readout(state)),
                                'readout': readout(state).tolist()})
    return state, checkpoints


def interventions(states):
    report = []
    for condition in data.CONDITIONS:
        seed = data.SEEDS[0]
        baseline = states[(condition, seed, 0, 'nn')]
        source = data.stream(seed, 0, condition)
        other = data.stream(seed, 1, condition)
        base_out = readout(baseline)
        initial = model.init(seed)
        correction = copy.deepcopy(source)
        correction[10]['observed'] = copy.deepcopy(other[10]['observed'])
        correction[10]['result'] = data._result(correction[10]['observed'])
        correction[10]['text'] = correction[10]['event'] + '\n' + correction[10]['result']
        correction[10]['annotation']['observedAxes'] = dict(zip(data.AXES, correction[10]['observed']))
        exchange = copy.deepcopy(source)
        for i in range(12, 24):
            exchange[i]['observed'] = copy.deepcopy(other[i]['observed'])
            exchange[i]['result'] = data._result(exchange[i]['observed'])
            exchange[i]['text'] = exchange[i]['event'] + '\n' + exchange[i]['result']
            exchange[i]['annotation']['observedAxes'] = dict(zip(data.AXES, exchange[i]['observed']))
        versions = {
            'delete-12': model.replay(data.counterfactuals(source, 'delete'), seed),
            'correct-1-result': model.replay(correction, seed),
            'exchange-12-results': model.replay(exchange, seed),
            'reverse-order': model.replay(list(reversed(source)), seed),
        }
        for name in ('reversal', 'unrelated'):
            state = baseline
            for event in data.additional(seed, 0, condition, kind=name):
                state = model.update(state, event)
            versions['add-' + name] = state
            if condition == 'nonlinear':
                save(ROOT / 'models' / condition / f'seed-{seed}' / f'nn-p0-{name}.json', state)
        for name, after in versions.items():
            out = readout(after)
            report.append({'condition': condition, 'seed': seed, 'person': 0, 'intervention': name,
                           'parameterHashBefore': model.parameter_digest(baseline),
                           'parameterHashAfter': model.parameter_digest(after),
                           'effect': difference(base_out, out),
                           'fromInitial': difference(readout(initial), out),
                           'relationalParameterEqual': baseline['branches']['relational'] == after['branches']['relational'],
                           'acousticParameterEqual': baseline['branches']['acoustic'] == after['branches']['acoustic'],
                           'readoutBefore': base_out.tolist(), 'readoutAfter': out.tolist()})
        # Criteria-state exchange changes evaluation without changing facts/forecast.
        swapped = copy.deepcopy(baseline)
        swapped['branches'] = copy.deepcopy(states[(condition, seed, 1, 'nn')]['branches'])
        report.append({'condition': condition, 'seed': seed, 'person': 0,
                       'intervention': 'valuation-branches-swap',
                       'effect': difference(base_out, readout(swapped)),
                       'fixedPredictionEqual': model.predict(baseline, [.2]*8, 'relational') == model.predict(swapped, [.2]*8, 'relational'),
                       'evaluationOnly': True})
    return report


def matched_target(states):
    """Common targets, multiple origins; approximation, not moral correctness."""
    rows = []
    label_manifest = []
    seed = data.SEEDS[0]
    for condition in data.CONDITIONS:
        for origin in ('nn','linear','quadratic','memory'):
            teacher = states[(condition, seed, 0, origin)]
            datasets = {}
            for phase, count in (('train',48), ('validation',24), ('test',96)):
                # Offsets unrelated to primary fit; these are frozen valuation points.
                rng = np.random.default_rng(seed + {'train':80000,'validation':90000,'test':100000}[phase])
                points = []
                for i in range(count):
                    features = rng.uniform(.08,.92,8).tolist()
                    space = 'acoustic' if i % 4 == 3 else 'relational'
                    points.append({'eventId': f'diagnostic-{phase}-{i}', 'features': features,
                                   'space': space, 'target': model.evaluate(teacher, features, space)['raw']})
                datasets[phase] = points
            label_manifest.append({'condition':condition,'origin':origin,
                                   'originParameterHash':model.parameter_digest(teacher),
                                   'datasets':datasets})
            for kind in ('nn','linear','quadratic','memory'):
                candidates = []
                for epochs in (8,32,128):
                    state = model.init(seed, kind=kind)
                    state['epochs'] = epochs
                    fitted = model.train_on_labels(state, datasets['train'], provenance=f'common-frozen-{origin}')
                    def mse(split):
                        return float(np.mean([(np.asarray(model.evaluate(fitted,row['features'],row['space'])['raw']) - row['target'])**2 for row in datasets[split]]))
                    candidates.append((mse('validation'), epochs, mse('test')))
                chosen = min(candidates, key=lambda item:(item[0],item[1]))
                rows.append({'condition':condition,'origin':origin,'method':kind,
                             'selectedEpochs':chosen[1],'validationMSE':chosen[0],'testMSE':chosen[2],
                             'allValidation': [{'epochs':e,'mse':v} for v,e,t in candidates],
                             'scope':'frozen learned valuation-function approximation; synthetic teacher-origin bias remains'})
    write(ROOT/'data'/'matched-targets.json',label_manifest)
    return rows


def stress(states):
    rows=[]
    seed=data.SEEDS[0]
    point=data.probes()[0]
    for kind in ('nn','linear','quadratic','memory'):
        state=states[('nonlinear',seed,0,kind)]
        initial=readout(state)
        checkpoints=[]
        stopped=None
        for i in range(1000):
            record={'id':f'stress-{kind}-{i}','space':'relational','cue':point['features'],
                    'observed':point['features'],'confirmed':True,'origin':'synthetic',
                    'text':'同じ変更と同じ結末を確認した研究用反復。感情の教師値はない。'}
            try:
                state=model.update(state,record)
            except ValueError as error:
                stopped={'at':i,'error':str(error),'originalRetained':True}
                break
            if i+1 in (1,10,100,500,1000):
                out=readout(state)
                checkpoints.append({'count':i+1,'parameterNorm':model.parameter_norm(state),
                                    'saturationFraction':float((np.abs(out)>.95).mean()),
                                    'readout':out.tolist(),'effect':difference(initial,out)})
                print('stress',kind,i+1,flush=True)
        reinforced=readout(state)
        for i in range(12):
            state=model.update(state,{'id':f'stress-opposite-{kind}-{i}','space':'relational',
                                      'cue':point['features'],'observed':(1-np.asarray(point['features'])).tolist(),
                                      'confirmed':True,'origin':'synthetic',
                                      'text':'同じ行為の後、以前とは反対の事実的結末を確認した研究用反復。'})
        rows.append({'kind':kind,'checkpoints':checkpoints,'stopped':stopped,
                     'afterDifferentResults':difference(reinforced,readout(state)),
                     'afterDifferentReadout':readout(state).tolist(),
                     'finite':bool(np.isfinite(readout(state)).all()),
                     'scope':'different observed facts are not desired emotion labels'})
    return rows


def main():
    start=time.perf_counter()
    settings={'schema':'frontalis-predeclared-numeric-v1','seeds':list(data.SEEDS),
              'conditions':list(data.CONDITIONS),'methods':list(METHODS),'trainCount':48,
              'unknownCount':96,'gain':1.25,'learningRate':.025,'epochs':8,'replayLimit':64,
              'diagnosticEpochGrid':[8,32,128],'stressCount':1000,
              'codeHashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                            for p in (ROOT/'npn'/'data.py',ROOT/'npn'/'model.py',Path(__file__))},
              'protocolHash':hashlib.sha256((ROOT/'docs'/'01-protocol.md').read_bytes()).hexdigest() if (ROOT/'docs'/'01-protocol.md').exists() else None,
              'noOptimalValueTargets':True,'noFamilyWinnerSelectedForDialogue':True}
    write(ROOT/'reports'/'numeric-settings.json',settings)
    rows=[]; formation=[]; states={}
    for condition in ('nonlinear','linear','quadratic'):
        for seed in data.SEEDS:
            base=readout(model.init(seed))
            for person in range(4):
                events=data.stream(seed,person,condition)
                if seed==data.SEEDS[0]:
                    write(ROOT/'data'/condition/f'seed-{seed}'/f'p{person}.json',events)
                for method in METHODS:
                    state,checkpoints=train(events,state_for(method,seed))
                    states[(condition,seed,person,method)]=state
                    out=readout(state)
                    heldout=data.unknown(seed,person,condition)
                    own_error=np.mean([(np.asarray(model.evaluate(state,e['cue'],e['space'])['raw'])-
                                       model.evaluate(state,e['observed'],e['space'])['raw'])**2 for e in heldout])
                    own_gain=0
                    for appraisal in state['appraisals']:
                        if max(abs(np.asarray(appraisal['target'])-appraisal['effectBefore']))>1e-8:
                            own_gain+=1
                    rows.append({'condition':condition,'seed':seed,'person':person,'method':method,
                                 'formation':difference(base,out),'readout':out.tolist(),
                                 'ownTargetAssociationMSE':float(own_error),
                                 'ownTargetWarning':'Targets differ across trajectories; this is not an across-method accuracy ranking.',
                                 'parameterChanged':model.parameter_digest(state_for(method,seed))!=model.parameter_digest(state),
                                 'parameterNorm':model.parameter_norm(state),'selfAmplifiedEvents':own_gain,
                                 'forecastFrozen':state['fixedPredictionGuard']==model.GUARD})
                    formation.append({'condition':condition,'seed':seed,'person':person,'method':method,'checkpoints':checkpoints})
                    if seed==data.SEEDS[0]:
                        save(ROOT/'models'/condition/f'seed-{seed}'/f'{method}-p{person}.json',state)
                        if person==0 and method=='nn':
                            save(ROOT/'models'/condition/f'seed-{seed}'/'initial.json',model.init(seed))
                    print('fit',condition,seed,person,method,flush=True)
    differentiation=[]
    for condition in data.CONDITIONS:
        for seed in data.SEEDS:
            for method in METHODS:
                arrays=[readout(states[(condition,seed,p,method)]) for p in range(4)]
                pairs=[np.abs(arrays[i]-arrays[j]) for i in range(4) for j in range(i+1,4)]
                differentiation.append({'condition':condition,'seed':seed,'method':method,
                                        'meanSeriesDifference':float(np.mean(pairs)),
                                        'byChannel':dict(zip(model.CHANNELS,np.mean(pairs,axis=(0,1)).tolist()))})
    intervention_rows=interventions(states)
    control=states[('nonlinear',data.SEEDS[0],0,'nn')]
    before=model.parameter_digest(control)
    invalid=data.counterfactuals(data.stream(data.SEEDS[0],0), 'no-observation')[0]
    rejected=False
    try: model.update(control,invalid)
    except ValueError: rejected=True
    neutral={'id':'neutral-event','space':'relational','cue':[.5]*8,'observed':[.5]*8,
             'confirmed':True,'origin':'synthetic','text':'識別できる出来事も結果もない研究用入力。'}
    neutral_after=model.update(control,neutral)
    controls={'unconfirmedRejected':rejected,'rejectedInputParameterUnchanged':before==model.parameter_digest(control),
              'noInformationParameterUnchanged':before==model.parameter_digest(neutral_after)}
    result={'schema':'frontalis-numeric-v1','rows':rows,'formation':formation,
            'differentiation':differentiation,'interventions':intervention_rows,
            'controls':controls,'matchedTarget':matched_target(states),'stress':stress(states),
            'probeOrder':[p['id'] for p in data.probes()],
            'elapsedSeconds':time.perf_counter()-start,
            'limits':['Subjective value has no external correctness target.',
                      'Initial random common base, channel names and self-amplification are designer assumptions.',
                      'Branch isolation preserves unrelated-space parameters by construction.',
                      'Matched-target diagnostic approximates already learned synthetic functions, not real morality.',
                      'Physical environments and feature annotations are synthetic and manually specified.']}
    write(ROOT/'reports'/'numeric.json',result)
    print('complete',result['elapsedSeconds'],flush=True)


if __name__=='__main__':
    main()
