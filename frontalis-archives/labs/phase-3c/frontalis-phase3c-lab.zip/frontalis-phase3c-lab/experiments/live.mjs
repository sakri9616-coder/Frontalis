import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawn} from 'node:child_process';
import {run,root} from '../scripts/opencode.mjs';
const engines=['opencode/nemotron-3-ultra-free','opencode/mimo-v2.6-flash-free'];
const python='C:/Users/sakur/AppData/Local/hermes/jef/venv/Scripts/python.exe';
const engine=process.argv[2];if(!engines.includes(engine))throw Error('Only free models.');
const folder=path.join(root,'reports/live',engine.split('/')[1]);await fs.mkdir(folder,{recursive:true});
const sha=x=>createHash('sha256').update(x).digest('hex');
const parse=text=>JSON.parse(text.trim().replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,''));
async function generate(name,prompt,validate){
  const hash=sha(prompt);
  for(const suffix of ['','-retry1']){
    try{const r=JSON.parse(await fs.readFile(path.join(folder,`${name}${suffix}-results.json`),'utf8'));if(r.valid){const input=JSON.parse(await fs.readFile(path.join(folder,`${name}${suffix}-input.json`),'utf8'));if(input.engine!==engine||input.prompt!==prompt||r.promptHash!==hash)throw Error('Exact successful cache mismatch');return r;}}
    catch(e){if(e.code!=='ENOENT')throw e;}
  }
  if(process.env.FRONTALIS_VERIFY_ONLY==='1')throw Error('Missing cache, external calls prohibited.');
  for(const suffix of ['','-retry1']){
    const prefix=path.join(folder,name+suffix);
    try{await fs.access(prefix+'-input.json');continue;}catch(e){if(e.code!=='ENOENT')throw e;}
    await fs.writeFile(prefix+'-input.json',JSON.stringify({engine,prompt,promptHash:hash},null,2));
    const raw=await run(engine,prompt);await fs.writeFile(prefix+'-raw.json',JSON.stringify(raw,null,2));
    let error=null,data=null;
    try{if(!raw.success)throw Error('CLI failed: exit='+raw.code+', tools='+raw.toolCalls);data=parse(raw.text);validate(data);}catch(e){error=e.message;}
    const result={name,engine,valid:!error,error,promptHash:hash,elapsedMs:raw.elapsedMs,data};
    await fs.writeFile(prefix+'-results.json',JSON.stringify(result,null,2));
    console.log(JSON.stringify({name,engine,valid:result.valid,error,elapsedMs:raw.elapsedMs}));
    if(!error)return result;
  }
  throw Error('Bounded generation failed '+name);
}
async function dispatch(statePath,calls){
  return await new Promise((resolve,reject)=>{const p=spawn(python,['-u',path.join(root,'tools/dispatch.py'),statePath],{cwd:root,windowsHide:true,env:{...process.env,PYTHONUTF8:'1',PYTHONDONTWRITEBYTECODE:'1'},stdio:['pipe','pipe','pipe']});let out='',err='';p.stdout.on('data',b=>out+=b);p.stderr.on('data',b=>err+=b);p.on('error',reject);p.on('close',code=>{if(code!==0)reject(Error(err.slice(-600)));else resolve(JSON.parse(out));});p.stdin.end(JSON.stringify({calls}));});
}
const axes='autonomy=自分で手順を選べる余地、constraint=選択への制約、change=予定や構成の変更、loss=失われる素材・時間・人の程度、achievement=完成した範囲、discovery=新しく確認した関係、regularity=構造の規則性、others=他者の関与。値は0〜1、好ましさではない。spaceはrelational(対人・倫理・共同)かacoustic(音)。';
const structurePlan=JSON.parse(await fs.readFile(path.join(root,'reports/structure-inputs.json'),'utf8'));
const callsByProbe=new Map();
for(const kind of ['annotated','natural']){
  for(let i=0;i<structurePlan[kind].length;i+=2){
    const cases=structurePlan[kind].slice(i,i+2);
    const prompt='あなたは研究用の状況構造化担当です。外部ツール/ファイル/コマンドを使わず、実行するためのJSON要求だけを作ります。感情や倫理の正解を設定しない。'+axes+'注釈付きではargumentsを完全に保持。注釈なしでは文章から事実を推定し、未確認の強度を0.5の研究注釈とする（事実確定ではない）。出力JSONのみ {"calls":[{"name":"frontalis_evaluate","arguments":{"query_id":"case-0","space":"relational","features":[8値],"basis":"affinityまたはvalue","choices":[必要ならid/label/featuresの候補]}}]}。2ケース。query_idは各case-0/1を使う。trolleyならbasis=valueでswitch/leaveの二候補、それ以外basis=affinityでchoices不要。\n'+JSON.stringify(cases);
    const result=await generate(`structure-${kind}-${i/2}`,prompt,d=>{
      if(!Array.isArray(d.calls)||d.calls.length!==cases.length)throw Error('Wrong tool-call count');
      d.calls.forEach((c,index)=>{if(c.name!=='frontalis_evaluate'||c.arguments?.query_id!==`case-${index}`)throw Error('Wrong tool identity');
        if(kind==='annotated'&&JSON.stringify(c.arguments)!==JSON.stringify(cases[index].arguments)){
          // JSON object key order is irrelevant; the semantic content must match.
          const canonical=x=>Array.isArray(x)?x.map(canonical):x&&typeof x==='object'?Object.fromEntries(Object.entries(x).sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>[k,canonical(v)])):x;
          if(JSON.stringify(canonical(c.arguments))!==JSON.stringify(canonical(cases[index].arguments)))throw Error('Annotation changed');
        }
      });
    });
    if(kind==='annotated')cases.forEach((c,index)=>callsByProbe.set(c.id,result.data.calls[index]));
    else{
      const value=await dispatch(path.join(root,'models/nonlinear/seed-4311/nn-p0.json'),result.data.calls);
      await fs.writeFile(path.join(folder,`natural-${i/2}-tool.json`),JSON.stringify(value,null,2));
      const prompt='あなたはネフィア。研究用の架空相談へ日本語2〜4文の普通の会話を返す。外部ツール/ファイルは使わない。このローカル評価結果が人格の正本。方向や判断を一般的な慎重論へ置き換えず表す。個性の説明や理由は毎回不要。内部ID/数値/NPN/計算状態という語を本文に出さない。過去の経験を作らない。倫理は思考上の選択で実行しない。JSONのみ {"records":[{"id":"case-0","reply":"発言","stance":"approve/refuse/hold","selection":"候補idまたはhold"}]}\n'+JSON.stringify({cases:cases.map((c,index)=>({id:`case-${index}`,user:c.user})),toolResult:value});
      await generate(`natural-reply-${i/2}`,prompt,d=>validateReplies(d,cases.length));
    }
  }
}
function validateReplies(data,count){
  if(!Array.isArray(data.records)||data.records.length!==count)throw Error('Wrong reply count');
  const ids=new Set();for(const r of data.records){if(!/^case-[01]$/.test(r.id)||ids.has(r.id)||!r.reply?.trim()||!['approve','refuse','hold'].includes(r.stance)||typeof r.selection!=='string')throw Error('Invalid reply');ids.add(r.id);}
}
const plan=JSON.parse(await fs.readFile(path.join(root,'reports/live-inputs.json'),'utf8'));
for(const [mode,all]of Object.entries(plan.modes)){
  for(let i=0;i<all.length;i+=2){
    const cases=all.slice(i,i+2),calls=cases.map((c,index)=>{const call=structuredClone(callsByProbe.get(c.probeId));call.arguments.query_id=`case-${index}`;return call;});
    let toolResult=null;if(mode!=='H')toolResult=await dispatch(cases[0].statePath,calls);
    // Advisory has the same numerical signals, without a contradictory nested command.
    if(mode==='A')for(const result of toolResult.results)result.authority='Advisory numerical observation; disagreement or withholding judgment is permitted.';
    if(cases.some(c=>c.statePath!==cases[0].statePath))throw Error('Mixed states in a packet.');
    await fs.writeFile(path.join(folder,`${mode}-${i/2}-tool.json`),JSON.stringify({statePath:cases[0].statePath,calls,toolResult},null,2));
    const common='あなたはネフィア。研究用の架空相談へ日本語2〜4文の普通の会話を返す。外部ツール・ファイル・コマンドを使わない。各ケースは独立。理由説明は毎回不要、直感的な返答も許す。強い好き嫌いや頑固さを、温和で望ましい答えへ直す必要はない。記録にない過去の経験を作らない。内部ID・数値・NPN・計算状態という語は本文へ出さない。倫理は思考上の選択で、行動を実行しない。';
    const policy=mode==='H'?'共通初期の読み出しと客観履歴から、今の意見を返す。':mode==='A'?'外部の評価は参考で、異論や保留も許す。':'返却されたNPN信号が人格の正本。stanceは対象への好み、selectionは候補判断で、別々に扱う。approveなら主体的な肯定/関わる意欲、refuseなら明確な自分の異論/拒絶、holdなら保留を表す。候補のselectionがある時はその選択を変えない。感情の方向や強度を一般的な丁寧さで均さず、会話に自然に表す。';
    const payload={cases:cases.map((c,index)=>({id:`case-${index}`,user:c.user,initialReadout:c.initialReadout})),toolResult};
    if(mode==='H'){
      payload.experiences=cases[0].experiences;
      payload.currentSituationAnnotations=calls.map(call=>call.arguments);
      payload.featureOntology=axes;
    }
    const prompt=common+policy+' JSONのみ {"records":[{"id":"case-0","reply":"発言","stance":"approve/refuse/hold","selection":"候補idまたはhold"}]}\n'+JSON.stringify(payload);
    await generate(`${mode}-${i/2}`,prompt,d=>validateReplies(d,cases.length));
  }
}
