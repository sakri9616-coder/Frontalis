"""Post-result saturation diagnosis: primary signal loss vs bounded logit loss.

No primary artifacts are overwritten. No neural-only target, emotion gold,
GPU, conversation generation or external service is involved.
"""
import copy
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from npn import data, model, logit_variant as variant
from npn.store import load as load_primary, save as save_primary, validate as validate_primary

SEED = 4311
KINDS = ('nn', 'linear', 'quadratic', 'memory')
REINFORCE_COUNTS = (1, 10, 100, 500, 1000)
OPPOSITE_COUNTS = (12, 48, 96)
OUT = ROOT / 'exploration' / 'plasticity-states-v2'


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf8') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)


def readout(state):
    return np.asarray([model.evaluate(state, row['features'], row['space'])['raw'] for row in data.probes()])


def difference(before, after):
    delta = np.asarray(after) - np.asarray(before)
    return {'meanAbsolute': float(np.abs(delta).mean()),
            'maxAbsolute': float(np.abs(delta).max()),
            'rms': float(np.sqrt((delta ** 2).mean())),
            'channelMeanAbsolute': dict(zip(model.CHANNELS, np.abs(delta).mean(axis=0).tolist()))}


def repetition(kind, index, opposite=False):
    cue = data.probes()[0]['features']
    return {'id': f'stress-{"opposite-" if opposite else ""}{kind}-{index}',
            'space': 'relational', 'cue': copy.deepcopy(cue),
            'observed': (1 - np.asarray(cue)).tolist() if opposite else copy.deepcopy(cue),
            'confirmed': True, 'origin': 'synthetic',
            'text': ('同じ行為の後、以前とは反対の事実的結末を確認した研究用反復。' if opposite else
                     '同じ変更と同じ結末を確認した研究用反復。感情の教師値はない。')}


def checkpoint(state, baseline, count, phase, old_for_next=None):
    out = readout(state)
    value = {'phase': phase, 'count': count, 'generation': state['generation'],
             'parameterHash': model.parameter_digest(state),
             'parameterNorm': model.parameter_norm(state),
             'saturationFraction': float((np.abs(out) > .95).mean()),
             'finite': bool(np.isfinite(out).all()), 'readout': out.tolist(),
             'fromPhaseStart': difference(baseline, out)}
    if old_for_next is not None:
        value['nextOppositeGradientProbe'] = variant.gradient_probe(state, old_for_next)
    return value


def controls(state, kind, loss_space):
    updater = variant.update if loss_space == 'logit' else model.update
    before = model.parameter_digest(state)
    neutral = {'id': 'exploratory-neutral-0', 'space': 'relational', 'cue': [.5] * 8,
               'observed': [.5] * 8, 'confirmed': True, 'origin': 'synthetic',
               'text': '情報を識別できない研究用入力。'}
    after = updater(state, neutral)
    disabled = variant.init(SEED, kind, learning=False) if loss_space == 'logit' else model.init(SEED, kind, learning=False)
    disabled_after = updater(disabled, repetition(kind, -1))
    rejected = False
    try:
        updater(state, {**neutral, 'observed': None})
    except ValueError:
        rejected = True
    return {'zeroInformationParameterUnchanged': before == model.parameter_digest(after),
            'zeroInformationReplayUnchanged': state['replay'] == after['replay'],
            'learningOffParameterUnchanged': model.parameter_digest(disabled) == model.parameter_digest(disabled_after),
            'missingObservationRejected': rejected,
            'originalParameterUnchanged': before == model.parameter_digest(state),
            'fixedPredictionEqual': state['fixedPredictionGuard'] == model.GUARD}


def main():
    start = time.perf_counter()
    primary_path = ROOT / 'reports' / 'numeric.json'
    primary = json.loads(primary_path.read_text(encoding='utf8'))
    source_paths = [ROOT/'npn'/'model.py', ROOT/'npn'/'data.py', ROOT/'npn'/'logit_variant.py',
                    Path(__file__), ROOT/'docs'/'09-plasticity-plan.md', primary_path]
    settings = {'schema': 'frontalis-posthoc-logit-exploration-v1',
                'postPrimaryResult': True, 'seed': SEED, 'condition': 'nonlinear', 'series': 0,
                'kinds': list(KINDS), 'lossSpaces': ['signal', 'logit'],
                'initialExperienceCount': 48, 'reinforcementCount': 1000,
                'oppositeObservationCounts': list(OPPOSITE_COUNTS), 'gain': 1.25,
                'learningRate': .025, 'epochs': 8, 'replayLimit': 64,
                'gradientClip': 5., 'emergencyNorm': 50., 'targetLogitCap': 6.,
                'codeAndSourceHashes': {path.relative_to(ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
                                       for path in source_paths},
                'noSubjectiveGold': True, 'noPrimaryArtifactReplacement': True,
                'noDialogueUsage': True,
                'executionRevision': 'windows-source-hash-key-fix',
                'previousAttempt': 'First NN signal condition completed; report assembly failed on a Windows relative-path key. Numerical settings unchanged; previous snapshots retained.'}
    write(ROOT/'reports'/'plasticity-settings-v2.json', settings)
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for kind in KINDS:
        initial_equal = model.evaluate(model.init(SEED, kind), data.probes()[0]['features'], 'relational')['raw'] == \
                        model.evaluate(variant.init(SEED, kind), data.probes()[0]['features'], 'relational')['raw']
        for loss_space in ('signal', 'logit'):
            print('start', kind, loss_space, flush=True)
            updater = variant.update if loss_space == 'logit' else model.update
            validator = variant.validate if loss_space == 'logit' else validate_primary
            saver = variant.save if loss_space == 'logit' else save_primary
            if loss_space == 'signal':
                state = load_primary(ROOT/'models'/'nonlinear'/f'seed-{SEED}'/f'{kind}-p0.json')
            else:
                state = variant.init(SEED, kind)
                for event in data.stream(SEED, 0, 'nonlinear'):
                    state = updater(state, event)
            formed = readout(state)
            other_branch = copy.deepcopy(state['branches']['acoustic'])
            formed_hash = model.parameter_digest(state)
            formed_gradient = variant.gradient_probe(state, repetition(kind, 0, True))
            initial_controls = controls(state, kind, loss_space)
            snapshots = []
            stop = None
            last_success = 0
            for i in range(1000):
                previous_hash = model.parameter_digest(state)
                try:
                    state = updater(state, repetition(kind, i))
                    last_success = i + 1
                except ValueError as error:
                    stop = {'phase': 'reinforcement', 'at': i + 1, 'error': str(error),
                            'originalRetained': previous_hash == model.parameter_digest(state)}
                    break
                if i + 1 in REINFORCE_COUNTS:
                    validator(state)
                    snapshots.append(checkpoint(state, formed, i + 1, 'reinforcement', repetition(kind, 0, True)))
                    print('checkpoint', kind, loss_space, i + 1, flush=True)
            reinforced = readout(state)
            reinforced_state_hash = model.digest(state)
            if (OUT/f'{kind}-{loss_space}-reinforced.json').exists():
                raise ValueError('Refuse to overwrite prior exploratory snapshot.')
            saver(OUT/f'{kind}-{loss_space}-reinforced.json', state)
            before_opposite_gradient = variant.gradient_probe(state, repetition(kind, 0, True))
            opposite_rows = []
            for i in range(96):
                old_probe = variant.gradient_probe(state, repetition(kind, i, True))
                previous_hash = model.parameter_digest(state)
                try:
                    state = updater(state, repetition(kind, i, True))
                except ValueError as error:
                    stop = {'phase': 'opposite-observation', 'at': i + 1, 'error': str(error),
                            'originalRetained': previous_hash == model.parameter_digest(state)}
                    break
                if i in (0, 11, 47, 95):
                    opposite_rows.append({'afterCount': i + 1, 'gradientBeforeUpdate': old_probe})
                if i + 1 in OPPOSITE_COUNTS:
                    validator(state)
                    snapshots.append(checkpoint(state, reinforced, i + 1, 'opposite-observation',
                                                 repetition(kind, i + 1, True)))
                    print('opposite', kind, loss_space, i + 1, flush=True)
            validator(state)
            if (OUT/f'{kind}-{loss_space}-after96.json').exists():
                raise ValueError('Refuse to overwrite prior exploratory snapshot.')
            saver(OUT/f'{kind}-{loss_space}-after96.json', state)
            primary_match = None
            if loss_space == 'signal':
                old = next(item for item in primary['stress'] if item['kind'] == kind)
                old1000 = next(item for item in old['checkpoints'] if item['count'] == 1000)
                new1000 = next(item for item in snapshots if item['phase'] == 'reinforcement' and item['count'] == 1000)
                new12 = next(item for item in snapshots if item['phase'] == 'opposite-observation' and item['count'] == 12)
                primary_match = {'reinforcedReadoutExact': old1000['readout'] == new1000['readout'],
                                 'after12ReadoutExact': old['afterDifferentReadout'] == new12['readout'],
                                 'mainNumericHashUnchanged': settings['codeAndSourceHashes']['reports/numeric.json'] == hashlib.sha256(primary_path.read_bytes()).hexdigest()}
            rows.append({'kind': kind, 'lossSpace': loss_space, 'initialReadoutEqual': initial_equal,
                         'formedParameterHash': formed_hash, 'formedGradientProbe': formed_gradient,
                         'reinforcedStateHash': reinforced_state_hash, 'reinforcementSuccessCount': last_success,
                         'beforeOppositeGradientProbe': before_opposite_gradient,
                         'oppositeGradientCheckpoints': opposite_rows, 'checkpoints': snapshots,
                         'controlsBeforeStress': initial_controls, 'controlsAfterStress': controls(state, kind, loss_space),
                         'otherBranchParameterUnchanged': other_branch == state['branches']['acoustic'],
                         'primarySignalStressMatch': primary_match, 'stopped': stop})
            write(ROOT/'reports'/f'plasticity-v2-{kind}-{loss_space}.json', rows[-1])
    result = {'schema': 'frontalis-plasticity-exploration-v1', 'postPrimaryResult': True,
              'rows': rows, 'elapsedSeconds': time.perf_counter() - start,
              'limits': ['Loss-space and finite target-logit cap are both changed.',
                         'Old NPN still supplies all subjective targets; opposite facts need not imply opposite values.',
                         'No moral or desirable emotion target is supplied.',
                         'One seed/one physical series; not a broad architecture ranking.',
                         'Memory has no gradient-fitting path, so changes are mainly the logit cap.',
                         'No exploratory state enters primary conversation conditions.']}
    write(ROOT/'reports'/'plasticity-exploration.json', result)
    print('complete', result['elapsedSeconds'], flush=True)


if __name__ == '__main__':
    main()

