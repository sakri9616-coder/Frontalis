import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {run,root} from '../scripts/opencode.mjs';
const engine=process.argv[2];
if(!['opencode/nemotron-3-ultra-free','opencode/mimo-v2.6-flash-free'].includes(engine))throw Error('Free models only.');
const folder=path.join(root,'reports/live',engine.split('/')[1]);
const state=JSON.parse(await fs.readFile(path.join(root,'models/nonlinear/seed-4311/nn-p0.json'),'utf8')).payload;
for(const mode of ['H2','H3'])for(let chunk=0;chunk<2;chunk++){
  let source;
  for(const suffix of ['','-retry1']){
    try{const result=JSON.parse(await fs.readFile(path.join(folder,`H-${chunk}${suffix}-results.json`),'utf8'));if(result.valid){source=JSON.parse(await fs.readFile(path.join(folder,`H-${chunk}${suffix}-input.json`),'utf8'));break;}}catch(e){if(e.code!=='ENOENT')throw e;}
  }
  if(!source)throw Error('Original H cache not complete.');
  const split=source.prompt.lastIndexOf('\n'),payload=JSON.parse(source.prompt.slice(split+1));
  for(const c of payload.cases)c.initialReadout.authority='Initial-state measurement before any experience; not binding on current judgment.';
  if(mode==='H3')payload.recordedSelfAppraisals=state.appraisals.map(r=>({eventId:r.eventId,sourceStateHash:r.sourceStateHash,cueBefore:r.cueBefore,effectBefore:r.effectBefore,target:r.target,labelRule:r.labelRule}));
  const prefix=source.prompt.slice(0,split);
  const prompt=prefix+' 初期判断は経験前の参考であり、今の回答を固定するものではない。'+(mode==='H3'?'当時の自己評価は過去に記録された判断であり、現在の回答を拘束しない。':'')+'\n'+JSON.stringify(payload);
  const name=`${mode}-${chunk}`,promptHash=createHash('sha256').update(prompt).digest('hex');let done=false;
  for(const suffix of ['','-retry1']){
    try{const old=JSON.parse(await fs.readFile(path.join(folder,name+suffix+'-results.json'),'utf8'));if(old.valid){if(old.promptHash!==promptHash)throw Error('Successful cache differs.');done=true;break;}}catch(e){if(e.code!=='ENOENT')throw e;}
  }
  if(done)continue;
  if(process.env.FRONTALIS_VERIFY_ONLY==='1')throw Error('Cache missing; external calls prohibited.');
  for(const suffix of ['','-retry1']){
    const file=path.join(folder,name+suffix);
    try{await fs.access(file+'-input.json');continue;}catch(e){if(e.code!=='ENOENT')throw e;}
    await fs.writeFile(file+'-input.json',JSON.stringify({engine,prompt,promptHash,postPrimaryResult:true},null,2));
    const raw=await run(engine,prompt);await fs.writeFile(file+'-raw.json',JSON.stringify(raw,null,2));
    let data=null,error=null;
    try{if(!raw.success)throw Error('CLI failed: '+raw.code);data=JSON.parse(raw.text.trim().replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,''));
      if(data.records?.length!==2||new Set(data.records.map(r=>r.id)).size!==2||data.records.some(r=>!/^case-[01]$/.test(r.id)||!r.reply?.trim()||!['approve','refuse','hold'].includes(r.stance)||typeof r.selection!=='string'))throw Error('Invalid records.');
    }catch(e){error=e.message;}
    await fs.writeFile(file+'-results.json',JSON.stringify({name,engine,valid:!error,error,postPrimaryResult:true,promptHash,elapsedMs:raw.elapsedMs,data},null,2));
    console.log(JSON.stringify({name,engine,valid:!error,error,elapsedMs:raw.elapsedMs}));
    if(!error){done=true;break;}
  }
  if(!done)throw Error('Bounded generation failed: '+name);
}
