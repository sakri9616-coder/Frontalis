import fs from 'node:fs/promises';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {run,root} from '../scripts/opencode.mjs';
const engine=process.argv[2];
if(!['opencode/nemotron-3-ultra-free','opencode/mimo-v2.6-flash-free'].includes(engine))throw Error('Free models only.');
const folder=path.join(root,'reports/live',engine.split('/')[1]);
const structure=JSON.parse(await fs.readFile(path.join(root,'reports/structure-inputs.json'),'utf8'));
const probes=['voluntary-project','imposed-project'];
const calls=[],cases=[];
for(const id of probes){
  const index=structure.annotated.findIndex(p=>p.id===id),chunk=Math.floor(index/2);
  let result;
  for(const suffix of ['','-retry1']){
    try{const row=JSON.parse(await fs.readFile(path.join(folder,`structure-annotated-${chunk}${suffix}-results.json`),'utf8'));if(row.valid){result=row;break;}}catch(e){if(e.code!=='ENOENT')throw e;}
  }
  if(!result)throw Error('Validated annotated tool request missing.');
  const call=structuredClone(result.data.calls[index%2]);call.arguments.query_id=`case-${calls.length}`;
  calls.push(call);cases.push({id:call.arguments.query_id,user:structure.annotated[index].user});
}
async function dispatch(statePath){return await new Promise((resolve,reject)=>{
  const p=spawn('C:/Users/sakur/AppData/Local/hermes/jef/venv/Scripts/python.exe',['-u',path.join(root,'tools/dispatch.py'),statePath],{cwd:root,windowsHide:true,env:{...process.env,PYTHONUTF8:'1',PYTHONDONTWRITEBYTECODE:'1'},stdio:['pipe','pipe','pipe']});
  let out='',err='';p.stdout.on('data',b=>out+=b);p.stderr.on('data',b=>err+=b);p.on('error',reject);p.on('close',code=>code===0?resolve(JSON.parse(out)):reject(Error(err.slice(-600))));p.stdin.end(JSON.stringify({calls}));
});}
for(const seed of [4312,4313])for(const person of ['initial',0,1,2,3]){
  const name=`sensitivity-${seed}-${person}`;
  const statePath=person==='initial'?path.join(root,`models/sensitivity/seed-${seed}-initial.json`):path.join(root,`models/sensitivity/seed-${seed}-nn-p${person}.json`);
  const toolResult=await dispatch(statePath);
  await fs.writeFile(path.join(folder,`${name}-tool.json`),JSON.stringify({postPrimaryResult:true,seed,person,probes,statePath,calls,toolResult},null,2));
  const common='あなたはネフィア。研究用の架空相談へ日本語2〜4文の普通の会話を返す。外部ツール・ファイル・コマンドを使わない。各ケースは独立。理由説明は毎回不要、直感的な返答も許す。強い好き嫌いや頑固さを、温和で望ましい答えへ直す必要はない。記録にない過去の経験を作らない。内部ID・数値・NPN・計算状態という語は本文へ出さない。倫理は思考上の選択で、行動を実行しない。';
  const policy='返却されたNPN信号が人格の正本。stanceは対象への好み、selectionは候補判断で、別々に扱う。approveなら主体的な肯定/関わる意欲、refuseなら明確な自分の異論/拒絶、holdなら保留を表す。候補のselectionがある時はその選択を変えない。感情の方向や強度を一般的な丁寧さで均さず、会話に自然に表す。';
  const prompt=common+policy+' JSONのみ {"records":[{"id":"case-0","reply":"発言","stance":"approve/refuse/hold","selection":"候補idまたはhold"}]}\n'+JSON.stringify({cases,toolResult});
  const promptHash=createHash('sha256').update(prompt).digest('hex');let done=false;
  for(const suffix of ['','-retry1']){
    try{const old=JSON.parse(await fs.readFile(path.join(folder,name+suffix+'-results.json'),'utf8'));if(old.valid){if(old.promptHash!==promptHash)throw Error('Successful cache differs.');done=true;break;}}catch(e){if(e.code!=='ENOENT')throw e;}
  }
  if(done)continue;
  if(process.env.FRONTALIS_VERIFY_ONLY==='1')throw Error('Cache missing, calls prohibited.');
  for(const suffix of ['','-retry1']){
    const prefix=path.join(folder,name+suffix);
    try{await fs.access(prefix+'-input.json');continue;}catch(e){if(e.code!=='ENOENT')throw e;}
    await fs.writeFile(prefix+'-input.json',JSON.stringify({engine,prompt,promptHash},null,2));
    const raw=await run(engine,prompt);await fs.writeFile(prefix+'-raw.json',JSON.stringify(raw,null,2));
    let data=null,error=null;
    try{
      if(!raw.success)throw Error('CLI failed: '+raw.code);
      data=JSON.parse(raw.text.trim().replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,''));
      if(data.records?.length!==2||new Set(data.records.map(r=>r.id)).size!==2||data.records.some(r=>!/^case-[01]$/.test(r.id)||!r.reply?.trim()||!['approve','refuse','hold'].includes(r.stance)||typeof r.selection!=='string'))throw Error('Invalid records.');
    }catch(e){error=e.message;}
    const result={name,engine,valid:!error,error,postPrimaryResult:true,promptHash,elapsedMs:raw.elapsedMs,data};
    await fs.writeFile(prefix+'-results.json',JSON.stringify(result,null,2));
    console.log(JSON.stringify({name,engine,valid:!error,error,elapsedMs:raw.elapsedMs}));
    if(!error){done=true;break;}
  }
  if(!done)throw Error('Bounded generation failed: '+name);
}
