"""Mechanical summary of saved primary results; never selects dialogue cases."""
import json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
r=json.loads((ROOT/'reports'/'numeric.json').read_text(encoding='utf8'))
summary={'formation':[],'matchedTargets':[],'matchedByOrigin':[], 'seedSensitivity':[],
         'differentiatedFunctions':{},'source':'reports/numeric.json',
         'note':'Descriptive derived summary; no moral or desired affect labels.'}
for condition in ('linear','quadratic','nonlinear'):
    for method in ('nn','linear','quadratic','memory','nn-off','nn-gain1'):
        rows=[x for x in r['rows'] if x['condition']==condition and x['method']==method]
        ds=[x for x in r['differentiation'] if x['condition']==condition and x['method']==method]
        summary['formation'].append({'condition':condition,'method':method,
           'initialChange':float(np.mean([x['formation']['meanAbsolute'] for x in rows])),
           'betweenSeries':float(np.mean([x['meanSeriesDifference'] for x in ds])),
           'changedStates':sum(x['parameterChanged'] for x in rows),'states':len(rows)})
    for method in ('nn','linear','quadratic','memory'):
        ds=[x for x in r['matchedTarget'] if x['condition']==condition and x['method']==method]
        summary['matchedTargets'].append({'condition':condition,'method':method,'testMSE':float(np.mean([x['testMSE'] for x in ds]))})
for origin in ('nn','linear','quadratic','memory'):
    for method in ('nn','linear','quadratic','memory'):
        ds=[x for x in r['matchedTarget'] if x['origin']==origin and x['method']==method]
        summary['matchedByOrigin'].append({'origin':origin,'method':method,'testMSE':float(np.mean([x['testMSE'] for x in ds]))})
for row in r['rows']:
    if row['method']=='nn' and row['condition']=='nonlinear':
        summary['seedSensitivity'].append({'seed':row['seed'],'person':row['person'],
           'affinityByProbe':dict(zip(r['probeOrder'], [v[0] for v in row['readout']]))})
array=np.asarray([x['readout'] for x in r['rows'] if x['method']=='nn']).reshape(-1,7)
summary['differentiatedFunctions']={
    'allNNUnknownScenarios':len(array),
    'affinityCuriosityOppositeAt005':int(((np.abs(array[:,0])>.05)&(np.abs(array[:,1])>.05)&(array[:,0]*array[:,1]<0)).sum()),
    'affinityValueOppositeAt005':int(((np.abs(array[:,0])>.05)&(np.abs(array[:,2])>.05)&(array[:,0]*array[:,2]<0)).sum()),
    'correlation':np.corrcoef(array.T).tolist(),
    'note':'Opposite sign demonstrates distinct readouts, not an external definition of correct feelings; independent channels existed at initialization.'}
(ROOT/'reports'/'numeric-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')
print(json.dumps(summary['differentiatedFunctions'],ensure_ascii=False))
