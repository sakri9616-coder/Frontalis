"""Small CPU-only self-appraisal demo; writes only a new runtime directory."""
import json,sys,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from npn.model import init,evaluate,update
from npn.store import Store

event={'id':'example-confirmed-fact','origin':'synthetic','confirmed':True,'space':'relational',
 'text':'共同制作の手順を変更した。完成範囲と失われた作業時間を研究用の事実特徴で記録した。',
 'cue':[.25,.8,.7,.2,.55,.3,.4,.8],
 'observed':[.7,.25,.45,.65,.6,.7,.5,.8]}
initial=init(4311)
before=evaluate(initial,event['cue'],event['space'])
learned=update(initial,event)
after=evaluate(learned,event['cue'],event['space'])
folder=ROOT/'runtime'/'learning-demo'/uuid.uuid4().hex
store=Store(folder)
head=store.commit(initial,None,'initial')
head=store.commit(learned,head)
restored=store.load()
assert restored==learned
rollback_head=store.rollback(0,head)
assert store.load()==initial
print(json.dumps({'directory':str(folder),'before':before['channels'],'after':after['channels'],
 'oldAppraisal':learned['appraisals'][-1],
 'forecastUnchanged':before['predictedOutcome']==after['predictedOutcome'],
 'learnedStoreGeneration':head,'rollbackStoreGeneration':rollback_head,
 'restoredNPNExperienceCount':store.load()['generation']},ensure_ascii=False,indent=2))
