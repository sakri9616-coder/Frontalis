# 読取専用NPNツールの独立境界レビュー

対象は `tools/evaluate.py` と `scripts/tool_cli.mjs`。LLM呼び出しを行わず、直接APIとJSONLの別process stdinで21試験を実行し、すべて合格した。Core/保存の39試験とは別の範囲である。

## 確認した性質

入力は8つの有限数値（0–1）と研究用のspace、query ID、任意の最大4候補だけを受理する。bool、NaN、Inf、未知field、任意ファイルpath、感情target、賞賛やrewardなどを受理しない。候補は全件を推論前に検証し、重複IDと保留を表す予約ID `hold` の衝突を拒否する。本文labelを変えても数値評価は変わらない。

同じ起動状態と同じ入力は同じ数値信号を返す。推論は学習パラメータ・履歴・状態snapshotを変更しない。sceneへの賛同・拒絶を示すstanceはaffinity由来であり、`stanceBasis:'affinity'` を明示した。倫理設問の候補順位はvalueで比較できるが、その選択をscene affinityの賛同と同一視しない。

起動stateのpathはLLM入力ではなくプロセス環境から固定し、研究models配下に限定する。raw JSONはschema/shape/数値/provenanceを検証、保存wrapperはhash検証を加える。trace IDにもpath文字を許可しない。起動後の評価操作は学習やファイル選択の権限を与えない。

JSONL MCPはinitialize、ping、tools/list、tools/call、通知を確認した。不正JSONの後も次の正常要求を処理でき、不正行に直前requestのIDを付けない。読取専用以外のtool名と未実装methodは拒否する。

OpenCode側は確認済み無料model IDを2種だけ許可し、有料IDの指定はCLI起動前に拒否する。設定は呼出processの環境値として渡し、既存設定ファイルを書き換えない。既存adapterを利用し、接続基盤は追加していない。

## 修正した欠陥

1. 不正JSON行で前回のrequest IDが残る場合があった。行ごとにIDを初期化し、parse error / invalid request / invalid paramsを分けた。
2. 候補数・型・重複の検査が候補推論の後だった。全入力を先行検証するよう変更した。
3. 候補ID `hold` が保留信号と衝突できた。予約IDとして拒否する。
4. 候補のdecisionBasisとscene stanceのaffinity由来が区別されていなかった。stanceBasisを明示した。

root担当がrawstateと保存wrapperの双方の読込みに対応し、wrapper改ざん拒否も別processで確認した。Coreの数値学習則には変更していない。

## 限界

この検査はtoolへの入力境界と数値返却の検査であり、自然文の意味抽出が正しいこと、LLMが返却信号を忠実に表現すること、感情が主観的に実在することを証明しない。`runTool.success` は利用されたtool名と正常終了を確認する指標であり、人格の言語表出の成功判定とは別である。

raw snapshotに署名はない。正常shapeを保った任意のparameter編集をraw検証だけで見分けることはできない。wrapper hashも真正性の署名ではなく、hashごと改変されたデータを認証する機構ではない。モデルdirectoryと起動環境は信頼境界である。

テスト用モデルとtraceは新lab配下の専用一時領域だけで扱い、終了後に削除した。既存OpenCode設定、旧研究、Nephia本体は変更していない。

