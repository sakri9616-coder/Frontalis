# Phase 3-C: 固定予測と自己更新する価値写像

## 結果を見る前の固定事項

主seedは4311 / 4312 / 4313。同一seed内の4系列と全比較方式は同じ初期出力で始める。初期基準は8×7の共通乱数readout、標準偏差0.16。人格の望ましい方向や道徳の正解は与えない。ただし、この乱数と更新則は開発者が置いた帰納バイアスであり、価値の無からの獲得を意味しない。

入力は8軸（autonomy, constraint, change, loss, achievement, discovery, regularity, others）の0–1値。2x−1へ中心化する。関係場面と音響場面の2枝を持ち、更新する枝以外の学習パラメータには触れない。これは無関係領域を保護する設計上の分離であり、学習によって領域境界を発見した成果ではない。

7出力はaffinity, curiosity, value, aesthetic, anger, joy, sadnessのsigned値。初期出力は `tanh(centered_input @ commonBase)`。共通baseは凍結し、学習残差を加える。結果予測は独立した `fixedPredictionGuard` とし、全観測に0.5を返す。予測器自体を学習する実験ではない。

## 自己評価・更新

経験は `{id,text,space,cue:[8],observed:[8],confirmed:true,origin:'synthetic'}`。受理済みの事実特徴であり、感情や人格の教師は含めない。学習前のNPNがcueとobservedを評価し、旧observed評価uから `tanh(1.25 × atanh(u))` を作る。同じtargetをcueへの連合とobserved自身の自己増幅の2点へ用いる。旧targetは当時の状態hashとともに凍結し、直近64点（最大32経験）をreplayする。

gain=1対照は自己増幅なしの連合学習であり、無更新ではない。learning=False対照がパラメータ無更新である。初期基準に戻すanchorや価値方向の正解は使わない。異なる経験による固有基準、自己強化、偏愛・嫌悪、頑固さ自体は失敗と定義しない。

学習率0.025、各経験8epoch、全勾配norm上限5、fresh Adam（β1=0.9, β2=0.999, ε=1e−8）。過去のoptimizer momentumは次の経験に持ち越さない。両入力が全軸0.5の情報ゼロ経験は、学習済み状態に偏りがあってもパラメータ更新しない。履歴と世代は追加してよい。

NNは8→16tanh→7残差。hidden初期標準偏差0.28、headとbiasは0。各枝263学習パラメータ、2枝526。共通固定56値は別に数える。線形はbias込み9×7=63 / 枝、二次回帰は一次8＋全対称二次36＋bias=45×7=315 / 枝。経験検索は同じfrozen targetのatanh残差をRBF帯域0.65で距離加重する。方式ごとの通常学習targetはその方式自身の旧出力から生じる。固定targetを共通化した診断は `train_on_labels` で別記録とし、通常の人格形成結果と混ぜない。

NN・線形・二次の残差は各方式に同じfresh Adam/epoch/replay制約を用いる。これは最適な正則化係数の探索や閉形式回帰の結果ではない。合成特徴とこの更新則でNNが勝つことを保証しない。

## 表出信号

affinityの正側を意欲、負側を嫌悪・反抗に写す。この3つを独立学習したとは扱わない。怒り・喜び・悲しみは独立signed channelの正側を表示する。感情名、positive gate、こうした表出規約は固定であり、NPNが感情概念を自力で発見した証拠にはならない。理由説明は必須ではない。意味抽出の8軸注釈自体も研究者の表現制約である。

## 数値的保全と移植

NaN / Inf、破損shape、未確認観測、重複経験ID、賞賛・報酬・感情gold・系列IDなどの教師入力を拒否する。全連続値を範囲確認する。NN/回帰は全parameter norm上限50、記憶方式は蓄積行数でnormが増えるため各保存vectorの最大norm50を緊急停止の基準とする。超過は元状態へ戻す（純関数updateは元を変更しない）。これは技術的発散検査であり、嫌悪や感情が強いことを矯正する閾値ではない。

JSON保存は本文hashと経験・自己評価のhashchainを検証する。世代storeはappend-only、rollbackも新世代として保存する。expected_headは古い状態からの上書きを防ぐ単一writer用確認であり、プロセス間lockではない。SHA-256は偶発的破損の検出であり、署名・認証や観測の真実性保証ではない。

この試作は自然文の意味を自動検証しない。LLM構造化、本人の評価、ユーザー評価、観測結果を混ぜないため、通常学習では研究用の確認済み合成観測しか受理しない。本体経験を直ちに取り込める完成品ではない。

## API

`init(seed,kind='nn',gain=1.25,learning=True)`、`evaluate(state,features,space)`、`update(state,event)`、`replay(events,seed,...)`。evaluateはraw[7] / channels / signals / 固定prediction / parameterHashを返す。`train_on_labels(state,labels,provenance='diagnostic')` は共有frozen-label診断用。保存は `npn.store.save(path,state)` / `load(path)`、生state検証は `validate(state)`。

