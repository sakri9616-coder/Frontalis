# 飽和後の可塑性: 事後探索プロトコル

主実験の結果を見た後に追加した原因診断である。主実験のdefault、状態、metrics、会話条件を置き換えない。これはNNが勝つ条件を選び直す実験ではなく、signal-space MSEの勾配消失と、旧NPNの評価自体が一様化する問題を分けて調べる。

## 結果前に固定する比較

seed4311 / nonlinear物理環境 / p0、同じ48の初期経験。4方式（NN、線形、二次、経験検索）をすべて比較する。各方式にsignal-spaceの主実装controlと独立したlogit-space variantを用意する。全方式・両条件の初期数値出力は同じ。

続いて同じpromise-change特徴に、cue=observedの事実反復を1000件与える。1 / 10 / 100 / 500 / 1000件で記録する。次にcueは同じ、observedだけを1−cueへ変更した96件を与え、12 / 48 / 96件で記録する。これは『怒りを喜びに変えよ』という教師ではなく、反対の事実的特徴を経験する条件である。旧NPNがその事実を同じ価値として評価する場合、価値の反転を正解としない。

gain1.25、lr0.025、8epoch、frozen selflabel replay64点、fresh Adam、gradient clip5、emergency norm50は主実装と同じ。追加の初期価値anchorは置かない。独立module `npn/logit_variant.py` でだけ更新する。

## 変更する点

旧状態によるobserved評価から同じ自己増幅targetを生成し、そのtargetのatanhを±6へclipした値へpreactivationをfitする。NNのhidden tanh微分は維持し、出力tanhを経由した微分だけを学習経路から外す。線形と二次も同じlogit target、経験検索は同じbounded logit残差を保存する。emotion/moral goldやNNにだけ有利なtargetを用意しない。

±6は数値precision capであり、好ましい感情や穏健さへ戻すanchorではない。比較は『損失空間と有限logit capの変更』を含む。経験検索には出力勾配そのものがないため、variantによる違いは主にこのcapの効果である。

## 原因診断と判定

- 出力飽和率（|raw|>0.95）、全probeの出力変化、signal7ch別の変化、parameter norm、finite判定、停止/拒否を記録する。
- 追加経験時の旧cue評価と旧observed評価の距離、旧targetの距離、raw出力の1−raw²、同じbounded targetに対するsignal-loss/logit-lossの原始出力勾配を記録する。
- 反対の事実が旧NPNで同じ評価になっている場合は、学習信号自体の区別消失として報告する。損失関数を変えたら必ず価値が反転するとはしない。
- learned stateに情報ゼロ経験を追加したパラメータ完全不変、learning off、無観測拒否、無関係spaceの完全保持、固定予測の完全一致を確認する。
- signal controlは主numeric stressの1000後と12追加後のreadoutに一致することを確認し、既存主実験の状態/metricsへ書き込まない。

探索状態は `exploration/plasticity-states`、結果は `reports/plasticity-exploration.json` と独立して保存する。主LLMツールのmodels配下に置かず、会話実験に使用しない。GPU/LLM/有料APIは使用しない。全8条件の結果を報告し、一番良い条件だけを採用しない。

実行上の修正: 初回のNN signal 1000反復と反対96件は完走したが、report組立て時にWindowsのsourcehash key区切りでKeyErrorが生じた。数値設計を変更せず、キーをPOSIX表記へ統一した別実行を行う。初回settingsとsnapshotは保持し、再実行のsettingsを `plasticity-settings-v2.json`、snapshotを `exploration/plasticity-states-v2` へ保存する。これは研究条件の変更ではない。

