# Claude Codeへの引き継ぎ

このファイルとREADME.md、docs/04-results.mdを最初に読んでください。Phase 2は独立プロトタイプまでで、現行ASISTへの変更は依頼されていません。実際の統合や実記憶の利用は、利用者が次の作業範囲を決めてから進めます。

## 受け取る成果物

作業領域：`C:\Users\sakur\AppData\Local\asist-shisa\nephia-npn-lab`。
依存するPhase 1：隣接する`nephia-core-lab`。このフォルダーのCore/線形学習/比較方式をread-only importしています。両フォルダーをまとめて保持してください。ASISTの本体は隣接する`asist`です。

| 実装の入口 | 実際に行うこと |
|---|---|
| `npn/model.py` | 学習する共有特徴・集合encoder・個人head・短期遷移。CPU PyTorch |
| `npn/runtime.py` | NumPy参照、長期/短期state、snapshot/restore、版・整合検査 |
| `npn/canonical.py` | Python/JS間のIEEE754正規化hash |
| `src/host.mjs` | Phase 1台帳を所有、propose/accept、学習候補作成/promote、compare、複合export/restore/rollback |
| `src/inference-port.mjs` / `scripts/inference-server.py` | 通常参照の常駐JSON Lines。actorごとのstate、snapshot hash照合 |
| `scripts/worker.py` | 別プロセスで個人headを適応。共有モデルは固定 |
| `experiments/train.py` / `evaluate.py` | 人格分割、3seed、検証によるcheckpoint選択、未知領域/変化/負の対照/アブレーション |
| `experiments/phase1-baselines.mjs` | 元のPhase 1比較方式を使う。評価正解は渡さない |
| `experiments/live.mjs` | Claudeサブスクリプション限定の助言/確定判断言語化試験。架空データのみ |
| `scripts/report.py` | 保存済み結果を集計。学習もbest seed選択もしない |

ホストの主な呼び出し順は、`propose(experience, revision)`→信頼するホストが`accept(id, revision, review)`→`prepareCheckpoint(owner, revision)`→検査後`promote(candidate, review)`→`compare(owner, left, right, domain)`です。review文字列は認証ではありません。LLMにはaccept/promote/rollback/restoreを公開しないでください。実行例はscripts/ledger-demo.mjsにあります。

## 最初に再検査する

追加インストールはせず、READMEの`npm test`、`npm run test:host`、`npm run demo`を実行。Python 13テスト、Node 3テスト、保存/復元/rollbackを検査します。既存のASISTには未コミット変更があるので、resetや上書きをしないでください。

結果はNPN未経験領域平均73.0%、同じ学習済み特徴の記憶集計73.0%。D-E ridge平均差は3.12ポイントで、事前の5ポイント基準を満たしません。複雑な潜在モデルの優位性は結論にしないでください。修正前の結果は最終結論へ混ぜず、fixed-pool-v2/保存形式2を使います。

## 次の独立実験

1. 自然文からの入力表現を準備。最初は固定encoder＋記憶検索/集計を基準にし、同じ候補・経験・表現・予算で学習モデルを比較する。
2. 許可された自己経験/ユーザー経験を分ける。実me.mdは原文と来歴を保存し、構造化候補をpendingへ出す。共有メタ学習に必要な複数人格データを実際に得られるかも検討する。
3. 自己生成の教師の循環を検査。model originをhumanへ書き換えない。実行結果・後日の自己報告・訂正との対応を別に記録するschemaを設計する。
4. 長期保持と変化を両方評価。最新だけの適応、replay、必要ならattentionを比較し、最初から複雑化しない。
5. 台帳に短期状態遷移を残す、実際のkill/crash再開、削除・暗号化・保存形式upgrade、常駐プロセス再起動後のreloadを実装・検証する。現行hostのexportはpromoteしたcheckpointを保存し、ポート内の短期変化を自動保存しない。

## 将来ASISTを変更する際の接続位置

2026-10-13に現行ソースを再照合済み。以後の変更で行番号は動くため、関数名も確認してください。

- `asist/src/main/services/brain/turn.ts`: contextNotesを180行付近で作り、recordInputが205行付近でnotesを履歴へ保存、memory injectionを244–259行付近で追加、buildSystemLayersは271行付近。Coreの世代とNPN判断をターン開始で凍結し、動的なJSON注記をrecordInputより前へ追加する案。全tool roundで同じ状態を使う。
- `asist/src/main/services/brain/tools.ts`: toolRegistryは260行付近、toolSpecsを返すtoolsは287行付近。read/compare/proposeだけを既存ToolRegistry/ToolSpecへ追加し、Claude CLI shimと別ProviderAdapterの双方で実呼び出しを検証する。
- `asist/src/main/services/llm/claude-cli.ts`: sessionKeyは419行付近でmodel/effort/system/toolsをhash化。動的stateでsystem/toolsを毎回変更するとセッションを切り替えるため、input contextNotesへ載せる。CLIセッションは人格や履歴の正本にしない。

Coreをmainが所有し、rendererへ生のDB操作を渡さない。参照と学習を別プロセスにする。Electron側のNode SQLite互換とPython配布方針は未検証。学習OFFでも会話が動く経路と、候補の世代確認・非同期中断・終了時cleanupを用意する。

用途によって助言方式かCore確定方式かを選ぶ。助言方式ではLLMによる別判断が起こった。確定方式ではhostがID/choiceを検査し、違う出力を採用しない。ただし選択の一致を正確さの改善と呼ばない。LLMの反論や修正は新しい提案として来歴を残し、即座に人格重みへ反映しない。

詳細な未実装事項と採用条件はdocs/03-architecture.md、05-roadmap-handoff.mdにあります。現在の数値モデルを実Nephiaの価値観としてpromoteすることは、この成果物の検証範囲外です。
