"""Aggregate saved results without retraining or selecting a best seed."""
import csv
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "reports"
SEEDS = [2417, 2418, 2419]
results = [json.loads((REPORTS / ("results.json" if seed == 2417 else f"results-seed{seed}.json")).read_text(encoding="utf-8")) for seed in SEEDS]
assert all(r["generatorVersion"] == "fixed-pool-v2" and r["trainingSeed"] == seed for seed, r in zip(SEEDS, results))
assert len({r["datasetHash"] for r in results}) == 1
assert all(r["testPersonas"] == results[0]["testPersonas"] for r in results)
methods = [key for key in results[0]["summary"]["shared"] if key != "pairedDifference"]
aggregate = {"seeds": SEEDS, "personas": results[0]["testPersonas"], "datasetHash": results[0]["datasetHash"], "conditions": {}, "pairedDifferences": {}}

def stats(values):
    return {"mean": float(np.mean(values)), "min": float(np.min(values)), "max": float(np.max(values))}

for condition in ("shared", "noise20", "independent", "drift"):
    aggregate["conditions"][condition] = {method: {axis: stats([r["summary"][condition][method][axis] for r in results])
        for axis in ("within", "cross")} for method in methods}
    if condition == "drift":
        for method in ("D_stale", "D_replay"):
            aggregate["conditions"][condition][method] = {axis: stats([r["summary"][condition][method][axis] for r in results]) for axis in ("within", "cross")}

def crossed_bootstrap(matrix):
    # The same 40 people recur across seeds. Sample common person indices and seeds separately.
    rng = np.random.default_rng(85113)
    draws = [matrix[np.ix_(rng.integers(0, 3, 3), rng.integers(0, 40, 40))].mean() for _ in range(5000)]
    return {"mean": float(matrix.mean()), "low": float(np.quantile(draws, .025)), "high": float(np.quantile(draws, .975)),
            "scope": "Descriptive crossed bootstrap over 3 seeds and 40 paired personas; only 3 seeds, not 120 independent personas."}

for method in ("B", "C", "E_ridge", "B_learned_space", "B_plus_learned_space", "D_no_head"):
    matrix = np.asarray([[row["scores"]["D"]["cross"]-row["scores"][method]["cross"]
        for row in r["rows"] if row["condition"] == "shared"] for r in results])
    aggregate["pairedDifferences"][method] = crossed_bootstrap(matrix)
aggregate["curves"] = {str(n): {method: float(np.mean([row["scores"][method] for r in results for row in r["curves"] if row["n"] == n]))
    for method in ("D", "E_ridge", "D_no_head")} for n in (4, 8, 16, 32, 64)}
aggregate["observedAgreement"] = {method: float(np.mean([row["observedChoiceAgreement"][method]
    for r in results for row in r["continuity"] if row["condition"] == "shared"])) for method in ("D", "E_ridge", "D_no_head")}
aggregate["unchangedAfterDrift"] = {key: float(np.mean([row[key] for r in results for row in r["continuity"] if row["condition"] == "drift"]))
    for key in ("unchangedCrossBefore", "unchangedCrossFresh", "unchangedCrossReplay")}
aggregate["reaction"] = {"MSE": stats([r["reaction"]["MSE"] for r in results]), "zeroMSE": stats([r["reaction"]["zeroMSE"] for r in results]),
    "allLongUnchangedOnElapse": all(r["reaction"]["allLongUnchangedOnElapse"] for r in results)}
aggregate["restoration"] = [r["restoration"] for r in results]
aggregate["trainingSeconds"] = stats([r["training"]["trainingSeconds"] for r in results])

live = {name: json.loads((REPORTS / "live" / f"{name}-results.json").read_text(encoding="utf-8")) for name in ("haiku", "sonnet", "haiku-binding", "sonnet-binding")}
aggregate["live"] = {name: [{key: value for key, value in row.items() if key != "records"} for row in value["conditions"]] for name, value in live.items()}
aggregate["liveInputEquality"] = {}
aggregate["liveChoiceAgreement"] = {}
for mode in ("A", "B", "C", "D", "binding"):
    suffix = f"-binding-{mode}" if mode == "binding" else f"-{mode}"
    inputs = [json.loads((REPORTS / "live" / f"{engine}{suffix}-input.json").read_text(encoding="utf-8")) for engine in ("haiku", "sonnet")]
    aggregate["liveInputEquality"][mode] = inputs[0] == inputs[1]
    names = ("haiku-binding", "sonnet-binding") if mode == "binding" else ("haiku", "sonnet")
    conditions = [next(row for row in live[name]["conditions"] if row["mode"] == mode) for name in names]
    if all(row["status"] == "complete" for row in conditions):
        maps = [{r["id"]: r["choice"] for r in row["records"]} for row in conditions]
        aggregate["liveChoiceAgreement"][mode] = sum(maps[0][key] == maps[1][key] for key in maps[0])/len(maps[0])
    else:
        aggregate["liveChoiceAgreement"][mode] = None
cases = json.loads((REPORTS / "live-cases.json").read_text(encoding="utf-8"))
bad_output = json.loads((REPORTS / "live" / "sonnet-D-output.json").read_text(encoding="utf-8"))
bad_answers = json.loads(bad_output["text"])["answers"]
expected_ids = {case["id"] for case in cases}
returned_ids = {answer["id"] for answer in bad_answers}
aggregate["sonnetAdvisoryContractFailure"] = {"missingIds": sorted(expected_ids-returned_ids), "unexpectedIds": sorted(returned_ids-expected_ids)}
aggregate["coreAccuracyLive"] = sum(case["npn"]["choice"] == case["expected"] for case in cases)/len(cases)

examples = {}
for line in (REPORTS / "predictions.jsonl").read_text(encoding="utf-8").splitlines():
    row = json.loads(line)
    if not row["id"].startswith("shared-"):
        continue
    for i in range(120, 360):
        nn = row["predictions"]["D"][i]
        memory = row["predictions"]["B_plus_learned_space"][i]
        expected = row["expected"][i]
        kind = "success" if nn == expected and memory != expected else "failure" if nn != expected and memory == expected else None
        if kind and kind not in examples:
            examples[kind] = {"id": row["queryIds"][i], "expected": expected, "D": nn, "alignedMemorySummary": memory}
    if len(examples) == 2:
        break
aggregate["illustrativeCases"] = examples
performance = json.loads((REPORTS / "performance.json").read_text())
port = json.loads((REPORTS / "port-performance.json").read_text())
ledger = json.loads((REPORTS / "ledger-demo.json").read_text())
audit = json.loads((REPORTS / "audit-after.json").read_text())
aggregate["performance"] = performance
aggregate["portPerformance"] = port
aggregate["ledgerChecks"] = {key: ledger[key] for key in ("restoreSameChoice", "restoreSameMargin", "rollbackHasNoCheckpoint", "rollbackRestoresMargin", "sourceIdsPreserved")}
(REPORTS / "aggregate.json").write_text(json.dumps(aggregate, ensure_ascii=False, indent=2), encoding="utf-8")
with (REPORTS / "comparison.csv").open("w", encoding="utf-8-sig", newline="") as file:
    writer = csv.writer(file)
    writer.writerow(["condition", "method", "within_mean", "cross_mean", "cross_seed_min", "cross_seed_max"])
    for condition, values in aggregate["conditions"].items():
        for method, axes in values.items():
            writer.writerow([condition, method, axes["within"]["mean"], axes["cross"]["mean"], axes["cross"]["min"], axes["cross"]["max"]])

def pct(value):
    return f"{100*value:.1f}%"

def cells(method):
    v = aggregate["conditions"]["shared"][method]
    return f"{pct(v['within']['mean'])} | {pct(v['cross']['mean'])} | {pct(v['cross']['min'])}–{pct(v['cross']['max'])}"

labels = {"A": "A 固定人格・経験なし", "B": "B 通常検索（元の座標）", "B_plus": "B+ 単純集計（元の座標）", "C": "C Phase 1線形", "D": "D NPN＋個人head",
    "E_ridge": "E 同じ共有特徴＋ridge", "B_learned_space": "B 学習済み特徴＋検索", "B_plus_learned_space": "B+ 学習済み特徴＋集計", "D_no_head": "D 個人headなし"}
lines = ["# Phase 2実験結果：何ができて、何がまだ言えないか", "", "2026-10-13。保存された修正後の結果をscripts/report.pyで集計。", "",
    "## 結論", "", "**実際に重みが変わる小型の外部人格モデルは作れた。ただし、複雑な潜在人格モデルが強い記憶方式を上回ることは示せなかった。**",
    "", "NPNの未経験領域の正解率は3訓練seed平均で"+pct(aggregate["conditions"]["shared"]["D"]["cross"]["mean"])+"。同じ学習済み特徴を使う単純な記憶集計も"+pct(aggregate["conditions"]["shared"]["B_plus_learned_space"]["cross"]["mean"])+"だった。採用価値が見えたのは経験を別領域へつなぐ共通表現で、個人headや潜在集約の複雑さの優位性は未確立である。", "",
    "## 比較の条件", "", "訓練64人格・検証16人格・評価40人格を分離。評価人格はstoryの32選択のみを個人適応へ使用。未知候補はstory 120件、ethics/aesthetics各120件、計360件/人格。共有モデルは訓練人格を通じて3領域を見ている。評価人格にとって未経験の領域であり、共有モデルにとって未知の領域ではない。",
    "", "seed 2417/2418/2419を固定し、検証損失でcheckpointを選択。同じ40人格・候補を3seedで評価したので、120人の独立した標本ではない。正解は架空の生成器の教師ラベルで、哲学・美意識の客観的正解ではない。", "",
    "## 主比較", "", "| 方式 | 同領域の未知候補 | 個人にとって未経験の2領域 | 3seedの範囲 |", "|---|---:|---:|---:|"]
lines += [f"| {label} | {cells(method)} |" for method, label in labels.items()]
lines += ["", "元の座標は領域ごとに異なるため、B/Cの約41%との大差をそのまま『普通の長期記憶よりNNが優れる』という結論にできない。後から追加した学習済み特徴の記憶条件で、この不公平を検査した。追加条件は探索分析として明記している。",
    "", "| Dとの差（未経験領域） | 平均差 | 記述的95%bootstrap区間 |", "|---|---:|---:|"]
for method in ("E_ridge", "B_learned_space", "B_plus_learned_space", "D_no_head"):
    v = aggregate["pairedDifferences"][method]
    lines.append(f"| D − {labels[method]} | {v['mean']*100:+.2f}ポイント | {v['low']*100:+.2f}～{v['high']*100:+.2f} |")
lines += ["", "seedと同じ人格IDを別々に再標本化するcrossed bootstrap 5,000回。seedが3つしかないため区間は限定された記述である。事前の実質改善基準『5ポイント以上かつ区間下限>0』を、強い記憶集計とridgeに対して満たさない。個人headは同領域への適合を増やす一方、領域横断を悪化させるseedがあった。", "",
    "## 少量経験・継続・失敗条件", "", "| 自己経験件数 | D NPN | E ridge | D headなし |", "|---:|---:|---:|---:|"]
for n, row in aggregate["curves"].items():
    lines.append(f"| {n} | {pct(row['D'])} | {pct(row['E_ridge'])} | {pct(row['D_no_head'])} |")
lines += ["", "記録済みの32選択との一致率："+"、".join(f"{labels[m]} {pct(v)}" for m,v in aggregate["observedAgreement"].items())+"。これは訓練経験への適合で、未知候補の成績とは分けている。", "",
    "| 条件・アブレーション | 未経験領域の平均正解率 |", "|---|---:|"]
for condition, method, label in (("shared", "D_untrained", "未学習の初期ネットワーク"), ("shared", "D_zero", "人格潜在を0"), ("shared", "D_shuffled", "別人格の潜在へ交換"), ("shared", "D_fixed4", "4経験のまま固定"), ("noise20", "D", "選択ラベル20%反転"), ("independent", "D", "領域間の人格関係がない負の対照"), ("drift", "D_stale", "好み変化後、更新前の状態"), ("drift", "D", "変化後の新32経験へ適応"), ("drift", "D_replay", "旧32＋新32を同じ重みでreplay")):
    lines.append(f"| {label} | {pct(aggregate['conditions'][condition][method]['cross']['mean'])} |")
lines += ["", "過去の選択を入れ替えると判断が変わり、潜在を消す/別人格へ交換する/共有重みを未学習にすると成績が落ちた。共有可能な関係がない負の対照では成功しない。すべての趣味から価値観を推測してよい根拠にはならない。",
    "", "変化後も教師の判断が変わらなかった候補に限った正解率は、更新前"+pct(aggregate["unchangedAfterDrift"]["unchangedCrossBefore"])+"、新経験適応"+pct(aggregate["unchangedAfterDrift"]["unchangedCrossFresh"])+"、均等replay"+pct(aggregate["unchangedAfterDrift"]["unchangedCrossReplay"])+"。replayは継続した判断をよく保持する一方、全体では変化への適応を遅らせた。保持と変化の両方を評価する必要がある。これは急な合成変化の結果で、年単位の忘却・保持の設計は未検証。", "",
    "## 短期反応と長期状態", "", f"反応系列のMSEは{aggregate['reaction']['MSE']['mean']:.4f}、常に0とする比較は{aggregate['reaction']['zeroMSE']['mean']:.4f}。入力からforce・減衰・readoutを学習した。出来事のない時間経過で長期潜在は全評価で不変。短期状態を保存した後の次の反応もテストで再現した。",
    "", "反応の比較対象は0予測だけであり、線形遷移や単純な指数移動平均に対するニューラル遷移の優位性は未検証。反応は架空の数値proxyで、感情の実在、哲学、自然文の自己認識を実証していない。短期状態のruntime snapshotはあるが、ホスト内の短期変化の自動台帳保存は今後の実装。", "",
    "## 成功例と失敗例", "", "seed 2417の評価ファイルからID順の最初の該当例を採用。代表例は全体成績の代わりではない。", "", "| 例 | 未経験領域の候補ID | 教師の選択 | D | 同じ特徴の記憶集計 |", "|---|---|---|---|---|"]
choice = lambda value: "left" if value else "right"
for kind, label in (("success", "Dが当たり記憶集計が外れた"), ("failure", "Dが外れ記憶集計が当たった")):
    row = examples[kind]
    lines.append(f"| {label} | {row['id']} | {choice(row['expected'])} | {choice(row['D'])} | {choice(row['alignedMemorySummary'])} |")
lines += ["", "## 実Claude CLIとモデル交換", "", "既存サブスクリプション認証だけで実行し、API key sourceはnone、ツールなし、独立cwd、セッション保存なし。送ったのは架空の12候補と合成経験。実me.md・user.md・会話履歴は送信していない。同一入力・同一NPN状態をHaiku/Sonnetへ渡した。", "",
    "| 接続条件 | Haiku正解 | Sonnet正解 | 両モデルの選択一致 |", "|---|---:|---:|---:|"]
for mode in ("A", "B", "C", "D", "binding"):
    names = ("haiku-binding", "sonnet-binding") if mode == "binding" else ("haiku", "sonnet")
    rows = [next(row for row in live[name]["conditions"] if row["mode"] == mode) for name in names]
    scores = [f"{sum(x['correct'] for x in row['records'])}/12" if row["status"] == "complete" else "形式不一致で拒否" for row in rows]
    agreement = aggregate["liveChoiceAgreement"][mode]
    lines.append(f"| {'探索：Core確定・LLM言語化' if mode == 'binding' else mode+'（助言方式）'} | {scores[0]} | {scores[1]} | {pct(agreement) if agreement is not None else '集計対象外'} |")
lines += ["", f"Sonnet Dは12回答中{len(expected_ids-returned_ids)}件の正しい問題IDが欠け、{len(returned_ids-expected_ids)}件の別IDを作った。勝手に対応付けて採点していない。Haiku Dの改善も認められなかった。実際のモデルIDはclaude-haiku-5-5、claude-sonnet-5-5。各条件1回、1人格、12件だけで統計的な優位性を主張できない。",
    "", "bindingはこの失敗後に追加した探索試験。両モデルはCoreの選択を12/12保持したが、Core自身の正解は6/12。Coreによる確定とホスト検査は判断の引き継ぎを可能にするが、間違った判断も引き継ぐ。別提供元・ローカルLLM・自然会話は未検証。",
    "", "根拠の整合性は、同じsnapshot/hash/source ID、marginの符号とchoice、受理経験の来歴を検査した。LLMが作る文章理由の因果的正しさを定量証明していない。NNから個々の経験の因果寄与を説明する機構も未実装。", "",
    "## 保存・復元と性能", "", "3seedそれぞれ360候補のsnapshot復元前後の予測が完全一致。Phase 1台帳を実際に使い、32受理経験→checkpoint Revision 33→複合export/空DB restore→Revision 32 rollback→33へ復帰でchoice/margin/source IDを再現。破損・欠落・古い学習候補・帰属不一致は拒否する。",
    "", f"共有パラメーター1,102、個人head8重み、長期潜在8、短期状態4。CPU2スレッドの共有学習は平均{aggregate['trainingSeconds']['mean']:.1f}秒（{aggregate['trainingSeconds']['min']:.1f}–{aggregate['trainingSeconds']['max']:.1f}秒）。これは64合成人格の小さい実験で、大規模な実学習の予測ではない。", "",
    f"NumPyのみの参照プロセスはWorking Set {performance['workingSetAfterMiB']:.1f}MiB、候補比較中央値{performance['prediction']['p50Ms']:.3f}ms / p95 {performance['prediction']['p95Ms']:.3f}ms。Nodeとの常駐JSONL往復は中央値{port['p50Ms']:.3f}ms / p95 {port['p95Ms']:.3f}ms、初回起動・読込{port['coldLoadMs']:.1f}ms。台帳参照とLLM応答時間は除外。重みJSON {performance['weightsFileBytes']:,} bytes、個人snapshot {performance['snapshotBytes']:,} bytes。GPUは使っていない。", "",
    "Python 13テスト、Node 3テストを実行し0失敗。詳細はreports/test-results.txt、host-tests.tap。optimizerの途中再開、強制終了からの復旧、長期間の連続運用はこの検証に含めない。", "",
    "## 原環境と再現用成果物", "", f"ASISTの監査対象{len(audit['hashes'])}ファイル中、差分{len(audit['changedSourceFiles'])}ファイル（"+", ".join(audit['changedSourceFiles'])+"）。記憶/設定は"+", ".join(audit['changedMemoryOrSettings'])+"のhashが変化し、実me.md/user.mdは一致した。今回の成果物はnephia-npn-lab、テストは専用の一時DBへ書き込んだ。原環境の差分を戻す操作は行っていない。監査は変化を示すもので、別プロセスの変更理由を特定したものではない。",
    "", "results.json / results-seed2418.json / results-seed2419.jsonに全条件・人格別・学習履歴を保存。aggregate.jsonとcomparison.csvが3seed集計。data/personalization-support.jsonlとheldout-evaluation.jsonlを分離。predictions*.jsonlは候補単位の再検査用。モデル・state・来歴はmodels、reports/compound-export.json、ledger-demo.jsonに保存。",
    "", "同じIDで件数により候補が変わる生成器の来歴問題と、Python/JSの1.0/1でhashが変わる相互運用問題を修正した。旧結果は別名で残し、最終評価はfixed-pool-v2/保存形式2に統一。前者の修正で256件プールを使った共有訓練・checkpoint選択は変わっていない。記憶を学習済み特徴へ載せる比較とbinding試験は後追加である。", "",
    "## 次の判断", "", "本番の人格へ採用する段階ではない。次は自然文の固定表現＋記憶集計を先に作り、同じ表現・同じ許可データで学習する潜在モデルが追加価値を生むか測る。現在の数値モデルをme.mdや実Nephiaの人格へ移植しない。具体的な順序・接続箇所・未実装事項は05-roadmap-handoff.mdに記載した。"]
(ROOT / "docs" / "04-results.md").write_text("\n".join(lines)+"\n", encoding="utf-8")
print(json.dumps({"aggregate": "reports/aggregate.json", "report": "docs/04-results.md", "Dcross": aggregate["conditions"]["shared"]["D"]["cross"]["mean"], "alignedSummaryCross": aggregate["conditions"]["shared"]["B_plus_learned_space"]["cross"]["mean"]}))
