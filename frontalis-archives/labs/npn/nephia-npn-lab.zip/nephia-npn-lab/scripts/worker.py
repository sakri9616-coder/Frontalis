import json
import sys
from pathlib import Path
import numpy as np
from npn.runtime import Runtime, snapshot, restore

ROOT = Path(__file__).resolve().parents[1]
request = json.load(sys.stdin)
method = request["method"]

if method == "personalize":
    from npn.model import NPN, adapt_personal_head
    import torch
    torch.set_num_threads(2)
    artifact = json.loads((ROOT / "models" / "trained.json").read_text(encoding="utf-8"))
    source = request["support"]
    for key in ("left", "right", "y"):
        source[key] = np.asarray(source[key], np.float32)
    source["domain"] = np.asarray(source["domain"], np.int64)
    model = NPN.from_artifact(artifact)
    state = adapt_personal_head(model, source)
    state.update({"formatVersion": 1, "modelHash": artifact["sha256"], "owner": request["owner"]})
    result = snapshot(artifact, state, request["sourceRevision"], request["sourceHash"])
elif method == "compare":
    runtime, state = restore(request["snapshot"])
    runtime.validate_state(state, request["owner"])
    value = runtime.logits(state["longLatent"], np.asarray([request["left"]]), np.asarray([request["right"]]), np.asarray([request["domain"]]))[0]
    result = {"choice": "left" if value >= 0 else "right", "margin": float(value),
              "owner": state["owner"], "modelHash": runtime.model_hash,
              "experienceIds": state["experienceIds"], "sourceRevision": request["snapshot"]["payload"]["sourceRevision"],
              "uncertain": bool(len(state["experienceIds"]) < 8 or abs(value) < 0.2)}
elif method == "validate":
    runtime, state = restore(request["snapshot"])
    result = {"valid": True, "modelHash": runtime.model_hash, "owner": state["owner"]}
else:
    raise ValueError("Unknown worker method.")
print(json.dumps(result, allow_nan=False))
