import { NPNHost } from '../src/host.mjs';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const lab = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const run = join(lab, 'runtime', `demo-${Date.now()}`);
const row = readFileSync(join(lab, 'data', 'personalization-support.jsonl'), 'utf8').split('\n')
  .filter(Boolean).map((line) => JSON.parse(line)).find((entry) => entry.id === 'shared-200');
const host = new NPNHost(join(run, 'original')); const clone = new NPNHost(join(run, 'restored'));
const source = row.support;
try {
  for (let i = 0; i < source.ids.length; i++) {
    const experience = { schema: 'npn.experience.v1', id: source.ids[i], owner: 'nephia', domain: source.domain[i],
      left: source.left[i], right: source.right[i], preferred: source.y[i] ? 'left' : 'right',
      signal: 'self_report', confidence: 1, encoderVersion: 'synthetic-domain-v1', at: new Date(1767225600000+i*1000).toISOString(),
      evidence: { sourceId: 'synthetic-persona-200', locator: `support:${i}`, origin: 'synthetic' } };
    host.propose(experience, host.revision); host.accept(experience.id, host.revision, 'host_verified');
  }
  const candidate = await host.prepareCheckpoint('nephia', host.revision);
  await host.promote(candidate, 'host_verified');
  const savedRevision = host.revision;
  const before = await host.compare('nephia', source.left[0], source.right[0], 1);
  const bundle = host.exportPortable();
  writeFileSync(join(lab, 'reports', 'compound-export.json'), JSON.stringify(bundle));
  await clone.restorePortable(JSON.parse(JSON.stringify(bundle)));
  const after = await clone.compare('nephia', source.left[0], source.right[0], 1);
  host.rollback(32, host.revision);
  let rollbackHasNoCheckpoint = false;
  try { host.currentCheckpoint('nephia'); } catch { rollbackHasNoCheckpoint = true; }
  host.rollback(savedRevision, host.revision);
  const reverted = await host.compare('nephia', source.left[0], source.right[0], 1);
  const result = { reusedPhase1Ledger: true, sourceRevision: candidate.expectedRevision, checkpointRevision: savedRevision,
    restoreSameChoice: before.choice === after.choice, restoreSameMargin: before.margin === after.margin,
    rollbackHasNoCheckpoint, rollbackRestoresMargin: reverted.margin === before.margin,
    sourceIdsPreserved: JSON.stringify(before.experienceIds) === JSON.stringify(source.ids),
    trainedPersonalWeightNorm: Math.hypot(...candidate.snapshot.payload.state.personalWeights),
    comparison: before };
  writeFileSync(join(lab, 'reports', 'ledger-demo.json'), JSON.stringify(result, null, 2));
  console.log(JSON.stringify(result));
} finally { await host.close(); await clone.close(); }
