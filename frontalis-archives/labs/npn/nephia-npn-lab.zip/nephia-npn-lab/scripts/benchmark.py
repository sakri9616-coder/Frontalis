import ctypes
import json
import sys
import time
import statistics
from pathlib import Path
import numpy as np
from npn.runtime import restore

ROOT = Path(__file__).resolve().parents[1]


def working_set():
    class Counters(ctypes.Structure):
        _fields_ = [("cb", ctypes.c_ulong), ("PageFaultCount", ctypes.c_ulong),
                    ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]
    counters = Counters(); counters.cb = ctypes.sizeof(counters)
    kernel = ctypes.windll.kernel32
    kernel.GetCurrentProcess.restype = ctypes.c_void_p
    get_info = ctypes.windll.psapi.GetProcessMemoryInfo
    get_info.argtypes = [ctypes.c_void_p, ctypes.POINTER(Counters), ctypes.c_ulong]
    if not get_info(kernel.GetCurrentProcess(), ctypes.byref(counters), counters.cb):
        raise OSError("Process memory query failed.")
    return counters.WorkingSetSize / 1024**2


before = working_set(); started = time.perf_counter()
file = ROOT / "models" / "persona-200.json"
value = json.loads(file.read_text(encoding="utf-8"))
runtime, state = restore(value)
load_ms = (time.perf_counter()-started)*1000
rng = np.random.default_rng(591)
left = rng.uniform(-0.4, 0.4, (1, 6)); right = rng.uniform(-0.4, 0.4, (1, 6)); domain = np.asarray([1])
prediction_times = []; reaction_times = []
for _ in range(1000):
    started = time.perf_counter(); runtime.logits(state["longLatent"], left, right, domain)
    prediction_times.append((time.perf_counter()-started)*1000)
    started = time.perf_counter(); runtime.observe_reaction(state, left[0], 1, 1)
    reaction_times.append((time.perf_counter()-started)*1000)
after = working_set()
stats = lambda values: {"n": len(values), "p50Ms": float(np.quantile(values, 0.5)), "p95Ms": float(np.quantile(values, 0.95))}
result = {"python": sys.version.split()[0], "numpy": np.__version__, "torchImported": "torch" in sys.modules,
          "loadMs": load_ms, "prediction": stats(prediction_times), "reaction": stats(reaction_times),
          "workingSetBeforeMiB": before, "workingSetAfterMiB": after, "snapshotBytes": file.stat().st_size,
          "weightsFileBytes": (ROOT / "models" / "trained.json").stat().st_size,
          "scope": "Fresh NumPy-only process, includes model/state validation; excludes IPC startup and LLM."}
(ROOT / "reports" / "performance.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result))
