import json
from pathlib import Path
import numpy as np
from npn.data import pairs, DOMAINS
from npn.runtime import restore, digest

ROOT = Path(__file__).resolve().parents[1]
value = json.loads((ROOT / "models" / "persona-200.json").read_text(encoding="utf-8"))
runtime, state = restore(value)
row = next(json.loads(line) for line in (ROOT / "data" / "personalization-support.jsonl").read_text(encoding="utf-8").splitlines()
           if json.loads(line)["id"] == "shared-200")
source = row["support"]
for key in ("left", "right", "y"):
    source[key] = np.asarray(source[key], np.float32)
source["domain"] = np.asarray(source["domain"], np.int64)
if source["ids"] != state["experienceIds"]:
    raise ValueError("Live source memories do not match the NPN snapshot.")
source_left = runtime.facets(source["left"], source["domain"])
source_right = runtime.facets(source["right"], source["domain"])
source_diff = source_left-source_right
cases = []
for domain in range(3):
    query = pairs(200, domain, 4, 60)
    left = runtime.facets(query["left"], query["domain"]); right = runtime.facets(query["right"], query["domain"])
    margins = runtime.logits(state["longLatent"], query["left"], query["right"], query["domain"])
    for index in range(4):
        diff = left[index]-right[index]
        similarities = source_diff @ diff / np.maximum(1e-12, np.linalg.norm(source_diff, axis=1)*np.linalg.norm(diff))
        hits = np.argsort(-np.abs(similarities))[:8]
        cases.append({"id": query["ids"][index], "domain": DOMAINS[domain],
                      "leftRaw": query["left"][index].tolist(), "rightRaw": query["right"][index].tolist(),
                      "left": np.round(left[index], 4).tolist(), "right": np.round(right[index], 4).tolist(),
                      "memories": [{"id": source["ids"][i], "domain": "story", "left": np.round(source_left[i], 4).tolist(),
                                    "right": np.round(source_right[i], 4).tolist(), "preferred": "left" if source["y"][i] else "right"} for i in hits],
                      "npn": {"choice": "left" if margins[index] >= 0 else "right", "margin": float(margins[index]),
                              "modelHash": runtime.model_hash, "stateHash": digest(state), "sourceIds": state["experienceIds"]},
                      "expected": "left" if query["y"][index] else "right"})
(ROOT / "reports" / "live-cases.json").write_text(json.dumps(cases, indent=2), encoding="utf-8")
print(json.dumps({"caseCount": len(cases), "modelHash": runtime.model_hash}))
