import json
import sys
import numpy as np
from npn.runtime import restore, snapshot, digest

loaded = {}


def handle(request):
    method = request["method"]
    if method == "load":
        value = request["snapshot"]
        runtime, state = restore(value)
        loaded[state["owner"]] = {"runtime": runtime, "state": state, "source": value["payload"], "model": value["payload"]["model"], "snapshotHash": value["sha256"]}
        return {"owner": state["owner"], "modelHash": runtime.model_hash, "stateHash": digest(state)}
    owner = request["owner"]
    if owner not in loaded:
        raise ValueError("No state loaded for owner.")
    item = loaded[owner]; runtime = item["runtime"]; state = item["state"]
    if request.get("expectedSnapshotHash") is not None and request["expectedSnapshotHash"] != item["snapshotHash"]:
        raise ValueError("Inference snapshot changed.")
    runtime.validate_state(state, owner)
    if method == "compare":
        margin = runtime.logits(state["longLatent"], np.asarray([request["left"]]), np.asarray([request["right"]]), np.asarray([request["domain"]]))[0]
        return {"choice": "left" if margin >= 0 else "right", "margin": float(margin),
                "owner": owner, "modelHash": runtime.model_hash, "stateHash": digest(state),
                "experienceIds": state["experienceIds"], "sourceRevision": item["source"]["sourceRevision"],
                "uncertain": bool(len(state["experienceIds"]) < 8 or abs(margin) < 0.2)}
    if method == "reaction":
        state, response = runtime.observe_reaction(state, request["raw"], request["domain"], request["elapsed"], owner)
        item["state"] = state
        return {"response": response, "stateHash": digest(state), "owner": owner}
    if method == "elapse":
        item["state"] = runtime.elapse(state, request["elapsed"], owner)
        return {"stateHash": digest(item["state"]), "owner": owner}
    if method == "snapshot":
        return snapshot(item["model"], state, item["source"]["sourceRevision"], item["source"]["sourceHash"])
    raise ValueError("Unknown inference method.")


for line in sys.stdin:
    request = None
    try:
        if len(line) > 250000:
            raise ValueError("Request is too large.")
        request = json.loads(line)
        result = handle(request)
        response = {"id": request["id"], "result": result}
    except Exception as error:
        response = {"id": request.get("id") if isinstance(request, dict) else None, "error": str(error)}
    print(json.dumps(response, allow_nan=False), flush=True)
