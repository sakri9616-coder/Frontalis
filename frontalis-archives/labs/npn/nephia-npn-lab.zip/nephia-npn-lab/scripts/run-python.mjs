import { spawn } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const lab = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const paths = JSON.parse(readFileSync(join(lab, 'runtime-paths.json'), 'utf8'));
const command = process.argv[2];
const tasks = { train: 'experiments/train.py', evaluate: 'experiments/evaluate.py',
  benchmark: 'scripts/benchmark.py', report: 'scripts/report.py', test: null };
if (!Object.hasOwn(tasks, command)) throw new Error('Unknown Python task.');
const binary = ['benchmark', 'report'].includes(command) ? paths.inferencePython : paths.trainingPython;
const args = command === 'test' ? ['-m', 'unittest', 'discover', '-s', 'tests', '-v'] : [tasks[command], ...process.argv.slice(3)];
const child = spawn(binary, args, { cwd: lab, windowsHide: true, stdio: 'inherit',
  env: { ...process.env, PYTHONPATH: lab, PYTHONIOENCODING: 'utf-8' } });
child.on('error', (error) => { process.stderr.write(error.message + '\n'); process.exitCode = 1; });
child.on('close', (code) => { process.exitCode = code ?? 1; });
