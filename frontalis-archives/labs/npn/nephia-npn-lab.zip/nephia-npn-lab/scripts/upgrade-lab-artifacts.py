"""This explicit migration only upgrades generated Phase 2 research artifacts."""
import json
from pathlib import Path
from npn.canonical import digest, HASH_ENCODING

ROOT = Path(__file__).resolve().parents[1]
changes = {}
for file in (ROOT / "models").glob("*.json"):
    value = json.loads(file.read_text(encoding="utf-8"))
    payload = value["payload"]
    if "weights" not in payload:
        continue
    if payload["formatVersion"] == 2:
        continue
    original = value["sha256"]
    payload.update({"formatVersion": 2, "hashEncoding": HASH_ENCODING})
    value["sha256"] = digest(payload)
    file.write_text(json.dumps(value), encoding="utf-8")
    changes[original] = value["sha256"]
for file in (ROOT / "reports").glob("training*.json"):
    value = json.loads(file.read_text(encoding="utf-8"))
    value["initialHash"] = changes.get(value["initialHash"], value["initialHash"])
    value["selectedHash"] = changes.get(value["selectedHash"], value["selectedHash"])
    file.write_text(json.dumps(value, indent=2), encoding="utf-8")
(ROOT / "reports" / "hash-format-upgrade.json").write_text(json.dumps({"mapping": changes,
    "weightsChanged": False, "reason": "JSON round-trip through Node converted integral floats to integers, causing false digest mismatch."}, indent=2), encoding="utf-8")
print(json.dumps({"upgradedModels": len(changes), "weightsChanged": False}))
