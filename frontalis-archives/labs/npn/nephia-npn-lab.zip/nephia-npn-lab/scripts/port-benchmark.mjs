import { InferencePort } from '../src/inference-port.mjs';
import { readFileSync, writeFileSync } from 'node:fs';
import { performance } from 'node:perf_hooks';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const lab = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const value = JSON.parse(readFileSync(join(lab, 'models', 'persona-200.json'), 'utf8'));
const port = new InferencePort(); const request = { method: 'compare', owner: 'nephia',
  left: [0.1, 0.2, 0, 0.1, 0, 0], right: [-0.1, -0.2, 0, -0.1, 0, 0], domain: 1 };
try {
  const started = performance.now(); await port.call({ method: 'load', snapshot: value });
  const coldLoadMs = performance.now()-started; const elapsed = [];
  for (let i = 0; i < 100; i++) { const t = performance.now(); await port.call(request); elapsed.push(performance.now()-t); }
  elapsed.sort((a, b) => a-b);
  const result = { coldLoadMs, n: 100, p50Ms: elapsed[50], p95Ms: elapsed[95],
    scope: 'Node to persistent NumPy JSON Lines, model loaded once; excludes ledger reads and LLM.' };
  writeFileSync(join(lab, 'reports', 'port-performance.json'), JSON.stringify(result, null, 2));
  console.log(JSON.stringify(result));
} finally { await port.close(); }
