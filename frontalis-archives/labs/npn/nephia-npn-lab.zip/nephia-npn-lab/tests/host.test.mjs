import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve, dirname, basename } from 'node:path';
import { fileURLToPath } from 'node:url';
import { NPNHost } from '../src/host.mjs';

const lab = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const bundle = JSON.parse(readFileSync(join(lab, 'reports', 'compound-export.json'), 'utf8'));
function removeTestDirectory(directory) {
  const absolute = resolve(directory);
  assert.equal(dirname(absolute).toLowerCase(), resolve(tmpdir()).toLowerCase());
  assert.ok(basename(absolute).startsWith('npn-host-test-'));
  rmSync(absolute, { recursive: true, force: true });
}
const experience = { schema: 'npn.experience.v1', id: 'fixture', owner: 'nephia', domain: 0,
  left: [0.1, 0.2, 0.3, 0.1, 0.2, 0.3], right: [-0.1, -0.2, -0.3, 0, 0, 0], preferred: 'left',
  signal: 'self_report', confidence: 1, encoderVersion: 'synthetic-domain-v1', at: '2026-01-01T00:00:00Z',
  evidence: { sourceId: 'synthetic-fixture', locator: 'case:1', origin: 'synthetic' } };

test('pending, praise, generated choices and user history stay outside self personalization', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'npn-host-test-')); const host = new NPNHost(dir);
  try {
    host.propose(experience, 0); assert.equal(host.experiences('nephia').length, 0);
    host.accept(experience.id, 0, 'host_verified'); assert.equal(host.experiences('nephia').length, 1);
    for (const [id, signal, owner] of [['praise', 'user_praise', 'nephia'], ['generated', 'generated_choice', 'nephia'], ['user', 'user_report', 'user']]) {
      host.propose({ ...experience, id, signal, owner }, host.revision); host.accept(id, host.revision, 'host_verified');
    }
    assert.equal(host.experiences('nephia').length, 1); assert.equal(host.experiences('user').length, 1);
  } finally { await host.close(); removeTestDirectory(dir); }
});

test('stale checkpoint proposals are refused without activating any model', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'npn-host-test-')); const host = new NPNHost(dir);
  try {
    await assert.rejects(() => host.promote({ expectedRevision: -1 }, 'host_verified'), /Stale checkpoint/);
    assert.throws(() => host.currentCheckpoint('nephia'), /No active/);
  } finally { await host.close(); removeTestDirectory(dir); }
});

test('compound restore reproduces predictions and refuses incomplete or corrupt model bundles', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'npn-host-test-')); const host = new NPNHost(dir);
  try {
    const incomplete = { ...bundle, checkpoints: [] };
    await assert.rejects(() => host.restorePortable(incomplete), /missing/);
    assert.equal(host.revision, 0);
    const corrupt = structuredClone(bundle); corrupt.checkpoints[0].raw += ' ';
    await assert.rejects(() => host.restorePortable(corrupt), /integrity/);
    assert.equal(host.revision, 0);
    await host.restorePortable(bundle);
    const current = host.currentCheckpoint('nephia');
    const before = await host.compare('nephia', experience.left, experience.right, 2);
    host.rollback(32, host.revision); assert.throws(() => host.currentCheckpoint('nephia'), /No active/);
    host.rollback(33, host.revision);
    const after = await host.compare('nephia', experience.left, experience.right, 2);
    assert.equal(before.margin, after.margin); assert.equal(before.checkpointHash, after.checkpointHash);
  } finally { await host.close(); removeTestDirectory(dir); }
});
