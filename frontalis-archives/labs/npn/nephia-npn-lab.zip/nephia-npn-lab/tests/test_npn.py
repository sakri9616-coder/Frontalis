import copy
import json
import unittest
from pathlib import Path
import numpy as np
import torch

from npn.data import pairs, public_pairs, ENCODER_VERSION
from npn.model import NPN, tensor, adapt_personal_head
from npn.runtime import Runtime, snapshot, restore, digest

ROOT = Path(__file__).resolve().parents[1]
torch.set_num_threads(2)


class NPNTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.artifact = json.loads((ROOT / "models" / "trained.json").read_text(encoding="utf-8"))
        cls.initial = json.loads((ROOT / "models" / "initial.json").read_text(encoding="utf-8"))
        cls.model = NPN.from_artifact(cls.artifact)
        cls.runtime = Runtime(cls.artifact)
        sample = pairs(217, 0, 32, 50)
        cls.support = {key: sample[key] for key in ("left", "right", "domain", "y", "ids")}

    def test_training_updates_actual_encoder_and_feature_weights(self):
        initial = self.initial["payload"]["weights"]
        trained = self.artifact["payload"]["weights"]
        for key in ("domain_maps", "feature.0.weight", "encoder.0.weight", "force.0.weight", "decay_logits"):
            self.assertFalse(np.array_equal(np.asarray(initial[key]), np.asarray(trained[key])), key)

    def test_numpy_inference_matches_torch_for_each_domain(self):
        z = self.runtime.latent(self.support)
        z_torch = self.model.latent(tensor(self.support["left"]), tensor(self.support["right"]),
                                    tensor(self.support["domain"], torch.long), tensor(self.support["y"])).detach()
        np.testing.assert_allclose(z, z_torch.numpy(), rtol=1e-5, atol=1e-5)
        for domain in range(3):
            query = pairs(217, domain, 40, 80)
            predicted = self.runtime.logits(z, query["left"], query["right"], query["domain"])
            torch_pred = self.model.logits(z_torch, tensor(query["left"]), tensor(query["right"]),
                                           tensor(query["domain"], torch.long)).detach().numpy()
            np.testing.assert_allclose(predicted, torch_pred, rtol=1e-4, atol=1e-5)
            np.testing.assert_array_equal(predicted >= 0, torch_pred >= 0)

    def test_personal_head_changes_without_mutating_shared_weights(self):
        before = self.model.artifact()["payload"]["weights"]
        state = adapt_personal_head(self.model, self.support)
        self.assertGreater(float(np.linalg.norm(state["personalWeights"])), 0)
        self.assertEqual(before, self.model.artifact()["payload"]["weights"])

    def test_snapshot_restores_predictions_exactly_and_refuses_corruption(self):
        state = self.runtime.new_state(self.support)
        value = snapshot(self.artifact, state, 32, "example-source-hash")
        loaded, restored_state = restore(json.loads(json.dumps(value)))
        query = pairs(217, 2, 40, 80)
        np.testing.assert_array_equal(self.runtime.logits(state["longLatent"], query["left"], query["right"], query["domain"]),
                                      loaded.logits(restored_state["longLatent"], query["left"], query["right"], query["domain"]))
        value["payload"]["state"]["longLatent"][0] += 0.1
        with self.assertRaisesRegex(ValueError, "integrity"):
            restore(value)

    def test_transient_snapshot_restores_next_reaction_and_time(self):
        state = self.runtime.new_state(self.support)
        event = pairs(217, 1, 1, 81)
        updated, _ = self.runtime.observe_reaction(state, event["left"][0], 1, 2)
        updated = self.runtime.elapse(updated, 3)
        loaded, restored = restore(json.loads(json.dumps(snapshot(self.artifact, updated, 32, "source"))))
        first, prediction = self.runtime.observe_reaction(updated, event["right"][0], 1, 4)
        second, reproduced = loaded.observe_reaction(restored, event["right"][0], 1, 4)
        self.assertEqual(first, second)
        self.assertEqual(prediction, reproduced)
        self.assertEqual(restored["time"], 5)

    def test_semantically_invalid_state_and_fractional_domain_are_rejected(self):
        state = self.runtime.new_state(self.support)
        for field, replacement in (("owner", "other"), ("time", -1), ("steps", 0.5), ("experienceIds", ["same", "same"]), ("base", [0]*8)):
            invalid = {**state, field: replacement}
            with self.assertRaises(ValueError):
                self.runtime.validate_state(invalid, invalid["owner"])
        event = pairs(217, 1, 1, 81)
        with self.assertRaises(ValueError):
            self.runtime.observe_reaction(state, event["left"][0], 1.5, 2)

    def test_time_changes_only_transient_state_not_long_preferences(self):
        state = self.runtime.new_state(self.support)
        event = pairs(217, 1, 1, 81)
        updated, response = self.runtime.observe_reaction(state, event["left"][0], 1, 2)
        elapsed = self.runtime.elapse(updated, 30)
        self.assertEqual(state["longLatent"], elapsed["longLatent"])
        self.assertLess(np.linalg.norm(elapsed["shortState"]), np.linalg.norm(updated["shortState"]))
        self.assertTrue(np.isfinite(response).all())

    def test_user_state_cannot_be_used_as_self_state(self):
        state = self.runtime.new_state(self.support, owner="user")
        with self.assertRaisesRegex(ValueError, "owner"):
            self.runtime.observe_reaction(state, self.support["left"][0], 0, 1, owner="nephia")
        original_self = self.runtime.new_state(self.support)
        changed_user, _ = self.runtime.observe_reaction(state, self.support["right"][0], 0, 1, owner="user")
        self.assertEqual(original_self["shortState"], [0.0]*4)
        self.assertNotEqual(changed_user["shortState"], original_self["shortState"])

    def test_encoder_model_versions_and_unknown_domains_are_rejected(self):
        state = self.runtime.new_state(self.support)
        bad = {**state, "encoderVersion": "different"}
        with self.assertRaisesRegex(ValueError, "mismatch"):
            self.runtime.validate_state(bad, "nephia")
        bad = {**state, "modelHash": "different"}
        with self.assertRaisesRegex(ValueError, "mismatch"):
            self.runtime.validate_state(bad, "nephia")
        with self.assertRaisesRegex(ValueError, "unknown domain"):
            self.runtime.facets(np.zeros(6), np.asarray(3))

    def test_query_interface_excludes_oracle_labels_and_persona_identifiers(self):
        query = public_pairs(pairs(217, 2, 10, 81))
        self.assertEqual(set(query), {"left", "right", "domain"})

    def test_case_ids_have_identical_content_at_different_batch_sizes(self):
        small = pairs(217, 1, 4, 81)
        large = pairs(217, 1, 120, 81)
        self.assertEqual(small["ids"], large["ids"][:4])
        np.testing.assert_array_equal(small["left"], large["left"][:4])
        np.testing.assert_array_equal(small["right"], large["right"][:4])
        np.testing.assert_array_equal(small["y"], large["y"][:4])

    def test_experience_order_does_not_invent_extra_long_term_evidence(self):
        source = copy.deepcopy(self.support)
        source["left"] = source["left"][::-1]
        source["right"] = source["right"][::-1]
        source["domain"] = source["domain"][::-1]
        source["y"] = source["y"][::-1]
        np.testing.assert_allclose(self.runtime.latent(source), self.runtime.latent(self.support), atol=1e-5)

    def test_reversed_experiences_have_a_measurable_effect_on_unseen_decisions(self):
        reverse = {**self.support, "y": 1-self.support["y"]}
        query = pairs(217, 1, 80, 81)
        one = self.runtime.logits(self.runtime.latent(self.support), query["left"], query["right"], query["domain"])
        two = self.runtime.logits(self.runtime.latent(reverse), query["left"], query["right"], query["domain"])
        self.assertGreater(np.mean((one >= 0) != (two >= 0)), 0.5)


if __name__ == "__main__":
    unittest.main()
