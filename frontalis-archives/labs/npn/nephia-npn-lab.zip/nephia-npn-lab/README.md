# Nephia NPN Lab — Phase 2

**学習する外部人格モデルの試作・評価まで完了。強い長期記憶に対する追加の改善は、今回の実験では確認できませんでした。**

架空の経験から学ぶ、1,102パラメーターの小型ニューラルネットワークです。Claudeの内部重みには触れず、経験・モデル・個人状態をLLMの外へ保存します。潜在次元に性格名を付けたり、好みの方向をあらかじめ固定したりしていません。

| わかったこと | 結果と意味 |
|---|---|
| 過去の経験から未知の候補へ判断を広げられるか | 合成実験で未経験領域の正解率73.0%。共有モデルは別の訓練人格から各領域を学習済み |
| 潜在人格モデルを複雑にする価値があったか | 同じ学習済み特徴の単純な記憶集計も73.0%。安定した上積みを示せなかった |
| 経験が変わると判断も変わるか | 変化後の新経験へ適応すると56.0%→73.8%。古い経験との均等replayは67.3% |
| LLMを替えて判断を保てるか | Coreで判断を確定しLLMが言語化する試験ではHaiku/Sonnetとも12/12保持。判断自体の正解は6/12 |
| 保存して戻せるか | モデル・個人状態・来歴を保存。復元、Revision rollback、破損拒否を検証 |
| 軽いか | 通常の参照プロセス約32MiB。常駐プロセスとの比較往復中央値約0.44ms。LLM時間は含まない |

通常の参考情報として渡す接続では、Haikuの改善は見られず、Sonnetは問題IDを取り違えました。人格を外部保存できること、応答が人格判断を保つこと、判断の質が上がることは、別々に評価しています。

自然な文章、実際のネフィアの価値観、自己認識、年単位の学習は未検証です。既存のme.mdを数値モデルへ置き換えていません。次は自然文の共通表現を用意し、同じ条件の記憶方式を基準として追加価値を調べる段階です。

## 読む順序

1. [実験結果と限界](docs/04-results.md)：全比較、3訓練seed、成功例・失敗例、実Claude CLI、性能。
2. [技術調査](docs/02-research.md)：HYDRA・Persona-Plug・MoFなどの一次資料と採用判断。
3. [設計と実装範囲](docs/03-architecture.md)：長期/短期状態、実際の学習処理、台帳・保存形式・LLM境界。
4. [段階的な統合計画](docs/05-roadmap-handoff.md)：自然文・実経験・ASISTへの具体的な接続案。
5. [Claude Codeへの引き継ぎ](CLAUDE_HANDOFF.md)：再実行コマンド、コードの入口、次の作業範囲。
6. [実験計画と変更記録](docs/01-protocol.md)：事前の基準、後追加の比較、来歴の修正。

## 動かす

このPCに既にあるランタイムをruntime-paths.jsonで指定しています。Node 24.20.0、学習Python 3.12.13＋CPU版PyTorch 2.14.1、参照Python 3.12.14＋NumPy 2.3.5。追加インストールは不要です。Phase 1のnephia-core-labを隣接フォルダーへ保持してください。

```powershell
cd C:\Users\sakur\AppData\Local\asist-shisa\nephia-npn-lab
npm test
npm run test:host
npm run demo
npm run benchmark
npm run benchmark:port
npm run report
```

学習・評価をやり直す場合は、既存の研究成果をコピーしてから、コピー先で次を実行します。3seedを個別に扱い、最も成績のよいseedだけを選ばないでください。

```powershell
npm run train -- 2417
npm run evaluate -- 2417
npm run train -- 2418
npm run evaluate -- 2418
npm run train -- 2419
npm run evaluate -- 2419
```

CLI実験は自動テストやdemoに含めていません。`node experiments/live.mjs haiku` / `sonnet`は架空データのみをサブスクリプションへ送り、結果ファイルを再生成します。引数`binding`を付けるとCore確定方式を試します。API認証への切替は拒否します。

reports/aggregate.jsonとcomparison.csvが全seedの集計、modelsが学習重みと個人snapshot、dataの2ファイルが個人適応用/評価用の分離データです。過去の修正前結果も名前を分けて保存しています。

成果物の書込先はこの独立フォルダーで、テストには専用の一時DBを使います。ASIST・Claude設定・既存人格・実記憶への実装変更、Push、外部公開は行っていません。読取監査では実me.md/user.mdのhashは一致しました。一方、調査中にOverlayView.tsxとsettings.jsonのhashは変わっており、その既存環境の差分を巻き戻していません。監査の詳細はreports/audit-before.json / audit-after.jsonにあります。
