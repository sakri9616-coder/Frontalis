# 学習可能な外部人格表現の技術調査

調査日: 2026-10-13。論文本文・著者公開リポジトリを一次資料として確認した。研究の主な対象はユーザーへの個人化であり、AI自身の人格形成への適用は本研究の仮説である。元論文の成績をNephiaの改善率として使わない。

## 名称と実在の確認

| 技術 | 学ぶもの・教師信号 | 推論時の接続条件 | Nephiaでの採用判断 |
|---|---|---|---|
| [HYDRA, NeurIPS 2024](https://papers.neurips.cc/paper_files/paper/2024/file/b6b4906c1334656e97cc9968ccfca073-Paper-Conference.pdf) | 外部reranker/候補回答scorerの共通encoderと個人head。履歴付きLLM回答を正解と比べた有用性ラベル、候補回答の適合ラベル | 履歴を再順位付けし、LLMが出した複数候補を外部でbest-of-b選択。LLM内部重み・勾配は不要 | 外部判定器という責務を採用。訓練ラベル・複数候補生成の費用が必要で、1,102パラメーター試作をHYDRA再現とは呼ばない |
| [Persona-Plug / PPlug, ACL 2025](https://aclanthology.org/2025.acl-long.461.pdf) | 凍結した履歴encoder、学ぶinput encoder/projector/instruction embedding。教師は個人化した文章のtoken loss | 本文式(5)(6)で個人の連続埋め込みをLLM入力埋め込みへ接続。LLM重み凍結でも、入力埋め込みへの接続と学習の微分経路が要る | Claude CLIへ原方式を直接採用できない。履歴集約の考え方だけ参考にし、外部decoderで判断をJSONへ復号する |
| [Mixture-of-Facets / MoF, arXiv 2610.08330](https://arxiv.org/html/2610.08330v1) | 共通facet heads、履歴router、SAEなど。候補の適合BCEと疎な再構成損失 | 履歴から共有facetを混ぜ、外部reranker/scorerとして使用。個人専用headを追加しない構成 | 学習した共通表現＋個人の状態という構成を参考にする。2026-10-06提出の新しいプレプリントで、追試した成果ではない |

HYDRAは同名のLoRA手法や状態空間言語モデルと区別した。対象は **Model Factorization Framework for Black-Box LLM Personalization**。著者の[HYDRA実装](https://github.com/night-chen/HYDRA)でreranker/adapterと訓練経路の存在を確認した。[PPlug実装](https://github.com/rucliujn/PPlug)はFlanT5-XXL、BGE等を用意する経路を公開している。[MoF実装](https://github.com/hoonpak/Mixture-of-Facets)の公開も確認した。これらの大きいモデル・データ・APIを導入して原論文を再現したわけではない。

## 構成要素として調べた研究

| 研究・領域 | パラメーターと教師信号 | 今回の関係 |
|---|---|---|
| [Conditional Neural Processes, 2018](https://arxiv.org/abs/1807.01613) | 経験集合をまとめるencoderと、文脈付き予測decoder。観測した入出力から別の出力を予測する損失 | 少数の経験から個人潜在を推定する骨格。原論文の回帰等をそのまま人格へ読み替えず、選好対の予測へ適応 |
| [Attentive Neural Processes, 2019](https://arxiv.org/abs/1901.05761) | contextへのattentionを含むencoder/decoder。観測点と未観測点の予測 | 単純平均の圧縮が情報を落とす問題への候補。初期案は小ささを優先した平均集約で、attentionの効果は未検証 |
| [Deep Sets, 2017](https://arxiv.org/abs/1703.06114) | 順序に依存しない集合encoder/decoder。対象課題の教師信号 | 長期の経験集合と、順序・時間を持つ短期反応系列を分ける根拠。今回は長期の集約を順序不変にする |
| [Persona-Based Neural Conversation Model, 2016](https://aclanthology.org/P16-1094/) | speaker embeddingと会話生成ネットワーク。話者付き応答の尤度 | Persona-conditioned generationの先例。話者表現の着想は有効だが、生成モデル内部を学ぶ原方式はClaude CLIでは使えない |
| [Deep Interest Network, KDD 2018](https://arxiv.org/abs/1706.06978) | embedding、候補に応じるinterest aggregation、予測MLP。クリックラベル | Neural User Modelingの参考。候補依存の注意と安定した自己傾向を混同しない。クリック・賞賛・利用時間を自己人格の教師にしない |
| [PEARL, 2019](https://arxiv.org/abs/1903.08254) | 経験から文脈を推定するencoder、policy/critic等。環境の遷移・報酬 | 少量経験からの適応と共通事前知識の区別。今回の選好教師と報酬は異なり、メタRL実装としては採用しない |
| [PlaNet / Latent Dynamics, 2019](https://arxiv.org/abs/1811.04551) | 再帰的な潜在遷移、観測decoder等。行動・観測系列と予測目的 | 時系列の外部潜在状態という発想を参考にする。画像世界モデルを人格や情動の実在証拠にはしない |
| [Experience Replay for Continual Learning, 2018/2019](https://arxiv.org/abs/1811.11682) | 新旧データを用いて更新するネットワーク。元の教師ラベルを再利用 | 小さいreplay集合を本番前に比較する。古い評価をすべて正解として固定せず、時点と変化の理由を残す |
| [Gradient Surgery / PCGrad, 2020](https://arxiv.org/abs/2001.06782) | マルチタスクで競合する勾配の処理。各課題の教師損失 | 選好と反応の損失が干渉する場合の候補。今回の2損失は単純な加重和で、PCGradを使ったとは言わない |
| [FiLM, 2018](https://arxiv.org/abs/1709.07871) | 条件から特徴の変調を学ぶネットワーク。対象の推論ラベル | 将来の条件付きdecoderの候補。今回は学習済み特徴と個人潜在の内積という小さい構成で始める |

## ブラックボックス接続の区別

外部の経験encoder、状態遷移、候補評価は、それぞれの外部ネットワークに勾配を流せば学べる。Claudeの内部を学ぶ必要はない。ただし教師となる本人の判断・実際の結果・時間付き反応は必要である。

一方、soft prompt、連続persona embeddingのLLMへの注入、LoRA、activation editing、生成token lossからの端から端までの学習には、対象LLMの内部インターフェースや微分可能な経路が要る。LLMを凍結している論文を「通常のCLIで使える」と扱わない。CLIが返す文章や候補スコアだけで成立する接続を優先する。

学習した8次元の潜在をそのまま別LLMへ送っても、その座標の意味を理解する保証はない。今回の可搬性は、同じNPNの入力表現・重み・個人状態を保持し、NPN側で判断に復号してから各LLMへ渡すことにある。局所LLM向けsoft adapterへ移る場合も、そのadapterと人格の正本を分ける。

## 今回採用した仮説と必要条件

共有特徴を学ぶ小型ネットワーク、選択経験から潜在を推定するencoder、小さい個人head、学習する短期減衰モデルを組み合わせた。各潜在次元には「共感」「自由」等の名前を割り当てない。選好の方向を開発者が先に指定しない。

重要な条件は、共有モデルを学ぶための複数人格・複数領域の教師データがあること。今回の合成人口はこの条件を満たすように作った。実Nephia一人の少量の会話しかない状態で、同じ領域横断効果が得られるとは言えない。共有関係がない領域では転移は失敗し、平均集約や個人head更新が情報を失うこともある。

研究判断は、共通表現の学習を有力な次段階として残し、潜在推定器や個人追加学習の複雑化は独立して評価すること。通常記憶にも同じ表現を与えた比較を含め、NNを持ったことだけを人格形成の成功にしない。
