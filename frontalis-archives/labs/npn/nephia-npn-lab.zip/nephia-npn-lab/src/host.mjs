import { NephiaCore } from '../../nephia-core-lab/src/core.mjs';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { InferencePort } from './inference-port.mjs';

const lab = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const paths = JSON.parse(readFileSync(join(lab, 'runtime-paths.json'), 'utf8'));
const sha = (raw) => createHash('sha256').update(raw).digest('hex');
const check = (value, message) => { if (!value) throw new Error(message); };

export function worker(request) {
  return new Promise((done, fail) => {
    const binary = request.method === 'personalize' ? paths.trainingPython : paths.inferencePython;
    const child = spawn(binary, [join(lab, 'scripts', 'worker.py')], { cwd: lab, windowsHide: true,
      stdio: ['pipe', 'pipe', 'pipe'], env: { ...process.env, PYTHONPATH: lab, PYTHONIOENCODING: 'utf-8' } });
    let output = ''; let error = '';
    const timer = setTimeout(() => { child.kill(); fail(new Error('NPN worker timed out.')); }, 60000);
    child.on('error', (e) => { clearTimeout(timer); fail(e); });
    child.stdout.setEncoding('utf8').on('data', (value) => { output += value; });
    child.stderr.setEncoding('utf8').on('data', (value) => { error = (error+value).slice(-2000); });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (code !== 0) { fail(new Error(`NPN worker exited ${code}: ${error}`)); return; }
      try { done(JSON.parse(output)); } catch { fail(new Error('NPN worker returned invalid JSON.')); }
    });
    child.stdin.end(JSON.stringify(request));
  });
}

/** This host reuses the Phase 1 ledger without modifying its source or schema. */
export class NPNHost {
  constructor(directory = join(lab, 'runtime', 'host')) {
    this.directory = resolve(directory);
    mkdirSync(join(this.directory, 'checkpoints'), { recursive: true });
    this.core = new NephiaCore(join(this.directory, 'core.db'));
    this.port = new InferencePort();
    this.loadedHashes = new Map();
  }
  async close() { this.core.close(); await this.port.close(); }
  get revision() { return this.core.revision; }
  propose(experience, expectedRevision) {
    check(experience.schema === 'npn.experience.v1', 'Unknown experience schema.');
    check(['nephia', 'user'].includes(experience.owner), 'Unknown owner.');
    check(Number.isInteger(experience.domain) && experience.domain >= 0 && experience.domain < 3, 'Unknown domain.');
    check(['left', 'right'].includes(experience.preferred), 'Unknown preferred side.');
    for (const side of ['left', 'right']) check(Array.isArray(experience[side]) && experience[side].length === 6 &&
      experience[side].every((value) => Number.isFinite(value) && Math.abs(value) <= 1), 'Invalid features.');
    check(['self_report', 'user_report', 'generated_choice', 'user_praise', 'observed_choice'].includes(experience.signal), 'Unknown signal.');
    check(experience.encoderVersion === 'synthetic-domain-v1', 'Encoder version mismatch.');
    check(Number.isFinite(experience.confidence) && experience.confidence >= 0 && experience.confidence <= 1, 'Invalid confidence.');
    check(experience.signal !== 'self_report' || experience.owner === 'nephia', 'Self report owner mismatch.');
    check(experience.signal !== 'user_report' || experience.owner === 'user', 'User report owner mismatch.');
    const event = { id: experience.id, kind: 'episode', owner: experience.owner, at: experience.at,
      evidence: experience.evidence, text: JSON.stringify(experience) };
    return this.core.propose(event, expectedRevision);
  }
  accept(id, revision, review) { return this.core.accept(id, revision, review); }
  experiences(owner) {
    return this.core.activeEvents().filter((event) => event.kind === 'episode').map((event) => {
      try { return JSON.parse(event.text); } catch { return null; }
    }).filter((e) => e?.schema === 'npn.experience.v1' && e.owner === owner && e.confidence >= 0.5 &&
      !['generated_choice', 'user_praise'].includes(e.signal) &&
      ['synthetic', 'human', 'observation'].includes(e.evidence.origin));
  }
  async prepareCheckpoint(owner, expectedRevision) {
    check(expectedRevision === this.revision, 'Stale revision.');
    const accepted = this.experiences(owner).slice(-64);
    check(accepted.length > 0, 'No eligible experience.');
    const source = this.core.state();
    const support = { ids: accepted.map((e) => e.id), left: accepted.map((e) => e.left), right: accepted.map((e) => e.right),
      domain: accepted.map((e) => e.domain), y: accepted.map((e) => e.preferred === 'left' ? 1 : 0) };
    const snapshot = await worker({ method: 'personalize', owner, support,
      sourceRevision: source.revision, sourceHash: source.stateHash });
    return { expectedRevision, snapshot };
  }
  async promote(candidate, review) {
    check(['host_verified', 'human_reviewed'].includes(review), 'Trusted review required.');
    check(candidate.expectedRevision === this.revision, 'Stale checkpoint revision.');
    const payload = candidate.snapshot.payload;
    check(payload.sourceRevision === this.revision && payload.sourceHash === this.core.state().stateHash, 'Checkpoint source mismatch.');
    const owner = payload.state.owner;
    const expectedIds = this.experiences(owner).slice(-64).map((event) => event.id);
    check(JSON.stringify(expectedIds) === JSON.stringify(payload.state.experienceIds), 'Checkpoint evidence mismatch.');
    await worker({ method: 'validate', snapshot: candidate.snapshot });
    check(candidate.expectedRevision === this.revision, 'Stale checkpoint revision.');
    const raw = JSON.stringify(candidate.snapshot); const fileHash = sha(raw);
    const file = join(this.directory, 'checkpoints', `${fileHash}.json`);
    if (!existsSync(file)) writeFileSync(file, raw, { flag: 'wx' });
    const id = `npn-checkpoint-${fileHash}`;
    const record = { id, kind: 'episode', owner, at: new Date().toISOString(),
      evidence: { sourceId: payload.sourceHash, locator: `core-revision:${payload.sourceRevision}`, origin: 'observation' },
      text: JSON.stringify({ schema: 'npn.checkpoint.v1', fileHash, owner, sourceRevision: payload.sourceRevision,
        modelHash: payload.model.sha256, experienceIds: payload.state.experienceIds }) };
    this.core.propose(record, candidate.expectedRevision);
    this.core.accept(id, candidate.expectedRevision, review);
    return { revision: this.revision, fileHash };
  }
  currentCheckpoint(owner) {
    const checkpoints = this.core.activeEvents().map((event) => {
      try { return JSON.parse(event.text); } catch { return null; }
    }).filter((e) => e?.schema === 'npn.checkpoint.v1' && e.owner === owner);
    check(checkpoints.length > 0, 'No active checkpoint.');
    const reference = checkpoints.at(-1);
    check(/^[a-f0-9]{64}$/.test(reference.fileHash), 'Invalid checkpoint hash.');
    const raw = readFileSync(join(this.directory, 'checkpoints', `${reference.fileHash}.json`), 'utf8');
    check(sha(raw) === reference.fileHash, 'Checkpoint file integrity failure.');
    return { snapshot: JSON.parse(raw), reference };
  }
  async compare(owner, left, right, domain) {
    const frozenRevision = this.revision;
    const { snapshot, reference } = this.currentCheckpoint(owner);
    if (this.loadedHashes.get(owner) !== reference.fileHash) {
      await this.port.call({ method: 'load', snapshot });
      this.loadedHashes.set(owner, reference.fileHash);
    }
    const result = await this.port.call({ method: 'compare', owner, left, right, domain, expectedSnapshotHash: snapshot.sha256 });
    const activeIds = this.experiences(owner).slice(-64).map((event) => event.id);
    return { ...result, coreRevision: frozenRevision, currentCoreRevision: this.revision, checkpointHash: reference.fileHash,
      stale: frozenRevision !== this.revision || JSON.stringify(activeIds) !== JSON.stringify(result.experienceIds) };
  }
  rollback(targetRevision, expectedRevision) { this.loadedHashes.clear(); return this.core.rollback(targetRevision, expectedRevision); }
  exportPortable() {
    const ledger = this.core.exportPortable();
    const hashes = new Set(ledger.events.map((event) => {
      try { const value = JSON.parse(event.text); return value.schema === 'npn.checkpoint.v1' ? value.fileHash : null; } catch { return null; }
    }).filter(Boolean));
    return { formatVersion: 1, ledger,
      checkpoints: [...hashes].map((fileHash) => ({ fileHash,
        raw: readFileSync(join(this.directory, 'checkpoints', `${fileHash}.json`), 'utf8') })) };
  }
  async restorePortable(bundle) {
    const destination = this.core.exportPortable();
    check(bundle.formatVersion === 1 && this.core.revision === 0 && destination.events.length === 0 &&
      destination.proposals.length === 0, 'Restore requires an empty compatible destination.');
    const referenced = new Set(bundle.ledger.events.map((event) => {
      try { const value = JSON.parse(event.text); return value.schema === 'npn.checkpoint.v1' ? value.fileHash : null; } catch { return null; }
    }).filter(Boolean));
    const provided = new Set(bundle.checkpoints.map((item) => item.fileHash));
    check(provided.size === bundle.checkpoints.length && provided.size === referenced.size &&
      [...referenced].every((item) => provided.has(item)), 'Export is missing or duplicating checkpoint files.');
    for (const checkpoint of bundle.checkpoints) {
      check(/^[a-f0-9]{64}$/.test(checkpoint.fileHash) && sha(checkpoint.raw) === checkpoint.fileHash, 'Checkpoint integrity failure.');
      await worker({ method: 'validate', snapshot: JSON.parse(checkpoint.raw) });
    }
    const source = new NephiaCore();
    try {
      source.restorePortable(bundle.ledger);
      for (const checkpoint of bundle.checkpoints) {
        const payload = JSON.parse(checkpoint.raw).payload;
        check(source.revisionRow(payload.sourceRevision).digest === payload.sourceHash, 'Checkpoint source lineage mismatch.');
        const sourceIds = new Set(JSON.parse(source.revisionRow(payload.sourceRevision).ids));
        check(payload.state.experienceIds.every((id) => sourceIds.has(id)), 'Checkpoint contains unknown evidence.');
      }
    } finally { source.close(); }
    for (const checkpoint of bundle.checkpoints) {
      const file = join(this.directory, 'checkpoints', `${checkpoint.fileHash}.json`);
      if (!existsSync(file)) writeFileSync(file, checkpoint.raw, { flag: 'wx' });
    }
    return this.core.restorePortable(bundle.ledger);
  }
}
