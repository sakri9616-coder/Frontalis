import { spawn } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const lab = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const paths = JSON.parse(readFileSync(join(lab, 'runtime-paths.json'), 'utf8'));

/** A lazy NumPy process owns reference requests and never imports the training runtime. */
export class InferencePort {
  constructor() { this.pending = new Map(); this.nextId = 0; this.child = null; }
  start() {
    if (this.child) return;
    const child = spawn(paths.inferencePython, [join(lab, 'scripts', 'inference-server.py')], {
      cwd: lab, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env, PYTHONPATH: lab, PYTHONIOENCODING: 'utf-8' } });
    this.child = child; let buffer = '';
    child.stderr.on('data', () => {});
    this.closed = new Promise((done) => child.on('close', () => { this.child = null; this.failAll(new Error('Inference process closed.')); done(); }));
    child.on('error', (error) => this.failAll(error));
    child.stdout.setEncoding('utf8').on('data', (chunk) => {
      buffer += chunk; let index;
      while ((index = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, index); buffer = buffer.slice(index+1);
        let response; try { response = JSON.parse(line); } catch { this.failAll(new Error('Invalid inference JSON.')); continue; }
        const waiting = this.pending.get(response.id);
        if (!waiting) continue;
        clearTimeout(waiting.timer); this.pending.delete(response.id);
        if (response.error) waiting.fail(new Error(response.error)); else waiting.done(response.result);
      }
    });
  }
  failAll(error) {
    for (const request of this.pending.values()) { clearTimeout(request.timer); request.fail(error); }
    this.pending.clear();
  }
  call(request) {
    this.start();
    return new Promise((done, fail) => {
      const id = ++this.nextId;
      const timer = setTimeout(() => { this.pending.delete(id); fail(new Error('Inference request timed out.')); }, 30000);
      this.pending.set(id, { done, fail, timer });
      this.child.stdin.write(JSON.stringify({ id, ...request })+'\n');
    });
  }
  async close() {
    if (!this.child) return;
    this.child.stdin.end();
    await this.closed;
  }
}
