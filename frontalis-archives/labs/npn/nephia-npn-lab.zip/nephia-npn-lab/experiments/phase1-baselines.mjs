import { Methods } from '../../nephia-core-lab/experiments/baselines.mjs';

let input = ''; for await (const chunk of process.stdin) input += chunk;
const jobs = JSON.parse(input);
const result = jobs.map((job) => {
  const methods = new Methods();
  for (let i = 0; i < job.support.y.length; i++) {
    methods.update({ id: job.support.ids[i], kind: 'preference', owner: 'nephia', signal: 'self_report', confidence: 1,
      left: { id: `${job.support.ids[i]}-a`, features: job.support.left[i] },
      right: { id: `${job.support.ids[i]}-b`, features: job.support.right[i] },
      preferred: job.support.y[i] ? 'left' : 'right' });
  }
  const predictions = Object.fromEntries((job.methods ?? ['A', 'B', 'B_plus', 'B_recent', 'C']).map((name) => [name,
    job.query.left.map((left, i) => methods.compare(name, {
      left: { id: `${job.query.ids[i]}-a`, features: left },
      right: { id: `${job.query.ids[i]}-b`, features: job.query.right[i] }
    }).choice === 'left' ? 1 : 0)]));
  return { id: job.id, predictions };
});
process.stdout.write(JSON.stringify(result));
