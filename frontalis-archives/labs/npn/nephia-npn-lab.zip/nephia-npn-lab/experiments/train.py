import json
import time
import platform
import sys
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F

from npn.data import pairs, reaction_series
from npn.model import NPN, tensor

ROOT = Path(__file__).resolve().parents[1]
torch.set_num_threads(2)
seed = int(sys.argv[1]) if len(sys.argv) > 1 else 2417
suffix = "" if seed == 2417 else f"-seed{seed}"
torch.manual_seed(seed)
torch.use_deterministic_algorithms(True)
rng = np.random.default_rng(seed)
(ROOT / "models").mkdir(exist_ok=True)
(ROOT / "reports").mkdir(exist_ok=True)


def pools(persona_ids):
    left, right, labels, query_left, query_right, query_labels, raw, domains, gaps, reactions = [], [], [], [], [], [], [], [], [], []
    for pid in persona_ids:
        source = [pairs(pid, d, 256, 10) for d in range(3)]
        query = [pairs(pid, d, 256, 20) for d in range(3)]
        left.append(np.stack([s["left"] for s in source])); right.append(np.stack([s["right"] for s in source]))
        labels.append(np.stack([s["y"] for s in source]))
        query_left.append(np.stack([s["left"] for s in query])); query_right.append(np.stack([s["right"] for s in query]))
        query_labels.append(np.stack([s["y"] for s in query]))
        sequence = reaction_series(pid, 12)
        raw.append(sequence["raw"]); domains.append(sequence["domain"])
        gaps.append(sequence["gaps"]); reactions.append(sequence["targets"])
    values = (left, right, labels, query_left, query_right, query_labels, raw, domains, gaps, reactions)
    return [tensor(np.asarray(value), torch.long if i == 7 else torch.float32) for i, value in enumerate(values)]


train_ids = list(range(64))
validation_ids = list(range(100, 116))
pool = pools(train_ids)
validation = pools(validation_ids)
model = NPN()
initial = model.artifact({"stage": "initial", "seed": seed})
(ROOT / "models" / f"initial{suffix}.json").write_text(json.dumps(initial), encoding="utf-8")
optimizer = torch.optim.AdamW(model.parameters(), lr=0.003, weight_decay=0.0001)


def validate():
    model.eval()
    with torch.no_grad():
        left, right, labels, ql, qr, qy, raw, rd, gaps, targets = validation
        sd = torch.zeros((16, 32), dtype=torch.long)
        latent = model.latent(left[:, 0, :32], right[:, 0, :32], sd, labels[:, 0, :32])
        ql = ql[:, :, :64].reshape(16, 192, 6); qr = qr[:, :, :64].reshape(16, 192, 6)
        qd = torch.arange(3).repeat_interleave(64).unsqueeze(0).expand(16, -1)
        qy = qy[:, :, :64].reshape(16, 192)
        logits = model.logits(latent, ql, qr, qd)
        bce = F.binary_cross_entropy_with_logits(logits, qy)
        mse = F.mse_loss(model.reactions(latent, raw, rd, gaps), targets)
        cross_acc = ((logits[:, 64:] >= 0) == qy[:, 64:].bool()).float().mean()
        return {"loss": float(bce + 0.2*mse), "preferenceLoss": float(bce),
                "reactionMSE": float(mse), "crossAccuracy": float(cross_acc)}


history = [{"step": 0, **validate()}]
best_loss = float("inf")
best = None
started = time.perf_counter()
for step in range(1, 3001):
    model.train()
    ids = tensor(rng.integers(0, 64, 16), torch.long)
    source_domains = tensor(rng.integers(0, 3, 16), torch.long)
    count = int(rng.choice([8, 16, 32, 64]))
    support_indices = tensor(rng.integers(0, 256, (16, count)), torch.long)
    batch = ids[:, None]; sd = source_domains[:, None].expand(-1, count)
    left = pool[0][batch, sd, support_indices]; right = pool[1][batch, sd, support_indices]
    labels = pool[2][batch, sd, support_indices]
    query_domains = tensor(rng.integers(0, 3, (16, 48)), torch.long)
    query_indices = tensor(rng.integers(0, 256, (16, 48)), torch.long)
    ql = pool[3][batch, query_domains, query_indices]; qr = pool[4][batch, query_domains, query_indices]
    qy = pool[5][batch, query_domains, query_indices]
    latent = model.latent(left, right, sd, labels)
    logits = model.logits(latent, ql, qr, query_domains)
    prediction = model.reactions(latent, pool[6][ids], pool[7][ids], pool[8][ids])
    loss = F.binary_cross_entropy_with_logits(logits, qy) + 0.2*F.mse_loss(prediction, pool[9][ids])
    optimizer.zero_grad(); loss.backward()
    torch.nn.utils.clip_grad_norm_(model.parameters(), 5)
    optimizer.step()
    if step % 200 == 0:
        measured = validate(); history.append({"step": step, **measured})
        print(json.dumps({"step": step, **measured}), flush=True)
        if measured["loss"] < best_loss:
            best_loss = measured["loss"]
            best = model.artifact({"stage": "trained", "seed": seed, "step": step,
                                  "trainingPersonas": train_ids, "validationPersonas": validation_ids,
                                  "losses": {"preference": "BCE", "reaction": "MSE", "reactionWeight": 0.2}})
            (ROOT / "models" / f"trained{suffix}.json").write_text(json.dumps(best), encoding="utf-8")

result = {"torch": torch.__version__, "python": platform.python_version(), "cpuOnly": True,
          "cudaAvailable": torch.cuda.is_available(), "threads": torch.get_num_threads(),
          "trainingSeconds": time.perf_counter()-started,
          "parameters": sum(p.numel() for p in model.parameters()),
          "initialHash": initial["sha256"], "selectedHash": best["sha256"],
          "selectedStep": best["payload"]["metadata"]["step"], "history": history,
          "protocol": "phase2-cnp-v1", "testLabelsUsedInSelection": False}
(ROOT / "reports" / f"training{suffix}.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps({"trainingComplete": True, **{k: result[k] for k in ("parameters", "trainingSeconds", "selectedStep")}}), flush=True)
