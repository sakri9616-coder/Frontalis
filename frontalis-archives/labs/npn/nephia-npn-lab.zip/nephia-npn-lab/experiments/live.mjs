import { spawn, execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Methods } from '../../nephia-core-lab/experiments/baselines.mjs';

const lab = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const paths = JSON.parse(readFileSync(join(lab, 'runtime-paths.json'), 'utf8'));
execFileSync(paths.inferencePython, [join(lab, 'scripts', 'prepare-live.py')], { cwd: lab, windowsHide: true,
  env: { ...process.env, PYTHONPATH: lab, PYTHONIOENCODING: 'utf-8' } });
const cases = JSON.parse(readFileSync(join(lab, 'reports', 'live-cases.json'), 'utf8'));
const support = readFileSync(join(lab, 'data', 'personalization-support.jsonl'), 'utf8').split('\n')
  .filter(Boolean).map((line) => JSON.parse(line)).find((row) => row.id === 'shared-200').support;
const methods = new Methods();
support.ids.forEach((id, i) => methods.update({ id, kind: 'preference', owner: 'nephia', signal: 'self_report', confidence: 1,
  left: { id: `${id}-a`, features: support.left[i] }, right: { id: `${id}-b`, features: support.right[i] },
  preferred: support.y[i] ? 'left' : 'right' }));
const work = join(lab, 'runtime', 'live'); const reports = join(lab, 'reports', 'live');
mkdirSync(work, { recursive: true }); mkdirSync(reports, { recursive: true });
const engine = process.argv[2] ?? 'haiku';
if (!['haiku', 'sonnet'].includes(engine)) throw new Error('Unknown subscription model.');
const binding = process.argv[3] === 'binding';
const runName = binding ? `${engine}-binding` : engine;
const system = binding ? 'あなたはNephia Coreの判断を言葉にする推論エンジンです。' +
  '各選択はCoreが確定しています。入力のidとchoiceをそのまま出力し、短い日本語で説明してください。' +
  'marginは候補間のスコア差で、確率ではありません。sourceIdsは来歴であり、内容が与えられていない経験を捏造しません。' +
  'ツールや外部情報は使わずJSONだけを出力します。' : 'あなたは架空のコンパニオン、ネフィアです。初期の好き嫌いは指定しません。' +
  '自分の経験とユーザーの好みを区別し、未知の候補について判断します。これは架空の数値実験です。' +
  '8つの入力座標は外部で学習した共通表現で、性格名を付けた固定スコアではありません。' +
  'ツールや外部情報は使わず、与えられた経験・提案を使い、出力はJSONだけにします。';

function prompt(mode) {
  if (binding) return JSON.stringify({ instruction: '全12件のidとnpn.choiceを厳密に保持してください。' +
    '形式: {"answers":[{"id":"入力と同じID","choice":"入力のnpn.choice","reason":"短い日本語の説明"}]}。',
    queries: cases.map((sample) => ({ id: sample.id, domain: sample.domain, npn: sample.npn })) });
  const queries = cases.map((sample) => ({ id: sample.id, domain: sample.domain,
    left: sample.left, right: sample.right,
    ...(mode !== 'A' ? { memories: sample.memories } : {}),
    ...(mode === 'D' ? { npn: sample.npn } : {}),
    ...(mode === 'C' ? { linear: methods.compare('C', { left: { id: 'a', features: sample.leftRaw }, right: { id: 'b', features: sample.rightRaw } }) } : {})
  }));
  return JSON.stringify({ instruction: '各候補の座標は全領域で共通の学習済み表現です。sourceの経験はstoryだけです。' +
    'あなた自身の選好を踏まえ、全問題でleft/rightを選んでください。npn/linearは外部の判断候補で、異論があれば理由を短く書いてよいです。' +
    '形式: {"answers":[{"id":"問題ID","choice":"leftまたはright","reason":"短い日本語の理由"}]}。' +
    '記憶がない場合はそれを述べます。入力にない具体的な経験や性格を捏造しません。', queries });
}

function environment() {
  const env = { ...process.env };
  for (const key of Object.keys(env)) if (/api.?key|auth.?token|oauth.?token|^ANTHROPIC_|^CLAUDE_CODE_USE_|^CLAUDECODE$|^CLAUDE_CODE_ENTRYPOINT$|^CLAUDE_CODE_SIMPLE$/i.test(key)) delete env[key];
  return env;
}
async function ask(user) {
  const env = environment();
  const auth = JSON.parse(execFileSync('claude', ['auth', 'status', '--json'], { env, cwd: work, windowsHide: true, encoding: 'utf8', timeout: 30000 }));
  if (!auth.loggedIn || auth.authMethod !== 'claude.ai' || (auth.apiKeySource && auth.apiKeySource !== 'none')) throw new Error('Subscription routing is unverified; inference is not submitted.');
  const args = ['-p', '--safe-mode', '--input-format', 'stream-json', '--output-format', 'stream-json', '--verbose',
    '--no-session-persistence', '--model', engine, '--tools', '', '--strict-mcp-config', '--mcp-config', '{"mcpServers":{}}',
    '--setting-sources', '', '--permission-mode', 'dontAsk', '--system-prompt', system];
  return await new Promise((done, fail) => {
    const child = spawn('claude', args, { env, cwd: work, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    let buffer = ''; let result; let init; let stopped = false;
    const timer = setTimeout(() => { stopped = true; child.kill(); fail(new Error('Subscription inference timed out.')); }, 180000);
    child.on('error', (error) => { clearTimeout(timer); fail(error); });
    child.stderr.on('data', () => {});
    child.stdout.setEncoding('utf8').on('data', (chunk) => {
      buffer += chunk; let index;
      while ((index = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, index); buffer = buffer.slice(index+1);
        let event; try { event = JSON.parse(line); } catch { continue; }
        if (event.type === 'system' && event.subtype === 'init') {
          init = { model: event.model, apiKeySource: event.apiKeySource };
          if (event.apiKeySource !== 'none') { stopped = true; clearTimeout(timer); child.kill(); fail(new Error('Init rejected subscription routing.')); }
        }
        if (event.type === 'result') { result = event; child.stdin.end(); }
      }
    });
    child.on('close', (code) => {
      clearTimeout(timer); if (stopped) return;
      if (code !== 0 || !result || result.is_error || init?.apiKeySource !== 'none') {
        fail(new Error(`CLI failed: exit=${code}, ${String(result?.result ?? 'no result').slice(0, 200)}`)); return;
      }
      done({ text: result.result, model: init.model, authentication: { method: auth.authMethod, apiKeySource: init.apiKeySource }, usage: result.usage });
    });
    child.stdin.write(JSON.stringify({ type: 'user', message: { role: 'user', content: user } })+'\n');
  });
}

const result = { engine, date: new Date().toISOString(), modelHash: cases[0].npn.modelHash,
  scope: binding ? 'Exploratory binding rendering: the same 12 cases and snapshot; host decisions are fixed, no memory or numeric feature inference.' : '12 fixed synthetic cases, advisory NPN decoded judgments, one run per condition.', conditions: [] };
for (const mode of binding ? ['binding'] : ['A', 'B', 'C', 'D']) {
  const user = prompt(mode); const started = Date.now();
  writeFileSync(join(reports, `${runName}-${mode}-input.json`), JSON.stringify({ system, user: JSON.parse(user) }, null, 2));
  try {
    const response = await ask(user);
    writeFileSync(join(reports, `${runName}-${mode}-output.json`), JSON.stringify(response, null, 2));
    const parsed = JSON.parse(response.text.trim().replace(/^```(?:json)?\s*/, '').replace(/\s*```$/, ''));
    if (!Array.isArray(parsed.answers) || parsed.answers.length !== cases.length || new Set(parsed.answers.map((a) => a.id)).size !== cases.length ||
      parsed.answers.some((a) => !cases.some((c) => c.id === a.id) || !['left', 'right'].includes(a.choice))) throw new Error('Invalid answer contract.');
    const records = parsed.answers.map((answer) => { const c = cases.find((c) => c.id === answer.id);
      return { ...answer, domain: c.domain, expected: c.expected, npnChoice: c.npn.choice,
        correct: answer.choice === c.expected, agreesWithNPN: answer.choice === c.npn.choice }; });
    if (binding && records.some((record) => !record.agreesWithNPN)) throw new Error('Binding decision mismatch; response is not accepted.');
    result.conditions.push({ mode, status: 'complete', model: response.model, milliseconds: Date.now()-started,
      accuracy: records.filter((r) => r.correct).length/records.length,
      npnAgreement: records.filter((r) => r.agreesWithNPN).length/records.length, records });
    console.log(JSON.stringify({ engine, mode, accuracy: result.conditions.at(-1).accuracy }));
  } catch (error) {
    result.conditions.push({ mode, status: 'failed', error: error.message });
    console.log(JSON.stringify({ engine, mode, error: error.message })); break;
  }
  writeFileSync(join(reports, `${runName}-results.json`), JSON.stringify(result, null, 2));
}
writeFileSync(join(reports, `${runName}-results.json`), JSON.stringify(result, null, 2));
