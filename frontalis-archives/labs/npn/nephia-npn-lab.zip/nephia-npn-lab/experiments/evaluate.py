import copy
import json
import subprocess
import time
import sys
from pathlib import Path
import numpy as np
import torch

from npn.data import pairs, reaction_series, serial, public_pairs, ENCODER_VERSION
from npn.model import NPN, tensor, adapt_personal_head, digest
from npn.runtime import Runtime, snapshot, restore

ROOT = Path(__file__).resolve().parents[1]
torch.set_num_threads(2)
seed = int(sys.argv[1]) if len(sys.argv) > 1 else 2417
suffix = "" if seed == 2417 else f"-seed{seed}"
artifact = json.loads((ROOT / "models" / f"trained{suffix}.json").read_text(encoding="utf-8"))
initial_artifact = json.loads((ROOT / "models" / f"initial{suffix}.json").read_text(encoding="utf-8"))
model = NPN.from_artifact(artifact)
runtime = Runtime(artifact)
untrained = Runtime(initial_artifact)
started = time.perf_counter()
(ROOT / "data").mkdir(exist_ok=True)


def support(pid, n=32, noise=0, independent=False, stream=50, changed=False):
    data = pairs(pid, 0, 64, stream, independent, changed)
    result = {key: value[:n] for key, value in data.items() if key in ("left", "right", "domain", "y", "ids")}
    if noise:
        rng = np.random.default_rng(9823+pid)
        flip = rng.random(n) < noise
        result["y"] = np.where(flip, 1-result["y"], result["y"])
    return result


def query(pid, independent=False, changed=False):
    data = [pairs(pid, d, 120, 60, independent, changed) for d in range(3)]
    return {key: sum([s[key] for s in data], []) if key == "ids" else np.concatenate([s[key] for s in data])
            for key in data[0]}


def learned_state(source):
    value = adapt_personal_head(model, source)
    value.update({"formatVersion": 1, "modelHash": artifact["sha256"]})
    return value


def ridge(source):
    features = runtime.facets(source["left"], source["domain"]) - runtime.facets(source["right"], source["domain"])
    return np.linalg.solve(features.T@features + 0.1*np.eye(features.shape[1]), features.T@(2*source["y"]-1))


def predictions(source, target, state, shuffled_state=None):
    z = np.asarray(state["longLatent"])
    base = runtime.latent(source)
    frozen = learned_state({key: value[:4] for key, value in source.items()})
    def classify(engine, latent):
        return (engine.logits(latent, target["left"], target["right"], target["domain"]) >= 0).astype(int)
    output = {"D": classify(runtime, z), "E_ridge": classify(runtime, ridge(source)),
              "D_no_head": classify(runtime, base), "D_zero": classify(runtime, np.zeros_like(z)),
              "D_fixed4": classify(runtime, frozen["longLatent"]),
              "D_untrained": classify(untrained, untrained.latent(source))}
    if shuffled_state:
        output["D_shuffled"] = classify(runtime, shuffled_state["longLatent"])
    return output


personas = list(range(200, 240))
states = {pid: learned_state(support(pid)) for pid in personas}
rows = []
jobs = []
aligned_jobs = []
raw_outputs = []
continuity = []
for condition in ("shared", "noise20", "independent", "drift"):
    for index, pid in enumerate(personas):
        src = support(pid, noise=0.2 if condition == "noise20" else 0,
                      independent=condition == "independent", stream=70 if condition == "drift" else 50,
                      changed=condition == "drift")
        target = query(pid, independent=condition == "independent", changed=condition == "drift")
        state = learned_state(src)
        shuffled = states[personas[(index+1) % len(personas)]]
        pred = predictions(src, target, state, shuffled)
        if condition in ("shared", "noise20"):
            same_choices = predictions(src, src, state)
            continuity.append({"condition": condition, "persona": pid,
                               "observedChoiceAgreement": {key: float(np.mean(value == src["y"])) for key, value in same_choices.items()}})
        if condition == "drift":
            stale = states[pid]
            pred["D_stale"] = (runtime.logits(stale["longLatent"], target["left"], target["right"], target["domain"]) >= 0).astype(int)
            old = support(pid)
            replay_source = {key: old[key] + src[key] if key == "ids" else np.concatenate([old[key], src[key]]) for key in src}
            replay_state = learned_state(replay_source)
            pred["D_replay"] = (runtime.logits(replay_state["longLatent"], target["left"], target["right"], target["domain"]) >= 0).astype(int)
            old_expected = query(pid)["y"]
            unchanged = old_expected[120:] == target["y"][120:]
            continuity.append({"condition": "drift", "persona": pid,
                               "unchangedCrossBefore": float(np.mean(pred["D_stale"][120:][unchanged] == target["y"][120:][unchanged])),
                               "unchangedCrossFresh": float(np.mean(pred["D"][120:][unchanged] == target["y"][120:][unchanged])),
                               "unchangedCrossReplay": float(np.mean(pred["D_replay"][120:][unchanged] == target["y"][120:][unchanged]))})
        identifier = f"{condition}-{pid}"
        raw_outputs.append({"id": identifier, "pid": pid, "condition": condition, "support": src,
                            "query": target, "state": state, "predictions": pred})
        jobs.append({"id": identifier, "support": serial(src),
                     "query": serial({**public_pairs(target), "ids": target["ids"]})})
        aligned_source = {**serial(src), "left": runtime.facets(src["left"], src["domain"]).tolist(),
                          "right": runtime.facets(src["right"], src["domain"]).tolist()}
        aligned_query = {"ids": target["ids"], "left": runtime.facets(target["left"], target["domain"]).tolist(),
                         "right": runtime.facets(target["right"], target["domain"]).tolist()}
        aligned_jobs.append({"id": identifier, "support": aligned_source, "query": aligned_query, "methods": ["B", "B_plus"]})

completed = subprocess.run(["node", str(ROOT / "experiments" / "phase1-baselines.mjs")],
                           input=json.dumps(jobs), capture_output=True, text=True, check=True,
                           creationflags=subprocess.CREATE_NO_WINDOW)
baseline = {job["id"]: job["predictions"] for job in json.loads(completed.stdout)}
aligned_run = subprocess.run(["node", str(ROOT / "experiments" / "phase1-baselines.mjs")],
                            input=json.dumps(aligned_jobs), capture_output=True, text=True, check=True,
                            creationflags=subprocess.CREATE_NO_WINDOW)
aligned = {job["id"]: job["predictions"] for job in json.loads(aligned_run.stdout)}
pred_file = (ROOT / "reports" / f"predictions{suffix}.jsonl").open("w", encoding="utf-8")
for row in raw_outputs:
    predictions_all = {**baseline[row["id"]], **row["predictions"],
                       "B_learned_space": aligned[row["id"]]["B"],
                       "B_plus_learned_space": aligned[row["id"]]["B_plus"]}
    expected = row["query"]["y"]
    scores = {}
    for method, choices in predictions_all.items():
        choices = np.asarray(choices)
        scores[method] = {"within": float(np.mean(choices[:120] == expected[:120])),
                          "cross": float(np.mean(choices[120:] == expected[120:]))}
    rows.append({"persona": row["pid"], "condition": row["condition"], "scores": scores})
    pred_file.write(json.dumps({"id": row["id"], "queryIds": row["query"]["ids"],
                              "expected": expected.tolist(),
                              "predictions": {k: np.asarray(v).tolist() for k, v in predictions_all.items()}})+"\n")
pred_file.close()


def ci(differences):
    values = np.asarray(differences)
    rng = np.random.default_rng(935)
    boot = values[rng.integers(0, len(values), (2000, len(values)))].mean(axis=1)
    return {"mean": float(values.mean()), "low": float(np.quantile(boot, 0.025)), "high": float(np.quantile(boot, 0.975))}


summary = {}
for condition in ("shared", "noise20", "independent", "drift"):
    subset = [row for row in rows if row["condition"] == condition]
    summary[condition] = {method: {stage: float(np.mean([row["scores"][method][stage] for row in subset]))
                                  for stage in ("within", "cross")} for method in subset[0]["scores"]}
    summary[condition]["pairedDifference"] = {method: ci([row["scores"]["D"]["cross"]-row["scores"][method]["cross"] for row in subset])
                                              for method in ("B", "B_plus", "C", "E_ridge", "B_learned_space", "B_plus_learned_space", "D_no_head", "D_shuffled", "D_zero", "D_untrained")}

curves = []
for n in (4, 8, 16, 32, 64):
    for pid in personas:
        src = support(pid, n); target = query(pid)
        state = learned_state(src)
        score = predictions(src, target, state)
        curves.append({"n": n, "persona": pid, "scores": {method: float(np.mean(value[120:] == target["y"][120:]))
                                                       for method, value in score.items()}})

reaction_rows = []
for pid in personas:
    state = copy.deepcopy(states[pid]); sequence = reaction_series(pid, 24, 45)
    outputs = []
    for raw, domain, gap in zip(sequence["raw"], sequence["domain"], sequence["gaps"]):
        state, response = runtime.observe_reaction(state, raw, int(domain), float(gap))
        outputs.append(response)
    outputs = np.asarray(outputs)
    long_before = state["longLatent"][:]
    short_norm_before = float(np.linalg.norm(state["shortState"]))
    state_after = runtime.elapse(state, 30)
    target = sequence["targets"]
    reaction_rows.append({"persona": pid, "MSE": float(np.mean((outputs-target)**2)),
                          "zeroMSE": float(np.mean(target**2)),
                          "shortNormBefore": short_norm_before, "shortNormAfter": float(np.linalg.norm(state_after["shortState"])),
                          "longUnchanged": state_after["longLatent"] == long_before})

state = states[200]
dump = snapshot(artifact, state, 32, "synthetic-input-hash")
restored, restored_state = restore(json.loads(json.dumps(dump)))
sample = query(200)
before = runtime.logits(state["longLatent"], sample["left"], sample["right"], sample["domain"])
after = restored.logits(restored_state["longLatent"], sample["left"], sample["right"], sample["domain"])
restoration_exact = bool(np.array_equal(before, after))
(ROOT / "models" / f"persona-200{suffix}.json").write_text(json.dumps(dump), encoding="utf-8")

with (ROOT / "data" / "personalization-support.jsonl").open("w", encoding="utf-8") as file:
    for row in raw_outputs:
        file.write(json.dumps({"id": row["id"], "support": serial(row["support"])})+"\n")
with (ROOT / "data" / "heldout-evaluation.jsonl").open("w", encoding="utf-8") as file:
    for row in raw_outputs:
        file.write(json.dumps({"id": row["id"], "query": serial(row["query"])})+"\n")

training = json.loads((ROOT / "reports" / f"training{suffix}.json").read_text(encoding="utf-8"))
result = {"protocol": "phase2-cnp-v1", "trainingSeed": seed, "modelHash": artifact["sha256"], "training": training,
          "generatorVersion": "fixed-pool-v2", "provenanceCorrection": "Pair identity is now independent of requested batch size. Training/validation pools of size 256 are numerically unchanged; personalization and test fixtures were regenerated.",
          "testPersonas": personas, "labelsPerEvaluationPersona": 32, "withinQueries": 120, "crossQueries": 240,
          "scope": "Synthetic cross-domain transfer to unseen personas. Shared training observed every evaluated domain for other personas.",
          "exploratoryAddition": "Memory retrieval and summary in the same learned facet space were added after the first evaluation to isolate representation benefit from latent personalization benefit.",
          "summary": summary, "rows": rows, "curves": curves, "continuity": continuity,
          "reaction": {"rows": reaction_rows, "MSE": float(np.mean([row["MSE"] for row in reaction_rows])),
                       "zeroMSE": float(np.mean([row["zeroMSE"] for row in reaction_rows])),
                       "allLongUnchangedOnElapse": all(row["longUnchanged"] for row in reaction_rows)},
          "restoration": {"exact": restoration_exact, "queries": len(before), "snapshotBytes": len(json.dumps(dump).encode())},
          "evaluationSeconds": time.perf_counter()-started,
          "datasetHash": digest([serial({"support": serial(row["support"]), "query": serial(row["query"])}) for row in raw_outputs])}
(ROOT / "reports" / f"results{suffix}.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps({"summary": summary, "reaction": {k: v for k, v in result["reaction"].items() if k != "rows"},
                  "restoration": result["restoration"], "evaluationSeconds": result["evaluationSeconds"]}), flush=True)
