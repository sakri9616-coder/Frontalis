"""NumPy-only inference never imports Torch or trains shared parameters."""
import hashlib
import json
import numpy as np
from npn.canonical import digest, HASH_ENCODING

MODEL_VERSION = "npn-cnp-v1"
ENCODER_VERSION = "synthetic-domain-v1"


class Runtime:
    def __init__(self, artifact):
        payload = artifact["payload"]
        if artifact["sha256"] != digest(payload) or payload["formatVersion"] != 2 or payload["hashEncoding"] != HASH_ENCODING or payload["modelVersion"] != MODEL_VERSION or payload["encoderVersion"] != ENCODER_VERSION:
            raise ValueError("Model integrity or representation version mismatch.")
        if payload["config"]["inputDim"] != 6 or payload["config"]["domains"] != 3:
            raise ValueError("Unsupported input schema.")
        self.model_hash = artifact["sha256"]
        self.config = payload["config"]
        self.weights = {name: np.asarray(value, dtype=np.float32) for name, value in payload["weights"].items()}
        width = self.config["width"]; latent = self.config["latentDim"]
        if not isinstance(width, int) or not isinstance(latent, int) or not (1 <= width <= 128 and 1 <= latent <= 32):
            raise ValueError("Unsupported network shape.")
        shapes = {"domain_maps": (3, 6, 6), "feature.0.weight": (width, 6), "feature.0.bias": (width,),
                  "feature.2.weight": (latent, width), "feature.2.bias": (latent,),
                  "encoder.0.weight": (16, latent), "encoder.0.bias": (16,), "encoder.2.weight": (latent, 16), "encoder.2.bias": (latent,),
                  "force.0.weight": (16, latent), "force.0.bias": (16,), "force.2.weight": (4, 16), "force.2.bias": (4,),
                  "decay_logits": (4,), "reaction_readout.weight": (2, 4), "reaction_readout.bias": (2,)}
        if set(shapes) != set(self.weights) or any(self.weights[key].shape != shape for key, shape in shapes.items()):
            raise ValueError("Weight schema mismatch.")
        if not all(np.isfinite(value).all() for value in self.weights.values()):
            raise ValueError("Nonfinite model weights.")
        self.decay = 1/(1+np.exp(-self.weights["decay_logits"]))

    def linear(self, x, name):
        return x @ self.weights[f"{name}.weight"].T + self.weights[f"{name}.bias"]

    def facets(self, raw, domains):
        raw = np.asarray(raw, dtype=np.float32)
        domains = np.asarray(domains)
        if raw.shape[-1] != 6 or not np.isfinite(raw).all() or not np.issubdtype(domains.dtype, np.integer) or np.any((domains < 0) | (domains >= 3)):
            raise ValueError("Invalid candidate features or unknown domain.")
        value = np.einsum("...ij,...j->...i", self.weights["domain_maps"][domains], raw*np.sqrt(6))
        return self.linear(np.tanh(self.linear(value, "feature.0")), "feature.2")

    def latent(self, support):
        labels = np.asarray(support["y"], dtype=np.float32)
        if labels.ndim != 1 or len(labels) == 0 or not np.isin(labels, [0, 1]).all():
            raise ValueError("Support must contain observed binary labels.")
        difference = self.facets(support["left"], support["domain"]) - self.facets(support["right"], support["domain"])
        mean = (difference*(2*labels-1)[:, None]).mean(axis=0)
        return self.linear(np.tanh(self.linear(mean, "encoder.0")), "encoder.2")

    def logits(self, latent, left, right, domains):
        value = np.asarray(latent, dtype=np.float32)
        if value.shape != (self.config["latentDim"],) or not np.isfinite(value).all():
            raise ValueError("Invalid latent state.")
        return (self.facets(left, domains) - self.facets(right, domains)) @ value

    def new_state(self, support, owner="nephia"):
        if owner not in ("nephia", "user"):
            raise ValueError("Unknown owner.")
        base = self.latent(support)
        return {"formatVersion": 1, "owner": owner, "modelHash": self.model_hash,
                "encoderVersion": ENCODER_VERSION, "base": base.tolist(),
                "personalWeights": [0.0]*len(base), "longLatent": base.tolist(),
                "shortState": [0.0]*4, "time": 0.0, "experienceIds": list(support["ids"]), "steps": 0}

    def validate_state(self, state, owner):
        if owner not in ("nephia", "user") or state.get("formatVersion") != 1:
            raise ValueError("Unknown state owner or format.")
        if state.get("owner") != owner or state.get("modelHash") != self.model_hash or state.get("encoderVersion") != ENCODER_VERSION:
            raise ValueError("State owner/model/encoder mismatch.")
        for field, size in (("base", self.config["latentDim"]), ("longLatent", self.config["latentDim"]), ("shortState", 4), ("personalWeights", self.config["latentDim"])):
            value = np.asarray(state[field])
            if value.shape != (size,) or not np.isfinite(value).all():
                raise ValueError("Invalid state shape.")
        if not np.allclose(np.asarray(state["base"])+np.asarray(state["personalWeights"]), state["longLatent"], rtol=1e-5, atol=1e-6):
            raise ValueError("Inconsistent personal state.")
        if not isinstance(state.get("time"), (int, float)) or not np.isfinite(state["time"]) or state["time"] < 0:
            raise ValueError("Invalid state time.")
        if type(state.get("steps")) is not int or state["steps"] < 0:
            raise ValueError("Invalid adaptation steps.")
        ids = state.get("experienceIds")
        if not isinstance(ids, list) or not ids or not all(isinstance(i, str) and i for i in ids) or len(set(ids)) != len(ids):
            raise ValueError("Invalid state provenance.")

    def observe_reaction(self, state, raw, domain, elapsed, owner="nephia"):
        self.validate_state(state, owner)
        if not isinstance(domain, (int, np.integer)) or isinstance(domain, bool) or not 0 <= domain < 3:
            raise ValueError("Unknown reaction domain.")
        if not np.isfinite(elapsed) or elapsed < 0:
            raise ValueError("Invalid elapsed time.")
        features = self.facets(np.asarray(raw), np.asarray(domain, dtype=np.int64))
        force = np.tanh(self.linear(np.tanh(self.linear(features*np.asarray(state["longLatent"]), "force.0")), "force.2"))
        factor = self.decay ** elapsed
        new_short = factor*np.asarray(state["shortState"]) + (1-factor)*force
        updated = {**state, "shortState": new_short.tolist(), "time": state["time"]+elapsed}
        return updated, self.linear(new_short, "reaction_readout").tolist()

    def elapse(self, state, elapsed, owner="nephia"):
        self.validate_state(state, owner)
        if not np.isfinite(elapsed) or elapsed < 0:
            raise ValueError("Invalid elapsed time.")
        return {**state, "shortState": (np.asarray(state["shortState"])*self.decay**elapsed).tolist(), "time": state["time"]+elapsed}


def snapshot(artifact, state, source_revision, source_hash):
    runtime = Runtime(artifact)
    runtime.validate_state(state, state["owner"])
    payload = {"formatVersion": 2, "hashEncoding": HASH_ENCODING, "model": artifact, "state": state,
               "sourceRevision": source_revision, "sourceHash": source_hash}
    return {"payload": payload, "sha256": digest(payload)}


def restore(value):
    if value["payload"].get("formatVersion") != 2 or value["sha256"] != digest(value["payload"]):
        raise ValueError("Snapshot integrity failure.")
    payload = value["payload"]
    runtime = Runtime(payload["model"])
    runtime.validate_state(payload["state"], payload["state"]["owner"])
    return runtime, payload["state"]
