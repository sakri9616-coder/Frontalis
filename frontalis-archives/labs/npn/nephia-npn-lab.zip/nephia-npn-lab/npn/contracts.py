INPUT_DIM = 6
ENCODER_VERSION = "synthetic-domain-v1"
DOMAINS = ("story", "ethics", "aesthetics")
