"""Synthetic supervision lives outside the learner and its runtime interfaces."""
import numpy as np
from npn.contracts import INPUT_DIM, ENCODER_VERSION, DOMAINS

FACETS = 8


def rotations():
    rng = np.random.default_rng(91804)
    values = [np.eye(INPUT_DIM)]
    for _ in range(2):
        q, _ = np.linalg.qr(rng.normal(size=(INPUT_DIM, INPUT_DIM)))
        values.append(q)
    return np.asarray(values, dtype=np.float32)


ROTATIONS = rotations()


def hidden_features(semantic):
    x = np.asarray(semantic)
    return np.stack([x[..., 0], x[..., 1], x[..., 2], x[..., 3],
                     1.5*x[..., 0]*x[..., 1], 1.5*x[..., 2]*x[..., 3],
                     x[..., 4]**2 - 1/3, x[..., 5]**2 - 1/3], axis=-1)


def hidden_persona(persona_id, independent=False):
    rng = np.random.default_rng(100003 + persona_id * 17)
    z = rng.normal(size=(3, FACETS))
    if not independent:
        z[:] = z[0]
    return z.astype(np.float32)


def pairs(persona_id, domain, n, stream, independent=False, changed=False):
    if n < 1 or n > 256:
        raise ValueError("Synthetic pair pool supports 1..256 cases.")
    rng = np.random.default_rng(739391 + persona_id*3001 + domain*101 + stream*97)
    semantic_left = rng.uniform(-1, 1, (256, INPUT_DIM)).astype(np.float32)[:n]
    semantic_right = rng.uniform(-1, 1, (256, INPUT_DIM)).astype(np.float32)[:n]
    z = hidden_persona(persona_id, independent)[domain].copy()
    if changed:
        z[np.argmax(np.abs(z))] *= -1
    left = semantic_left @ ROTATIONS[domain].T / np.sqrt(INPUT_DIM)
    right = semantic_right @ ROTATIONS[domain].T / np.sqrt(INPUT_DIM)
    margin = (hidden_features(semantic_left) - hidden_features(semantic_right)) @ z
    return {"left": left, "right": right, "domain": np.full(n, domain, np.int64),
            "y": (margin >= 0).astype(np.float32), "margin": margin,
            "ids": [f"p{persona_id}-{DOMAINS[domain]}-pool-v2-s{stream}-{i}" for i in range(n)]}


def reaction_series(persona_id, n, stream=40):
    rng = np.random.default_rng(90917 + persona_id*31 + stream)
    domains = rng.integers(0, 3, n)
    semantic = rng.uniform(-1, 1, (n, INPUT_DIM)).astype(np.float32)
    raw = np.stack([semantic[i] @ ROTATIONS[domains[i]].T / np.sqrt(INPUT_DIM) for i in range(n)])
    gaps = rng.integers(1, 4, n).astype(np.float32)
    z = hidden_persona(persona_id)[0]
    score = hidden_features(semantic) @ z
    forces = np.stack([np.tanh(0.8*score), np.abs(np.tanh(0.8*score))], axis=-1)
    state = np.zeros(2, np.float32)
    targets = []
    for force, gap in zip(forces, gaps):
        decay = np.asarray([0.72, 0.85]) ** gap
        state = decay * state + (1-decay) * force
        targets.append(state.copy())
    return {"raw": raw, "domain": domains, "gaps": gaps,
            "targets": np.asarray(targets, np.float32)}


def public_pairs(sample):
    """Inference sees no target labels, oracle weights, margins or persona IDs."""
    return {key: sample[key] for key in ("left", "right", "domain")}


def serial(sample):
    return {key: value.tolist() if isinstance(value, np.ndarray) else value for key, value in sample.items()}
