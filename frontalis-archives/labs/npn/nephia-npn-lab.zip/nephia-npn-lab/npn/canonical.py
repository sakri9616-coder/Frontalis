"""The digest treats 1 and 1.0 identically across JSON implementations."""
import hashlib
import json
import math
import struct

HASH_ENCODING = "ieee754-json-v1"


def normalized(value):
    if isinstance(value, bool) or value is None or isinstance(value, str):
        return value
    if isinstance(value, (int, float)):
        number = float(value)
        if not math.isfinite(number):
            raise ValueError("Nonfinite number in portable data.")
        if number == 0:
            number = 0.0
        return {"$number": struct.pack(">d", number).hex()}
    if isinstance(value, list):
        return [normalized(item) for item in value]
    if isinstance(value, dict):
        return {key: normalized(item) for key, item in value.items()}
    raise ValueError("Unsupported portable value.")


def digest(value):
    raw = json.dumps(normalized(value), sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()
