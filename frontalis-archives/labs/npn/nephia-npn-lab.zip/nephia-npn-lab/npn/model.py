"""A small conditional preference network and a separate learned transient state."""
import copy
import hashlib
import json
import torch
from torch import nn
import torch.nn.functional as F

from npn.contracts import INPUT_DIM, ENCODER_VERSION
from npn.canonical import digest, HASH_ENCODING

MODEL_VERSION = "npn-cnp-v1"


class NPN(nn.Module):
    def __init__(self, width=32, latent_dim=8):
        super().__init__()
        self.config = {"width": width, "latentDim": latent_dim, "inputDim": INPUT_DIM, "domains": 3}
        self.domain_maps = nn.Parameter(torch.eye(INPUT_DIM).repeat(3, 1, 1))
        self.feature = nn.Sequential(nn.Linear(INPUT_DIM, width), nn.Tanh(), nn.Linear(width, latent_dim))
        self.encoder = nn.Sequential(nn.Linear(latent_dim, 16), nn.Tanh(), nn.Linear(16, latent_dim))
        self.force = nn.Sequential(nn.Linear(latent_dim, 16), nn.Tanh(), nn.Linear(16, 4), nn.Tanh())
        self.decay_logits = nn.Parameter(torch.ones(4))
        self.reaction_readout = nn.Linear(4, 2)

    def facets(self, raw, domains):
        transformed = torch.einsum("...ij,...j->...i", self.domain_maps[domains], raw * INPUT_DIM**0.5)
        return self.feature(transformed)

    def latent(self, support_left, support_right, support_domains, labels):
        difference = self.facets(support_left, support_domains) - self.facets(support_right, support_domains)
        encoded = difference * (2*labels-1).unsqueeze(-1)
        return self.encoder(encoded.mean(dim=-2))

    def logits(self, latent, left, right, domains):
        difference = self.facets(left, domains) - self.facets(right, domains)
        return (difference * latent.unsqueeze(-2)).sum(dim=-1)

    def reactions(self, latent, raw, domains, gaps):
        facets = self.facets(raw, domains)
        force = self.force(facets * latent.unsqueeze(-2))
        decay = torch.sigmoid(self.decay_logits)
        state = torch.zeros(force.shape[0], 4, device=force.device)
        outputs = []
        for t in range(raw.shape[-2]):
            factor = decay.unsqueeze(0) ** gaps[:, t].unsqueeze(-1)
            state = factor*state + (1-factor)*force[:, t]
            outputs.append(self.reaction_readout(state))
        return torch.stack(outputs, dim=1)

    def artifact(self, metadata=None):
        payload = {"formatVersion": 2, "hashEncoding": HASH_ENCODING, "modelVersion": MODEL_VERSION, "encoderVersion": ENCODER_VERSION,
                   "config": self.config,
                   "weights": {name: value.detach().cpu().tolist() for name, value in self.state_dict().items()},
                   "metadata": metadata or {}}
        return {"payload": payload, "sha256": digest(payload)}

    @classmethod
    def from_artifact(cls, artifact):
        payload = artifact["payload"]
        if digest(payload) != artifact["sha256"] or payload["modelVersion"] != MODEL_VERSION or payload["formatVersion"] != 2:
            raise ValueError("Model integrity or version mismatch.")
        config = payload["config"]
        model = cls(config["width"], config["latentDim"])
        model.load_state_dict({name: torch.tensor(value, dtype=torch.float32) for name, value in payload["weights"].items()}, strict=True)
        return model.eval()


def tensor(value, dtype=torch.float32):
    return torch.as_tensor(value, dtype=dtype)


def infer_latent(model, support):
    with torch.no_grad():
        return model.latent(tensor(support["left"]), tensor(support["right"]),
                            tensor(support["domain"], torch.long), tensor(support["y"]))


def adapt_personal_head(model, support, steps=60):
    """Only the personal last-layer residual changes; shared weights stay fixed."""
    base = infer_latent(model, support).detach()
    with torch.no_grad():
        features = model.facets(tensor(support["left"]), tensor(support["domain"], torch.long)) - \
                   model.facets(tensor(support["right"]), tensor(support["domain"], torch.long))
    residual = nn.Parameter(torch.zeros_like(base))
    optimizer = torch.optim.Adam([residual], lr=0.04)
    targets = tensor(support["y"])
    for _ in range(steps):
        optimizer.zero_grad()
        logits = features @ (base+residual)
        loss = F.binary_cross_entropy_with_logits(logits, targets) + 0.08*residual.square().mean()
        loss.backward()
        optimizer.step()
    return {"base": base.tolist(), "personalWeights": residual.detach().tolist(),
            "longLatent": (base+residual.detach()).tolist(), "steps": steps,
            "experienceIds": list(support["ids"]), "encoderVersion": ENCODER_VERSION,
            "owner": "nephia", "shortState": [0.0]*4, "time": 0.0}
