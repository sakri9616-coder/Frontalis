import { createInterface } from 'node:readline';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { NephiaCore } from './core.mjs';
import { exactKeys, invariant } from './contracts.mjs';

const lab = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const core = new NephiaCore(process.argv.includes('--memory') ? ':memory:' : resolve(lab, 'runtime', 'core.db'));
const methods = {
  state: () => core.state(),
  context: (p) => { exactKeys(p, ['now']); return core.context(p.now); },
  compare: (p) => { exactKeys(p, ['owner', 'left', 'right']); return core.compare(p.owner, p.left, p.right); },
  propose: (p) => { exactKeys(p, ['event', 'expectedRevision']); return core.propose(p.event, p.expectedRevision); },
  accept: (p) => { exactKeys(p, ['id', 'expectedRevision', 'review']); return core.accept(p.id, p.expectedRevision, p.review); },
  reject: (p) => { exactKeys(p, ['id']); return core.reject(p.id); },
  rollback: (p) => { exactKeys(p, ['targetRevision', 'expectedRevision']); return core.rollback(p.targetRevision, p.expectedRevision); },
  export: () => core.exportPortable()
};
const lines = createInterface({ input: process.stdin, crlfDelay: Infinity });
lines.on('line', (line) => {
  let request;
  try {
    invariant(line.length <= 250000, 'Request is too large.');
    request = JSON.parse(line);
    exactKeys(request, ['id', 'method', 'params']);
    invariant(typeof request.id === 'string' || Number.isInteger(request.id), 'Invalid request ID.');
    invariant(Object.hasOwn(methods, request.method), 'Unknown method.');
    const result = methods[request.method](request.params);
    process.stdout.write(JSON.stringify({ id: request.id, result }) + '\n');
  } catch (error) {
    process.stdout.write(JSON.stringify({ id: request?.id ?? null, error: { message: error.message } }) + '\n');
  }
});
lines.on('close', () => core.close());
