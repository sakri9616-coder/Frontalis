export const FEATURE_NAMES = ['acoustic', 'energy', 'complexity', 'warmth', 'novelty', 'vocal'];
export const FEATURE_VERSION = 'music.v1';
export const DEFAULT_CONFIG = Object.freeze({ learningRate: 0.4, l2: 0.005, retention: 0.995 });

export const dot = (a, b) => a.reduce((sum, value, i) => sum + value * b[i], 0);
export const subtract = (a, b) => a.map((value, i) => value - b[i]);
export const sigmoid = (value) => 1 / (1 + Math.exp(-Math.max(-40, Math.min(40, value))));

/** A deterministic pairwise scorer owns no language-model parameters. */
export class OnlinePreference {
  constructor(config = DEFAULT_CONFIG) {
    this.config = { ...config };
    this.weights = FEATURE_NAMES.map(() => 0);
    this.support = FEATURE_NAMES.map(() => 0);
    this.count = 0;
    this.evidenceIds = [];
  }

  update(event) {
    const difference = subtract(event.left.features, event.right.features);
    const label = event.preferred === 'left' ? 1 : -1;
    const residual = label * sigmoid(-label * dot(this.weights, difference));
    const { retention, learningRate, l2 } = this.config;
    this.weights = this.weights.map((weight, i) => retention * weight +
      learningRate * event.confidence * (residual * difference[i] - l2 * weight));
    this.support = this.support.map((value, i) => value + difference[i] ** 2);
    this.count++;
    this.evidenceIds.push(event.id);
  }

  compare(left, right) {
    const difference = subtract(left.features, right.features);
    const contributions = difference.map((value, i) => ({
      feature: FEATURE_NAMES[i], weight: this.weights[i], difference: value,
      contribution: value * this.weights[i], support: this.support[i]
    }));
    const margin = contributions.reduce((sum, item) => sum + item.contribution, 0);
    const choice = margin === 0 ? (left.id.localeCompare(right.id, 'en') <= 0 ? 'left' : 'right') :
      (margin > 0 ? 'left' : 'right');
    return { choice, selectedId: choice === 'left' ? left.id : right.id, margin, contributions,
      evidenceIds: [...this.evidenceIds], trainingCount: this.count,
      uncertain: this.count < 8 || Math.abs(margin) < 0.15,
      uncertaintyMeaning: 'Heuristic support/margin flag; not a calibrated probability.' };
  }

  toJSON() {
    return { config: this.config, featureVersion: FEATURE_VERSION, weights: this.weights,
      support: this.support, count: this.count, evidenceIds: this.evidenceIds };
  }
}

/** Only independently reported or observed experience may change preferences. */
export function learns(event) {
  if (event.kind !== 'preference' || event.confidence < 0.5) return false;
  return (event.owner === 'nephia' && event.signal === 'self_report') ||
    (event.owner === 'user' && event.signal === 'user_report') || event.signal === 'observed_choice';
}

export function project(events, config = DEFAULT_CONFIG) {
  const models = { nephia: new OnlinePreference(config), user: new OnlinePreference(config) };
  const state = { identityReferences: [], episodes: [], selfAssessments: [], currentState: { nephia: {}, user: {} }, decisions: [] };
  for (const event of events) {
    if (learns(event)) models[event.owner].update(event);
    if (event.kind === 'identity_import') state.identityReferences.push(event);
    if (event.kind === 'episode') state.episodes.push(event);
    if (event.kind === 'self_assessment') state.selfAssessments.push(event);
    if (event.kind === 'transient') state.currentState[event.owner][event.key] = event;
    if (event.kind === 'preference') state.decisions.push({ id: event.id, owner: event.owner,
      signal: event.signal, learned: learns(event), evidence: event.evidence, preferred: event.preferred });
  }
  return { ...state, preferences: Object.fromEntries(Object.entries(models).map(([key, model]) => [key, model.toJSON()])) };
}

export function modelFromState(state, owner) {
  const data = state.preferences[owner];
  const model = new OnlinePreference(data.config);
  Object.assign(model, { weights: [...data.weights], support: [...data.support], count: data.count,
    evidenceIds: [...data.evidenceIds] });
  return model;
}
