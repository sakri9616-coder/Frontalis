import { FEATURE_NAMES, FEATURE_VERSION } from './learner.mjs';

export function invariant(condition, message) {
  if (!condition) throw new Error(message);
}

export function exactKeys(value, allowed, required = allowed) {
  invariant(value !== null && typeof value === 'object' && !Array.isArray(value), 'Expected an object.');
  invariant(Object.keys(value).every((key) => allowed.includes(key)), 'Unknown field.');
  invariant(required.every((key) => Object.hasOwn(value, key)), 'Missing field.');
}

function text(value, max = 4000) {
  invariant(typeof value === 'string' && value.trim().length > 0 && value.length <= max, 'Invalid text.');
}

export function validateCandidate(value) {
  exactKeys(value, ['id', 'features']);
  text(value.id, 160);
  invariant(Array.isArray(value.features) && value.features.length === FEATURE_NAMES.length &&
    value.features.every((feature) => Number.isFinite(feature) && feature >= -1 && feature <= 1), 'Invalid features.');
}

export function validateEvent(event) {
  const common = ['id', 'kind', 'owner', 'at', 'evidence'];
  const fields = {
    preference: ['featureVersion', 'left', 'right', 'preferred', 'signal', 'confidence'],
    episode: ['text'], self_assessment: ['text'], transient: ['key', 'value', 'expiresAt'],
    identity_import: ['sourcePath', 'sourceHash', 'text']
  };
  invariant(event && Object.hasOwn(fields, event.kind), 'Unknown event kind.');
  exactKeys(event, [...common, ...fields[event.kind]]);
  text(event.id, 160);
  invariant(['nephia', 'user'].includes(event.owner), 'Unknown owner.');
  invariant(typeof event.at === 'string' && Number.isFinite(Date.parse(event.at)), 'Invalid timestamp.');
  exactKeys(event.evidence, ['sourceId', 'locator', 'origin']);
  text(event.evidence.sourceId, 200);
  text(event.evidence.locator, 500);
  invariant(['synthetic', 'human', 'observation', 'model', 'legacy'].includes(event.evidence.origin), 'Invalid origin.');
  if (event.kind === 'preference') {
    invariant(event.featureVersion === FEATURE_VERSION, 'Feature version mismatch.');
    validateCandidate(event.left);
    validateCandidate(event.right);
    invariant(event.left.id !== event.right.id, 'Candidates must differ.');
    invariant(['left', 'right'].includes(event.preferred), 'Invalid preferred side.');
    invariant(['self_report', 'user_report', 'observed_choice', 'generated_choice', 'user_praise'].includes(event.signal), 'Invalid signal.');
    invariant(Number.isFinite(event.confidence) && event.confidence >= 0 && event.confidence <= 1, 'Invalid confidence.');
    invariant(event.signal !== 'self_report' || event.owner === 'nephia', 'Self report owner mismatch.');
    invariant(event.signal !== 'user_report' || event.owner === 'user', 'User report owner mismatch.');
    invariant(event.signal !== 'observed_choice' || ['observation', 'synthetic'].includes(event.evidence.origin), 'Choice has no observed outcome.');
  } else if (event.kind === 'transient') {
    text(event.key, 100); text(event.value, 500);
    invariant(Number.isFinite(Date.parse(event.expiresAt)) && Date.parse(event.expiresAt) > Date.parse(event.at), 'Invalid expiry.');
  } else {
    text(event.text, event.kind === 'identity_import' ? 100000 : 4000);
    invariant(event.kind !== 'self_assessment' || event.owner === 'nephia', 'Self assessment owner mismatch.');
    if (event.kind === 'identity_import') {
      invariant(event.owner === 'nephia' && event.evidence.origin === 'legacy', 'Identity import must be legacy self memory.');
      text(event.sourcePath, 1000);
      invariant(/^[a-f0-9]{64}$/.test(event.sourceHash), 'Invalid source hash.');
    }
  }
  return event;
}

export function validateConfig(config) {
  exactKeys(config, ['learningRate', 'l2', 'retention']);
  invariant(Number.isFinite(config.learningRate) && config.learningRate > 0 && config.learningRate <= 1, 'Invalid learning rate.');
  invariant(Number.isFinite(config.l2) && config.l2 >= 0 && config.l2 < 1, 'Invalid regularization.');
  invariant(Number.isFinite(config.retention) && config.retention > 0 && config.retention <= 1, 'Invalid retention.');
}
