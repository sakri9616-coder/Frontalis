import { DatabaseSync } from 'node:sqlite';
import { createHash } from 'node:crypto';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { DEFAULT_CONFIG, FEATURE_VERSION, modelFromState, project } from './learner.mjs';
import { invariant, exactKeys, validateCandidate, validateConfig, validateEvent } from './contracts.mjs';

export const FORMAT_VERSION = 2;
export const LEARNER_VERSION = 'pairwise-sgd.v1';

export function canonical(value) {
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (value !== null && typeof value === 'object') return '{' + Object.keys(value).sort()
    .map((key) => JSON.stringify(key) + ':' + canonical(value[key])).join(',') + '}';
  return JSON.stringify(value);
}
export const hash = (value) => createHash('sha256').update(canonical(value)).digest('hex');
export const textHash = (value) => createHash('sha256').update(value, 'utf8').digest('hex');

/** SQLite transactions make acceptance, branch movement and projection atomic. */
export class NephiaCore {
  constructor(file = ':memory:', config = DEFAULT_CONFIG) {
    validateConfig(config);
    if (file !== ':memory:') mkdirSync(dirname(file), { recursive: true });
    this.db = new DatabaseSync(file);
    try {
      const hasMeta = this.db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='meta'").get();
      if (!hasMeta) {
        const tables = this.db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
        invariant(tables.length === 0, 'Refuse to initialize a non-Core database.');
        this.db.exec('BEGIN IMMEDIATE');
        try {
          this.db.exec(`
            CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE events (id TEXT PRIMARY KEY, body TEXT NOT NULL, digest TEXT NOT NULL);
            CREATE TABLE proposals (id TEXT PRIMARY KEY, body TEXT NOT NULL, digest TEXT NOT NULL, base INTEGER NOT NULL, status TEXT NOT NULL);
            CREATE TABLE revisions (revision INTEGER PRIMARY KEY, parent INTEGER, kind TEXT NOT NULL, ids TEXT NOT NULL, state TEXT NOT NULL, digest TEXT NOT NULL);
          `);
          this.db.prepare('INSERT INTO meta VALUES (?, ?)').run('format', String(FORMAT_VERSION));
          this.db.prepare('INSERT INTO meta VALUES (?, ?)').run('config', canonical(config));
          this.db.prepare('INSERT INTO meta VALUES (?, ?)').run('learner', LEARNER_VERSION);
          this.db.prepare('INSERT INTO meta VALUES (?, ?)').run('head', '0');
          const empty = project([], config);
          this.db.prepare('INSERT INTO revisions VALUES (0, NULL, ?, ?, ?, ?)').run('init', '[]', canonical(empty), hash(empty));
          this.db.exec('COMMIT');
        } catch (error) { this.db.exec('ROLLBACK'); throw error; }
      }
      invariant(this.meta('format') === String(FORMAT_VERSION), 'Unsupported Core format; migration required.');
      invariant(this.meta('learner') === LEARNER_VERSION, 'Learner version mismatch; explicit migration required.');
      invariant(this.meta('config') === canonical(config), 'Learner configuration mismatch.');
      this.config = Object.freeze({ ...config });
      this.db.exec('PRAGMA busy_timeout=5000; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;');
      const initial = this.state();
      invariant(hash(project(this.activeEvents(), this.config)) === initial.stateHash, 'Stored projection does not match its event ledger.');
    } catch (error) { this.db.close(); throw error; }
  }

  meta(key) { return this.db.prepare('SELECT value FROM meta WHERE key=?').get(key)?.value; }
  get revision() { return Number(this.meta('head')); }
  close() { this.db.close(); }
  transaction(work) {
    this.db.exec('BEGIN IMMEDIATE');
    try { const result = work(); this.db.exec('COMMIT'); return result; }
    catch (error) { this.db.exec('ROLLBACK'); throw error; }
  }
  requireRevision(expected) {
    invariant(Number.isInteger(expected) && expected === this.revision, 'Stale revision.');
  }
  revisionRow(revision = this.revision) {
    const row = this.db.prepare('SELECT * FROM revisions WHERE revision=?').get(revision);
    invariant(row, 'Unknown revision.');
    return row;
  }
  state() {
    const row = this.revisionRow();
    const state = JSON.parse(row.state);
    invariant(hash(state) === row.digest, 'State integrity failure.');
    return { revision: row.revision, stateHash: row.digest, state };
  }
  activeEvents() {
    return JSON.parse(this.revisionRow().ids).map((id) => {
      const row = this.db.prepare('SELECT body, digest FROM events WHERE id=?').get(id);
      invariant(row && hash(JSON.parse(row.body)) === row.digest, 'Event integrity failure.');
      return JSON.parse(row.body);
    });
  }
  saveRevision(kind, ids) {
    const events = ids.map((id) => JSON.parse(this.db.prepare('SELECT body FROM events WHERE id=?').get(id).body));
    const state = project(events, this.config);
    const revision = this.db.prepare('SELECT COALESCE(MAX(revision),0)+1 AS n FROM revisions').get().n;
    this.db.prepare('INSERT INTO revisions VALUES (?, ?, ?, ?, ?, ?)')
      .run(revision, this.revision, kind, canonical(ids), canonical(state), hash(state));
    this.db.prepare("UPDATE meta SET value=? WHERE key='head'").run(String(revision));
    return this.state();
  }

  /** A proposal cannot mutate identity or preferences until a trusted host reviews it. */
  propose(event, expectedRevision) {
    validateEvent(event);
    invariant(event.kind !== 'identity_import', 'Identity import is a separate host operation.');
    return this.transaction(() => {
      const previous = this.db.prepare('SELECT * FROM proposals WHERE id=?').get(event.id);
      if (previous) {
        invariant(previous.digest === hash(event), 'Event ID content conflict.');
        return { id: event.id, status: previous.status, baseRevision: previous.base };
      }
      this.requireRevision(expectedRevision);
      this.db.prepare('INSERT INTO proposals VALUES (?, ?, ?, ?, ?)')
        .run(event.id, canonical(event), hash(event), expectedRevision, 'pending');
      return { id: event.id, status: 'pending', baseRevision: expectedRevision };
    });
  }

  accept(id, expectedRevision, review) {
    invariant(['host_verified', 'human_reviewed'].includes(review), 'Trusted review is required.');
    return this.transaction(() => {
      const proposal = this.db.prepare('SELECT * FROM proposals WHERE id=?').get(id);
      invariant(proposal, 'Unknown proposal.');
      if (proposal.status === 'accepted') return { ...this.state(), duplicate: true };
      invariant(proposal.status === 'pending', 'Proposal was rejected.');
      this.requireRevision(expectedRevision);
      invariant(proposal.base === expectedRevision, 'Proposal is based on stale state; create a new proposal.');
      const event = validateEvent(JSON.parse(proposal.body));
      invariant(hash(event) === proposal.digest, 'Proposal integrity failure.');
      invariant(!this.db.prepare('SELECT id FROM events WHERE id=?').get(id), 'Event already exists.');
      this.db.prepare('INSERT INTO events VALUES (?, ?, ?)').run(id, proposal.body, proposal.digest);
      this.db.prepare("UPDATE proposals SET status='accepted' WHERE id=?").run(id);
      return this.saveRevision('accept', [...JSON.parse(this.revisionRow().ids), id]);
    });
  }
  reject(id) {
    return this.transaction(() => {
      const proposal = this.db.prepare('SELECT status FROM proposals WHERE id=?').get(id);
      invariant(proposal?.status === 'pending', 'Only pending proposals can be rejected.');
      this.db.prepare("UPDATE proposals SET status='rejected' WHERE id=?").run(id);
      return { id, status: 'rejected' };
    });
  }
  record(event) {
    const revision = this.revision;
    this.propose(event, revision);
    return this.accept(event.id, revision, 'host_verified');
  }
  importIdentity(event, expectedRevision) {
    validateEvent(event);
    invariant(event.kind === 'identity_import' && textHash(event.text) === event.sourceHash, 'Identity source hash mismatch.');
    return this.transaction(() => {
      this.requireRevision(expectedRevision);
      this.db.prepare('INSERT INTO events VALUES (?, ?, ?)').run(event.id, canonical(event), hash(event));
      return this.saveRevision('import', [...JSON.parse(this.revisionRow().ids), event.id]);
    });
  }
  rollback(targetRevision, expectedRevision) {
    return this.transaction(() => {
      this.requireRevision(expectedRevision);
      const target = this.revisionRow(targetRevision);
      return this.saveRevision('rollback', JSON.parse(target.ids));
    });
  }
  compare(owner, left, right) {
    invariant(['nephia', 'user'].includes(owner), 'Unknown owner.');
    validateCandidate(left); validateCandidate(right);
    invariant(left.id !== right.id, 'Candidates must differ.');
    const snapshot = this.state();
    return { revision: snapshot.revision, stateHash: snapshot.stateHash, owner,
      featureVersion: FEATURE_VERSION, ...modelFromState(snapshot.state, owner).compare(left, right) };
  }
  context(now = Date.now()) {
    invariant(Number.isFinite(now), 'Invalid context time.');
    const snapshot = this.state();
    const state = structuredClone(snapshot.state);
    state.currentState = Object.fromEntries(Object.entries(state.currentState).map(([owner, entries]) => [owner,
      Object.fromEntries(Object.entries(entries).filter(([, event]) => Date.parse(event.expiresAt) > now))]));
    return { ...snapshot, state };
  }
  exportPortable() {
    return { formatVersion: FORMAT_VERSION, learnerVersion: LEARNER_VERSION, featureVersion: FEATURE_VERSION,
      config: this.config, currentRevision: this.revision,
      events: this.db.prepare('SELECT body FROM events ORDER BY rowid').all().map((row) => JSON.parse(row.body)),
      proposals: this.db.prepare('SELECT * FROM proposals ORDER BY rowid').all().map((row) => ({
        event: JSON.parse(row.body), baseRevision: row.base, status: row.status })),
      revisions: this.db.prepare('SELECT * FROM revisions ORDER BY revision').all().map((row) => ({
        revision: row.revision, parentRevision: row.parent, kind: row.kind,
        eventIds: JSON.parse(row.ids), stateHash: row.digest })) };
  }
  restorePortable(dump) {
    exactKeys(dump, ['formatVersion', 'learnerVersion', 'featureVersion', 'config', 'currentRevision', 'events', 'proposals', 'revisions']);
    invariant(dump.formatVersion === FORMAT_VERSION && dump.learnerVersion === LEARNER_VERSION &&
      dump.featureVersion === FEATURE_VERSION && canonical(dump.config) === canonical(this.config), 'Incompatible export.');
    invariant(Array.isArray(dump.events) && Array.isArray(dump.proposals) && Array.isArray(dump.revisions), 'Invalid export collections.');
    const events = new Map();
    for (const event of dump.events) {
      validateEvent(event);
      invariant(!events.has(event.id), 'Duplicate exported event.');
      if (event.kind === 'identity_import') invariant(textHash(event.text) === event.sourceHash, 'Imported identity integrity failure.');
      events.set(event.id, event);
    }
    const revisions = new Map();
    for (const revision of dump.revisions) {
      exactKeys(revision, ['revision', 'parentRevision', 'kind', 'eventIds', 'stateHash']);
      invariant(Number.isInteger(revision.revision) && revision.revision >= 0 && !revisions.has(revision.revision), 'Invalid revision sequence.');
      invariant(revision.revision === 0 ? revision.parentRevision === null : revisions.has(revision.parentRevision), 'Invalid revision parent.');
      invariant(['init', 'accept', 'import', 'rollback'].includes(revision.kind), 'Invalid revision kind.');
      invariant(Array.isArray(revision.eventIds) && new Set(revision.eventIds).size === revision.eventIds.length &&
        revision.eventIds.every((id) => events.has(id)), 'Invalid revision events.');
      const state = project(revision.eventIds.map((id) => events.get(id)), this.config);
      invariant(hash(state) === revision.stateHash, 'Export replay hash mismatch.');
      revisions.set(revision.revision, { ...revision, state });
    }
    invariant(revisions.has(0) && revisions.has(dump.currentRevision), 'Missing export head.');
    for (const proposal of dump.proposals) {
      exactKeys(proposal, ['event', 'baseRevision', 'status']); validateEvent(proposal.event);
      invariant(revisions.has(proposal.baseRevision) && ['pending', 'accepted', 'rejected'].includes(proposal.status), 'Invalid proposal state.');
      invariant(proposal.status !== 'accepted' || (events.has(proposal.event.id) &&
        hash(events.get(proposal.event.id)) === hash(proposal.event)), 'Accepted proposal conflicts with event.');
    }
    return this.transaction(() => {
      invariant(this.revision === 0 && this.db.prepare('SELECT COUNT(*) AS n FROM events').get().n === 0 &&
        this.db.prepare('SELECT COUNT(*) AS n FROM proposals').get().n === 0, 'Restore requires an empty destination.');
      this.db.exec('DELETE FROM revisions');
      for (const event of dump.events) this.db.prepare('INSERT INTO events VALUES (?, ?, ?)').run(event.id, canonical(event), hash(event));
      for (const proposal of dump.proposals) this.db.prepare('INSERT INTO proposals VALUES (?, ?, ?, ?, ?)')
        .run(proposal.event.id, canonical(proposal.event), hash(proposal.event), proposal.baseRevision, proposal.status);
      for (const revision of revisions.values()) this.db.prepare('INSERT INTO revisions VALUES (?, ?, ?, ?, ?, ?)')
        .run(revision.revision, revision.parentRevision, revision.kind, canonical(revision.eventIds), canonical(revision.state), revision.stateHash);
      this.db.prepare("UPDATE meta SET value=? WHERE key='head'").run(String(dump.currentRevision));
      return this.state();
    });
  }
}
