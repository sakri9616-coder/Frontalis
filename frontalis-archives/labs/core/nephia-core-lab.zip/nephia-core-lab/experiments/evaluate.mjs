import { mkdirSync, writeFileSync, createWriteStream } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { performance } from 'node:perf_hooks';
import { cpus, totalmem } from 'node:os';
import { dataset, random } from './data.mjs';
import { Methods } from './baselines.mjs';
import { NephiaCore, hash } from '../src/core.mjs';
import { DEFAULT_CONFIG, OnlinePreference } from '../src/learner.mjs';

const lab = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const reports = join(lab, 'reports'); const dataDir = join(lab, 'data');
mkdirSync(reports, { recursive: true }); mkdirSync(dataDir, { recursive: true });
const methodNames = ['A', 'B', 'B_recent', 'B_plus', 'B_plus_recent', 'C'];
const scenarios = ['linear', 'correlated', 'noisy', 'nonlinear'];
const seedCount = 40;
const datasets = [];
const scores = [];
const curves = [];
const predictions = createWriteStream(join(reports, 'predictions.jsonl'));
const started = performance.now(); const cpuStarted = process.cpuUsage();
let explanationChecks = 0; let explanationFailures = 0;

function measure(methods, samples, scenario, seed, stage) {
  const count = Object.fromEntries(methodNames.map((method) => [method, 0]));
  for (const sample of samples) {
    const choices = {};
    for (const method of methodNames) {
      const prediction = methods.compare(method, sample);
      if (prediction.choice === sample.expected) count[method]++;
      choices[method] = prediction.choice;
      if (method === 'C') {
        explanationChecks++;
        const sum = prediction.contributions.reduce((total, item) => total + item.contribution, 0);
        const validIds = new Set(methods.models.nephia.evidenceIds);
        if (Math.abs(sum - prediction.margin) > 1e-12 || !prediction.evidenceIds.every((id) => validIds.has(id))) explanationFailures++;
      }
    }
    predictions.write(JSON.stringify({ seed, scenario, stage, id: sample.id, expected: sample.expected, choices }) + '\n');
  }
  return Object.fromEntries(methodNames.map((method) => [method, count[method] / samples.length]));
}

for (const scenario of scenarios) {
  for (let seed = 1; seed <= seedCount; seed++) {
    const data = dataset(seed, scenario); datasets.push(data);
    const trainIds = new Set(data.training.flatMap((e) => [e.left.id, e.right.id]));
    if (data.novel.some((p) => trainIds.has(p.left.id) || trainIds.has(p.right.id))) throw new Error('Training/test leakage.');
    const methods = new Methods();
    for (let i = 0; i < 64; i++) {
      methods.update(data.training[i]);
      if ([4, 8, 16, 32, 64].includes(i + 1)) curves.push({ scenario, seed, n: i + 1,
        ...measure(methods, data.novel, scenario, seed, `curve-${i + 1}`) });
    }
    data.training.slice(64).forEach((e) => methods.update(e));
    const userIsolationBefore = hash(methods.models.nephia.toJSON());
    const novel = measure(methods, data.novel, scenario, seed, 'novel');
    const known = measure(methods, data.known, scenario, seed, 'known');
    const observedKnown = measure(methods, data.known.map((sample) => ({ ...sample,
      expected: data.training.find((event) => event.id === `${sample.id}-event`).preferred })), scenario, seed, 'observed-known');
    const praise = { ...data.training[64], id: 'extra-praise', owner: 'user', signal: 'user_praise' };
    methods.update(praise);
    if (hash(methods.models.nephia.toJSON()) !== userIsolationBefore) throw new Error('User preference contamination.');
    const beforeReversal = measure(methods, [data.reversal], scenario, seed, 'before-reversal');
    const stableBefore = measure(methods, data.stableAxes, scenario, seed, 'stable-before');
    data.driftTraining.forEach((e) => methods.update(e));
    const after = measure(methods, data.driftTest, scenario, seed, 'drift');
    const reversal = measure(methods, [data.reversal], scenario, seed, 'reversal');
    const stableAfter = measure(methods, data.stableAxes, scenario, seed, 'stable-after');
    scores.push({ seed, scenario, novel, known, observedKnown, after, beforeReversal, reversal, stableBefore, stableAfter });
  }
}
await new Promise((done) => predictions.end(done));

const mean = (a) => a.reduce((sum, x) => sum + x, 0) / a.length;
const percentile = (a, p) => { const x = [...a].sort((a, b) => a - b); return x[Math.min(x.length - 1, Math.floor(p * x.length))]; };
function pairedCI(differences) {
  const rng = random(90817); const bootstrap = [];
  for (let b = 0; b < 2000; b++) bootstrap.push(mean(differences.map(() => differences[Math.floor(rng() * differences.length)])));
  return { mean: mean(differences), low: percentile(bootstrap, 0.025), high: percentile(bootstrap, 0.975) };
}
const summary = {};
for (const scenario of scenarios) {
  const subset = scores.filter((row) => row.scenario === scenario);
  const stages = Object.fromEntries(['novel', 'known', 'observedKnown', 'after', 'beforeReversal', 'reversal', 'stableBefore', 'stableAfter']
    .map((stage) => [stage, Object.fromEntries(methodNames.map((method) => [method, mean(subset.map((r) => r[stage][method]))]))]));
  const differences = Object.fromEntries(['B', 'B_recent', 'B_plus', 'B_plus_recent'].map((baseline) => [baseline,
    pairedCI(subset.map((r) => r.novel.C - r.novel[baseline]))]));
  const driftDifferences = Object.fromEntries(['B', 'B_recent', 'B_plus', 'B_plus_recent'].map((baseline) => [baseline,
    pairedCI(subset.map((r) => r.after.C - r.after[baseline]))]));
  summary[scenario] = { ...stages, novelPairedDifference: differences,
    driftPairedDifference: driftDifferences,
    practicalImprovementOverStrongMemory: differences.B_plus.mean >= 0.05 && differences.B_plus.low > 0 };
}

const benchmarkData = dataset(901);
const learner = new OnlinePreference();
const updateTimes = [];
for (let i = 0; i < 2000; i++) {
  const t = performance.now(); learner.update({ ...benchmarkData.training[i % 64], id: `bench-${i}` });
  updateTimes.push(performance.now() - t);
}
const compareTimes = [];
for (let i = 0; i < 2000; i++) {
  const p = benchmarkData.novel[i % 120]; const t = performance.now(); learner.compare(p.left, p.right);
  compareTimes.push(performance.now() - t);
}
const db = new NephiaCore(join(lab, 'runtime', `benchmark-${Date.now()}.db`));
const writeTimes = [];
for (let i = 0; i < 128; i++) {
  const t = performance.now(); db.record({ ...benchmarkData.training[i], id: `db-${i}` });
  writeTimes.push(performance.now() - t);
}
const dbCompareTimes = [];
for (let i = 0; i < 300; i++) {
  const p = benchmarkData.novel[i % 120]; const t = performance.now(); db.compare('nephia', p.left, p.right);
  dbCompareTimes.push(performance.now() - t);
}
const dump = db.exportPortable(); const restored = new NephiaCore(); const restoreStarted = performance.now(); restored.restorePortable(dump);
const restoreMs = performance.now() - restoreStarted;
const restoreExact = benchmarkData.novel.every((p) => hash(db.compare('nephia', p.left, p.right)) === hash(restored.compare('nephia', p.left, p.right)));
const portableBytes = Buffer.byteLength(JSON.stringify(dump)); db.close(); restored.close();
const perf = (a) => ({ n: a.length, p50Ms: percentile(a, 0.5), p95Ms: percentile(a, 0.95) });
const cpu = process.cpuUsage(cpuStarted);
const result = { protocol: '2026-10-13-v1-plus-exploratory-recency-summary', config: DEFAULT_CONFIG,
  exploratoryAddition: 'B_plus_recent added after v1 results to distinguish learner benefit from simple memory recency. Recency factor 0.97 is fixed, not tuned.',
  scope: 'Offline algorithm test. A/B/C use deterministic decision surrogates, not real LLM dialogue.',
  environment: { node: process.version, platform: process.platform, arch: process.arch,
    cpu: cpus()[0].model, logicalCpus: cpus().length, totalRamGiB: totalmem() / 1024 ** 3 },
  seedCount, trainPerOwner: 64, novelPerSeed: 120, driftTrain: 48,
  datasetHash: hash(datasets), summary, scores, curves,
  explanation: { checks: explanationChecks, failures: explanationFailures,
    scope: 'Arithmetic attribution and evidence membership only; not natural-language causal validity.' },
  reproducibility: { portableRestoreExact: restoreExact, novelDecisionsChecked: 120 },
  performance: { update: perf(updateTimes), pureCompare: perf(compareTimes), acceptSQLite: perf(writeTimes),
    compareSQLite: perf(dbCompareTimes), restoreMs, portableBytes,
    totalWallMs: performance.now() - started, totalCpuMs: (cpu.user + cpu.system) / 1000,
    processRssMiB: process.memoryUsage().rss / 1024 ** 2 } };
writeFileSync(join(dataDir, 'training.jsonl'), datasets.map((d) => JSON.stringify({ seed: d.seed, scenario: d.scenario,
  events: d.training, driftEvents: d.driftTraining })).join('\n') + '\n');
writeFileSync(join(dataDir, 'evaluation.jsonl'), datasets.map((d) => JSON.stringify({ seed: d.seed, scenario: d.scenario,
  known: d.known, novel: d.novel, driftTest: d.driftTest, reversal: d.reversal, stableAxes: d.stableAxes })).join('\n') + '\n');
writeFileSync(join(reports, 'results.json'), JSON.stringify(result, null, 2));
writeFileSync(join(reports, 'results.csv'), 'scenario,stage,method,accuracy\n' + scenarios.flatMap((scenario) =>
  ['novel', 'known', 'observedKnown', 'after', 'reversal', 'stableAfter'].flatMap((stage) => methodNames.map((method) =>
    `${scenario},${stage},${method},${summary[scenario][stage][method]}`))).join('\n') + '\n');
console.log(JSON.stringify({ summary, performance: result.performance, explanation: result.explanation,
  reproducibility: result.reproducibility }, null, 2));
