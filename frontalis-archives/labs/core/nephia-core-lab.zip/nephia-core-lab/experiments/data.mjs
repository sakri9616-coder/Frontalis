import { dot, FEATURE_VERSION, FEATURE_NAMES, subtract } from '../src/learner.mjs';

export function random(seed) {
  let state = seed >>> 0;
  return () => { state += 0x6D2B79F5; let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
const normalize = (v) => { const norm = Math.sqrt(dot(v, v)); return v.map((x) => x / norm); };
const clamp = (x) => Math.max(-1, Math.min(1, x));

/** The oracle and its parameters stay in the evaluator, never in a learner request. */
export function dataset(seed, scenario = 'linear') {
  const rng = random(seed * 101 + 7);
  const weights = normalize(FEATURE_NAMES.map(() => rng() * 2 - 1));
  const userWeights = weights.map((value) => -value);
  const changedDimension = weights.reduce((best, value, i) => Math.abs(value) > Math.abs(weights[best]) ? i : best, 0);
  const changedWeights = weights.map((value, i) => i === changedDimension ? -value : value);
  const feature = () => {
    const f = FEATURE_NAMES.map(() => rng() * 2 - 1);
    if (scenario === 'correlated') f[1] = clamp(0.85 * f[0] + 0.3 * f[1]);
    return f;
  };
  const utility = (f, w) => scenario === 'nonlinear' ?
    w[0] * 3 * f[0] * f[1] + dot(f, w) * 0.15 : dot(f, w);
  const pair = (id, w, axis = null) => {
    const left = { id: `${id}-a`, features: axis === null ? feature() : FEATURE_NAMES.map((_, i) => i === axis ? 1 : 0) };
    const right = { id: `${id}-b`, features: axis === null ? feature() : FEATURE_NAMES.map((_, i) => i === axis ? -1 : 0) };
    const margin = utility(left.features, w) - utility(right.features, w);
    return { id, left, right, expected: margin >= 0 ? 'left' : 'right', oracleMargin: margin };
  };
  let tick = 0;
  const event = (owner, sample, stage) => {
    const observed = scenario === 'noisy' && rng() < 0.2 ? (sample.expected === 'left' ? 'right' : 'left') : sample.expected;
    return { id: `${sample.id}-event`, kind: 'preference', owner,
      at: new Date(Date.UTC(2026, 0, 1) + tick++ * 1000).toISOString(),
      evidence: { sourceId: `synthetic-${seed}-${scenario}`, locator: `${stage}/${sample.id}`, origin: 'synthetic' },
      featureVersion: FEATURE_VERSION, left: sample.left, right: sample.right, preferred: observed,
      signal: owner === 'nephia' ? 'self_report' : 'user_report', confidence: 1 };
  };
  const training = [];
  const known = [];
  for (const owner of ['nephia', 'user']) {
    for (let i = 0; i < 64; i++) {
      const sample = pair(`${seed}-${scenario}-train-${owner}-${i}`, owner === 'nephia' ? weights : userWeights);
      training.push(event(owner, sample, 'train'));
      if (owner === 'nephia' && i < 32) known.push(sample);
    }
  }
  const novel = Array.from({ length: 120 }, (_, i) => pair(`${seed}-${scenario}-test-${i}`, weights));
  const driftTraining = Array.from({ length: 48 }, (_, i) => event('nephia', pair(`${seed}-${scenario}-drift-train-${i}`, changedWeights), 'drift-train'));
  const driftTest = Array.from({ length: 120 }, (_, i) => pair(`${seed}-${scenario}-drift-test-${i}`, changedWeights));
  const reversal = pair(`${seed}-${scenario}-reversal`, changedWeights, changedDimension);
  const stableAxes = FEATURE_NAMES.map((_, i) => i).filter((i) => i !== changedDimension)
    .map((i) => pair(`${seed}-${scenario}-stable-${i}`, weights, i));
  return { seed, scenario, training, known, novel, driftTraining, driftTest, reversal, stableAxes,
    oracle: { weights, userWeights, changedWeights, changedDimension } };
}

export const vectorDifference = (pair) => subtract(pair.left.features, pair.right.features);
