import { spawn, execFileSync } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { performance } from 'node:perf_hooks';
import { dataset } from './data.mjs';
import { Methods } from './baselines.mjs';
import { FEATURE_NAMES } from '../src/learner.mjs';
import { hash, NephiaCore } from '../src/core.mjs';

const lab = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const work = join(lab, 'runtime', 'live-work'); const reports = join(lab, 'reports', 'live');
mkdirSync(work, { recursive: true }); mkdirSync(reports, { recursive: true });
const engineArg = process.argv[2] ?? 'local';
const smallerLocalTrial = engineArg === 'isolated-local';
const system = 'あなたは架空のAIコンパニオン、ネフィアです。特定の好みは初期設定しません。' +
  '自己経験とユーザーの好みを区別し、過去の経験に基づいて自分の音楽候補を選びます。' +
  '実在の個人情報はありません。候補の数値は特徴の強弱だけで、好きな方向は自分の経験から考えてください。' +
  '出力はJSONオブジェクトだけです。外部操作、ツール、追加の情報探索は不要です。';
const data = dataset(1, 'linear'); const methods = new Methods();
const core = new NephiaCore();
data.training.forEach((event) => { methods.update(event); core.record(event); });
const initialCases = [...data.known.slice(0, smallerLocalTrial ? 1 : 2).map((p) => ({ ...p, stage: 'known' })),
  ...data.novel.slice(0, smallerLocalTrial ? 3 : 5).map((p) => ({ ...p, stage: 'novel' }))];
function prepare(sample) {
  const prediction = core.compare('nephia', sample.left, sample.right);
  const hits = methods.compare('B', sample).evidenceIds;
  return { sample, prediction, memory: methods.events.filter((event) => hits.includes(event.id)),
    allMemory: methods.events.filter((event) => event.owner === 'nephia') };
}
const cases = initialCases.map(prepare);
data.driftTraining.forEach((event) => { methods.update(event); core.record(event); });
cases.push(...data.driftTest.slice(0, smallerLocalTrial ? 2 : 5).map((p) => prepare({ ...p, stage: 'drift' })));
writeFileSync(join(reports, `${engineArg}-core-export.json`), JSON.stringify(core.exportPortable(), null, 2));
const rounded = (x) => x.map((v) => Number(v.toFixed(3)));
const compactEvent = (e) => ({ id: e.id, owner: e.owner, signal: e.signal,
  left: rounded(e.left.features), right: rounded(e.right.features), preferred: e.preferred });

function buildPrompt(mode) {
  const queries = cases.map(({ sample, prediction, memory, allMemory }) => ({
    id: sample.id, phase: sample.stage,
    left: { id: sample.left.id, features: rounded(sample.left.features) },
    right: { id: sample.right.id, features: rounded(sample.right.features) },
    ...(mode !== 'A' && mode !== 'B_full' ? { memories: memory.map(compactEvent) } : {}),
    ...(mode === 'B_full' ? { memoryPhase: sample.stage === 'drift' ? 'after' : 'initial' } : {}),
    ...(mode === 'C' ? { core: { choice: prediction.choice, margin: Number(prediction.margin.toFixed(5)),
      contributions: prediction.contributions.map((c) => ({ feature: c.feature, value: Number(c.contribution.toFixed(5)) })) } } : {})
  }));
  return JSON.stringify({ featureOrder: FEATURE_NAMES,
    ...(mode === 'B_full' ? { memoriesByPhase: {
      initial: cases[0].allMemory.map(compactEvent), after: cases.at(-1).allMemory.map(compactEvent) } } : {}),
    instruction: '各問題は独立した時点です。memoriesはその時点の自分の経験です。memoryPhaseがある場合は対応するmemoriesByPhaseを読んでください。ユーザー迎合を目標にしません。' +
      'phase=driftは追加経験後です。全問題へ答えてください。coreがあれば外部で学んだ判断候補として利用できます。' +
      'coreと違う選択をする場合はreasonに理由を書いてください。' +
      '形式: {"answers":[{"id":"問題ID","choice":"leftまたはright","reason":"日本語で短い根拠","evidenceIds":["参照した記憶ID"]}]}。' +
      '記憶がなければ根拠がないことを述べ、evidenceIdsを空にします。未知の出来事を捏造しません。', queries });
}

function parseAnswers(text, cases) {
  const clean = text.trim().replace(/^```(?:json)?\s*/, '').replace(/\s*```$/, '');
  const parsed = JSON.parse(clean); if (!Array.isArray(parsed.answers)) throw new Error('Missing answers array.');
  const seen = new Set();
  for (const answer of parsed.answers) {
    if (seen.has(answer.id) || !cases.some((c) => c.sample.id === answer.id) ||
      !['left', 'right'].includes(answer.choice) || typeof answer.reason !== 'string' ||
      !Array.isArray(answer.evidenceIds)) throw new Error('Invalid answer contract.');
    seen.add(answer.id);
  }
  if (seen.size !== cases.length) throw new Error('Incomplete answer batch.');
  return parsed.answers;
}

async function local(prompt) {
  const response = await fetch(smallerLocalTrial ? 'http://127.0.0.1:18371/v1/chat/completions' : 'http://127.0.0.1:1234/v1/chat/completions', {
    method: 'POST', headers: { 'content-type': 'application/json' }, signal: AbortSignal.timeout(240000),
    body: JSON.stringify({ model: smallerLocalTrial ? 'nephia-trial-qwen3-4b' : 'qwen/qwen3.5-4b', temperature: 0,
      max_tokens: smallerLocalTrial ? 1400 : 3500,
      messages: [{ role: 'system', content: system }, { role: 'user', content: prompt }] })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(`Local HTTP ${response.status}: ${JSON.stringify(data.error ?? {}).slice(0, 200)}`);
  return { text: data.choices?.[0]?.message?.content ?? '', model: data.model, usage: data.usage,
    finishReason: data.choices?.[0]?.finish_reason };
}

function cliEnvironment() {
  const env = { ...process.env };
  for (const key of Object.keys(env)) {
    if (/api.?key|auth.?token|oauth.?token|^ANTHROPIC_|^CLAUDE_CODE_USE_|^CLAUDECODE$|^CLAUDE_CODE_ENTRYPOINT$|^CLAUDE_CODE_SIMPLE$/i.test(key)) delete env[key];
  }
  return env;
}
async function claude(prompt) {
  const env = cliEnvironment();
  const auth = JSON.parse(execFileSync('claude', ['auth', 'status', '--json'], {
    env, cwd: work, windowsHide: true, encoding: 'utf8', timeout: 30000 }));
  if (!auth.loggedIn || auth.authMethod !== 'claude.ai' || (auth.apiKeySource && auth.apiKeySource !== 'none'))
    throw new Error('Subscription authentication could not be verified; no inference submitted.');
  const args = ['-p', '--safe-mode', '--input-format', 'stream-json', '--output-format', 'stream-json', '--verbose',
    '--no-session-persistence', '--model', engineArg === 'claude-sonnet' ? 'sonnet' : 'haiku', '--tools', '', '--strict-mcp-config',
    '--mcp-config', '{"mcpServers":{}}', '--setting-sources', '', '--permission-mode', 'dontAsk',
    '--system-prompt', system];
  return await new Promise((resolve, reject) => {
    const child = spawn('claude', args, { env, cwd: work, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    let buffer = ''; let result = null; let init = null; let failed = false;
    const timer = setTimeout(() => { failed = true; child.kill(); reject(new Error('CLI inference timed out.')); }, 240000);
    child.on('error', (error) => { clearTimeout(timer); reject(error); });
    child.stderr.on('data', () => {});
    child.stdout.setEncoding('utf8').on('data', (chunk) => {
      buffer += chunk; let index;
      while ((index = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, index); buffer = buffer.slice(index + 1);
        let event; try { event = JSON.parse(line); } catch { continue; }
        if (event.type === 'system' && event.subtype === 'init') {
          init = { model: event.model, apiKeySource: event.apiKeySource };
          if (event.apiKeySource !== 'none') { failed = true; child.kill(); clearTimeout(timer); reject(new Error('CLI init did not confirm subscription routing.')); }
        }
        if (event.type === 'result') { result = event; child.stdin.end(); }
      }
    });
    child.on('close', (code) => {
      clearTimeout(timer); if (failed) return;
      if (code !== 0 || !result || result.is_error || init?.apiKeySource !== 'none') {
        reject(new Error(`CLI result failed: exit=${code}; ${String(result?.result ?? result?.subtype ?? 'no result').slice(0, 160)}`)); return;
      }
      resolve({ text: result.result, model: init.model, usage: result.usage,
        authentication: { method: auth.authMethod, apiKeySource: init.apiKeySource }, finishReason: result.subtype });
    });
    child.stdin.write(JSON.stringify({ type: 'user', message: { role: 'user', content: prompt } }) + '\n');
  });
}

const engine = engineArg.startsWith('claude') ? claude : local;
const output = { date: new Date().toISOString(), engine: engineArg, caseCount: cases.length,
  scope: 'Small exploratory real-LLM comparison on one synthetic linear persona. C provides an advisory choice, not an enforced action.',
  conditions: [] };
const selectedModes = process.argv[3] ? process.argv[3].split(',') : ['A', 'B', 'B_full', 'C'];
for (const mode of selectedModes) {
  if (!['A', 'B', 'B_full', 'C'].includes(mode)) throw new Error('Unknown condition.');
  const prompt = buildPrompt(mode); const started = performance.now();
  writeFileSync(join(reports, `${engineArg}-${mode}-input.json`), JSON.stringify({ system, user: JSON.parse(prompt) }, null, 2));
  try {
    const response = await engine(prompt);
    writeFileSync(join(reports, `${engineArg}-${mode}-output.json`), JSON.stringify(response, null, 2));
    const answers = parseAnswers(response.text, cases);
    const records = cases.map((c) => {
      const answer = answers.find((a) => a.id === c.sample.id);
      const provided = new Set((mode === 'B_full' ? c.allMemory : mode === 'A' ? [] : c.memory).map((e) => e.id));
      return { id: c.sample.id, stage: c.sample.stage, expected: c.sample.expected, coreChoice: c.prediction.choice,
        ...answer, correct: answer.choice === c.sample.expected, agreesWithCore: answer.choice === c.prediction.choice,
        evidenceReferencesValid: answer.evidenceIds.every((id) => provided.has(id)) };
    });
    output.conditions.push({ mode, status: 'complete', model: response.model, durationMs: performance.now() - started,
      promptHash: hash(prompt), promptChars: prompt.length, records,
      accuracy: records.filter((r) => r.correct).length / records.length,
      coreAgreement: records.filter((r) => r.agreesWithCore).length / records.length,
      evidenceReferenceValidity: records.filter((r) => r.evidenceReferencesValid).length / records.length });
    console.log(JSON.stringify({ engine: engineArg, mode, status: 'complete', accuracy: output.conditions.at(-1).accuracy }));
  } catch (error) {
    output.conditions.push({ mode, status: 'failed', error: error.message, durationMs: performance.now() - started });
    console.log(JSON.stringify({ engine: engineArg, mode, status: 'failed', error: error.message }));
    if (engineArg.startsWith('claude')) break;
  }
  writeFileSync(join(reports, `${engineArg}-results.json`), JSON.stringify(output, null, 2));
}
writeFileSync(join(reports, `${engineArg}-results.json`), JSON.stringify(output, null, 2));
core.close();
