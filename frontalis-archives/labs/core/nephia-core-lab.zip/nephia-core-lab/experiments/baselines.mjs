import { dot, learns, subtract, OnlinePreference } from '../src/learner.mjs';

const difference = (event) => subtract(event.left.features, event.right.features);
const tie = (left, right) => left.id.localeCompare(right.id, 'en') <= 0 ? 'left' : 'right';
const result = (margin, left, right, evidenceIds) => ({ margin,
  choice: margin === 0 ? tie(left, right) : (margin > 0 ? 'left' : 'right'), evidenceIds });
const norm = (x) => Math.sqrt(dot(x, x));

/** B uses feature-based retrieval, which is stronger than keyword-only memory search. */
export function memoryVote(events, left, right, k = 8, recency = false) {
  const query = subtract(left.features, right.features);
  const hits = events.map((event, i) => {
    const d = difference(event);
    const similarity = dot(query, d) / Math.max(1e-12, norm(query) * norm(d));
    const ageWeight = recency ? 0.97 ** (events.length - i - 1) : 1;
    return { event, similarity, score: Math.abs(similarity) * ageWeight };
  }).sort((a, b) => b.score - a.score).slice(0, k);
  const margin = hits.reduce((sum, hit) => sum + hit.score * Math.sign(hit.similarity) *
    (hit.event.preferred === 'left' ? 1 : -1) * hit.event.confidence, 0);
  return result(margin, left, right, hits.map((hit) => hit.event.id));
}

/** B+ recomputes a simple feature summary from all memory without iterative fitting. */
export function memorySummary(events, left, right, recency = false) {
  const weights = left.features.map(() => 0);
  for (const [index, event] of events.entries()) {
    const label = event.preferred === 'left' ? 1 : -1;
    const ageWeight = recency ? 0.97 ** (events.length - index - 1) : 1;
    difference(event).forEach((value, i) => { weights[i] += label * value * event.confidence * ageWeight; });
  }
  return result(dot(weights, subtract(left.features, right.features)), left, right, events.map((event) => event.id));
}

export class Methods {
  constructor() { this.events = []; this.models = { nephia: new OnlinePreference(), user: new OnlinePreference() }; }
  update(event) {
    this.events.push(event);
    if (learns(event)) this.models[event.owner].update(event);
  }
  compare(method, pair, owner = 'nephia') {
    const relevant = this.events.filter((event) => event.owner === owner && learns(event));
    if (method === 'A') return result(0, pair.left, pair.right, []);
    if (method === 'B') return memoryVote(relevant, pair.left, pair.right);
    if (method === 'B_recent') return memoryVote(relevant, pair.left, pair.right, 8, true);
    if (method === 'B_plus') return memorySummary(relevant, pair.left, pair.right);
    if (method === 'B_plus_recent') return memorySummary(relevant, pair.left, pair.right, true);
    if (method === 'C') return this.models[owner].compare(pair.left, pair.right);
    throw new Error('Unknown evaluation method.');
  }
}
