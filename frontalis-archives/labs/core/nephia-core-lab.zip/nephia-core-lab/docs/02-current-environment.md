# 確認した現行実装

調査日: 2026-10-13。対象のソースは `C:\Users\sakur\AppData\Local\asist-shisa\asist`。調査開始時点で多数の未コミット変更があったため、上流ASISTの説明ではなく、このローカル改造版を根拠とする。全2,228ファイルの開始時SHA-256とGit状態は `reports/audit-before.json` に保存した。稼働中Electronの全経路を再実行して検証したわけではない。

| 確認事項 | 原文の根拠 |
|---|---|
| Electron / TypeScript / React。mainがサービス・保存・外部プロセスを持ち、rendererはpreload越しに利用 | `asist/AGENTS.md`、`asist/package.json` |
| 永続長期記憶の正本は `userData/memory` のMarkdown。検索用に `memory-index.db` がある | `src/main/services/memory.ts:18`、`memory-store.ts:81` |
| 実ファイル `C:\Users\sakur\AppData\Roaming\asist\memory\me.md` が存在。調査時2,493バイト | 読み取り専用のファイル情報確認。内容を実験へ取り込んでいない |
| `me.md` と `user.md` はシステムの記憶ブロックに入る。ページ・日誌は検索で取得 | `memory.ts:18`、`memory.ts:339`、`brain/prompt.ts:341` |
| 記憶ブロックは連続した会話中は凍結。前回ターンから5分以上空くか、アプリがinvalidateすると再読込 | `src/shared/memory-block.ts:12`、`memory.ts:346` |
| ユーザー入力で記憶を最大8件検索。注記を記録してモデルが読んだものと履歴を合わせる | `brain/turn.ts:244`、`turn.ts:250`、`turn.ts:259`、`turn.ts:205` |
| 会話ログは `dataPath('conversations')`。日次整理は日付ごとにログを読み、checkpointを除く | `brain/session.ts:99`、`memory-curation.ts:112` |
| 日次整理は別のGit worktreeで実行し、記憶内の変更・書式を検査してmerge、reindex、invalidate、その後処理済み日を進める | `memory-curation.ts:129`、`memory-curation.ts:239`、`memory-curation.ts:251` |
| Claudeによる記憶整理のモデル指定はソース定数 `claude-haiku-5-5`。設定上のagentEngineもclaude | `agent.ts:517`、`agent.ts:525`、設定の非機密項目だけの読取 |
| 日次整理の開始条件はローカル0時を基準にし、60秒ごとの確認がある | `src/shared/memory-curation.ts:97`、`memory-curation.ts:37` |
| 設定ファイル上の主会話モデルは `claude-cli / claude-haiku-5-5`、personaは存在 | 設定の非機密項目だけの読取。実際にこのIDで直近の会話が成功したかは今回未確認 |
| Claude CLIはstream-jsonの子プロセスを継続利用し、モデル・system・tools・履歴が変わると新規プロセスを作る | `llm/claude-cli.ts:419`、`claude-cli.ts:440`、`claude-cli.ts:462` |
| CLIは `--no-session-persistence`。CLI履歴を正本にしない。既存ツールをMCP shim→named pipe→brainに渡す | `claude-cli.ts:19`、`claude-cli.ts:66`、`claude-cli.ts:233` |
| CLI子環境からAPIキー・endpoint overrideを落とし、initのapiKeySourceがnone以外なら停止 | `claude-cli.ts:36`、`claude-cli.ts:52`、`claude-cli.ts:309` |
| 共通ProviderAdapter境界があり、プロバイダー選択をcall.tsが担当 | `llm/adapter.ts:46`、`llm/call.ts:24`、`src/shared/conversation.ts:81` |
| toolsはレジストリから生成。recall用のmemoryToolsもここに登録される | `brain/tools.ts:269`、`brain/tools.ts:287` |

## 今回確認していないもの

- 実会話の人格の内容、意味、選好ラベルの抽出精度。実会話ログは読まず、外部へ送信していない。
- 日次整理ジョブの直近の成功状態、実CLIモデルIDの有効性、全ツールの稼働状況。
- Spotifyの接続・利用権限・再生結果取得。機能をCore試作へ組み込んでいない。
- 軽量環境認識と自発会話の全仕様。改造版には `services/initiative`、`play` 等が存在するが、人格更新の根拠として採用していない。
- 音声・TTSの実行品質。Core比較に音声処理を混ぜていない。
- `out/main/index.js` は存在し調査時の更新時刻を確認したが、ソースの各行と稼働中プロセスの同一性は未検証。

## 調査の制約

長いソースに対してローカル `lmstudio-preprocess` を試したが、2件とも `LM Studio HTTP 400: {"error":"terminated"}` となった。補助要約を根拠にせず、上表の重要箇所を原文で読んだ。ネットワーク制限下のlocalhost接続も最初はソケット権限エラーだったが、読み取り専用の許可済み実行で確認した。これはサーバー停止と区別する。

LM Studioの推論試験は `terminated` / `Engine protocol predict request failed: fetch failed` / `Model is unloaded` で失敗した。状態読取時のloaded_instancesは空だった。失敗の原因や、失敗前のロード状態は確定していない。既存サービスの再設定・再起動・モデル削除は行っていない。別ポートの独立した試験プロセスの情報は `reports/isolated-local-process.json` に残す。

## 終了時の照合

`reports/audit-after.json`では、me.md/user.mdのSHA-256は開始時と同じだった。既存ソースでは `src/main/ipc.ts`、`services/aizuchi.ts`、`services/tts.ts`、`services/time-stretch.ts`、`tests/time-stretch.test.ts` の5ファイルに変化を検出した。settings.jsonのハッシュとGit状態も変わっていた。

この研究作業は `nephia-core-lab` 以外へ書き込んでいない。上記の変更を巻き戻していない。並行した別経路による更新があり得るが、原因・担当者・設定差分の内容は今回特定していない。「全ての既存ファイルが開始時から不変」とは主張しない。上表は読取時点の証拠であり、統合前に現在のソースと設定を照合する必要がある。
