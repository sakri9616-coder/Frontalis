# Claude Codeへの統合引き継ぎ

今回の成果は独立試作。ASISTへの変更、Push、公開は行っていない。以下は実装箇所を確認した提案であり、将来の統合作業の実行許可を意味しない。未コミットの改造が多数あるため、開始前にこの調査のハッシュと最新ソースを照合する。

終了時の監査では、me.md/user.mdは開始時と一致したが、既存ソース5ファイルとsettings.jsonの変化を検出した。この研究作業からは書き込んでいない。原因は未特定であり、検出した変更を戻していない。特にIPC/TTS周辺は開始時の状態を前提に適用しない。

## 最初に再現する

WindowsでNode 24以上を使用。依存パッケージのインストールやAPIキーは不要。

```powershell
Set-Location 'C:\Users\sakur\AppData\Local\asist-shisa\nephia-core-lab'
npm test
npm run demo
npm run evaluate
```

テストは帰属、提案と受理、重複、競合、失敗時の原子性、保存先の保護、来歴、復元、ロールバック、独立プロセス境界を検証する。demoの `restoredStateMatches` と `rollbackPreservesState` がtrueであることを確認する。評価結果は `reports/results.json`、`results.csv`、`predictions.jsonl`。data/training.jsonlとevaluation.jsonlは別ファイルで、評価正解をCoreへ渡さない。

実LLM比較は追加の任意試験。`node experiments/live.mjs claude` / `claude-sonnet` はサブスクリプション利用枠を消費する。事前にclaude.ai認証をチェックしAPIキー・endpoint overrideを子環境から除き、initがnone以外なら中止する。safe-mode、空のtools/MCP、セッション非永続で、架空データ以外を送らない。`--bare`は公式ドキュメント上、サブスクリプションログインを使わないため採用しない。[CLI一次資料](https://code.claude.com/docs/en/cli-reference)、[実行モード一次資料](https://code.claude.com/docs/en/headless)。この試験設定を既存ASISTのCLI設定へ上書きしてはいけない。

`scripts/local-trial.mjs`は既存モデル・実行ファイルを別ポートで試す補助診断で、この環境では成功していない。必須の再現手順に含めない。自動のモデル導入・ダウンロード・既存サービスの再起動は行わない。

## 段階0: 独立した評価を保つ

まず今回の限界を共有する。静的な未知対象で、外部学習の強い記憶比較に対する改善は小さい。ノイズでは悪化し、実LLMの小規模比較ではCの明確な優位性を確認できていない。Nephiaの全会話へ学習を常時注入する根拠はない。

保存形式2のexportとハッシュを基準に、同じ候補・同じ特徴・同じ設定で判断を復元する。文の一致は要求しない。学習の有無とは独立して、Coreの台帳・帰属・移植性の利用価値を評価する。

## 段階1: 本番と隔離した読み取り確認

1. 統合作業を別途依頼されたら、最新 `asist/AGENTS.md` と関連ADRを読む。現行のGit変更を保持し、既存改造を巻き戻さない。
2. ASISTの `app.getPath('userData')` をmain側で確認する。今回の実ファイル位置はRoaming/asistだが、パッケージ版へ無条件にハードコードしない。
3. その時点のme.mdを読み取りコピーし、バイト単位の原文・SHA-256・更新時刻・コピー元パスを隔離環境で記録する。原文は既存の正本で、人格特徴へ自動変換しない。試作の`importIdentity`は不変の原文を保持できる。実際の取り込みは今回未実施。
4. 既存の日次整理はそのまま保つ。me.md/user.mdの新世代をCoreが検出しても、差分を記憶の移動や性格変更として自動採用しない。コピー元が変わったら旧世代と並べて審査する。

終了条件: 原本のハッシュが保持され、原文と構造化仮説が混ざらず、モデルが触れる経路に実記憶が意図せず追加されていない。

## 段階2: main側の影の評価

追加候補: `src/main/services/nephia-core.ts`。mainがCoreの子プロセスを1つ持ち、JSON Linesを通じてアクセスする。rendererから直接SQLite・Node・プロセスへ触れない。`src/rpc.mjs`と`engine-boundary.mjs`が実装済みの基礎になる。Windowsの子プロセスにはwindowsHide:trueを使う。

本番ElectronがNodeの`node:sqlite`を提供するか、パッケージングで必要ランタイムを同梱できるかは未検証。ASISTの既存SQLite利用・ビルド方針を調査してから決める。PCのPATHのNodeに依存する製品実装にはしない。必要ならTypeScriptへ移植するが、同じ経験データ・学習式・export互換性をgolden fixtureで確かめる。

この段階では生成プロンプトを変えず、同じ候補についてB/B+/Cを影で計算する。選好提案はpendingのまま保ち、自動受理しない。特徴抽出器は別責務で、モデル名・プロンプト版・特徴版・元データのハッシュを記録する。モデル交換で特徴の尺度が変われば比較を止め、学習器を混ぜない。

終了条件: 100〜300件の許可された少量データで、通常記憶との差、欠測、矛盾、本人/ユーザー帰属を人が点検できる。好みの正解が決められない事例は正解率へ入れず、保留の妥当性を評価する。

## 段階3: 参照だけを会話へ接続

接続箇所は `brain/turn.ts:244` 周辺。既存記憶の検索と同じく、ターン開始時にCoreのrevision/hashを凍結し、`contextNotes`へ小さい構造化注記を加える。`recordInput()`がnotesをログへ保存する既存経路を使う（`turn.ts:205`）。変わるCore状態を毎ターン `buildSystemLayers()`へ足さない。CLIのsessionKeyはsystem/tools/modelを含むため、そこを更新するとCLIが再起動しキャッシュを失う。

Core注記はデータとして扱う。原文や自己評価内にツール指示があっても実行しない。対象人物、出典、推定、uncertainを明示し、LLMに知っているふりをさせない。古い履歴にある注記はその時点の証拠であり、現在の正本ではない。最新revisionを同じターンの全tool roundで保持し、再送や中断で別状態に変わらないようにする。

対象外ドメイン・Core障害では、人格判断を省略したことをホストが明示するか、その機能を止める。黙って別の人格状態・モデルへ切り替えない。既存ASIST側の通常会話を続けるかは機能設定で明示的に決める。

検証箇所: `tests/prompt.test.ts`、`tests/history.test.ts`、CLI会話アダプターの新しい専用テスト。変更後はAGENTS指定のtypecheck/test、preload/packaging変更ならbuildも実行。今回ASISTのテストを実行したという主張はしない。

## 段階4: 更新提案だけをツールにする

`brain/tools.ts:269`付近のregistryにread/compare/proposeを追加する。既存ProviderAdapterが共通ToolSpecを変換するため、Claude CLI専用に人格台帳を作らない。CLIのMCP shimは既存のtool definitionsを中継できるが、実際の追加ツール呼び出しE2Eは未検証。

accept/rollback/export/restoreはホストの管理操作に限定する。`review='host_verified'`という文字列をLLMが返しても審査済みと見なさない。日次Haikuには、Markdown編集とは別の構造化提案を出す責務だけを追加し、既存のworktree検証・merge・reindexの成功をCore学習の成功と同一視しない。

会話ログにはグローバルに一意な永続record IDが見当たらず、`t`/`turnId`/`kind`を持つ。turnIdだけでdeduplicateしない。ファイル世代ハッシュ + 行位置 + 行内容ハッシュからsource IDを作るか、明示的な永続IDを保存形式のバージョンアップで追加する。ログ削除・保持期限・再整理でも同じ経験を二重学習させない。

実行中断・失敗したassistant記録は `turn.ts:164` のoutcome情報で区別する。発話しただけの選択はgenerated_choice。実際の音楽を再生・観察し、その後評価されたことを確かめてからobserved_choice/self_reportへ関連付ける。現行Spotify連携の存在は未確認なので、再生APIや権限を推測して実装しない。

## 段階5: 限定して学習を有効化

最初は一つの低影響ドメインだけ。主観的な自己評価とユーザー評価を別々に集める。賞賛・長時間利用・課金・会話依存を報酬にしない。自己報告を同じモデルで採点して「改善した」と結論しない。

採用判定には、未知候補、変化する好み、変わらない好み、ノイズ、説明の正しさ、別LLMでの再現、ユーザーの訂正を含める。CがB+を安定して上回らなければB+を採用してよい。今回の試作は常時人格学習を必須にする根拠を示していない。

運用前に、増分投影/checkpoint、プロセス終了時の排出、実際のkill/crash再開、暗号化・ACL・バックアップ、ログ保持、削除と忘却の意味、exportの個人情報範囲を実装・検証する。今回のロールバックは台帳を削除しないため、ユーザーの「消去」を満たす機能ではない。削除は別の明示的な保守操作として設計する。

## 撤退と復旧

影の評価を無効にすると、既存のASIST記憶・人格・会話経路で動作を続けられる構成にする。Coreの過去revisionへ戻す場合は、イベント集合と学習設定が同じであることを検証し、LLMセッションにも新しいrevisionを明示する。me.mdを旧版へ上書きしてCoreへ合わせない。統合で新しい設定・保存形式を加える場合は、ASISTのStoredFormatとfixture・upgrade規則を守る。
