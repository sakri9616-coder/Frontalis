import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { dataset } from '../experiments/data.mjs';
import { NephiaCore } from '../src/core.mjs';

test('the process boundary preserves decisions and refuses invalid and stale writes', async () => {
  const rpc = resolve(dirname(fileURLToPath(import.meta.url)), '../src/rpc.mjs');
  const child = spawn(process.execPath, [rpc, '--memory'], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
  const lines = createInterface({ input: child.stdout }); const waiting = new Map(); let next = 0;
  lines.on('line', (line) => { const value = JSON.parse(line); waiting.get(value.id)?.(value); waiting.delete(value.id); });
  const call = (method, params) => new Promise((done, fail) => {
    const id = ++next; const timeout = setTimeout(() => fail(new Error('RPC test timed out.')), 5000);
    waiting.set(id, (value) => { clearTimeout(timeout); done(value); });
    child.stdin.write(JSON.stringify({ id, method, params }) + '\n');
  });
  const direct = new NephiaCore();
  try {
    const data = dataset(8); const event = data.training[0];
    await call('propose', { event, expectedRevision: 0 });
    assert.equal((await call('state', {})).result.revision, 0);
    await call('accept', { id: event.id, expectedRevision: 0, review: 'host_verified' });
    direct.record(event);
    const pair = data.novel[0]; const args = { owner: 'nephia', left: pair.left, right: pair.right };
    assert.deepEqual((await call('compare', args)).result, direct.compare(args.owner, args.left, args.right));
    assert.match((await call('rollback', { targetRevision: 0, expectedRevision: 0 })).error.message, /Stale/);
    assert.match((await call('compare', { ...args, owner: 'both' })).error.message, /owner/);
    assert.equal((await call('state', {})).result.revision, 1);
  } finally {
    direct.close(); child.stdin.end(); lines.close();
    await new Promise((done) => child.once('close', done));
  }
});
