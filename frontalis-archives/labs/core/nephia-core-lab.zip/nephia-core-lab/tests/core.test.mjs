import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { NephiaCore, textHash } from '../src/core.mjs';
import { DatabaseSync } from 'node:sqlite';
import { dataset } from '../experiments/data.mjs';

const event = () => dataset(17).training[0];
function withCore(work) { const core = new NephiaCore(); try { work(core); } finally { core.close(); } }

test('a proposal changes neither preferences nor accepted revision before review', () => withCore((core) => {
  const before = core.state(); core.propose(event(), 0); assert.deepEqual(core.state(), before);
  assert.throws(() => core.accept(event().id, 0, 'model_approved'), /Trusted review/);
  const after = core.accept(event().id, 0, 'host_verified');
  assert.equal(after.revision, 1); assert.equal(after.state.preferences.nephia.count, 1);
}));
test('user reports and praise cannot overwrite self preferences', () => withCore((core) => {
  core.record(event()); const before = core.state().state.preferences.nephia;
  const user = { ...event(), id: 'user-1', owner: 'user', signal: 'user_report', preferred: 'right' };
  core.record(user);
  core.record({ ...event(), id: 'praise-1', signal: 'user_praise', preferred: 'right' });
  core.record({ ...event(), id: 'generated-1', signal: 'generated_choice', preferred: 'right' });
  assert.deepEqual(core.state().state.preferences.nephia, before);
  assert.equal(core.state().state.preferences.user.count, 1);
}));
test('low confidence and unobserved outcomes are not promoted to learning', () => withCore((core) => {
  core.record({ ...event(), confidence: 0.4 }); assert.equal(core.state().state.preferences.nephia.count, 0);
  assert.throws(() => core.record({ ...event(), id: 'unobserved', signal: 'observed_choice', evidence: { ...event().evidence, origin: 'model' } }), /observed outcome/);
}));
test('stale updates and conflicts fail without partial state changes', () => withCore((core) => {
  const original = event(); core.propose(original, 0);
  core.record({ ...original, id: 'other' }); const before = core.state();
  assert.throws(() => core.accept(original.id, 0, 'host_verified'), /Stale revision/);
  assert.throws(() => core.accept(original.id, 1, 'host_verified'), /stale state/);
  assert.deepEqual(core.state(), before);
  assert.throws(() => core.propose({ ...original, preferred: original.preferred === 'left' ? 'right' : 'left' }, 1), /content conflict/);
}));
test('accepted duplicates do not learn twice or resurrect a rolled back event', () => withCore((core) => {
  core.record(event()); core.record(event()); assert.equal(core.revision, 1);
  core.rollback(0, 1); const before = core.state(); core.record(event());
  assert.deepEqual(core.state(), before); assert.equal(core.exportPortable().events.length, 1);
}));
test('rejected proposals never enter the accepted event ledger', () => withCore((core) => {
  core.propose(event(), 0); core.reject(event().id);
  assert.throws(() => core.accept(event().id, 0, 'human_reviewed'), /rejected/);
  assert.equal(core.exportPortable().events.length, 0);
}));
test('schema and feature changes are rejected before mutation', () => withCore((core) => {
  for (const bad of [{ ...event(), extra: 1 }, { ...event(), featureVersion: 'unknown' },
    { ...event(), left: { ...event().left, features: [NaN, 0, 0, 0, 0, 0] } },
    { ...event(), owner: 'user' }, { ...event(), confidence: -0.1 }]) assert.throws(() => core.record(bad));
  assert.equal(core.revision, 0);
}));
test('SQLite restart and portable restore reproduce decisions and all rollback history', () => {
  const dir = mkdtempSync(join(tmpdir(), 'nephia-test-')); const file = join(dir, 'core.db');
  try {
    let core = new NephiaCore(file); const data = dataset(5);
    data.training.slice(0, 24).forEach((sample) => core.record(sample));
    const previous = core.state(); const decision = core.compare('nephia', data.novel[0].left, data.novel[0].right);
    core.close(); core = new NephiaCore(file); assert.deepEqual(core.state(), previous);
    assert.deepEqual(core.compare('nephia', data.novel[0].left, data.novel[0].right), decision);
    const fresh = new NephiaCore(); fresh.restorePortable(JSON.parse(JSON.stringify(core.exportPortable())));
    assert.deepEqual(fresh.compare('nephia', data.novel[0].left, data.novel[0].right), decision);
    core.rollback(10, 24); fresh.rollback(10, 24); assert.deepEqual(core.state(), fresh.state());
    assert.equal(core.exportPortable().events.length, 24); assert.equal(core.activeEvents().length, 10);
    core.close(); fresh.close();
  } finally { rmSync(dir, { recursive: true, force: true }); }
});
test('tampered portable export is refused without overwriting destination', () => withCore((source) => {
  source.record(event()); const dump = source.exportPortable();
  dump.events[0].preferred = dump.events[0].preferred === 'left' ? 'right' : 'left';
  withCore((destination) => {
    assert.throws(() => destination.restorePortable(dump), /replay hash/); assert.equal(destination.revision, 0);
  });
}));
test('nonempty destinations cannot be overwritten by restore', () => withCore((core) => {
  const dump = core.exportPortable(); core.record(event()); const before = core.state();
  assert.throws(() => core.restorePortable(dump), /empty destination/); assert.deepEqual(core.state(), before);
}));
test('legacy self text is preserved verbatim and never becomes invented numeric preferences', () => withCore((core) => {
  const text = '---\nupdated: 2026-01-01\n---\n# 私\nまだ決めていない。\n';
  const imported = { id: 'legacy', kind: 'identity_import', owner: 'nephia', at: event().at,
    evidence: { sourceId: 'local-me', locator: 'me.md', origin: 'legacy' },
    sourcePath: 'synthetic/me.md', sourceHash: textHash(text), text };
  assert.throws(() => core.propose(imported, 0), /separate host/);
  core.importIdentity(imported, 0);
  assert.equal(core.state().state.identityReferences[0].text, text);
  assert.equal(core.state().state.preferences.nephia.count, 0);
}));
test('transient state expires in the context without destroying its audit trail', () => withCore((core) => {
  core.record({ id: 'transient', kind: 'transient', owner: 'nephia', at: '2026-01-01T00:00:00Z',
    evidence: event().evidence, key: 'focus', value: 'music', expiresAt: '2026-01-01T00:05:00Z' });
  assert.equal(Object.keys(core.context(Date.parse('2026-01-01T00:01:00Z')).state.currentState.nephia).length, 1);
  assert.equal(Object.keys(core.context(Date.parse('2026-01-01T00:06:00Z')).state.currentState.nephia).length, 0);
  assert.equal(core.activeEvents().length, 1);
}));
test('the explanation sum and every evidence ID agree with the accepted learning state', () => withCore((core) => {
  const data = dataset(8); data.training.slice(0, 16).forEach((sample) => core.record(sample));
  const result = core.compare('nephia', data.novel[0].left, data.novel[0].right);
  assert.ok(Math.abs(result.contributions.reduce((sum, item) => sum + item.contribution, 0) - result.margin) < 1e-12);
  assert.deepEqual(result.evidenceIds, core.activeEvents().map((e) => e.id));
}));

test('a failed revision write leaves the accepted ledger and projection unchanged', () => withCore((core) => {
  core.propose(event(), 0); const before = core.state();
  core.db.exec("CREATE TRIGGER fail_revision BEFORE INSERT ON revisions BEGIN SELECT RAISE(ABORT, 'simulated write failure'); END;");
  assert.throws(() => core.accept(event().id, 0, 'host_verified'), /simulated write failure/);
  assert.deepEqual(core.state(), before); assert.equal(core.activeEvents().length, 0);
  assert.equal(core.exportPortable().proposals[0].status, 'pending');
}));
test('reopening refuses a broken event ledger even if its cached state looks intact', () => {
  const dir = mkdtempSync(join(tmpdir(), 'nephia-ledger-test-')); const file = join(dir, 'core.db');
  try {
    const core = new NephiaCore(file); core.record(event()); core.close();
    const db = new DatabaseSync(file); db.prepare('UPDATE events SET digest=?').run('broken'); db.close();
    assert.throws(() => new NephiaCore(file), /Event integrity failure/);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});
