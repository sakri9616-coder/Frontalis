import test from 'node:test';
import assert from 'node:assert/strict';
import { NephiaCore } from '../src/core.mjs';
import { prepareInference, infer } from '../src/engine-boundary.mjs';
import { dataset } from '../experiments/data.mjs';

test('switching engines reuses the frozen Core decision and cannot silently train it', async () => {
  const core = new NephiaCore();
  try {
    const data = dataset(9); data.training.slice(0, 16).forEach((event) => core.record(event));
    const pair = data.novel[0]; const before = core.state();
    const prepared = prepareInference(core, { requestId: 'turn-1', userText: '次はどちら？', pair });
    const engineOne = { generate: async ({ packet }) => ({ text: `私は${packet.decision.selectedId}を選ぶ。`, proposals: [] }) };
    const engineTwo = { generate: async (value) => {
      const packet = JSON.parse(value.userMessage.contextNote.split('\n')[1]);
      return { text: `選択: ${packet.decision.selectedId}`, proposals: [{ ...data.training[0], id: 'generated-proposal' }] };
    } };
    const first = await infer(engineOne, prepared); const second = await infer(engineTwo, prepared);
    assert.equal(first.coreStateHash, second.coreStateHash); assert.equal(first.coreRevision, second.coreRevision);
    assert.ok(first.text.includes(prepared.packet.decision.selectedId));
    assert.ok(second.text.includes(prepared.packet.decision.selectedId));
    assert.deepEqual(core.state(), before);
  } finally { core.close(); }
});
