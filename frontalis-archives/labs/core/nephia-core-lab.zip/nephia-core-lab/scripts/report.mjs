import { readFileSync, writeFileSync, createReadStream, existsSync } from 'node:fs';
import { createInterface } from 'node:readline';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { NephiaCore, hash } from '../src/core.mjs';
import { dataset } from '../experiments/data.mjs';

const lab = resolve(dirname(fileURLToPath(import.meta.url)), '..'); const reports = join(lab, 'reports');
const r = JSON.parse(readFileSync(join(reports, 'results.json'), 'utf8'));
const perf = JSON.parse(readFileSync(join(reports, 'isolated-performance.json'), 'utf8'));
const methods = ['A', 'B', 'B_plus', 'B_recent', 'B_plus_recent', 'C'];
const names = { linear: '線形・ノイズなし', correlated: '相関した特徴', noisy: '評価ノイズ20%', nonlinear: '非線形な好み' };
const percent = (v) => (v * 100).toFixed(2) + '%';
const pp = (v) => (v * 100).toFixed(2);
const table = (stage) => '| 条件 | ' + methods.join(' | ') + ' |\n|' + methods.map(() => '---:').concat('---:').join('|') + '|\n' +
  Object.entries(r.summary).map(([s, v]) => '| ' + names[s] + ' | ' + methods.map((m) => percent(v[stage][m])).join(' | ') + ' |').join('\n');
const examples = {};
const lines = createInterface({ input: createReadStream(join(reports, 'predictions.jsonl')), crlfDelay: Infinity });
for await (const line of lines) {
  const p = JSON.parse(line);
  if (p.stage !== 'novel') continue;
  if (!examples.success && p.scenario === 'linear' && p.choices.B_plus !== p.expected && p.choices.C === p.expected) examples.success = p;
  if (!examples.noiseFailure && p.scenario === 'noisy' && p.choices.B_plus === p.expected && p.choices.C !== p.expected) examples.noiseFailure = p;
  if (!examples.nonlinearFailure && p.scenario === 'nonlinear' && p.choices.B === p.expected && p.choices.C !== p.expected) examples.nonlinearFailure = p;
  if (Object.keys(examples).length === 3) { lines.close(); break; }
}
writeFileSync(join(reports, 'representative-cases.json'), JSON.stringify(examples, null, 2));

const engines = ['claude', 'claude-sonnet'];
const live = Object.fromEntries(engines.map((engine) => [engine,
  JSON.parse(readFileSync(join(reports, 'live', `${engine}-results.json`), 'utf8'))]));
const exchange = [];
for (const mode of ['A', 'B', 'B_full', 'C']) {
  const one = live.claude.conditions.find((c) => c.mode === mode);
  const two = live['claude-sonnet'].conditions.find((c) => c.mode === mode);
  const agreement = one.records.filter((record) => two.records.find((p) => p.id === record.id)?.choice === record.choice).length / one.records.length;
  exchange.push({ mode, modelOne: one.model, modelTwo: two.model, n: one.records.length, agreement,
    identicalPrompts: one.promptHash === two.promptHash });
}

const data = dataset(1); const core = new NephiaCore();
data.training.forEach((event) => core.record(event));
const initialState = core.state(); const initial = new Map([...data.known, ...data.novel].map((p) => [p.id,
  core.compare('nephia', p.left, p.right)]));
data.driftTraining.forEach((event) => core.record(event));
const after = new Map(data.driftTest.map((p) => [p.id, core.compare('nephia', p.left, p.right)]));
const restoration = new NephiaCore(); restoration.restorePortable(core.exportPortable());
let promptDecisionChecks = 0; let mismatches = 0;
for (const engine of engines) {
  const input = JSON.parse(readFileSync(join(reports, 'live', `${engine}-C-input.json`), 'utf8'));
  for (const query of input.user.queries) {
    const prediction = (query.phase === 'drift' ? after : initial).get(query.id);
    promptDecisionChecks++;
    if (prediction.choice !== query.core.choice || Math.abs(prediction.margin - query.core.margin) > 0.000006) mismatches++;
  }
}
const portability = { currentPortableRestorationMatches: restoration.state().stateHash === core.state().stateHash,
  currentCoreMatchesRecordedLiveScorer: { checks: promptDecisionChecks, mismatches },
  note: 'This is a post-hoc scorer equivalence check. The completed live runs used the shared OnlinePreference scorer directly, not the RPC process.',
  exchange, initialRevision: initialState.revision, finalRevision: core.revision };
writeFileSync(join(reports, 'live', 'core-portable-v2.json'), JSON.stringify(core.exportPortable(), null, 2));
writeFileSync(join(reports, 'live-analysis.json'), JSON.stringify(portability, null, 2));
core.close(); restoration.close();

const curveTable = '| 自己経験件数 | A | B | B+ | C |\n|---:|---:|---:|---:|---:|\n' + [4, 8, 16, 32, 64].map((n) => {
  const rows = r.curves.filter((x) => x.scenario === 'linear' && x.n === n);
  return '| ' + n + ' | ' + ['A', 'B', 'B_plus', 'C'].map((m) => percent(rows.reduce((sum, x) => sum + x[m], 0) / rows.length)).join(' | ') + ' |';
}).join('\n');
const liveTable = '| モデル | A | B（8件検索） | B_full（全経験） | C（8件＋外部学習） |\n|---|---:|---:|---:|---:|\n' + engines.map((e) =>
  '| ' + live[e].conditions[0].model + ' | ' + ['A', 'B', 'B_full', 'C'].map((mode) => percent(live[e].conditions.find((c) => c.mode === mode).accuracy)).join(' | ') + ' |').join('\n');

const content = `# 実験結果と限界

実行日: 2026-10-13。**結論: 外部学習は変化する線形選好への適応に限定的な価値を示したが、通常の長期記憶を強くした比較方式に対する、人格全般への実質的改善は確認できていない。** 現時点で本番の常時人格学習を有効化する判断は推奨しない。

## 方法と再現性

事前計画はdocs/01-feasibility-and-protocol.md。4条件×40seed。1seedは別の架空人格。自己/ユーザー各64件、未知候補120組、変化後48件と別の未知候補120組。主評価は各条件4,800組。特徴は6次元、初期好みはランダムな隠れた重みから生成し、Coreに隠れた重み・正解を渡さない。ユーザー好みは自己と逆向きに生成し、帰属の混同が見つかる条件にした。候補IDは学習と未知評価で重ならない。学習と評価は別ファイル。既知候補だけは継続性を見るため意図的に再使用する。

オフラインA/B/CはLLMの振る舞いを代替する決定的アルゴリズム比較である。Aは好みを指定しない固定人格の同点処理、Bは特徴差に近い8経験の投票、B+は全経験の特徴別相関集計、Cはペアワイズ線形オンライン学習。Bの検索は特徴を直接利用しており、語句検索より有利な比較である。実際のASIST記憶の品質・検索器・Claudeによる自然文推論を再現したとは言わない。

B_recentは新しさを重視した8件検索。B_plus_recentは初回の結果を見た後に追加した探索分析で、新しさを重視した全経験集計。新しさの係数0.97を固定し、最適化していない。初回の結果はreports/results-preregistered-v1.jsonに保存。knownは既知候補の潜在好みへの正解率、observedKnownは実際に記録した評価との一致率である。ノイズ条件でこの2つを混同しないため、後者を追加集計した。評価結果に合わせたCのパラメーター変更はない。

データ集合ハッシュ: ${r.datasetHash}。再実行の精度は決定的に再現するが、遅延・メモリ使用量は環境負荷で変わる。bootstrapはseed単位の対応差、2,000回。実ユーザーへの一般化や、因果効果の信頼区間ではない。

## 未知対象の選択

${table('novel')}

線形条件のC-Bは+${pp(r.summary.linear.novelPairedDifference.B.mean)}ポイント（95%区間 ${pp(r.summary.linear.novelPairedDifference.B.low)}〜${pp(r.summary.linear.novelPairedDifference.B.high)}）。C-B+は+${pp(r.summary.linear.novelPairedDifference.B_plus.mean)}ポイント（${pp(r.summary.linear.novelPairedDifference.B_plus.low)}〜${pp(r.summary.linear.novelPairedDifference.B_plus.high)}）。事前の実質改善基準「5ポイント以上かつ区間下限>0」を満たさない。40seedという条件内で差が正でも、人格機能として十分な価値があるとは結論しない。

ノイズ条件はCがB+を${pp(-r.summary.noisy.novelPairedDifference.B_plus.mean)}ポイント下回った。非線形条件もCがB+を${pp(-r.summary.nonlinear.novelPairedDifference.B_plus.mean)}ポイント下回る。線形特徴の表現不足、最近の誤った評価を追いやすい更新が限界として表れた。理由の診断は設計と条件からの推論であり、学習率等の独立した要因分解を済ませたわけではない。

## 少量の経験からの学習

線形条件。各列は同じ独立した未知評価集合を使う。

${curveTable}

少量からスコアは形成できるが、少量で外部学習が最良であるとは限らない。必要件数を実Nephiaについて保証しない。

## 経験による変化

最も重みの大きい特徴1個の好みを反転させ、48件の追加経験の後に評価する。Coreには反転の正解や変化した特徴名を教えない。

${table('after')}

線形条件ではCがB+より+${pp(r.summary.linear.driftPairedDifference.B_plus.mean)}ポイント改善。追加のB_plus_recentに対しても+${pp(r.summary.linear.driftPairedDifference.B_plus_recent.mean)}ポイント（95%区間 ${pp(r.summary.linear.driftPairedDifference.B_plus_recent.low)}〜${pp(r.summary.linear.driftPairedDifference.B_plus_recent.high)}）。これはこの合成条件での成功であり、全ての記憶要約方式を超えた証明ではない。ノイズ条件ではB_plus_recentとの差の区間に0を含み、非線形条件では改善がない。

変化した特徴だけの組では線形条件でC/B_recent/B_plus_recentがいずれも100%になった。この成功だけなら外部学習は不要である。変わらなかった5特徴の軸別判断はCが変化前${percent(r.summary.linear.stableBefore.C)}、変化後${percent(r.summary.linear.stableAfter.C)}。相関条件では変化しない特徴のCが${percent(r.summary.correlated.stableBefore.C)}から${percent(r.summary.correlated.stableAfter.C)}に下がるため、適応しても維持を保証しない。

## 好みの継続と根拠

観測された既知32組/seedへの一致率:

${table('observedKnown')}

線形・ノイズなしの既知候補ではBがCよりわずかに良い。新しい対象への汎化と、過去判断の完全な再現は同じ目的ではない。ノイズ条件で過去の誤った評価を全部維持することも成功にしない。

数値の根拠は${r.explanation.checks.toLocaleString('en-US')}判断で寄与の和・有効な来歴IDを検査し、失敗${r.explanation.failures}。これは数式・IDの整合であり、自然言語の説明が正しいことや、記憶IDが因果の唯一の根拠であることを保証しない。ユーザー評価・褒め・未実行の生成選択の追加で、自己選好の重みが変わらないことは別のテストで確認した。

代表例の再計算用ID:

- 成功: ${examples.success.id}。正解${examples.success.expected}、B+=${examples.success.choices.B_plus}、C=${examples.success.choices.C}。
- ノイズ時の失敗: ${examples.noiseFailure.id}。正解${examples.noiseFailure.expected}、B+=${examples.noiseFailure.choices.B_plus}、C=${examples.noiseFailure.choices.C}。
- 非線形時の失敗: ${examples.nonlinearFailure.id}。正解${examples.nonlinearFailure.expected}、B=${examples.nonlinearFailure.choices.B}、C=${examples.nonlinearFailure.choices.C}。

原データはdata/evaluation.jsonl、判定はreports/predictions.jsonl、抜粋はreports/representative-cases.json。好みの意味を実Nephiaの性格として採用していない。

## 実LLMでの小規模比較

同じ合成線形人格の12問（既知2/未知5/変化後5）、各方式1回。Claude CLIのclaude.aiサブスクリプション認証・initのapiKeySource=noneを確認。API課金は前提にせず、APIキーを渡していない。CはCoreの提案を助言として提示し、LLMの選択を強制していない。実会話履歴、me.md、個人情報は送っていない。

${liveTable}

初回試験ではB_fullの記憶が各問題で重複していたため、全経験をphase別に1回だけ載せる形に変更し、同じ入力で両モデルをそろえた。初回はreports/live-first-pass、最終比較はreports/liveに保存。初回HaikuのBが9/12、最終が10/12となり、Aも変動した。temperatureが0のAPIでないCLI試験には出力の揺れがある。大規模な統計的優位性の根拠にしない。

モデル間の選択一致率（同じ問題・同じ入力）:

| 方式 | Haiku/Sonnetの一致率 |
|---|---:|
${exchange.map((e) => `| ${e.mode} | ${percent(e.agreement)} |`).join('\n')}

Cは両モデルともCore提案への遵守が11/12。完全な選択再現ではない。1-linear-drift-test-2ではHaikuがCoreのrightに反してleftを選び、古い高エネルギーの記憶を根拠にした。これは状態を外に置くだけでは表現エンジンの判断を統制しきれない具体例である。Coreを行動選択の主体にし、LLMを文章化へ限定する方式と、LLMが再考できる方式を設計上区別する必要がある。

全出力の記憶ID参照は提供した集合に属したが、文章の因果的・意味的な正しさを全件独立評価したわけではない。Cの全学習来歴は8件より多い一方、LLMが読む記憶は8件であり、文章が数値学習の来歴を過剰に特定しないよう注意が必要。

実試験は共有OnlinePreferenceを直接使った。最終Core台帳を再構成して、記録済みC入力の24判断を照合した結果は不一致${mismatches}。この後からの同値確認と、実RPCを経由したLLM試験を混同しない。独立プロセス境界はテストで別途検証している。保存/復元したCore判断120組は完全一致したが、異なる実LLMの自然な文章まで同一とは言わない。

LM Studioの実推論は失敗し、別ポートのCPUサーバーも初期化が完了しなかった。第2の実行ファイルはexit=3221225781で早期終了。原因は確定していない。異なるモデル提供元・ローカルLLMとの実比較は未完了であり、Haiku/Sonnetの結果だけでClaudeからの完全な移植を実証したとは言えない。

## 性能と運用上の限界

実機: ${r.environment.cpu.trim()}、RAM ${r.environment.totalRamGiB.toFixed(2)}GiB、Windows x64、Node ${r.environment.node}。学習CoreにGPUは使用しない。

| 測定 | p50 | p95 |
|---|---:|---:|
| 純粋な学習更新 | ${r.performance.update.p50Ms.toFixed(4)}ms | ${r.performance.update.p95Ms.toFixed(4)}ms |
| 純粋な候補比較 | ${r.performance.pureCompare.p50Ms.toFixed(4)}ms | ${r.performance.pureCompare.p95Ms.toFixed(4)}ms |
| 独立プロセスでSQLite受理（128件） | ${perf.writes.p50Ms.toFixed(2)}ms | ${perf.writes.p95Ms.toFixed(2)}ms |
| SQLiteからの候補比較 | ${perf.reads.p50Ms.toFixed(2)}ms | ${perf.reads.p95Ms.toFixed(2)}ms |

独立測定RSSは${perf.rssBeforeMiB.toFixed(1)}→${perf.rssAfterMiB.toFixed(1)}MiB。128件のDBは${(perf.databaseBytes / 1024 ** 2).toFixed(2)}MiB。これはNodeプロセス全体のworking setで、Coreだけの私有メモリではない。実験全体のRSS ${r.performance.processRssMiB.toFixed(1)}MiBは多数のデータ集合・出力を含み、常駐Coreの値として引用しない。

SQLite書込みは負荷のある別測定でp95=180msにもなった。synchronous=FULL、各更新の全投影・完全snapshot保存を含むため、会話のリアルタイム経路で連続して同期実行しない。128件測定から大量履歴での軽量性を推測しない。増分投影・checkpoint・非同期の受理処理は統合前に必要。

## 次の判断

通常の記憶 + 単純な傾向集計を有力候補として残す。Core台帳は人格の保存・移植の基礎として使い、学習器は限定ドメインで影の評価を続ける。自然言語からの特徴/評価抽出、独立した根拠評価、ノイズへの耐性、別の提供元のLLM、小量の許可された実データが次の検証対象である。ニューラルネットを採用する前に、文脈・特徴相互作用・ベイズ推定等の単純な比較を追加する。意識・感情の実在や、完全な人格移植は今回の成果として主張しない。
`;
writeFileSync(join(lab, 'docs', '05-results.md'), content);
console.log(JSON.stringify({ reportWritten: true, liveExchange: exchange, portability, representativeCases: examples }));
