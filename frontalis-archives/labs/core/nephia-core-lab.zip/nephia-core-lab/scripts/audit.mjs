import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const lab = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const repo = resolve(lab, '..', 'asist');
const reports = join(lab, 'reports'); mkdirSync(reports, { recursive: true });
const digest = (file) => createHash('sha256').update(readFileSync(file)).digest('hex');
const git = (args) => execFileSync('git', ['-C', repo, ...args], { encoding: 'utf8', windowsHide: true });
const files = git(['ls-files', '--cached', '--others', '--exclude-standard', '-z']).split('\0').filter(Boolean);
const hashes = Object.fromEntries([...new Set(files)].filter((f) => existsSync(join(repo, f))).map((f) => [f, digest(join(repo, f))]));
const userData = join(process.env.APPDATA, 'asist');
const memoryHashes = Object.fromEntries(['memory/me.md', 'memory/user.md', 'settings.json'].filter((f) => existsSync(join(userData, f))).map((f) => [f, digest(join(userData, f))]));
const result = { capturedAt: new Date().toISOString(), repo, userData, status: git(['status', '--porcelain=v1']),
  head: git(['rev-parse', 'HEAD']).trim(), hashes, memoryHashes };
const phase = process.argv[2] ?? 'before';
if (phase === 'after') {
  const before = JSON.parse(readFileSync(join(reports, 'audit-before.json'), 'utf8'));
  result.changedSourceFiles = [...new Set([...Object.keys(before.hashes), ...Object.keys(hashes)])]
    .filter((f) => before.hashes[f] !== hashes[f]);
  result.changedMemoryOrSettings = Object.keys(memoryHashes).filter((f) => memoryHashes[f] !== before.memoryHashes[f]);
  result.gitStatusUnchanged = before.status === result.status;
  console.log(JSON.stringify({ changedSourceFiles: result.changedSourceFiles,
    changedMemoryOrSettings: result.changedMemoryOrSettings, gitStatusUnchanged: result.gitStatusUnchanged }));
}
writeFileSync(join(reports, `audit-${phase}.json`), JSON.stringify(result, null, 2));
if (phase === 'before') console.log(`Read-only baseline captured: ${Object.keys(hashes).length} files.`);
