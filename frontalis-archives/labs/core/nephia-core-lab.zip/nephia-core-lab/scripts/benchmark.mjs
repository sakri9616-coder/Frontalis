import { performance } from 'node:perf_hooks';
import { mkdirSync, writeFileSync, statSync } from 'node:fs';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { NephiaCore } from '../src/core.mjs';
import { dataset } from '../experiments/data.mjs';

const lab = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const directory = join(lab, 'runtime', `isolated-bench-${Date.now()}`); mkdirSync(directory, { recursive: true });
const file = join(directory, 'core.db'); const rssBefore = process.memoryUsage().rss;
const data = dataset(30); const core = new NephiaCore(file); const writes = []; const reads = [];
for (let i = 0; i < 128; i++) {
  const started = performance.now(); core.record(data.training[i]); writes.push(performance.now() - started);
}
for (let i = 0; i < 300; i++) {
  const sample = data.novel[i % 120]; const started = performance.now();
  core.compare('nephia', sample.left, sample.right); reads.push(performance.now() - started);
}
const rssAfter = process.memoryUsage().rss; core.close();
const quantile = (a, p) => [...a].sort((a, b) => a - b)[Math.floor(a.length * p)];
const stats = (a) => ({ n: a.length, p50Ms: quantile(a, 0.5), p95Ms: quantile(a, 0.95) });
const result = { capturedAt: new Date().toISOString(), scope: 'Fresh process with only 128 synthetic events; includes SQLite, full projection rebuild, two transactions/event and FULL fsync.',
  node: process.version, writes: stats(writes), reads: stats(reads),
  rssBeforeMiB: rssBefore / 1024 ** 2, rssAfterMiB: rssAfter / 1024 ** 2, databaseBytes: statSync(file).size };
writeFileSync(join(lab, 'reports', 'isolated-performance.json'), JSON.stringify(result, null, 2));
console.log(JSON.stringify(result));
