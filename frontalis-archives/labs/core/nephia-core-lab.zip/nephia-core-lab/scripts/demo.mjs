import { NephiaCore } from '../src/core.mjs';
import { dataset } from '../experiments/data.mjs';
import { writeFileSync, mkdirSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const core = new NephiaCore(); const data = dataset(9);
data.training.slice(0, 32).forEach((event) => core.record(event));
const before = core.state(); const sample = data.novel[0];
const reports = resolve(dirname(fileURLToPath(import.meta.url)), '..', 'reports');
mkdirSync(reports, { recursive: true });
writeFileSync(join(reports, 'demo-export.json'), JSON.stringify(core.exportPortable(), null, 2));
const restored = new NephiaCore(); restored.restorePortable(core.exportPortable());
console.log(JSON.stringify({ restoredStateMatches: restored.state().stateHash === before.stateHash }));
restored.close();
console.log(JSON.stringify({ description: 'Synthetic Nephia preference after 32 experiences',
  decision: core.compare('nephia', sample.left, sample.right) }, null, 2));
core.record(data.driftTraining[0]); core.rollback(before.revision, core.revision);
console.log(JSON.stringify({ rollbackPreservesState: core.state().stateHash === before.stateHash,
  acceptedEventsRetained: core.exportPortable().events.length, activeEvents: core.activeEvents().length }));
core.close();
