import { spawn } from 'node:child_process';
import { openSync, closeSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const lab = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const serverPath = 'C:/Users/sakur/.lmstudio/extensions/backends/llama.cpp-win-x86_64-nvidia-cuda12-avx2-2.56.0/llama-server.exe';
const modelPath = 'D:/LMstudio/.lmstudio/models/local-assistant/Qwen3-4B-Instruct-2507-GGUF/Qwen3-4B-Instruct-2507-Q4_K_M.gguf';
const work = join(lab, 'runtime', 'isolated-local'); mkdirSync(work, { recursive: true });
if (!existsSync(serverPath) || !existsSync(modelPath)) throw new Error('Existing binary/model is missing; no installation is performed.');
try {
  await fetch('http://127.0.0.1:18371/health', { signal: AbortSignal.timeout(1000) });
  throw new Error('Trial port is already occupied.');
} catch (error) { if (error.message === 'Trial port is already occupied.') throw error; }
const log = openSync(join(work, 'server.log'), 'w');
const args = ['--model', modelPath, '--alias', 'nephia-trial-qwen3-4b', '--host', '127.0.0.1', '--port', '18371',
  '--ctx-size', '16384', '--n-gpu-layers', '0', '--threads', '6', '--parallel', '1', '--jinja', '--no-warmup'];
const server = spawn(serverPath, args, { cwd: work, windowsHide: true, stdio: ['ignore', log, log] });
const result = { startedAt: new Date().toISOString(), serverPath, modelPath, args,
  processId: server.pid, existingServersModified: false, gpuLayers: 0 };
let serverError;
server.on('error', (error) => { serverError = error; });
let serverEnded = false;
const closed = new Promise((done) => server.on('close', (code) => { serverEnded = true; result.serverExitCode = code; done(); }));
try {
  const deadline = Date.now() + 120000; let ready = false;
  while (Date.now() < deadline && !serverEnded) {
    try { const response = await fetch('http://127.0.0.1:18371/health', { signal: AbortSignal.timeout(1000) }); if (response.ok) { ready = true; break; } } catch {}
    await new Promise((done) => setTimeout(done, 500));
  }
  if (!ready) throw serverError ?? new Error(serverEnded ? `Isolated server exited before readiness: ${result.serverExitCode}.` : 'Isolated server readiness timed out.');
  console.log('Independent CPU inference process is ready.');
  const child = spawn(process.execPath, [join(lab, 'experiments', 'live.mjs'), 'isolated-local'],
    { cwd: lab, windowsHide: true, stdio: ['ignore', 'inherit', 'inherit'] });
  result.trialExitCode = await new Promise((done, fail) => { child.on('error', fail); child.on('close', done); });
} catch (error) {
  result.error = error.message; console.log(JSON.stringify({ isolatedLocalTrialError: error.message }));
} finally {
  if (!serverEnded) server.kill();
  await closed; closeSync(log); result.finishedAt = new Date().toISOString();
  writeFileSync(join(lab, 'reports', 'isolated-local-process.json'), JSON.stringify(result, null, 2));
}
