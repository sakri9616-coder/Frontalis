# Nephia Core Lab

Windows上の独立した研究試作。既存のASIST・Claude CLI設定・人格・me.md/user.mdを変更せず、架空の経験で外部学習の効果を比較した。Node.js 24以上の標準機能だけで動き、依存パッケージのインストール、APIキー、GPUは不要。

**現時点の判断:** 通常の長期記憶に対する、人格全般への実質的な改善はまだ示せていない。線形な好みが変わる条件では利点があったが、静的な未知候補への改善は小さく、ノイズや非線形条件では悪化した。本番へ常時学習を入れる前に、記憶のみの方式と影で比較する。

## 成果物

1. [実現可能性と事前実験計画](docs/01-feasibility-and-protocol.md)
2. [現行ASISTの確認結果と未確認事項](docs/02-current-environment.md)
3. [先行研究・手法比較・採用判断](docs/03-research.md)
4. [Nephia Core設計](docs/04-design.md)
5. [実験結果・成功と失敗・性能・限界](docs/05-results.md)
6. [Claude Codeへの具体的な統合引き継ぎ](docs/06-integration-handoff.md)

試作には人物別の選好学習、出典付き経験台帳、提案/受理の分離、更新競合検査、JSON export/restore、履歴を残すロールバック、期限付き状態、独立プロセスのJSON Lines境界がある。自己記憶の原文を保つimportは架空文書で検証し、実me.mdには適用していない。

テストは17件実行、17件成功。終了時の照合でme.md/user.mdのハッシュは一致した。一方、既存ソース5ファイルとsettings.jsonの変化を検出した。この作業の書込みは本フォルダーに限り、検出した既存変更を戻していない。変化の原因は今回特定していない。統合時は最新の改造版を再確認する。

## 動かす

```powershell
Set-Location 'C:\Users\sakur\AppData\Local\asist-shisa\nephia-core-lab'
npm test
npm run demo
npm run evaluate
node scripts/report.mjs
```

`evaluate`は数十秒程度で、dataとreports内の再生成可能な実験出力を更新する。`report`には保存済みの実LLM比較ファイルも必要で、この成果物には含まれている。実LLM比較をやり直さなくてもオフライン実験は再現できる。

`demo`は架空の32経験から判断し、保存用exportを `reports/demo-export.json` に書き、復元一致とロールバックを表示する。実記憶は読み込まない。

`npm run serve`はstdioでのみ通信し、`runtime/core.db`を使う。`node src/rpc.mjs --memory`は保存しない試験用。1行1JSONをstdinへ渡す:

```json
{"id":"state-1","method":"state","params":{}}
```

LLMへ公開するのは参照・compare・proposeだけ。accept/rollback/exportは信頼するホストの管理操作で、reviewという文字列自体は権限確認にならない。公開ネットワークのサービスにはしない。保存形式2、異なる形式/学習設定は明示的な移行なしでは開かない。

## 検証データ

- `reports/results.json` / `results.csv`: 条件別集計、seed別結果、学習曲線、性能。
- `data/training.jsonl` / `evaluation.jsonl`: 分離した学習経験と評価問題。
- `reports/predictions.jsonl`: 全比較の判断。
- `reports/representative-cases.json`: 成功/ノイズ時失敗/非線形時失敗の再計算用ID。
- `reports/results-preregistered-v1.json`: 新しさを重視する全記憶集計を追加する前の結果。
- `reports/live/`: 架空データによるHaiku/Sonnet試験の入力・出力・採点。Cは助言として提示し、LLMは拒否できる。
- `reports/live-analysis.json`: 実モデル間の一致、最終Coreと記録済み学習スコアラーの後からの同値確認。
- `reports/test-results.tap`: 実行済みテストの記録。
- `reports/isolated-performance.json`: 小規模Coreだけを新しいプロセスで測った遅延・RSS・DB容量。
- `reports/audit-before.json` / `audit-after.json`: 既存ソース・me.md/user.md・設定のハッシュ照合。

## 制約

6特徴の線形選好は人格全体を表さない。自然言語からの特徴/評価抽出、意味の正しさを審査する仕組み、MCP実装、本番ASISTとのE2E、大量履歴への最適化、暗号化、消去は未実装。モデルの自然文・自己評価が交換後も完全に同じになる保証はない。

実LLM比較は各方式12問×1回の探索的な小規模試験で、オフラインの4条件×40seedとは別の証拠。LM Studioと独立CPUサーバーのローカル推論は失敗しており、異なる提供元・ローカルLLMへの移植の実証は未完了。意識・感情の実在を示す実験ではない。

ソースの中心は `src/core.mjs`、`learner.mjs`、`contracts.mjs`、`rpc.mjs`、`engine-boundary.mjs`。実際の統合手順と必要な追加検証は引き継ぎ文書を参照。
