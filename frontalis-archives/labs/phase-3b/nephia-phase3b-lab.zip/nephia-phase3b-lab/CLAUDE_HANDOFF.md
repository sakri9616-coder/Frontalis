# Claude Codeへの引き継ぎ：Phase 3-B

この資料は実装の引き継ぎ用である。今回Claude CLIは呼んでいない。本体統合、実記憶の取込、自動学習、Phase 4は未実施であり、次の作業へ勝手に広げない。

## 現在の正本と最初に読むもの

研究領域：`C:\Users\sakur\AppData\Local\asist-shisa\nephia-phase3b-lab`。

最初に [REPORT.md](REPORT.md)、[数値結果](docs/04-numeric.md)、[会話結果](docs/05-conversations.md)、[受理の限界](docs/07-ingestion.md) を読む。主NPN8を最良方式として採用しない。過去のPhase 3-Aと今回の数値・会話は合算しない。

## 実装の入口

| ファイル／入口 | 実際の責務 |
|---|---|
| `p3b/data.py`：`records()`、`probes()` | 具体的な合成経験、独立観測、手注釈、未知の行動候補 |
| `p3b/model.py`：`shared_train()` | CPU・人物情報なしの共有特徴学習 |
| 同：`select()`、`fit()`、`refit()` | 訓練と設定選択、受理済み経験から外部パラメータ更新 |
| 同：`predict()`、`transition()` | 長期傾向の推論と、別管理する短期反応の遷移 |
| `p3b/store.py`：`Store` | 世代保存、再読込、export、空領域へのrestore、rollback |
| `p3b/ingest.py`：`accept_proposal()` | 事実・解釈案・独立確認を照合。不足した評価は拒否／保留 |
| `scripts/infer.py` | JSON状態を新OSプロセスで読み、stdinの問い合わせへ数値を返す |
| `scripts/opencode.mjs` | 既存CLIの無料モデルだけを使う最小アダプター |
| `scripts/prepare_live.py` | 会話入力と評価専用targetを分離し凍結 |
| `experiments/live.mjs` | 原入力・原出力・失敗を保存、完全一致の有効cacheは再生成しない |
| `scripts/matched_controls.py` | 外部state以外を維持した追加対照を作る |
| `scripts/analyze.py` | 保守的な事前語句検査、別の人間評価用20返事を出力 |
| `scripts/review.mjs` | 許可フィールドだけから静的なブラインド画面を作る |
| `scripts/verify_live.py` | 追加LLM禁止のcache検証、100条件のreadoutと来歴、rawツールイベントの監査 |

共有488パラメータ、個人180＋回復2。6入力→32→8の共有層を凍結し、4領域×5headを学ぶ。保存には共有重みも含み、推論はNumPyだけで実行できる。`p35.context.v1` の形状だけを再利用し、意味の版は `p3b.semantic6.v1`。旧6入力と意味互換と扱わない。

反応強度のdecoderは `bounded-tanh-v1`。旧decoderの負値を後処理で隠す運用へ戻さない。初期強度0.5は未学習の中立値で、現在の短期反応は別の0から始まる。

## 読み取り中心の再検証

既存Python環境にNumPy／Torchがある。追加インストールとGPUは不要。以下はPowerShellで研究領域から実行する。

```powershell
Set-Location -LiteralPath 'C:\Users\sakur\AppData\Local\asist-shisa\nephia-phase3b-lab'
$taskPython = 'C:\Users\sakur\AppData\Local\hermes\jef\venv\Scripts\python.exe'
$env:PYTHONUTF8 = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
& $taskPython -m unittest discover -s tests -v
& 'D:\node.exe' scripts/test_review.cjs
& $taskPython scripts/verify_live.py
```

47 Python＋14画面テストが成功した実コマンドを [test-verification.json](reports/test-verification.json) に保存している。最終点検で空台帳exportのheadをNoneではなく−1と比較していた不具合を修正し、その回帰試験を追加した。試験は独立runtimeの一時データを作る。WindowsでCodex制限下の原子的置換がWinError5になる場合、新研究runtimeだけを対象に通常権限のホストで確認する。本体や旧領域を触る回避策を作らない。

`verify_live.py` は4つのCLI cacheチェックに必ず `NEPHIA_VERIFY_CACHE_ONLY=1` を指定する。欠落・不一致なら失敗し、外部呼び出しはしない。原結果では200有効、9無効試行、100個の入力条件と学習済みreadoutが一致した。

新プロセスからの推論例：

```powershell
@'
{"owner":"nephia","semanticSchema":"p3b.semantic6.v1","x":[[0.6,0.8,0.2,0.5,0.3,0.4]],"domain":[0]}
'@ | & $taskPython scripts/infer.py models/live-p0.json
```

結果は5機能の配列と別管理の短期状態。LLM、学習、実記憶の参照を伴わない。この問い合わせは検証済みの実装形式を使う例で、音の趣味を意味する固定プロフィールではない。

## 数値研究を再実行する場合

現研究領域の `data/`、`models/`、`reports/` は結果の正本なので上書きしない。空の別研究ディレクトリへ `p3b/`、`experiments/`、`scripts/`、`tests/` と、既存の `models/frozen-phase35.json` をコピーしてから実行する。旧Phase 3-A原本を変更する必要はない。

```powershell
# 空の再現用コピーを作った後、そのディレクトリで実行する。
& $taskPython experiments/numeric.py
& $taskPython experiments/diagnostics.py
& $taskPython scripts/audit_interventions.py
```

最初が180主条件、次が結果後に追加した容量・意味・転用の診断。最後は介入後の真値誤差を付ける。CPU thread数は共有学習側で2。時間は機器や負荷で変わる。訓練、設定選択、最終評価の入力や教師を結果に合わせて変更しない。

会話の凍結入力を作る処理は既存ファイルがあれば拒否する。新しい試験は別コピーで `prepare_live.py` → `matched_controls.py` の順。OpenCode呼び出しはその時点のユーザー指示の範囲でだけ行い、有料fallbackやClaudeへの切替はしない。現在は保存済みの200返事を使い、不要に再取得しない。

## 会話結果の扱いを変えない

- A/B/C/Dは履歴なし、履歴だけ、状態だけ、両方。診断Q・確定Fは自然会話と分ける。
- S/Tの元比較にはbatch相手や履歴条件の交絡がある。因果的解釈には、追加のSX/LX/TI/TAと同一入力Rを使う。
- 主案を復号できない自然な複合文を誤答扱いしない。事前語句の成績と、後からLLM分析者が読む文義監査と、人間のブラインド採点を混ぜない。
- 初期の同点をargmax先頭の人格正解にしない。NPN側の教師一致と、LLM側の状態一致も別に数える。
- Bには同領域の全訓練履歴があるが、NPNは別の検証16件で設定選択した。完全同情報の比較とは呼ばない。
- 同一入力Rでも1/8組の主案が変わった。SXの単発変化を、学習状態の固有の因果効果と断定しない。
- `reports/review-key.json` は非ブラインドの対応表。採点者へ先に見せない。20返事は重点点検用で、全200件を代表する無作為標本ではない。
- `runtime/ui-saved-test.json` は操作試験だけ。正式な人間採点ではない。実験終了時の正式採点数は0。

## 現行ASISTとの接点：確認済みと未実施

読み取りで確認した現行コードは、親領域の `asist/src/shared/agent-cli.ts` と `asist/src/main/services/opencode-models.ts`。OpenCodeを `run --standalone --format json --agent plan|build -m <model>` で起動し、stdinで入力する方式と、優先無料モデルの列挙がある。研究側はこの実績とPhase 3-Aの小アダプターを再利用した。新接続基盤は作っていない。

OpenCodeのplanモードはOS隔離を保証しない。今回の原ログでは取消されたquestionと、入力内のJSONを組み立てたexecuteが各1件あり、両方の試行を無効として再試行した。後者のnested toolCallsは空。file/shell/networkのtoolイベントは記録されていないが、これを一般的な安全保証と扱わない。

ASISTの現行セッションへCore参照を挿入するhook、日次記憶整理との正式なtransaction、本人確認の経路は今回実装・実証していない。未確認のhook名やファイル保存先を推測して改修しない。実 `me.md` は将来も原文を尊重し、生成した人格プロフィールで上書きしない。

## 統合を再検討する順序

1. **意味と根拠を先に検証する。** 複数話者、曖昧さ、訂正、未実行の案と実行結果を含む合成記録を追加し、解釈案の根拠を原文へ結び付ける。文章だけから連続6特徴や強度を得る部分は未解決。全5観測を要求する現ゲートは、不足観測を安全に扱う部分学習へ改良が必要。
2. **対照を完全に揃える。** 固定設定で同情報の履歴・検索・二次回帰・旧NN・提案NNを比較する。自然な複合案と診断の単一候補を分け、外部状態の交換と同一入力の再生成を反復する。次の評価基準と件数を結果取得前に決める。
3. **人間ブラインド評価を行う。** 今回の20件は入口として使える。数値順位の一致、実行経験の正しさ、会話の納得感を分離する。正式採点後も、重点標本を全件の成功率へ換算しない。
4. **読み取り専用のshadow接続を設計する。** 本体の会話LLMへ状況別readoutを渡すだけにし、経験受理と学習状態の書込は別ホストに置く。先に合成データで試し、実記憶への自動取込はしない。現段階ではこの接続も未実装。
5. **信頼できる受理が成立した後に限り学習を検討する。** `eventHash`／`proposalHash`の結び付けは実装済みだが、reviewer名・authority文字列は認証にならない。会話LLMがreviewを作れない経路、取消・訂正、世代の競合検査、単一writerの責務を実装する。複数writer・暗号化・多ファイルtransactionは未対応。

数値方式として優れていても、本人の観測が正しく、未知場面への転用が妥当で、生成された理由が原経験に対応することが必要。これらを満たすまで本体統合を保留する。NNの複雑化、固定プロフィールの追加、強制回答だけで未解決点を隠さない。
