# Nephia Core Phase 3-B

経験の解釈、外部人格の学習、日本語会話の表現を分けた、CPU優先の独立研究試作品。

**学習状態の形成と訂正は確認できた。自然な会話への忠実な反映と、履歴提示を超える会話上の優位は未確立。** 実際のネフィアの記憶を取り込んだり、本体へ統合したりしていない。

まず読むもの：

- [人間向け成果報告と8問への回答](REPORT.md)
- [20件のブラインド評価画面](reports/review.html) — ブラウザーで開く。モデル名や方式名を調べる前に採点する。
- [Claude Codeへの引き継ぎ・再現手順](CLAUDE_HANDOFF.md)

研究資料：

| 資料 | 内容 |
|---|---|
| [主会話計画](docs/00-conversation-plan.md)、[詳細プロトコル](docs/01-protocol.md) | 条件、分離、固定時期の限界 |
| [追加対照の計画](docs/00b-matched-controls.md) | 元試験の交絡を修正した探索対照 |
| [経験と設問](docs/02-experiences.md)、[設計](docs/03-design.md) | 自然文と手注釈の境界、多機能の学習 |
| [数値結果](docs/04-numeric.md)、[会話結果](docs/05-conversations.md) | 強い比較対象、成功と失敗 |
| [人間評価](docs/06-human-review.md) | 読み方、採点JSON、盲検条件 |
| [経験受理](docs/07-ingestion.md) | 提案と許可を分離、実運用では認証未実装 |
| [固定10件の補助監査](docs/08-qualitative-audit.md) | 結果後の分析者LLMによる読取、人間評価ではない |
| [技術選定と先行研究](docs/09-research-basis.md) | ブラックボックス対応と重み更新の区別 |
| [同条件24返事の補助監査](docs/10-matched-dialogue-audit.md) | 状態交換、説明、時期、再生成 |

実装は `p3b/`、再現ジョブは `experiments/`、試験は `tests/`。合成経験は `data/`、共有重み・個人head・反応状態・来歴は `models/`。実出力と集計は `reports/`。結果後に追加した診断は資料で探索的試験と明記した。

主試験160＋追加対照40＝200会話、別枠16解釈案。無料OpenCodeの2モデルを使用。正式な人間会話採点は0件。Python47／画面14の試験は全合格。旧研究成果1,143ファイルは変更0・欠落0。

研究結果を変える再実行は、新しいコピーで行う。元の凍結入力・有効返事を上書きしない。保存済み出力の検証は `scripts/verify_live.py` で追加LLM呼び出しなしに実行できる。
