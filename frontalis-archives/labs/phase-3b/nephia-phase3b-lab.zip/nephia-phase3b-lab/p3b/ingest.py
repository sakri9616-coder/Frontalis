"""Research prototype: proposals cannot authorize their own learning."""
import copy
import math
import hashlib
import json
from p3b.data import SEMANTIC_AXES, SEMANTIC_SCHEMA

SIGNALS = ('preference', 'curiosity', 'priority', 'reaction_direction', 'intensity')


def content_hash(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def accept_proposal(event, proposal, review):
    """A trusted host must supply review separately; missing signals stay pending.

    This function models provenance rules, not authentication of a reviewer.
    In production, the conversational LLM must never control the review channel.
    """
    if event.get('origin') not in ('synthetic', 'observation', 'human') or not isinstance(event.get('text'), str):
        raise ValueError('Missing original event and origin.')
    if review.get('approved') is not True or review.get('authority') not in ('research-human-equivalent', 'trusted-human'):
        raise ValueError('An extraction proposal is not permission to learn.')
    if review.get('eventId') != event.get('id') or not isinstance(review.get('reviewer'), str) or not review['reviewer']:
        raise ValueError('Unattributed review.')
    if review.get('eventHash') != content_hash(event) or review.get('proposalHash') != content_hash(proposal):
        raise ValueError('Approval does not match the exact event and proposal.')
    if proposal.get('owner') != 'nephia':
        raise ValueError('User preferences are not Nephia preferences.')
    inputs = proposal.get('features', {})
    outputs = proposal.get('assessments', {})
    if set(inputs) != set(SEMANTIC_AXES) or set(outputs) != set(SIGNALS):
        raise ValueError('Incomplete observations remain pending; do not fill with zero.')
    x, y = [], []
    evidence = []
    for key in SEMANTIC_AXES:
        item = inputs[key]
        value = item.get('value')
        quote = item.get('sourceQuote')
        if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value) or abs(value) > 1:
            raise ValueError('Invalid semantic feature.')
        if not isinstance(quote, str) or not quote or quote not in event['text']:
            raise ValueError('Feature must trace to the original event.')
        if review.get('confirmedFeatures', {}).get(key) is not True:
            raise ValueError('Inferred semantics need independent review.')
        x.append(value)
        evidence.append({'field': key, 'sourceQuote': quote})
    for key in SIGNALS:
        item = outputs[key]
        value, quote = item.get('value'), item.get('sourceQuote')
        if (item.get('actor') != 'nephia' or item.get('basis') != 'confirmed-own-record'
                or review.get('confirmedAssessments', {}).get(key) is not True):
            raise ValueError('LLM guesses, praise and unverified self-reports do not become own observations.')
        if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value) or abs(value) > 1 or key == 'intensity' and value < 0:
            raise ValueError('Invalid own observation.')
        if not isinstance(quote, str) or not quote or quote not in event['text']:
            raise ValueError('Assessment must trace to an independently confirmed record.')
        y.append(value)
        evidence.append({'field': key, 'sourceQuote': quote})
    domain = proposal.get('domain')
    if type(domain) is not int or not 0 <= domain < 4 or review.get('confirmedDomain') is not True:
        raise ValueError('Domain interpretation is unconfirmed.')
    return {'id': event['id'], 'text': event['text'], 'owner': 'nephia', 'origin': event['origin'],
            'inputSchema': 'p35.context.v1', 'semanticSchema': SEMANTIC_SCHEMA,
            'x': x, 'domain': domain, 'y': y, 'recovery': [], 'accepted': True,
            'signal': 'observed', 'confidence': 1, 'acceptance': copy.deepcopy(review),
            'interpretationProvenance': evidence, 'sourceEvent': copy.deepcopy(event)}
