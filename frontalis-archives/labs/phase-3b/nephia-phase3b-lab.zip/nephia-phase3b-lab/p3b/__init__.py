"""Phase 3-B: portable learned personality state, independent of an LLM."""
