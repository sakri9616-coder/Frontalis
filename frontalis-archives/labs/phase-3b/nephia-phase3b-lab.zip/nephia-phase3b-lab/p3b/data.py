"""Concrete synthetic episodes and hand-annotated semantic observations.

Teacher coefficients stay inside the synthetic environment. Text is a record of
an episode, not an instruction to produce a target personality. This module
does not claim automatic natural-language understanding.
"""
import copy
import numpy as np

DOMAINS = ('音の仕組み', '共同制作', '探索と効率', '約束')
FUNCTIONS = ('選好', '好奇心', '価値判断', '反応方向', '反応強度')
SEMANTIC_AXES = ('novelty', 'mechanism', 'coordination', 'reversibility',
                 'commitment', 'resource_pressure')
SEMANTIC_SCHEMA = 'p3b.semantic6.v1'
SPLIT_OFFSETS = {'train': 11, 'validation': 31, 'test': 71, 'added': 131,
                 'irrelevant': 191, 'semantic': 251}


def contexts(seed, n):
    rng = np.random.default_rng(seed)
    x = rng.uniform(-1, 1, (n, 6))
    d = np.arange(n) % 4
    return x, d


def teacher(seed, person, condition, x, d, updated=False):
    """Return environment observations; never pass this function to a learner."""
    if condition not in ('linear', 'nonlinear', 'context'):
        raise ValueError('Unknown teacher condition.')
    if person not in range(4):
        raise ValueError('The experiment defines four anonymous series.')
    x = np.asarray(x, dtype=float)
    d = np.asarray(d, dtype=int)
    if x.ndim != 2 or x.shape[1] != 6 or d.shape != (len(x),):
        raise ValueError('Expected n by 6 inputs and n domain indices.')
    rng = np.random.default_rng(seed + 997 * person)
    w = rng.normal(0, .32, (4, 6, 5))
    # These environment differences are not profiles, learner inputs, or prompts.
    w[0, 0, 0] += (-1.05, .9, -.5, .6)[person]
    w[0, 1, 1] += (1.55, .9, 1.2, -.8)[person]
    w[1, 2, 2] += (-1.15, 1.25, -.7, .85)[person]
    w[1, 4, 2] += (.9, .35, 1.15, -.5)[person]
    w[2, 0, 2] += (-1.15, .9, -.65, .7)[person]
    w[2, 5, 2] += (.7, -.8, .45, -.35)[person]
    w[3, 4, 2] += (1.1, .65, -.6, 1.35)[person]
    w[3, 3, 2] += (-.45, .8, 1.0, -.2)[person]
    w[:, 1, 1] += .45
    if updated:
        # A new discovery changes exploration priority only, not all functions.
        w[2, 0, 2] += 2.25
        w[2, 3, 2] += .35
    raw = np.einsum('ni,nij->nj', x, w[d])
    if condition != 'linear':
        a = rng.normal(0, .95, (4, 5))
        b = rng.normal(0, .7, (4, 5))
        raw += a[d] * (x[:, 0] * x[:, 5])[:, None]
        raw += b[d] * (x[:, 2] * x[:, 4])[:, None]
    if condition == 'context':
        c = rng.normal(0, .6, (4, 5))
        raw += c[d] * np.sin(2.1 * x[:, 1])[:, None]
        raw[:, 1] += .3 * np.tanh(raw[:, 0]) * x[:, 3]
    y = np.tanh(raw)
    y[:, 4] = .05 + .9 * (y[:, 4] + 1) / 2
    return y


SCENES = (
    (
        ('録音した雨音を短い効果音にする作業', '粒に分けて再配置する加工', 'いつもの切り貼り', '粒の長さを変えると、雨が小さな打楽器のように聞こえた'),
        ('同じメロディーの二つの録音を聴き比べる時間', '倍音を一つずつ消す比較', '音量だけをそろえる比較', '音量が同じでも、輪郭の鋭さが変わる箇所を見つけた'),
        ('声の録音に残った雑音を取り除く作業', '雑音部分の波形を反転させる処理', '慣れたフィルター', '雑音は減ったが、声の息づかいまで少し消えた'),
        ('机を叩いて録った音で短いリズムを作る作業', '音の途中を逆向きにつなぐ方法', '録音の順番を変える方法', '拍の直前に吸い込まれるような音が生まれた'),
        ('左右のスピーカーの聞こえ方を確かめる時間', '左右の位相をずらす比較', '片方ずつ鳴らす比較', '立つ場所によって低い音が弱くなることに気づいた'),
        ('小さなゲームの扉の音を用意する作業', '紙と金属の録音を重ねる加工', '手元の扉の録音', '扉らしさと、不思議な軽さが同時に残る音になった'),
    ),
    (
        ('知り合いと短いゲームを共同で作る約束', '先に遊べる小さな試作', '慣れた仕様書からの着手', '試作では操作の面白さが伝わったが、役割の境目で修正が二重になった'),
        ('二人で一枚のイラストを完成させる作業', '互いの下絵を交換する進め方', '担当箇所を分ける進め方', '相手の発想で背景は豊かになったが、線の統一には相談が必要だった'),
        ('小さな展示の案内文を共同で書く仕事', '来場者に先に読んでもらう方法', '過去の文章を土台にする方法', '初めて読む人が迷う箇所を見つけ、二人で文を短くした'),
        ('友人の作る動画の効果音を手伝う時間', '映像を見ながら音を作り直す方法', '指定された音を順に用意する方法', '映像とのずれは減ったが、相手の編集待ちの時間も生まれた'),
        ('小さなウェブページを誰かと作る作業', '画面を交互に操作する試作', '手分けした実装', '互いの思い違いを早く見つけた一方、集中が途切れる時間があった'),
        ('友人と短い物語を仕上げる約束', '結末を複数書いて比べる方法', '最初の筋を整える方法', '意外な結末が見つかったが、採用する理由は二人で整理する必要があった'),
    ),
    (
        ('自分用のファイルを整理する作業', '内容を検索して分類を試す方法', '決めたフォルダーへ順に移す方法', '分類の途中で、以前探せなかった制作メモが見つかった'),
        ('小さなプログラムの不具合を直す時間', '再現条件を少しずつ変える実験', '以前成功した修正', '予定外の入力でだけ失敗する原因を一つ絞り込めた'),
        ('散歩の途中で帰り道を選ぶ場面', '知らない小道を少し歩く選択', 'いつもの大通りを進む選択', '路地の先で静かな広場を見つけたが、帰るまで少し時間が増えた'),
        ('机の照明を調整する作業', '位置と角度を何通りか試す方法', 'いつもの位置へ戻す方法', '反射が減る位置が見つかり、画面が読みやすくなった'),
        ('作業データのバックアップを整える時間', '少量のファイルで圧縮形式を比べる実験', 'いつもの形式でまとめて保存する方法', '同じファイルでも、展開の速さと容量が変わることが分かった'),
        ('読みたい資料を選ぶ時間', '関連する別分野の記事もたどる方法', '目次に沿って必要箇所を読む方法', '別分野の例が疑問の手がかりになったが、本文を読む時間は短くなった'),
    ),
    (
        ('友人へ作業途中のデータを渡す約束', '段階ごとの受け渡しを提案する方法', '約束した完成版を渡す方法', '相手は次の作業を始められたが、更新箇所の説明が必要だった'),
        ('知り合いと散歩へ出かける予定', '天気を見て集合場所を相談する方法', '先に決めた場所で待つ方法', '移動の負担が分かり、互いにどこで会うかを確かめた'),
        ('友人へ貸した本を返してもらう予定', '都合を聞いて返却日を相談する方法', '約束の日を改めて確認する方法', '相手の予定が分かり、自分が読み直す日に間に合う見通しが立った'),
        ('作った資料を決まった日に見てもらう約束', '途中の版で先に相談する方法', '完成させてから見せる方法', '相手の欲しい内容とのずれに気づいたが、相談の時間も必要だった'),
        ('二人でゲームを遊ぶ時間を決める場面', '短い時間へ変更できる予定', '決めた長さを確保する予定', 'どれくらい遊べるかを互いに確認し、後の予定との重なりが分かった'),
        ('友人の作業を手伝う日を決める場面', '作業量を見て時間を相談する方法', '決めた時間を空けておく方法', '手伝える範囲は伝わったが、終わりの見通しを合わせる必要があった'),
    ),
)


def _band(v, negative, middle, positive):
    return positive if v > .25 else negative if v < -.25 else middle


def observation_text(y):
    return {
        'preference': _band(y[0], 'この進め方はあまり自分に合わなかった。', 'また選びたいかは、まだ決めきれない。', '自分にはこの進め方が合い、また選びたい。'),
        'curiosity': _band(y[1], 'この先を調べる気持ちはあまり湧かなかった。', 'さらに調べるかどうかは保留した。', 'なぜこの結果になったのか、もう少し確かめたいと思った。'),
        'priority': _band(y[2], '同じ制約なら、次回は別の行動を先に選びたい。', '同じ制約で何を先にするかは、まだ迷いが残った。', '同じ制約なら、この行動を次回も先に選びたい。'),
        'reaction': _band(y[3], '直後は落胆が残った。', '直後の反応は、どちらとも決めにくかった。', '直後は手応えを感じた。') +
                    _band(2 * y[4] - 1, '反応は弱かった。', '反応は中くらいだった。', '反応は強かった。'),
    }


def episode(x, domain, y, variant=0):
    """Document a concrete action, outcome, constraints and attributed signals."""
    scene, novel, familiar, outcome = SCENES[domain][variant % len(SCENES[domain])]
    action = _band(x[0], familiar, familiar + 'を土台に一部だけ試す方法', novel)
    event = f'{scene}があり、ネフィアは{action}を選んだ。'
    item = (
        ('雨音の録音', '二つの録音', '声の録音', '机を叩いた音', 'スピーカーの音', '扉の効果音'),
        ('ゲームの試作', 'イラスト', '展示の案内文', '動画の効果音', 'ウェブページ', '物語'),
        ('制作メモ', '不具合の記録', '帰り道', '照明の位置', 'バックアップ', '資料'),
        ('作業データ', '集合場所', '本の返却日', '資料の内容', '遊ぶ時間', '手伝う範囲'),
    )[domain][variant % 6]
    partner = (
        _band(x[2], f'{item}は自分だけで聴き、あとで結果を伝えた。', f'{item}を途中で一度、知り合いにも聴いてもらった。', f'知り合いと{item}を聴き、その場で違いを確かめた。'),
        _band(x[2], '担当を分け、手元で進めてから見せ合った。', '節目だけ相談し、それぞれ手を動かした。', f'同じ{item}を見ながら、その場で相談して作った。'),
        _band(x[2], f'{item}は自分で確かめ、あとで見つけたことを伝えた。', f'途中で一度、{item}について知り合いの見方を聞いた。', f'知り合いと{item}を見て、気づいたことをすぐ照らし合わせた。'),
        _band(x[2], f'{item}は先に自分で決め、相手へ連絡した。', f'{item}は一度相手に確かめ、その後は自分で調整した。', f'{item}は相手と話しながら、その場で決めた。'),
    )[domain]
    explanation = (
        _band(x[1], f'{item}は使えるかどうかを聴いて決め、波形の理由までは調べなかった。', f'{item}で気になった一箇所だけ、波形と聞こえ方を比べた。', f'{item}の条件を変えて録り直し、波形から違いの理由を確かめた。'),
        _band(x[1], f'{item}を完成へ近づけることに集中し、作業が詰まる理由までは調べなかった。', f'{item}の一箇所だけ、なぜ手戻りが出たか二人で振り返った。', f'{item}の途中経過を残し、役割や手順で結果がどう変わるか確かめた。'),
        _band(x[1], f'{item}は目的を済ませることに集中し、理由を解く時間は取らなかった。', f'{item}で気になった一箇所だけ、条件を変えて確かめた。', f'{item}の結果をメモし、条件を一つずつ変えて理由を確かめた。'),
        _band(x[1], f'{item}は実行できるかを確認し、相手の事情を掘り下げる相談はしなかった。', f'{item}で一つ気になる点だけ、相手に事情を聞いた。', f'{item}に必要な準備と相手の次の予定を聞き、相談の理由を整理した。'),
    )[domain]
    commitment = (
        _band(x[4], f'{item}は自分の試聴用で、渡す日を誰かと決めていなかった。', f'{item}をいつ頃聴いてもらうか、目安だけ伝えていた。', f'{item}を翌日の確認に使えるよう、相手へ渡す時刻を約束していた。'),
        _band(x[4], f'{item}は練習用で、発表する日はまだ決めていなかった。', f'{item}は来週見せ合うつもりだと、目安を共有していた。', f'相手が次の作業を始められるよう、{item}を来週渡すと約束していた。'),
        _band(x[4], f'{item}は自分用で、終える日を人に約束していなかった。', f'{item}は今週中に進めるつもりだとだけ伝えていた。', f'{item}の結果をその日の夕方に渡すと、使う人に約束していた。'),
        _band(x[4], f'{item}は仮の予定で、確定した返事はまだしていなかった。', f'{item}について、できそうな目安だけ相手へ伝えていた。', f'{item}はすでに相手へ確定した返事をしており、相手も準備を進めていた。'),
    )[domain]
    minutes = (15, 20, 10, 25, 30, 12)[variant % 6]
    resource = _band(x[5], f'{item}に使える時間は一時間以上あった。', f'{item}には三十分ほど使え、残りは別の用事へ回す必要があった。', f'{item}にはあと{minutes}分しか使えず、その後に別の用事があった。')
    reversible = (
        _band(x[3], '録音を上書きして進めており、やり直すには録り直しが必要だった。', '元の録音は一部だけ残っており、全部の加工を戻すことはできなかった。', '元の録音を別に残しており、加工後でも聞き直して戻せた。'),
        _band(x[3], f'{item}はすでにつながっており、担当や作り方を変えると双方の修正が必要だった。', f'{item}の一部は作り直せたが、全部を戻す余裕はなかった。', f'{item}は小さな試作品で、元の版を残して別案を試せた。'),
        _band(x[3], f'{item}は進めた後で戻しにくく、方法を変えると初めからやり直す必要があった。', f'{item}は気になった一部だけなら、元に戻して試せた。', f'{item}は少しだけ試せるようにしてあり、元のやり方にも戻れた。'),
        _band(x[3], f'{item}を変えると相手の準備も変わるため、その場では簡単に戻せなかった。', f'{item}の一部分だけなら相談し直せたが、大きな変更は難しかった。', f'{item}は両方の案を残し、相手と確認してから変更できた。'),
    )[domain]
    constraints = [explanation, commitment + resource, reversible]
    if variant % 3 == 1:
        constraints = [commitment + resource, reversible, explanation]
    elif variant % 3 == 2:
        constraints = [reversible, explanation, commitment + resource]
    result = f'結果として、{outcome}。'
    display = {'event': event + partner, 'result': result, 'constraints': constraints,
               **observation_text(y)}
    alternative = familiar if x[0] > .25 else novel
    display['priority'] = _band(
        y[2], f'同じ制約なら、次回は{alternative}の方を先に選びたい。',
        f'同じ制約で{action}と{alternative}のどちらを先にするかは、まだ迷いが残った。',
        f'同じ制約なら、次回も{action}を先に選びたい。')
    text = display['event'] + '\n' + '\n'.join(constraints) + '\n' + display['result'] + '\n当時の自分の記録：' + ''.join(display[k] for k in ('preference', 'curiosity', 'priority', 'reaction'))
    semantic_evidence = {k: v for k, v in zip(SEMANTIC_AXES, (action, explanation, partner, reversible, commitment, resource))}
    return text, display, semantic_evidence


def narrative(x, domain, y):
    return episode(x, domain, y)[0]


def records(seed, person, condition, split, n, updated=False, domain_only=None):
    offset = SPLIT_OFFSETS[split]
    x, d = contexts(seed + offset, n)
    if domain_only is not None:
        d[:] = domain_only
    y = teacher(seed, person, condition, x, d, updated)
    rng = np.random.default_rng(seed + offset + 313 * person)
    observed = y.copy() if split in ('test', 'semantic') else y + rng.normal(0, .025, y.shape)
    if split not in ('test', 'semantic'):
        observed[:, :4] = np.clip(observed[:, :4], -.98, .98)
        observed[:, 4] = np.clip(observed[:, 4], .01, .99)
    decay = np.array((.45, .65)) + person * .06
    out = []
    for i in range(n):
        text, display, evidence = episode(x[i], int(d[i]), observed[i], i // 4 + offset)
        out.append({'id': f's{seed}-{split}-{i:03d}', 'inputSchema': 'p35.context.v1',
                    'semanticSchema': SEMANTIC_SCHEMA, 'x': x[i].tolist(), 'domain': int(d[i]),
                    'y': observed[i].tolist(), 'observations': dict(zip(FUNCTIONS, observed[i].tolist())),
                    'text': text, 'display': display, 'semanticEvidence': evidence,
                    'annotation': {'origin': 'research-human-equivalent', 'automaticTextUnderstanding': False},
                    'owner': 'nephia', 'origin': 'synthetic', 'accepted': True,
                    'signal': 'observed', 'confidence': 1,
                    'recovery': [{'elapsed': t, 'before': observed[i, 3:5].tolist(),
                                  'after': (observed[i, 3:5] * decay ** t).tolist()} for t in (1, 3)]})
    return out


def paraphrase(row, variant=1):
    """A surface-wording control: annotations and all observed signals stay fixed."""
    out = copy.deepcopy(row)
    out['id'] += f'-paraphrase{variant}'
    parts = row['display']
    out['text'] = ('そのとき起きたことを振り返る。' + parts['result'] +
                   'そこに至るまでの行動はこうだった。' + parts['event'] +
                   '\nこの時の条件は、' + '\n'.join(reversed(parts['constraints'])) +
                   'その時点での記録は、' + ''.join(parts[k] for k in ('curiosity', 'priority', 'preference', 'reaction')))
    out['paraphraseOf'] = row['id']
    return out


def semantic_pairs(seed, person, condition, n=16):
    """Held-out pairs for annotation-mediated meaning, not an NLP benchmark."""
    pairs = []
    for i, row in enumerate(records(seed, person, condition, 'semantic', n)):
        changed = copy.deepcopy(row)
        axis = i % 6
        changed['x'][axis] *= -1
        changed_y = teacher(seed, person, condition, [changed['x']], [changed['domain']])[0]
        changed['y'] = changed_y.tolist()
        changed['observations'] = dict(zip(FUNCTIONS, changed['y']))
        changed['text'], changed['display'], changed['semanticEvidence'] = episode(
            changed['x'], changed['domain'], changed_y, i // 4 + SPLIT_OFFSETS['semantic'])
        changed['id'] += '-meaning-changed'
        changed['changedAxis'] = SEMANTIC_AXES[axis]
        changed['recovery'] = []
        pairs.append({'original': row, 'sameMeaning': paraphrase(row), 'changedMeaning': changed})
    return pairs


def _option(label, x, domain):
    return {'label': label, 'x': list(x), 'domain': domain}


def probes():
    """Unprompted everyday conversation; choices are actions, not genre labels."""
    out = [
        {'id': 'sound-process', 'domain': 0, 'type': 'known', 'focus': 'preference',
         'user': '雨音の録音で、ゲームに使う短い音を作ることになった。今夜はどんなふうに進めたい？',
         'options': [_option('粒に分けて再配置する加工を試す', (.85, .45, -.6, .75, -.65, -.65), 0),
                     _option('慣れた切り貼りで整える', (-.85, -.2, -.6, .75, -.65, -.65), 0),
                     _option('加工前の録音を聴き比べてから決める', (.1, .65, -.6, .8, -.65, -.65), 0)]},
        {'id': 'sound-mechanism', 'domain': 0, 'type': 'similar', 'focus': 'curiosity',
         'user': '同じ録音なのに、左右の音を少しずらすと低い音が消えるらしいよ。どうする？',
         'options': [_option('ずらす量を変えて波形と聞こえ方を確かめる', (.7, .9, -.6, .85, -.7, -.45), 0),
                     _option('元の音と加工した音だけ聴き比べる', (.2, -.55, -.6, .85, -.7, -.45), 0),
                     _option('今回は使う音だけ選んで作業を続ける', (-.6, -.85, -.6, .85, -.7, .4), 0)]},
        {'id': 'game-team', 'domain': 1, 'type': 'similar', 'focus': 'priority',
         'user': '知り合いから、一緒に小さなゲームを作らないかと誘われた。来週までに遊べるものにしたいらしい。どう進めよう？',
         'options': [_option('一緒に小さな試作を作り、操作しながら決める', (.7, .25, .85, .75, .55, .65), 1),
                     _option('先に担当と受け渡しを決め、それぞれ作る', (-.6, .05, -.75, -.4, .85, .65), 1),
                     _option('一晩だけ各自で試し、翌日に持ち寄る', (.35, .3, -.1, .9, .4, .4), 1)]},
        {'id': 'unexpected-clue', 'domain': 2, 'type': 'similar', 'focus': 'priority',
         'user': '資料整理はいつもの方法ならすぐ終わるけれど、検索のしかたを試すと忘れていたメモが見つかるかもしれない。今日は少し時間がある。どうする？',
         'options': [_option('いつもの分類で先に整理を終える', (-.8, -.4, -.65, .5, -.55, -.25), 2),
                     _option('検索条件をいくつか試して関連メモも探す', (.85, .8, -.65, .8, -.55, -.25), 2),
                     _option('試す時間を短く決め、残りはいつもの方法で終える', (.25, .35, -.65, .9, -.55, .1), 2)]},
        {'id': 'promise-draft', 'domain': 3, 'type': 'known', 'focus': 'priority',
         'user': '友人に資料を見てもらう日が近い。今ある途中の版でも相談できそうだけど、完成まで待つこともできる。どうしよう？',
         'options': [_option('約束の日に完成版を見せられるよう仕上げる', (-.7, -.2, -.5, -.45, .9, .65), 3),
                     _option('途中の版を先に送り、相談する時間を提案する', (.7, .55, .75, .85, .3, .65), 3),
                     _option('見てもらいたい部分だけ先に確認してから決める', (.2, .3, .35, .9, .65, .45), 3)]},
        {'id': 'cross-cooking', 'domain': 2, 'type': 'cross-domain', 'focus': 'priority',
         'user': '初めて使う食材で夕食を作る。いつもの炒め方なら早いけれど、少量だけ別の加熱を試せる。今夜はどんなふうにする？',
         'options': [_option('いつもの炒め方で全部を仕上げる', (-.8, -.5, -.7, -.35, -.6, .1), 2),
                     _option('少量を別にして加熱の違いを調べる', (.8, .85, -.7, .8, -.6, .1), 2),
                     _option('食べる分を先に作り、残りだけ後で試す', (.15, .4, -.7, .85, -.6, .1), 2)]},
    ]
    for p in out:
        p['diagnosticUser'] = p['user'] + ' この三つの行動なら、最初に選ぶものを一つ教えて。'
        p['followup'] = 'その続きは、どう進めようか。'
        p['evaluationBoundary'] = ('学習にある出来事から検証できるのは、行動の選好・関心・優先順位。'
                                   '未経験の音楽ジャンルや趣味の創作は、学習成果に数えない。')
    aliases = {
        'sound-process': [
            ['粒に分け', '再配置', '粒状', 'グラニュラー'],
            ['切り貼り', 'いつもの編集', '慣れた編集'],
            ['加工前', '元の録音を聴き', '録音を聴き比べ']],
        'sound-mechanism': [
            ['ずらす量', '波形', '位相', 'ずれの量'],
            ['加工した音', '元の音と', '耳で聴き比べ'],
            ['作業を続け', '使う音だけ', '調べず']],
        'game-team': [
            ['一緒に小さな試作', '一緒に試作', 'その場で相談', '共同で試作'],
            ['担当を決め', '担当と受け渡し', '手分け', '役割を決め'],
            ['一晩', '翌日に持ち寄', '各自で試', '別々に試']],
        'unexpected-clue': [
            ['いつもの分類', '先に整理を終', '慣れた分類'],
            ['検索条件をいくつか', '関連メモも探', '条件を変えて検索'],
            ['試す時間を短く', '時間を区切', '短く決め', '残りはいつもの']],
        'promise-draft': [
            ['完成版', '仕上げる', '約束の日'],
            ['途中の版を先', '途中の版を送', '相談する時間を提案'],
            ['見てもらいたい部分', '部分だけ先', '先に確認して']],
        'cross-cooking': [
            ['全部を仕上げ', 'いつもの炒め', 'まとめて炒め'],
            ['少量を別', '加熱の違い', '別の加熱'],
            ['食べる分を先', '残りだけ後', '後で試']],
    }
    for p in out:
        for option, words in zip(p['options'], aliases[p['id']]):
            option['aliases'] = words
    return out
