"""Append-only generations preserve observations, short state, and rollback ancestry."""
import copy
import json
import os
from pathlib import Path
import numpy as np
from p3b.model import accepted, digest, predict


def validate(model):
    if (model.get('formatVersion') != 1 or model.get('inputSchema') != 'p35.context.v1'
            or model.get('semanticSchema') != 'p3b.semantic6.v1' or model.get('owner') != 'nephia'
            or model.get('intensityDecoder') != 'bounded-tanh-v1'):
        raise ValueError('State owner/schema mismatch.')
    accepted(model['experiences'])
    if digest(model['experiences']) != model['experienceHash'] or [e['id'] for e in model['experiences']] != model['experienceIds']:
        raise ValueError('State provenance mismatch.')
    if (np.asarray(model['shortState']).shape != (2,) or not np.isfinite(model['shortState']).all()
            or not -1 <= model['shortState'][0] <= 1 or not 0 <= model['shortState'][1] <= 1
            or not np.isfinite(model['time']) or model['time'] < 0
            or np.asarray(model['decay']).shape != (2,)
            or not np.all((np.array(model['decay']) > 0) & (np.array(model['decay']) < 1))):
        raise ValueError('Invalid reaction state.')
    if model['kind'] in ('linear', 'quadratic', 'adapted', 'frozen'):
        if model['kind'] in ('adapted', 'frozen'):
            shared = model['shared' if model['kind'] == 'adapted' else 'old']
            latent = shared.get('latentDim')
            # The immutable Phase 3-A snapshot predates the latentDim field.
            # Infer its dimension only for the explicitly frozen legacy copy.
            if latent is None and model['kind'] == 'frozen':
                latent = len(shared['weights']['2.bias'])
            if type(latent) is not int or latent < 1: raise ValueError('Invalid shared dimension.')
            for name, shape in [('0.weight', (32, 6)), ('0.bias', (32,)),
                                ('2.weight', (latent, 32)), ('2.bias', (latent,))]:
                value = np.asarray(shared['weights'][name])
                if value.shape != shape or not np.isfinite(value).all():
                    raise ValueError('Invalid shared parameters.')
        expected = (28 if model['kind'] == 'linear' else 112 if model['kind'] == 'quadratic' else
                    (len(model['shared' if model['kind'] == 'adapted' else 'old']['weights']['2.bias']) + 1) * 4)
        w = np.asarray(model['weights'])
        if w.shape != (expected, 5) or not np.isfinite(w).all():
            raise ValueError('Invalid personal parameters.')
    elif model['kind'] == 'memory':
        if type(model.get('k')) is not int or model['k'] < 1: raise ValueError('Invalid neighbor configuration.')
    else:
        raise ValueError('Unknown personality method.')
    if not np.isfinite(predict(model, [[0] * 6], [0])).all():
        raise ValueError('Nonfinite prediction.')


class Store:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.manifest = self.directory / 'generations.json'
        if not self.manifest.exists():
            self._write({'formatVersion': 1, 'head': None, 'generations': []})
        self._read()

    def _read(self):
        value = json.loads(self.manifest.read_text(encoding='utf8'))
        if value.get('formatVersion') != 1 or value.get('head') != (len(value['generations']) - 1 if value['generations'] else None):
            raise ValueError('Invalid generation manifest.')
        return value

    def _write(self, value):
        temp = self.manifest.with_suffix('.pending')
        with temp.open('w', encoding='utf8') as f:
            json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False); f.flush(); os.fsync(f.fileno())
        temp.replace(self.manifest)

    def commit(self, model, kind='learn', expected_head=None, rollback_target=None):
        validate(model); value = self._read()
        if expected_head != value['head']:
            raise ValueError('Stale generation.')
        snapshot = {'payload': copy.deepcopy(model), 'sha256': digest(model)}
        file = self.directory / (snapshot['sha256'] + '.json')
        if file.exists():
            existing = json.loads(file.read_text(encoding='utf8'))
            if existing != snapshot:
                raise ValueError('Immutable snapshot collision/corruption.')
        else:
            with file.open('x', encoding='utf8') as f:
                json.dump(snapshot, f, ensure_ascii=False, indent=2, allow_nan=False); f.flush(); os.fsync(f.fileno())
        generation = {'generation': len(value['generations']), 'parent': value['head'], 'kind': kind,
                      'snapshotHash': snapshot['sha256'], 'experienceHash': model['experienceHash'], 'rollbackTarget': rollback_target}
        value['generations'].append(generation); value['head'] = generation['generation']; self._write(value)
        return value['head']

    def load(self, generation=None):
        value = self._read(); g = value['head'] if generation is None else generation
        if type(g) is not int or not 0 <= g < len(value['generations']):
            raise ValueError('Unknown generation.')
        sha = value['generations'][g]['snapshotHash']
        if len(sha) != 64 or any(c not in '0123456789abcdef' for c in sha):
            raise ValueError('Invalid snapshot identity.')
        snapshot = json.loads((self.directory / (sha + '.json')).read_text(encoding='utf8'))
        if snapshot['sha256'] != sha or digest(snapshot['payload']) != sha:
            raise ValueError('Snapshot integrity failure.')
        validate(snapshot['payload']); return snapshot['payload']

    def rollback(self, target, expected_head):
        return self.commit(self.load(target), 'rollback', expected_head, target)

    def export(self):
        value = self._read()
        return {'formatVersion': 1, 'manifest': value, 'snapshots': [self.load(i) for i in range(len(value['generations']))]}

    def restore(self, bundle):
        if self._read()['head'] is not None or bundle.get('formatVersion') != 1:
            raise ValueError('Restore requires a new empty store.')
        manifest = bundle['manifest']; models = bundle['snapshots']
        expected_head = len(models) - 1 if models else None
        if manifest['formatVersion'] != 1 or manifest['head'] != expected_head or len(models) != len(manifest['generations']):
            raise ValueError('Export structure mismatch.')
        for i, (g, m) in enumerate(zip(manifest['generations'], models)):
            validate(m)
            if g['generation'] != i or g['parent'] != (i - 1 if i else None) or g['snapshotHash'] != digest(m) or g['experienceHash'] != m['experienceHash']:
                raise ValueError('Export ancestry/integrity mismatch.')
        for i, (g, m) in enumerate(zip(manifest['generations'], models)):
            self.commit(m, g['kind'], i - 1 if i else None, g['rollbackTarget'])

