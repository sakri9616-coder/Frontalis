"""The Phase 3-A internal-token check retained without a prior-lab dependency."""
import re


def internal_leakage(text):
    return re.findall(r'(?<![A-Za-z0-9_])(?:(?:train|added|irrelevant)-\d+|p\d-s\d|NPN|[abc])(?![A-Za-z0-9_])|[-+]?\d+\.\d+', text, re.I)
