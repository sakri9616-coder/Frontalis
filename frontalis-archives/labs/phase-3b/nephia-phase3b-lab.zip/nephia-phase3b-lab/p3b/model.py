"""CPU training and portable inference on accepted semantic observations.

The four signed heads keep Phase 3-A's tanh decoder. Reaction intensity is
trained in a separate bounded coordinate and always decoded into [0, 1].
"""
import copy
import hashlib
import json
import numpy as np

KINDS = ('linear', 'quadratic', 'memory', 'adapted', 'frozen')
SEMANTIC_SCHEMA = 'p3b.semantic6.v1'


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def arrays(rows):
    return (np.asarray([e['x'] for e in rows], dtype=float).reshape(-1, 6),
            np.asarray([e['domain'] for e in rows], dtype=int),
            np.asarray([e['y'] for e in rows], dtype=float).reshape(-1, 5))


def accepted(rows):
    ids = set()
    for e in rows:
        if (e.get('inputSchema') != 'p35.context.v1' or e.get('semanticSchema') != SEMANTIC_SCHEMA
                or e.get('owner') != 'nephia' or e.get('origin') not in ('synthetic', 'human', 'observation')
                or e.get('accepted') is not True or e.get('signal') != 'observed'
                or not isinstance(e.get('confidence'), (float, int)) or not np.isfinite(e['confidence'])
                or not .5 <= e['confidence'] <= 1):
            raise ValueError('Only accepted, attributed semantic observations can train a personality.')
        if not isinstance(e.get('id'), str) or not e['id'] or e['id'] in ids:
            raise ValueError('Duplicate/invalid experience identity.')
        ids.add(e['id'])
        x, y = np.asarray(e['x'], dtype=float), np.asarray(e['y'], dtype=float)
        if (x.shape != (6,) or y.shape != (5,) or type(e['domain']) is not int or not 0 <= e['domain'] < 4
                or not np.isfinite(x).all() or not np.isfinite(y).all()
                or np.any(np.abs(x) > 1) or np.any(np.abs(y[:4]) > 1) or not 0 <= y[4] <= 1):
            raise ValueError('Invalid observations or intensity outside [0, 1].')
        if 'observations' in e:
            names = ('選好', '好奇心', '価値判断', '反応方向', '反応強度')
            if any(e['observations'].get(name) != y[i] for i, name in enumerate(names)):
                raise ValueError('Named observations disagree with the learning target.')
        for obs in e.get('recovery', []):
            b, a = np.asarray(obs['before']), np.asarray(obs['after'])
            if (b.shape != (2,) or a.shape != (2,) or not np.isfinite(b).all()
                    or not np.isfinite(a).all() or not np.isfinite(obs['elapsed']) or obs['elapsed'] <= 0
                    or np.any(np.abs(b[:1]) > 1) or np.any(np.abs(a[:1]) > 1)
                    or not 0 <= b[1] <= 1 or not 0 <= a[1] <= 1):
                raise ValueError('Invalid recovery observation.')
    return rows


def shared_train(seed, latent_dim=8):
    """Representation-only pretraining; no person IDs, ratings or test inputs."""
    import torch
    from torch import nn
    torch.set_num_threads(2)
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed + 91000)
    raw = rng.uniform(-1, 1, (2048, 6)).astype('float32')
    pairs = [(i, j) for i in range(6) for j in range(i, 6)]
    target = np.column_stack([raw] + [raw[:, i] * raw[:, j] for i, j in pairs]).astype('float32')
    encoder = nn.Sequential(nn.Linear(6, 32), nn.Tanh(), nn.Linear(32, latent_dim))
    decoder = nn.Linear(latent_dim, target.shape[1])
    opt = torch.optim.Adam(list(encoder.parameters()) + list(decoder.parameters()), lr=.012)
    x, y = torch.tensor(raw[:1792]), torch.tensor(target[:1792])
    vx, vy = torch.tensor(raw[1792:]), torch.tensor(target[1792:])
    best, best_loss = None, float('inf')
    for step in range(450):
        opt.zero_grad(); loss = (decoder(encoder(x)) - y).square().mean(); loss.backward(); opt.step()
        if step % 25 == 0 or step == 449:
            with torch.no_grad(): validation = float((decoder(encoder(vx)) - vy).square().mean())
            if validation < best_loss: best_loss, best = validation, copy.deepcopy(encoder.state_dict())
    return {'formatVersion': 1, 'weights': {k: v.tolist() for k, v in best.items()},
            'parameters': sum(v.numel() for v in best.values()), 'latentDim': latent_dim,
            'semanticSchema': SEMANTIC_SCHEMA,
            'pretraining': {'seed': seed, 'trainInputs': 1792, 'validationInputs': 256,
                            'personLabelsUsed': False, 'reconstructionMSE': best_loss,
                            'targets': 'input coordinates plus all degree-two products'}}


def encoded(shared, x):
    w = shared['weights']
    return np.tanh(x @ np.asarray(w['0.weight']).T + w['0.bias']) @ np.asarray(w['2.weight']).T + w['2.bias']


def representation(kind, shared, x, d, old=None):
    if kind == 'linear': phi = x
    elif kind == 'quadratic': phi = np.column_stack([x] + [x[:, i] * x[:, j] for i in range(6) for j in range(i, 6)])
    elif kind in ('adapted', 'frozen'): phi = encoded(shared if kind == 'adapted' else old, x)
    else: raise ValueError('Unknown representation.')
    phi = np.column_stack([phi, np.ones(len(x))])
    return (phi[:, None, :] * np.eye(4)[d, :, None]).reshape(len(x), phi.shape[1] * 4)


def target_coordinates(y, bounded=True):
    target = np.array(y, copy=True)
    if bounded: target[:, 4] = 2 * target[:, 4] - 1
    return np.arctanh(np.clip(target, -.98, .98))


def decode(logits, bounded=True):
    result = np.tanh(logits)
    if bounded: result[:, 4] = (result[:, 4] + 1) / 2
    return result


def recovery(rows):
    values = [[], []]
    for e in rows:
        for obs in e.get('recovery', []):
            for j in range(2):
                b, a = obs['before'][j], obs['after'][j]
                if abs(b) > .02 and 0 < a / b < 1 and obs['elapsed'] > 0:
                    values[j].append(np.log(a / b) / obs['elapsed'])
    return [float(np.exp(np.mean(v))) if v else .5 for v in values]


def fit(rows, kind, shared=None, old=None, regularization=.03, coupling=0, k=7, bounded=True):
    if kind not in KINDS or regularization <= 0 or coupling < 0 or type(k) is not int or k < 1:
        raise ValueError('Invalid method or training configuration.')
    rows = accepted(rows); x, d, y = arrays(rows)
    if kind == 'memory': model = {'kind': kind, 'k': k, 'learnedParameters': 0}
    else:
        phi = representation(kind, shared, x, d, old)
        gram = phi.T @ phi + regularization * np.eye(phi.shape[1])
        rhs = phi.T @ target_coordinates(y, bounded)
        weights = np.linalg.solve(gram, rhs)
        if coupling:
            plus = np.linalg.solve(gram, rhs[:, 0] + rhs[:, 1]) / 2
            minus = np.linalg.solve(gram + 2 * coupling * np.eye(len(gram)), rhs[:, 0] - rhs[:, 1]) / 2
            weights[:, 0], weights[:, 1] = plus + minus, plus - minus
        model = {'kind': kind, 'weights': weights.tolist(), 'regularization': regularization,
                 'coupling': coupling, 'initialWeights': 'all-zero', 'learnedParameters': weights.size}
    return {**model, 'formatVersion': 1, 'inputSchema': 'p35.context.v1', 'semanticSchema': SEMANTIC_SCHEMA,
            'intensityDecoder': 'bounded-tanh-v1' if bounded else 'old-unbounded-tanh-diagnostic',
            'shared': copy.deepcopy(shared) if kind == 'adapted' else None,
            'old': copy.deepcopy(old) if kind == 'frozen' else None,
            'decay': recovery(rows), 'shortState': [0, 0], 'time': 0,
            'experienceIds': [e['id'] for e in rows], 'experienceHash': digest(rows),
            'experiences': copy.deepcopy(rows), 'owner': 'nephia'}


def predict(model, x, d):
    x, original_d = np.asarray(x, dtype=float), np.asarray(d)
    if (x.ndim != 2 or x.shape[1] != 6 or original_d.shape != (len(x),)
            or not np.isfinite(x).all() or np.any(np.abs(x) > 1)
            or not np.isfinite(original_d).all() or np.any(original_d != original_d.astype(int))
            or np.any((original_d < 0) | (original_d > 3))):
        raise ValueError('Invalid query input.')
    d = original_d.astype(int)
    bounded = model.get('intensityDecoder') == 'bounded-tanh-v1'
    if model['kind'] == 'memory':
        hx, hd, hy = arrays(model['experiences']); output = []
        for v, domain in zip(x, d):
            available = np.flatnonzero(hd == domain)
            nearest = available[np.argsort(np.sum((hx[available] - v)**2, axis=1), kind='stable')[:model['k']]]
            if not len(nearest): output.append([0, 0, 0, 0, .5 if bounded else 0]); continue
            dist = np.sum((hx[nearest] - v)**2, axis=1)
            output.append(np.average(hy[nearest], axis=0, weights=1 / (dist + .2)))
        return np.asarray(output).reshape(-1, 5)
    phi = representation(model['kind'], model['shared'], x, d, model['old'])
    return decode(phi @ np.asarray(model['weights']), bounded)


def select(train, validation, kind, shared=None, old=None, coupled=False):
    accepted(validation); vx, vd, vy = arrays(validation)
    if not len(validation): raise ValueError('Validation set is required.')
    if set(e['id'] for e in train) & set(e['id'] for e in validation):
        raise ValueError('Training and validation identities overlap.')
    configs = ([{'k': k} for k in (3, 7, 15)] if kind == 'memory' else
               [{'regularization': r, 'coupling': c} for r in (.003, .03, .3)
                for c in ((0, .03, .3) if coupled else (0,))])
    candidates = []
    for config in configs:
        model = fit(train, kind, shared, old, **config)
        candidates.append((float(np.mean((predict(model, vx, vd) - vy)**2)), config, model))
    loss, config, model = min(candidates, key=lambda v: v[0])
    model['validationSelection'] = {'mse': loss, 'config': config,
                                    'candidates': [{'mse': a, 'config': b} for a, b, _ in candidates]}
    return model


def transition(model, x=None, domain=None, elapsed=1):
    if not np.isfinite(elapsed) or elapsed < 0: raise ValueError('Invalid elapsed time.')
    m = copy.deepcopy(model); factor = np.array(m['decay']) ** elapsed
    short = np.array(m['shortState']) * factor
    if x is not None: short += (1 - factor) * predict(m, [x], [domain])[0, 3:5]
    m['shortState'] = short.tolist(); m['time'] += elapsed
    m.setdefault('transitions', []).append({'kind': 'event' if x is not None else 'elapse', 'x': x,
        'domain': domain, 'elapsed': elapsed, 'owner': model['owner'], 'longStateHash': digest(model.get('weights'))})
    return m


def refit(model, rows):
    new = fit(rows, model['kind'], model.get('shared'), model.get('old'), model.get('regularization', .03),
              model.get('coupling', 0), model.get('k', 7), model.get('intensityDecoder') == 'bounded-tanh-v1')
    new['shortState'], new['time'] = copy.deepcopy(model['shortState']), model['time']
    if 'transitions' in model: new['transitions'] = copy.deepcopy(model['transitions'])
    return new
