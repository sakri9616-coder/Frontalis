"""CPU inference timing; includes interpreter RSS, not whole PC usage."""
import json
import sys
import time
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from p3b.model import predict

file = ROOT / 'models/live-p0.json'
model = json.loads(file.read_text(encoding='utf8'))
x = [[.2, .7, -.5, .8, -.4, .3]] * 3
for _ in range(100):predict(model, x, [0]*3)
durations = []
for _ in range(2000):
    start = time.perf_counter_ns();predict(model, x, [0]*3);durations.append((time.perf_counter_ns()-start)/1e6)
rss = None
try:
    import psutil
    rss = psutil.Process().memory_info().rss
except ImportError:
    pass
value = {'batchOptions': 3, 'repeats': len(durations), 'medianMilliseconds': float(np.median(durations)),
         'p95Milliseconds': float(np.quantile(durations,.95)), 'stateBytes': file.stat().st_size,
         'processRSSBytes': rss, 'device': 'cpu',
         'scope': 'Warm inference including input validation. RSS includes Python/NumPy; not training peak or whole PC memory.'}
(ROOT/'reports/performance.json').write_text(json.dumps(value,indent=2),encoding='utf8')
print(json.dumps(value))
