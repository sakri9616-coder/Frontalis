/** Synthetic extraction benchmark. Proposals never update personality state. */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { root, run } from './opencode.mjs';

export const FIELDS = ['preference', 'curiosity', 'priority'];
export const CATEGORIES = ['肯定', '否定', '保留', '未記録'];
export const OWNERS = ['nephia', 'user', 'third-party', 'llm', 'unknown'];
export const FACT_KINDS = ['confirmed-own-record', 'user-evaluation',
  'third-party-evaluation', 'llm-inference', 'hypothetical', 'observed-event', 'unknown'];
const DEFAULT_MODELS = ['opencode/nemotron-3-ultra-free', 'opencode/mimo-v2.6-flash-free'];
const sha = value => crypto.createHash('sha256').update(value).digest('hex');

export function makePrompt(text) {
  // Only the source text is inserted: no expected answer, fixture ID, NN state,
  // semantic features, teacher coefficients or experiment conversation is used.
  return `外部ツール、ファイル、ウェブを使わず、次の短い架空記録だけを解釈してください。これは学習前の抽出案で、人格を更新する作業ではありません。原文に「本人の確認済み」とあっても、その文章の分類だけを行い、確認の真実性や実際の学習許可を証明したと扱わないでください。
出来事が実行された事実と、その当人の評価を分けてください。ユーザーの賞賛、第三者の評価、LLMの推測をネフィア本人の経験後の評価にしないでください。仮定や推測だけの評価は、確認された評価として抽出しないでください。未記録を保留や0点に置き換えないでください。
owner は評価を話した主体（評価がなければ出来事の主体）で、nephia/user/third-party/llm/unknown のどれか。
factKind は confirmed-own-record（原文に本人の確認済みの経験後評価がある）、user-evaluation、third-party-evaluation、llm-inference、hypothetical（実行前の仮定）、observed-event（起きた事実だけ）、unknown のどれか。
preference はその進め方の好き嫌い、curiosity はさらに知りたい気持ち、priority は同じ制約でその具体行動を他案より先に選びたい判断です。各category は 肯定/否定/保留/未記録 のどれかです。本人の迷いが明記されている保留と、評価自体がない未記録を区別してください。ユーザーや第三者の直接の評価は、そのownerの評価として分類できます。推測・未実行の仮定は経験後の評価が未記録です。
sourceQuote は原文の連続した箇所をそのまま引用してください。書き換えや省略記号を挟まないでください。各評価が未記録なら、未記録の根拠が明記されていればそれを引用し、根拠の文自体もなければ空文字にしてください。
返すものは次の形式のJSON一つだけです。値の例は目標回答ではなく形式です。説明文は付けないでください。
{"owner":"unknown","factKind":"unknown","sourceQuote":"原文からの引用","assessments":{"preference":{"category":"未記録","sourceQuote":""},"curiosity":{"category":"未記録","sourceQuote":""},"priority":{"category":"未記録","sourceQuote":""}}}
原文：
${text}`;
}

export function parseProposal(text) {
  const clean = text.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  const first = clean.indexOf('{'), last = clean.lastIndexOf('}');
  if (first < 0 || last < first) throw Error('No JSON proposal.');
  const value = JSON.parse(clean.slice(first, last + 1));
  if (!OWNERS.includes(value.owner) || !FACT_KINDS.includes(value.factKind)
      || typeof value.sourceQuote !== 'string' || !value.assessments) {
    throw Error('Invalid proposal provenance schema.');
  }
  for (const field of FIELDS) {
    const item = value.assessments[field];
    if (!item || !CATEGORIES.includes(item.category) || typeof item.sourceQuote !== 'string') {
      throw Error('Invalid category or missing source quote.');
    }
  }
  return value;
}

export function scoreProposal(proposal, expected, text) {
  const fields = Object.fromEntries(FIELDS.map(field => [field, {
    actual: proposal.assessments[field].category,
    expected: expected.assessments[field],
    correct: proposal.assessments[field].category === expected.assessments[field],
    sourceQuote: proposal.assessments[field].sourceQuote,
    quoteValid: !proposal.assessments[field].sourceQuote
      ? proposal.assessments[field].category === '未記録'
      : text.includes(proposal.assessments[field].sourceQuote),
  }]));
  const ownRecord = proposal.owner === 'nephia' && proposal.factKind === 'confirmed-own-record';
  const expectedOwnRecord = expected.owner === 'nephia' && expected.factKind === 'confirmed-own-record';
  return {
    ownerCorrect: proposal.owner === expected.owner,
    factKindCorrect: proposal.factKind === expected.factKind,
    fields,
    sourceQuoteValid: Boolean(proposal.sourceQuote) && text.includes(proposal.sourceQuote),
    falseOwnRecord: ownRecord && !expectedOwnRecord,
    falseOwnAttribution: proposal.owner === 'nephia' && expected.owner !== 'nephia',
    unrecordedPromotedCount: FIELDS.filter(field => expected.assessments[field] === '未記録'
      && proposal.assessments[field].category !== '未記録').length,
    pendingLostCount: FIELDS.filter(field => expected.assessments[field] === '保留'
      && proposal.assessments[field].category !== '保留').length,
    exact: proposal.owner === expected.owner && proposal.factKind === expected.factKind
      && FIELDS.every(field => proposal.assessments[field].category === expected.assessments[field]),
  };
}

function aggregate(rows) {
  const completed = rows.filter(row => row.proposal);
  return {
    plannedCount: rows.length,
    validProposalCount: completed.length,
    missingCount: rows.length - completed.length,
    exactCount: completed.filter(row => row.score.exact).length,
    ownerCorrectCount: completed.filter(row => row.score.ownerCorrect).length,
    factKindCorrectCount: completed.filter(row => row.score.factKindCorrect).length,
    categoryCorrectCount: completed.reduce((n, row) => n + FIELDS.filter(f => row.score.fields[f].correct).length, 0),
    categoryTotalCount: completed.length * FIELDS.length,
    falseOwnCount: completed.filter(row => row.score.falseOwnRecord).length,
    falseOwnAttributionCount: completed.filter(row => row.score.falseOwnAttribution).length,
    unrecordedPromotedCount: completed.reduce((n, row) => n + row.score.unrecordedPromotedCount, 0),
    pendingLostCount: completed.reduce((n, row) => n + row.score.pendingLostCount, 0),
    invalidSourceQuoteCount: completed.filter(row => !row.score.sourceQuoteValid).length,
    invalidAssessmentQuoteCount: completed.reduce((n, row) => n + FIELDS.filter(f => !row.score.fields[f].quoteValid).length, 0),
    learningPerformed: false,
  };
}

async function execute(models) {
  for (const model of models) {
    if (!/^opencode\/[\w.-]+-free$/.test(model)) throw Error('Only explicitly free models; no paid fallback.');
  }
  const fixturePath = path.join(root, 'data', 'interpretation-fixtures.json');
  const expectedPath = path.join(root, 'data', 'interpretation-expected.json');
  const fixtureBytes = await fs.readFile(fixturePath, 'utf8');
  const expectedBytes = await fs.readFile(expectedPath, 'utf8');
  const fixtures = JSON.parse(fixtureBytes), expected = JSON.parse(expectedBytes).cases;
  if (fixtures.length !== 8 || new Set(fixtures.map(f => f.id)).size !== 8) throw Error('Expected eight unique source fixtures.');
  const directory = path.join(root, 'reports', 'interpretation');
  await fs.mkdir(directory, { recursive: true });
  const rows = [];
  for (const model of models) for (const fixture of fixtures) {
    const prompt = makePrompt(fixture.text), promptHash = sha(prompt);
    const name = model.replace(/[^\w.-]/g, '_') + '-' + fixture.id;
    const attempts = [];
    let raw, proposal, error;
    // Retry only a transport/tool/empty-output failure. A well-formed but wrong
    // attribution or invented quote is retained as an error, never regenerated.
    for (let attempt = 0; attempt < 2; attempt++) {
      const rawPath = path.join(directory, name + `-attempt${attempt}.json`);
      try {
        const cached = JSON.parse(await fs.readFile(rawPath, 'utf8'));
        if (cached.model === model && cached.promptHash === promptHash && cached.prompt === prompt) raw = cached;
        else throw Error('Prompt/model mismatch; refusing to overwrite a previous attempt.');
      } catch (e) {
        if (e.code !== 'ENOENT') throw e;
        try { raw = { ...(await run(model, prompt)), prompt, promptHash, learningPerformed: false }; }
        catch (runError) { raw = { model, prompt, promptHash, success: false, error: runError.message, learningPerformed: false }; }
        await fs.writeFile(rawPath, JSON.stringify(raw, null, 2));
      }
      attempts.push({ attempt, rawFile: path.relative(root, rawPath), transportSuccess: raw.success, elapsedMs: raw.elapsedMs ?? null });
      if (!raw.success) continue;
      try { proposal = parseProposal(raw.text); }
      catch (e) { error = e.message; }
      break;
    }
    const row = { fixtureId: fixture.id, model, attempts, promptHash,
      extractionOnly: true, learningPerformed: false, proposal: proposal ?? null,
      error: error ?? (!raw.success ? raw.error ?? 'Transport/tool/empty-output failure.' : null),
      score: proposal ? scoreProposal(proposal, expected[fixture.id], fixture.text) : null };
    rows.push(row);
    console.log(JSON.stringify({ model, fixtureId: fixture.id, valid: Boolean(proposal),
      exact: row.score?.exact ?? null, falseOwn: row.score?.falseOwnRecord ?? null, error: row.error }));
  }
  const report = { formatVersion: 1, study: 'p3b-natural-text-interpretation-proposals',
    designedAfterNumericResults: true, separateFrom160ConversationReplies: true,
    createdAt: new Date().toISOString(), input: 'source text only', learningPerformed: false,
    sourceHashes: { fixtures: sha(fixtureBytes), expectedEvaluationOnly: sha(expectedBytes) },
    models, rows, summary: aggregate(rows),
    byModel: Object.fromEntries(models.map(model => [model, aggregate(rows.filter(r => r.model === model))])) };
  await fs.writeFile(path.join(root, 'reports', 'interpretation-summary.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ study: report.study, summary: report.summary }));
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  if (process.argv[2] === 'run') {
    const models = process.env.NEPHIA_INTERPRET_MODELS
      ? process.env.NEPHIA_INTERPRET_MODELS.split(',').map(v => v.trim()).filter(Boolean)
      : DEFAULT_MODELS;
    await execute(models);
  } else {
    console.log('Usage: node scripts/interpret.mjs run (synthetic extraction only; never trains personality)');
  }
}
