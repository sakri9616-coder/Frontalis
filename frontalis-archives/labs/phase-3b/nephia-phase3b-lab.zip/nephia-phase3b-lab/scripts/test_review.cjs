const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

(async () => {
  const modulePath = path.join(__dirname, 'review.mjs');
  const review = await import(require('node:url').pathToFileURL(modulePath));
  let passed = 0;
  const check = (name, test) => { test(); passed++; process.stdout.write('PASS ' + name + '\n'); };
  const history = [
    { id: 'E001', text: '共同制作で音を試した。相手の提案で響きが変わった。', event: '共同制作で音を試した。', outcome: '相手の提案で響きが変わった。', preference: '重なった音が気に入った。', curiosity: '響きが変わる理由を知りたい。', value: '相手と確かめることを優先した。', preferenceDirection: 'positive', curiosityDirection: 'positive', valueDirection: 'positive' },
    { id: 'E002', text: '期限を決めずに作った。完成せず疲れた。', event: '期限を決めずに作った。', outcome: '完成せず疲れた。', preference: 'この進め方は避けたい。', curiosity: '理由はまだわからない。', value: '判断は保留した。', preferenceDirection: 'negative', curiosityDirection: 'undecided', valueDirection: 'undecided' },
    { id: 'E003', text: '一人で音を加工した。狙った効果が出た。', event: '一人で音を加工した。', outcome: '狙った効果が出た。', preference: '重なった音が気に入った。', curiosity: '響きが変わる理由を知りたい。', value: '相手と確かめることを優先した。', preferenceDirection: 'positive', curiosityDirection: 'positive', valueDirection: 'positive', prediction: 'FORBIDDEN_PREDICTION' },
    { id: 'E004', text: '違う方法を試した。好みではない音になった。', preference: 'この進め方は避けたい。', curiosity: '響きが変わる理由を知りたい。', value: '判断は保留した。', preferenceDirection: 'negative', curiosityDirection: 'positive', valueDirection: 'undecided' },
  ];
  const record = { blindId: 'B001', groupId: '01', groupTitle: '同じ場面への反応', question: '経験と発言のつながり、会話としての自然さを比較します。', history, user: '新しい音の作り方を聞いたよ。', reply: 'どうやって響きを変えるのか聞いてみたい。', model: 'FORBIDDEN_MODEL', mode: 'FORBIDDEN_METHOD', learnedState: { goal: 'FORBIDDEN_STATE' }, target: 'FORBIDDEN_TARGET', kind: 'FORBIDDEN_KIND' };
  const input = { formatVersion: 1, records: [record, { ...record, blindId: 'B002', reply: '少し聞いてみようかな。' }] };

  check('permitted source fields only', () => {
    const clean = review.sanitizeHistory(history);
    assert.equal(clean[2].prediction, undefined);
    assert.deepEqual(clean[0], history[0]);
    assert.equal(review.sanitizeHistory([{ id: 'x', text: '原文', preference: -0.6 }])[0].preference, undefined);
  });
  check('representatives are fixed positions', () => {
    assert.deepEqual(review.representativeIndices(0), []);
    assert.deepEqual(review.representativeIndices(1), [0]);
    assert.deepEqual(review.representativeIndices(2), [0, 1]);
    assert.deepEqual(review.representativeIndices(4), [0, 1, 3]);
    assert.deepEqual(review.representativeIndices(12), [0, 5, 11]);
  });
  check('source observations remain independent', () => {
    const summaries = review.summarizeHistory(review.sanitizeHistory(history));
    assert.deepEqual(summaries[0].counts, { positive: 2, negative: 2, undecided: 0, unrecorded: 0 });
    assert.deepEqual(summaries[1].counts, { positive: 3, negative: 0, undecided: 1, unrecorded: 0 });
    assert.deepEqual(summaries[2].counts, { positive: 2, negative: 0, undecided: 2, unrecorded: 0 });
    assert.equal(summaries[1].observations[0].text, '響きが変わる理由を知りたい。');
    assert.deepEqual(summaries[1].observations[0].ids, ['E001', 'E003', 'E004']);
  });
  check('summary is independent of answers', () => {
    const first = review.prepareDisplay(input);
    const changed = review.prepareDisplay({ formatVersion: 1, records: input.records.map(row => ({ ...row, reply: 'まったく別の回答。', target: '別目標' })) });
    assert.deepEqual(first.histories, changed.histories);
  });
  check('identical histories are shared', () => {
    const clean = review.prepareDisplay(input);
    assert.equal(clean.histories.length, 1);
    assert.equal(clean.groups.length, 1);
    assert.equal(clean.groups[0].records.length, 2);
    assert.equal(clean.groups[0].records[0].historyId, clean.groups[0].records[1].historyId);
    assert.deepEqual(clean.histories[0].experiences.map(row => row.text), history.map(row => row.text));
  });
  check('different source histories are separate', () => {
    const altered = history.map((row, index) => index === 0 ? { ...row, text: row.text + '追記。' } : row);
    assert.equal(review.prepareDisplay({ formatVersion: 1, records: [record, { ...record, blindId: 'B002', history: altered }] }).histories.length, 2);
  });
  check('blind metadata cannot enter HTML', () => {
    const html = review.buildReview(input);
    for (const secret of ['FORBIDDEN_MODEL', 'FORBIDDEN_METHOD', 'FORBIDDEN_STATE', 'FORBIDDEN_TARGET', 'FORBIDDEN_KIND', 'FORBIDDEN_PREDICTION']) assert.equal(html.includes(secret), false);
    assert.equal(html.includes('響きが変わる理由を知りたい。'), true);
    assert.equal(html.includes('どうやって響きを変えるのか聞いてみたい。'), true);
  });
  check('script payload is escaped and compiled', () => {
    const html = review.buildReview({ formatVersion: 1, records: [{ ...record, reply: '</script><script>alert(1)</script>' }] });
    assert.equal(html.includes('</script><script>alert(1)</script>'), false);
    const code = html.match(/<script>([\s\S]*?)<\/script>/)[1];
    new Function(code);
  });
  check('empty history is supported', () => {
    const clean = review.prepareDisplay({ formatVersion: 1, records: [{ ...record, history: [] }] });
    assert.deepEqual(clean.histories[0].experiences, []);
    assert.deepEqual(clean.histories[0].representatives, []);
  });
  check('invalid or duplicate cards are rejected', () => {
    assert.throws(() => review.prepareDisplay({ formatVersion: 1, records: [record, record] }));
    assert.throws(() => review.prepareDisplay({ formatVersion: 1, records: [{ ...record, blindId: 'unknown' }] }));
    assert.throws(() => review.prepareDisplay({ formatVersion: 1, records: [{ ...record, history: [{ id: 'E1' }] }] }));
    assert.throws(() => review.prepareDisplay({ formatVersion: 1, records: [record, { ...record, blindId: 'B002', question: '違う説明' }] }));
  });
  const ratings = { B001: { '経験との整合性': '4', '会話としての品質': '3', memo: '試験用メモ。正式な人間評価ではありません。' }, B002: { '経験との整合性': '未採点' } };
  check('score save and resume round trip', () => {
    const saved = review.scoreFile(ratings, '2026-10-14T00:00:00.000Z');
    const loaded = review.normalizeScores(JSON.parse(JSON.stringify(saved)), ['B001', 'B002'], review.SCORE_NAMES, review.SELECTION_ID);
    assert.deepEqual(loaded, ratings);
    assert.equal(saved.formatVersion, 1);
    assert.equal(saved.selectionId, 'phase3b-review-v1');
  });
  check('unrelated old evaluations cannot mix in', () => {
    assert.throws(() => review.normalizeScores({ formatVersion: 1, selectionId: 'phase35-diagnostic20-20261014', scores: { V009: {} } }, ['B001'], review.SCORE_NAMES, review.SELECTION_ID));
    assert.throws(() => review.normalizeScores({ formatVersion: 2, selectionId: review.SELECTION_ID, scores: ratings }, ['B001'], review.SCORE_NAMES, review.SELECTION_ID));
    assert.throws(() => review.normalizeScores({ formatVersion: 1, selectionId: review.SELECTION_ID, scores: [] }, ['B001'], review.SCORE_NAMES, review.SELECTION_ID));
  });
  check('unknown score values are ignored safely', () => {
    const scores = review.normalizeScores({ formatVersion: 1, selectionId: review.SELECTION_ID, scores: { B001: { '経験との整合性': '99', '会話としての品質': '5', memo: 1, secret: 'ignored' }, B999: ratings.B001 } }, ['B001'], review.SCORE_NAMES, review.SELECTION_ID);
    assert.deepEqual(scores, { B001: { '会話としての品質': '5' } });
  });
  check('all raw source narratives are retained', () => {
    const clean = review.prepareDisplay(input);
    assert.equal(clean.histories[0].experiences.length, history.length);
    history.forEach((row, index) => assert.equal(clean.histories[0].experiences[index].text, row.text));
  });

  const runtime = path.join(__dirname, '..', 'runtime', 'review-ui-tests');
  fs.mkdirSync(runtime, { recursive: true });
  fs.writeFileSync(path.join(runtime, 'fixture.html'), review.buildReview(input), 'utf8');
  fs.writeFileSync(path.join(runtime, 'ratings-fixture.json'), JSON.stringify(review.scoreFile(ratings), null, 2), 'utf8');
  fs.writeFileSync(path.join(runtime, 'ratings-empty.json'), JSON.stringify(review.scoreFile({}), null, 2), 'utf8');
  process.stdout.write(`${passed} tests passed. UI fixture is in runtime/review-ui-tests; it contains synthetic test responses only.\n`);
})().catch(error => { process.stderr.write(error.stack + '\n'); process.exitCode = 1; });
