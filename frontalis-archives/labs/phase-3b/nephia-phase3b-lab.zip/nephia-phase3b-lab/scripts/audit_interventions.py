"""Add truth-error diagnostics to already recorded interventions without fitting."""
import json
import sys
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from p3b.model import predict, refit
from p3b.data import records

path = ROOT / 'reports/numeric.json'
report = json.loads(path.read_text(encoding='utf8'))
for row in report['interventions']:
    person, method, name = row['person'], row['method'], row['intervention']
    test = records(3601, person, 'context', 'test', 96)
    x, d, y = np.array([e['x'] for e in test]), np.array([e['domain'] for e in test]), np.array([e['y'] for e in test])
    before_model = json.loads((ROOT / f'models/3601-context-p{person}-{method}.json').read_text(encoding='utf8'))
    if method == 'NPN_adapted8':
        after_model = json.loads((ROOT / f'models/interventions/p{person}-{name}.json').read_text(encoding='utf8'))
    else:
        # Every method shares the same intervention experience data.
        source = json.loads((ROOT / f'models/interventions/p{person}-{name}.json').read_text(encoding='utf8'))
        after_model = refit(before_model, source['experiences'])
    before, after = predict(before_model, x, d), predict(after_model, x, d)
    row['domainFunctionMSEBefore'] = {str(i): np.mean((before[d == i] - y[d == i])**2, axis=0).tolist() for i in range(4)}
    row['domainFunctionMSEAfterOriginalTeacher'] = {str(i): np.mean((after[d == i] - y[d == i])**2, axis=0).tolist() for i in range(4)}
path.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8')
print(json.dumps({'auditedInterventions': len(report['interventions'])}))
