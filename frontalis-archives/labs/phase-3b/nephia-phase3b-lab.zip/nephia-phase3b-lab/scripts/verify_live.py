"""Offline final audit. The exact-cache mode prohibits any new OpenCode call."""
import json
import os
import re
import subprocess
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from p3b.model import digest, predict
from p3b.store import validate

ENGINES = ('opencode/nemotron-3-ultra-free', 'opencode/mimo-v2.6-flash-free')
env = dict(os.environ, NEPHIA_VERIFY_CACHE_ONLY='1')
env.pop('NEPHIA_LIVE_PLAN', None)
cache_checks = []
for plan in ('main', 'matched'):
    if plan == 'matched':
        env['NEPHIA_LIVE_PLAN'] = 'matched'
    for engine in ENGINES:
        run = subprocess.run(['D:/node.exe', str(ROOT / 'experiments/live.mjs'), engine],
                             cwd=ROOT, env=env, capture_output=True, text=True,
                             encoding='utf8', timeout=45)
        assert run.returncode == 0, run.stderr
        cache_checks.append({'plan': plan, 'engine': engine, 'exitCode': 0,
                             'externalCallsDisabled': True})

models = {}
for name in ('live-p0', 'live-p1', 'live-p2', 'live-p3', 'initial-common', 'live-p0-added'):
    model = json.loads((ROOT / f'models/{name}.json').read_text(encoding='utf8'))
    validate(model)
    models[digest(model)] = model

inputs, targets = {}, {}
for prefix in ('live', 'matched'):
    source = json.loads((ROOT / f'reports/{prefix}-inputs.json').read_text(encoding='utf8'))
    inputs.update({(mode, case['id']): case for mode, cases in source.items() for case in cases})
    target = json.loads((ROOT / f'reports/{prefix}-targets-evaluation-only.json').read_text(encoding='utf8'))
    targets.update({(t['mode'], t['id']): t for t in target})

axes = ('novelty', 'mechanism', 'coordination', 'reversibility', 'commitment', 'resource_pressure')
state_checks = 0
for key, target in targets.items():
    case = inputs[key]
    model = models[target['stateHash']]
    xs = [[o['semanticFeatures'][a] for a in axes] for o in case['options']]
    output = predict(model, xs, [target['domain']] * len(xs))
    np.testing.assert_array_equal(output, target['npnScores'])
    if 'externalState' in case:
        readouts = [list(o['readout'].values()) for o in case['externalState']['options']]
        np.testing.assert_array_equal(readouts, output[:, :3])
        assert case['externalState']['availableObservations'] == len(model['experiences'])
    for e in case['experiences']:
        assert e['text'] == next(t['text'] for t in target['auditHistory'] if t['id'] == e['id'])
    state_checks += 1

valid = {}
invalid, tools, language = [], [], []
raw_count, free_guard = 0, True
for folder in ('live', 'live-matched'):
    for file in sorted((ROOT / 'reports' / folder).glob('*/*-results.json')):
        result = json.loads(file.read_text(encoding='utf8'))
        engine, mode = result['engine'], result['mode']
        assert engine in ENGINES
        if not result['valid']:
            invalid.append({'file': str(file.relative_to(ROOT)), 'error': result['error']})
            continue
        for row in result['records']:
            key = (engine, mode, row['id'])
            assert key not in valid
            assert (mode, row['id']) in inputs
            valid[key] = row
            mixed = re.findall(r'[\uac00-\ud7af]+', row['reply'])
            if mixed:
                language.append({'engine': engine, 'mode': mode, 'id': row['id'],
                                 'hangulFragments': mixed})
    for file in sorted((ROOT / 'reports' / folder).glob('*/*-raw.json')):
        raw = json.loads(file.read_text(encoding='utf8'))
        raw_count += 1
        free_guard &= raw.get('model') in ENGINES
        for line in raw.get('stdout', '').splitlines():
            try:
                event = json.loads(line)
            except ValueError:
                continue
            if event.get('type') != 'tool_use':
                continue
            part = event['part']
            state = part.get('state', {})
            meta = state.get('metadata', {})
            code = state.get('input', {}).get('code', '')
            tools.append({'file': str(file.relative_to(ROOT)), 'tool': part.get('tool'),
                          'status': state.get('status'),
                          'nestedToolCalls': meta.get('metadata', {}).get('toolCalls'),
                          'providerCallExecuted': meta.get('providerCall', {}).get('executed'),
                          'codeHasOnlyResultSerialization': bool(code and code.startswith('const result = {')
                                                                  and code.endswith('return JSON.stringify(result);')),
                          'excludedFromValidReplies': not raw.get('success', False)})

assert len(valid) == 200 and len(invalid) == 9 and free_guard
assert Counter(k[0] for k in valid) == Counter({e: 100 for e in ENGINES})
assert all(t['excludedFromValidReplies'] for t in tools)
assert {t['tool'] for t in tools} == {'question', 'execute'}
report = {
    'formatVersion': 1, 'checkedAt': datetime.now(timezone.utc).isoformat(),
    'cacheChecks': cache_checks, 'validReplies': 200,
    'mainReplies': sum(k[1] in ('A','B','C','D','L','Q','F','S','T') for k in valid),
    'matchedReplies': sum(k[1] in ('SX','LX','TI','TA','R') for k in valid),
    'duplicateValidCases': 0, 'invalidAttempts': invalid, 'rawAttempts': raw_count,
    'numericReadoutAndSourceChecks': state_checks, 'allUsedModelIdsExplicitlyFree': free_guard,
    'toolEvents': tools,
    'toolAuditScope': 'Captured tool events: one cancelled question, one completed execute that serializes an in-memory result; nested toolCalls empty. Both rejected. No file/shell/network tool event is recorded. This is not an OS sandbox guarantee.',
    'posthocLanguageScan': {'designedAfterResults': True, 'hangulOccurrences': language,
                           'changesPredeclaredScores': False},
    'formalHumanRatings': 0,
    'note': 'Verification only; no model fitting, external LLM calls, source experience changes or old lab writes.'
}
(ROOT / 'reports/live-verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
print(json.dumps({'valid':len(valid),'invalid':len(invalid),'stateChecks':state_checks,
                  'toolEvents':len(tools),'hangulReplies':len(language),'cacheChecks':4}))
