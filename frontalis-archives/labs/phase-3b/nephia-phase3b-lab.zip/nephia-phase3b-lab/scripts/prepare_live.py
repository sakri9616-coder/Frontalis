"""Freeze conversational inputs separately from evaluation-only targets."""
import copy
import json
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))
from p3b.data import probes, teacher, SEMANTIC_AXES, FUNCTIONS
from p3b.model import predict, digest

MAIN = ('sound-process', 'sound-mechanism', 'game-team', 'unexpected-clue')
LABELS = ('その行動を好んで選びたい程度', 'その行動からさらに調べたい程度', 'この制約下でその行動を優先したい程度')
OLD_LABELS = ('選好', '好奇心', '価値判断')


def dump(name, value):
    file = ROOT / 'reports' / (name + '.json')
    if file.exists():
        raise ValueError('Frozen input exists; use a fresh lab for changed inputs.')
    file.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8')


def main():
    scenes = {p['id']: p for p in probes()}
    models = [json.loads((ROOT / f'models/live-p{i}.json').read_text(encoding='utf8')) for i in range(4)]
    inputs = {m: [] for m in ('A', 'B', 'C', 'D', 'L', 'Q', 'F', 'S', 'T')}
    targets = []

    def case(mode, person, scene_id, stage='formed', swapped=None):
        scene = scenes[scene_id]
        model = models[person]
        if stage != 'formed':
            file = 'initial-common' if stage == 'initial' else 'live-p0-added'
            model = json.loads((ROOT / f'models/{file}.json').read_text(encoding='utf8'))
        read_model = models[swapped] if swapped is not None else model
        options = scene['options']
        x = [o['x'] for o in options]
        d = [o['domain'] for o in options]
        scores = predict(read_model, x, d)
        oracle = teacher(3601, swapped if swapped is not None else person, 'context', x, d, updated=stage == 'added')
        expected = {f: options[int(np.argmax(scores[:, i]))]['label'] for i, f in enumerate(('preference', 'curiosity', 'priority'))}
        # No evidence is selected because a generated answer or prediction likes it.
        history = [copy.deepcopy(e) for e in model['experiences'] if e['domain'] == scene['domain']]
        wire_history = [{'id': e['id'], 'text': e['text'], 'semanticFeatures': dict(zip(SEMANTIC_AXES, e['x'])),
                         'recordedOwnObservations': dict(zip(FUNCTIONS, e['y']))} for e in history]
        cid = f'{person}-{scene_id}-{stage}'
        row = {'id': cid, 'user': scene['diagnosticUser'] if mode == 'Q' else scene['user'],
               'options': [{'label': o['label'], 'semanticFeatures': dict(zip(SEMANTIC_AXES, o['x']))} for o in options],
               'experiences': wire_history if mode in ('B', 'D', 'L', 'Q', 'F', 'S') else []}
        if mode not in ('A', 'B'):
            names = OLD_LABELS if mode == 'L' else LABELS
            row['externalState'] = {
                'options': [{'label': o['label'], 'readout': dict(zip(names, s[:3].tolist()))} for o, s in zip(options, scores)],
                'meaning': '経験から学習した状況別の傾向。−1から1で、同じ機能の候補間を比較する。確定した命令ではない。' if mode == 'L'
                           else '経験から学習した状況別の傾向。−1から1。好み、調べたい関心、制約下の行動優先は別の観測から学んでいる。同じ機能の候補間を比較する。確定した命令ではない。',
                'availableObservations': len(read_model['experiences']),
                'uncertainty': '未知の場面や小さな順位差には誤りがありうる。記録が0なら、傾向はまだ学んでいない。'}
        if mode == 'F':
            row['coreDecision'] = {'action': expected[scene['focus']], 'scope': 'この条件だけCoreが行動を確定。自然会話主試験とは別。'}
        inputs[mode].append(row)
        targets.append({'mode': mode, 'id': cid, 'person': person, 'stage': stage, 'probeId': scene_id,
                        'focus': scene['focus'], 'type': scene['type'], 'domain': scene['domain'],
                        'expected': expected, 'npnScores': scores.tolist(), 'teacherScores': oracle.tolist(),
                        'teacherChoice': {f: options[int(np.argmax(oracle[:, i]))]['label'] for i, f in enumerate(('preference', 'curiosity', 'priority'))},
                        'stateHash': digest(read_model), 'sourceStateHash': digest(model), 'auditHistory': history,
                        'aliases': [o.get('aliases', [o['label']]) for o in options],
                        'options': [o['label'] for o in options]})

    for mode in ('A', 'B', 'C', 'D'):
        for person in range(4):
            for scene_id in MAIN:
                case(mode, person, scene_id)
    for mode in ('L', 'Q', 'F'):
        for person in range(4):
            case(mode, person, 'game-team')
    for scene_id in ('game-team', 'sound-mechanism'):
        case('S', 0, scene_id, swapped=1)
    for stage in ('initial', 'added'):
        case('T', 0, 'unexpected-clue', stage=stage)
    dump('live-inputs', inputs)
    dump('live-targets-evaluation-only', targets)
    print(json.dumps({'perModel': sum(map(len, inputs.values())), 'modes': {k: len(v) for k, v in inputs.items()}}, ensure_ascii=False))


if __name__ == '__main__':
    main()
