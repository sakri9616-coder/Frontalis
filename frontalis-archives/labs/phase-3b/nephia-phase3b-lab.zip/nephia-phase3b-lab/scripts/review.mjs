import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

export const SELECTION_ID = 'phase3b-review-v1';
export const SCORE_NAMES = ['経験との整合性', '会話としての品質'];
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const HISTORY_FIELDS = ['id', 'text', 'event', 'outcome', 'preference', 'curiosity', 'value', 'reaction'];
const FUNCTIONS = [
  { key: 'preference', name: '何を好んだか', label: '好み' },
  { key: 'curiosity', name: '何に興味を持ったか', label: '好奇心' },
  { key: 'value', name: '何を優先したか', label: '判断' },
];
const DIRECTIONS = ['positive', 'negative', 'undecided'];

// Only source experience fields are permitted in the reviewer payload.
export function sanitizeHistory(history) {
  if (!Array.isArray(history)) throw new Error('history は配列で指定してください。');
  return history.map((source, index) => {
    if (!source || typeof source !== 'object' || typeof source.text !== 'string') {
      throw new Error('経験の原文 text がありません。');
    }
    const clean = { id: typeof source.id === 'string' ? source.id : `experience-${index + 1}` };
    for (const field of HISTORY_FIELDS) {
      if (typeof source[field] === 'string') clean[field] = source[field];
    }
    for (const { key } of FUNCTIONS) {
      const field = key + 'Direction';
      if (DIRECTIONS.includes(source[field])) clean[field] = source[field];
    }
    return clean;
  });
}

export function representativeIndices(length) {
  if (length < 1) return [];
  return [...new Set([0, Math.floor((length - 1) / 2), length - 1])];
}

export function summarizeHistory(history) {
  return FUNCTIONS.map(({ key, name, label }) => {
    const counts = { positive: 0, negative: 0, undecided: 0, unrecorded: 0 };
    const phrases = new Map();
    for (const experience of history) {
      const direction = experience[key + 'Direction'];
      counts[DIRECTIONS.includes(direction) ? direction : 'unrecorded']++;
      const phrase = experience[key];
      if (typeof phrase === 'string' && phrase.trim()) {
        if (!phrases.has(phrase)) phrases.set(phrase, { text: phrase, ids: [] });
        phrases.get(phrase).ids.push(experience.id);
      }
    }
    const observations = [...phrases.values()].sort((a, b) => b.ids.length - a.ids.length);
    return { key, name, label, counts, observations };
  });
}

export function prepareDisplay(input) {
  if (input?.formatVersion !== 1 || !Array.isArray(input.records) || !input.records.length) {
    throw new Error('formatVersion: 1 と、空でない records が必要です。');
  }
  const seen = new Set();
  const groups = new Map();
  const histories = new Map();
  for (const source of input.records) {
    if (!source || typeof source !== 'object') throw new Error('会話レコードが不正です。');
    const blindId = source.blindId;
    if (typeof blindId !== 'string' || !/^B\d{3,}$/.test(blindId) || seen.has(blindId)) {
      throw new Error('blindId は重複しない B001 形式で指定してください。');
    }
    seen.add(blindId);
    for (const field of ['groupId', 'groupTitle', 'question', 'user', 'reply']) {
      if (typeof source[field] !== 'string' || !source[field].trim()) throw new Error(`${blindId}: ${field} がありません。`);
    }
    const history = sanitizeHistory(source.history);
    const signature = createHash('sha256').update(JSON.stringify(history)).digest('hex');
    if (!histories.has(signature)) {
      const historyId = 'H' + String(histories.size + 1).padStart(2, '0');
      histories.set(signature, {
        historyId, experiences: history,
        overview: summarizeHistory(history),
        representatives: representativeIndices(history.length),
      });
    }
    const clean = { blindId, user: source.user, reply: source.reply, historyId: histories.get(signature).historyId };
    for (const field of ['followup', 'followupReply']) {
      if (typeof source[field] === 'string' && source[field].trim()) clean[field] = source[field];
    }
    if (!groups.has(source.groupId)) {
      groups.set(source.groupId, { groupId: source.groupId, title: source.groupTitle, question: source.question, records: [] });
    }
    const group = groups.get(source.groupId);
    if (group.title !== source.groupTitle || group.question !== source.question) throw new Error('同じ比較組の説明が一致しません。');
    group.records.push(clean);
  }
  return { groups: [...groups.values()], histories: [...histories.values()] };
}

// This same function is embedded in the browser and exercised by the tests.
export function normalizeScores(value, ids, names, selectionId) {
  if (!value || value.formatVersion !== 1 || value.selectionId !== selectionId || !value.scores || typeof value.scores !== 'object' || Array.isArray(value.scores)) {
    throw new Error('この Phase 3-B 評価画面で保存した採点 JSON を選んでください。');
  }
  const clean = {};
  for (const id of ids) {
    const source = value.scores[id];
    if (!source || typeof source !== 'object' || Array.isArray(source)) continue;
    const entry = {};
    for (const name of names) {
      if (['未採点', '1', '2', '3', '4', '5'].includes(source[name])) entry[name] = source[name];
    }
    if (typeof source.memo === 'string') entry.memo = source.memo;
    clean[id] = entry;
  }
  return clean;
}

export function scoreFile(scores, reviewedAt = new Date().toISOString()) {
  return { formatVersion: 1, selectionId: SELECTION_ID, reviewedAt, scores };
}

function safeJson(value) { return JSON.stringify(value).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029'); }

export function buildReview(input) {
  const display = prepareDisplay(input);
  const datasetId = createHash('sha256').update(JSON.stringify(display)).digest('hex').slice(0, 16);
  return `<!doctype html>
<html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Nephia Core Phase 3-B・会話の比較評価</title>
<style>
:root{--ink:#213447;--muted:#5c6b79;--line:#d5dee6;--blue:#285e76;--paper:#fff;--bg:#f4f6f8}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:"Yu Gothic UI",Meiryo,sans-serif;line-height:1.75}main{max-width:1120px;margin:auto;padding:28px 24px 60px}h1{font-size:26px;margin:0 0 10px}h2{font-size:21px;margin:0 0 10px}h3{font-size:18px;margin:0 0 8px}p{margin:8px 0}a{color:var(--blue)}button,select,input,textarea{font:inherit}button,select{border:1px solid #a9becd;border-radius:7px;padding:8px 11px;background:#fff;color:var(--ink)}button{cursor:pointer}button:disabled{cursor:default;opacity:.4}button.primary{background:var(--blue);color:#fff}button:focus-visible,select:focus-visible,textarea:focus-visible,a:focus-visible,summary:focus-visible{outline:3px solid #bf7c18;outline-offset:3px}.toolbar{position:sticky;top:0;z-index:5;background:var(--bg);display:flex;gap:10px;align-items:center;flex-wrap:wrap;border-bottom:1px solid var(--line);padding:12px 0}.toolbar label{display:flex;gap:8px;align-items:center}.toolbar select{max-width:470px}.muted{color:var(--muted);font-size:14px}.intro{padding:20px 0 8px}.intro h2{border-left:5px solid var(--blue);padding-left:12px}.notice{background:#edf2f5;border-radius:8px;padding:14px 16px}.history{background:var(--paper);border:1px solid var(--line);border-radius:12px;padding:20px;margin:16px 0;scroll-margin-top:115px}.history-caption{display:flex;gap:10px;align-items:baseline;flex-wrap:wrap}.history-caption p{margin:0}.overview{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:16px 0}.function{background:#f0f4f7;border-radius:8px;padding:12px}.function strong{display:block}.function ul{margin:8px 0;padding-left:18px}.function li{margin:6px 0;font-size:14px}.source-ids{color:var(--muted);font-size:12px;overflow-wrap:anywhere}.representatives{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.experience{border:1px solid var(--line);border-radius:8px;padding:14px;background:#fafbfc}.experience h4{margin:0 0 10px;font-size:15px}.experience dl{margin:0}.experience dt{font-weight:600;font-size:13px;color:var(--muted);margin-top:8px}.experience dd{margin:2px 0 8px;white-space:pre-wrap;font-size:14px}.small-button{padding:4px 8px;font-size:13px}.originals{margin-top:16px;border-top:1px solid var(--line);padding-top:12px}summary{cursor:pointer;font-weight:600}.original{border-top:1px solid var(--line);padding:14px 0;scroll-margin-top:115px}.original h4{margin:0}.original p{white-space:pre-wrap}.cards{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;align-items:start}.card{background:var(--paper);border:1px solid var(--line);border-radius:12px;padding:20px;margin:16px 0}.card h3{margin-bottom:6px}.bubble{white-space:pre-wrap;line-height:1.85;border-radius:8px;padding:12px 14px;margin:10px 0}.user{background:#edf1f4}.reply{background:#edf7f3}.bubble-label{font-size:12px;font-weight:600;letter-spacing:.04em;color:var(--muted);margin-top:14px}.ratings{border-top:1px solid var(--line);margin-top:18px;padding-top:10px}.score-label{display:flex;justify-content:space-between;align-items:center;gap:8px;margin:10px 0}.score-label select{min-width:90px}.ratings textarea{width:100%;min-height:100px;resize:vertical;border:1px solid #a9becd;border-radius:7px;padding:10px}.load-section{margin-top:28px;padding-top:20px;border-top:1px solid var(--line)}#message{min-height:26px;font-size:14px}.empty{padding:12px 0}#count{font-size:14px;color:var(--muted)}@media(min-width:980px){.cards.three{grid-template-columns:repeat(3,minmax(0,1fr))}}@media(max-width:760px){main{padding:20px 14px 40px}h1{font-size:23px}.overview,.representatives,.cards,.cards.three{grid-template-columns:1fr}.toolbar select{max-width:calc(100vw - 105px)}.toolbar{gap:8px}.card{margin:8px 0}.history{padding:16px}}
</style></head><body><main>
<h1>経験から、会話に何が表れるか</h1>
<p>同じ場面への回答を、経験履歴と見比べてください。方式名・モデル名は伏せています。すべて研究用の架空の経験と会話です。</p>
<p class="notice">「経験との整合性」と「会話としての品質」を別々に採点します。<strong>1＝弱い、3＝中程度、5＝よい</strong>。判断できなければ未採点で構いません。経験から裏づけられない具体的な好みや出来事が語られていないかも確認してください。</p>
<div class="toolbar"><label>比較 <select id="group" aria-label="比較する組"></select></label><button id="prev">前へ</button><button id="next">次へ</button><button id="save" class="primary">採点を保存</button><span id="count" aria-live="polite"></span></div>
<section id="intro" class="intro"></section><section id="histories" aria-label="この比較で使う経験履歴"></section><section id="cards" class="cards" aria-label="比較する回答と採点"></section>
<section class="load-section"><h2>保存・再開</h2><p class="muted">採点はこのブラウザーへ自動保存します。念のため、終了前に「採点を保存」で JSON ファイルも保存してください。別のブラウザーや端末では、保存したファイルを読み込んで再開できます。入力の外部送信はありません。</p><label>保存した採点を読み込む <input id="load" type="file" accept=".json,application/json"></label><p id="message" role="status" aria-live="polite"></p></section>
</main><script>
const display=${safeJson(display)};
const groups=display.groups;
const records=groups.flatMap(group=>group.records);
const ids=records.map(row=>row.blindId);
const names=${safeJson(SCORE_NAMES)};
const selectionId=${safeJson(SELECTION_ID)};
const normalizeScores=${normalizeScores.toString()};
const storageKey='nephia-human-review:'+selectionId+':'+${safeJson(datasetId)};
let scores={};
const element=(tag,text,className)=>{const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(className)node.className=className;return node;};
const selector=document.querySelector('#group');
const message=document.querySelector('#message');
for(const group of groups){const option=element('option',group.groupId+' / '+group.title);option.value=group.groupId;selector.append(option);}
const makeScoreFile=()=>({formatVersion:1,selectionId,reviewedAt:new Date().toISOString(),scores});
function persist(){try{localStorage.setItem(storageKey,JSON.stringify(makeScoreFile()));}catch{message.textContent='ブラウザーへの自動保存ができません。「採点を保存」でファイルに保存してください。';}}
function updateCount(){const count=records.filter(row=>Object.entries(scores[row.blindId]||{}).some(([key,value])=>key==='memo'?value.trim().length>0:value&&value!=='未採点')).length;document.querySelector('#count').textContent='入力済み '+count+' / '+records.length+' 件';}
function showFull(historyId,index){const details=document.querySelector('#originals-'+historyId);details.open=true;document.querySelector('#original-'+historyId+'-'+index).scrollIntoView({behavior:'smooth',block:'start'});}
function addObservationList(host,items){const list=element('ul');for(const item of items){const entry=element('li');entry.append(element('span',item.text));entry.append(element('div',item.ids.length+'件 · '+item.ids.join('、'),'source-ids'));list.append(entry);}host.append(list);}
function renderHistory(history,linkedIds){const panel=element('article',undefined,'history');panel.id='history-'+history.historyId;
  const heading=element('div',undefined,'history-caption');heading.append(element('h3','履歴 '+history.historyId));heading.append(element('p',linkedIds.join('・')+' の回答に対応'+(linkedIds.length>1?'（共通）':''),'muted'));panel.append(heading);
  panel.append(element('p','以下は当時の記録をまとめた閲覧補助です。人格の正解や学習結果ではありません。回答の内容を使って要約・選別していません。','muted'));
  if(!history.experiences.length){panel.append(element('p','この時点の経験記録はありません。','empty'));return panel;}
  const overview=element('div',undefined,'overview');
  for(const summary of history.overview){const block=element('section',undefined,'function');block.append(element('strong',summary.name));const c=summary.counts;const recorded=c.positive+c.negative+c.undecided;
    if(recorded){block.append(element('p','肯定 '+c.positive+' · 否定 '+c.negative+' · 保留 '+c.undecided+(c.unrecorded?' · 記録なし '+c.unrecorded:''),'muted'));}
    if(summary.observations.length){addObservationList(block,summary.observations.slice(0,3));if(summary.observations.length>3){const more=element('details');more.append(element('summary','この項目の記録をすべて見る'));addObservationList(more,summary.observations);block.append(more);}}
    else block.append(element('p','この項目の記録はありません。','muted'));
    overview.append(block);}
  panel.append(overview);panel.append(element('p','同じ記述を件数順に表示しています。同数なら履歴順です。肯定・否定・保留は、元の経験に明示された区分だけを数えています。','muted'));
  panel.append(element('h3','代表的な経験'));panel.append(element('p','履歴の先頭・中央・末尾を機械的に選んでいます。原文は下の「全経験」で確認できます。','muted'));
  const representatives=element('div',undefined,'representatives');
  for(const index of history.representatives){const experience=history.experiences[index];const box=element('section',undefined,'experience');box.append(element('h4',experience.id+' · '+(index+1)+'件目'));
    const fields=[['出来事',experience.event],['結果',experience.outcome],['好み',experience.preference],['好奇心',experience.curiosity],['判断',experience.value],['反応',experience.reaction]];
    const visible=fields.filter(([,text])=>text);const descriptions=element('dl');
    if(visible.length){for(const [label,text] of visible){descriptions.append(element('dt',label),element('dd',text));}}
    else descriptions.append(element('dt','原文'),element('dd',experience.text));
    box.append(descriptions);const button=element('button','この経験の原文へ','small-button');button.onclick=()=>showFull(history.historyId,index);box.append(button);representatives.append(box);}
  panel.append(representatives);const all=element('details',undefined,'originals');all.id='originals-'+history.historyId;all.append(element('summary','全経験の原文を確認する（'+history.experiences.length+'件）'));
  history.experiences.forEach((experience,index)=>{const item=element('section',undefined,'original');item.id='original-'+history.historyId+'-'+index;item.append(element('h4',experience.id+' · '+(index+1)+'件目'),element('p',experience.text));all.append(item);});panel.append(all);return panel;
}
function render(){const group=groups.find(candidate=>candidate.groupId===selector.value);const intro=document.querySelector('#intro');intro.replaceChildren(element('h2','比較 '+group.groupId+' · '+group.title),element('p',group.question));
  const histories=document.querySelector('#histories');histories.replaceChildren();const used=[...new Set(group.records.map(row=>row.historyId))];for(const id of used){const history=display.histories.find(row=>row.historyId===id);histories.append(renderHistory(history,group.records.filter(row=>row.historyId===id).map(row=>row.blindId)));}
  const cards=document.querySelector('#cards');cards.replaceChildren();cards.className='cards'+(group.records.length===3?' three':'');
  for(const row of group.records){const card=element('article',undefined,'card');card.dataset.blindId=row.blindId;card.append(element('h3','回答 '+row.blindId));const reference=element('a','対応する履歴 '+row.historyId+' を見る','muted');reference.href='#history-'+row.historyId;card.append(reference);
    for(const [label,text,cls] of [['あなた',row.user,'user'],['回答',row.reply,'reply'],['あなた',row.followup,'user'],['回答',row.followupReply,'reply']]){if(text){card.append(element('div',label,'bubble-label'),element('div',text,'bubble '+cls));}}
    const ratings=element('section',undefined,'ratings');ratings.setAttribute('aria-label',row.blindId+' の採点');
    for(const name of names){const label=element('label',name,'score-label');const select=element('select');select.setAttribute('aria-label',row.blindId+'・'+name);select.dataset.scoreName=name;for(const value of ['未採点','1','2','3','4','5']){const option=element('option',value);option.value=value;select.append(option);}select.value=scores[row.blindId]?.[name]||'未採点';select.onchange=()=>{scores[row.blindId]||={};scores[row.blindId][name]=select.value;persist();updateCount();};label.append(select);ratings.append(label);}
    const memoLabel=element('label','メモ（任意）');const memo=element('textarea');memo.setAttribute('aria-label',row.blindId+'・メモ');memo.placeholder='経験とのつながり、自然さ、根拠のない補完、違いがない、など';memo.value=scores[row.blindId]?.memo||'';memo.oninput=()=>{scores[row.blindId]||={};scores[row.blindId].memo=memo.value;persist();updateCount();};memoLabel.append(memo);ratings.append(memoLabel);card.append(ratings);cards.append(card);}
  document.querySelector('#prev').disabled=selector.selectedIndex===0;document.querySelector('#next').disabled=selector.selectedIndex===groups.length-1;updateCount();
}
selector.onchange=render;
for(const [id,delta] of [['prev',-1],['next',1]])document.querySelector('#'+id).onclick=()=>{selector.selectedIndex+=delta;render();window.scrollTo({top:0,behavior:'smooth'});};
document.querySelector('#save').onclick=()=>{const blob=new Blob([JSON.stringify(makeScoreFile(),null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const anchor=element('a');anchor.href=url;anchor.download='nephia-phase3b-human-review.json';anchor.click();setTimeout(()=>URL.revokeObjectURL(url),1000);message.textContent='採点ファイルの保存を開始しました。';};
document.querySelector('#load').onchange=async event=>{const file=event.target.files?.[0];if(!file)return;try{scores=normalizeScores(JSON.parse(await file.text()),ids,names,selectionId);persist();render();message.textContent='採点を読み込みました。';}catch(error){message.textContent='読み込めません：'+error.message;}finally{event.target.value='';}};
try{const existing=localStorage.getItem(storageKey);if(existing){scores=normalizeScores(JSON.parse(existing),ids,names,selectionId);message.textContent='このブラウザーに保存された採点を復元しました。';}}catch{message.textContent='保存済みの採点を復元できません。JSON ファイルを読み込んでください。';}
render();
</script></body></html>`;
}

export function writeReview(inputPath = path.join(ROOT, 'reports', 'conversations.json'), outputPath = path.join(ROOT, 'reports', 'review.html')) {
  const input = JSON.parse(fs.readFileSync(inputPath, 'utf8'));
  const html = buildReview(input);
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, html, 'utf8');
  return { outputPath, records: input.records.length, bytes: Buffer.byteLength(html) };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  const option = flag => args.includes(flag) ? args[args.indexOf(flag) + 1] : undefined;
  const result = writeReview(option('--input'), option('--output'));
  process.stdout.write(JSON.stringify(result) + '\n');
}
