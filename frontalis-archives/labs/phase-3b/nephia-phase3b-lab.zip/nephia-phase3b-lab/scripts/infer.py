"""Read a portable snapshot and query from stdin; no LLM or learning is used."""
import json
import sys
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from p3b.model import predict
from p3b.store import validate
model = json.loads(Path(sys.argv[1]).read_text(encoding='utf8'))
validate(model)
query = json.loads(sys.stdin.read())
if query.get('owner') != model['owner']: raise ValueError('Query owner mismatch.')
if query.get('semanticSchema', 'p3b.semantic6.v1') != model['semanticSchema']:
    raise ValueError('Semantic query schema mismatch.')
print(json.dumps({'prediction': predict(model, query['x'], query['domain']).tolist(), 'shortState': model['shortState']}))
