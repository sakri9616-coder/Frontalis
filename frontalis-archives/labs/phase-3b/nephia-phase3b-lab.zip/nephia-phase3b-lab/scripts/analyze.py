"""Conservative, predeclared surface tests; not a human semantic rating."""
import json
import random
import re
from pathlib import Path
from collections import defaultdict

ROOT = Path(__file__).resolve().parents[1]
ENGINES = ('opencode/nemotron-3-ultra-free', 'opencode/mimo-v2.6-flash-free')


def decode(text, target):
    # Multiple mentioned actions, negation and paraphrases remain unscored.
    hits = {}
    for index, aliases in enumerate(target['aliases']):
        evidence = []
        for sentence in re.split(r'[。！？\n]', text):
            found = [a for a in aliases if a and a in sentence]
            if not found:
                continue
            if re.search(r'ではなく|じゃなく|避け|しない|したくない|関心はない|興味はない', sentence):
                continue
            evidence.extend(found)
        if evidence:
            hits[target['options'][index]] = sorted(set(evidence))
    return {'choice': next(iter(hits)) if len(hits) == 1 else None,
            'status': 'one-action-expression' if len(hits) == 1 else 'multiple-actions' if hits else 'not-decoded',
            'hits': hits}


def load():
    targets = []
    for name in ('live-targets-evaluation-only', 'matched-targets-evaluation-only'):
        targets += json.loads((ROOT / f'reports/{name}.json').read_text(encoding='utf8'))
    indexed = {(t['mode'], t['id']): t for t in targets}
    valid, failures = {}, []
    for folder in ('live', 'live-matched'):
        for file in sorted((ROOT / 'reports' / folder).glob('*/*-results.json')):
            result = json.loads(file.read_text(encoding='utf8'))
            if not result['valid']:
                failures.append({'file': str(file.relative_to(ROOT)), 'engine': result['engine'], 'mode': result['mode'], 'error': result['error']})
                continue
            for r in result['records']:
                key = (result['engine'], result['mode'], r['id'])
                if key in valid:
                    raise ValueError('Two valid outputs for one frozen case.')
                t = indexed[(result['mode'], r['id'])]
                code = decode(r['reply'], t)
                j = ('preference', 'curiosity', 'priority').index(t['focus'])
                ordered = sorted(s[j] for s in t['npnScores'])
                eligible = t['stage'] != 'initial' and ordered[-1] - ordered[-2] > .05
                valid[key] = {**r, 'engine': result['engine'], 'mode': result['mode'], 'target': t,
                              'code': code, 'clearNPNRanking': eligible,
                              'matchingNPNExpression': eligible and code['choice'] == t['expected'][t['focus']],
                              'allFocusScoresNegative': ordered[-1] < 0}
    return valid, failures


def main():
    valid, failures = load()
    summary = {}
    for engine in ENGINES:
        summary[engine] = {}
        for mode in ('A', 'B', 'C', 'D', 'L', 'Q', 'F', 'S', 'T', 'SX', 'LX', 'TI', 'TA', 'R'):
            rows = [r for (e, m, _), r in valid.items() if e == engine and m == mode]
            focus = {}
            for field in ('preference', 'curiosity', 'priority'):
                relevant = [r for r in rows if r['target']['focus'] == field]
                clear = [r for r in relevant if r['clearNPNRanking']]
                focus[field] = {'count': len(relevant), 'clearNPNRanking': len(clear),
                                'oneActionDecoded': sum(r['code']['choice'] is not None for r in clear),
                                'matchingNPNExpression': sum(r['matchingNPNExpression'] for r in clear),
                                'undecodableOrMultiple': sum(r['code']['choice'] is None for r in clear)}
            diagnostic = [r for r in rows if mode == 'Q']
            summary[engine][mode] = {'valid': len(rows), 'focus': focus,
                                    'diagnosticSelectionMatch': sum(r.get('selection') == r['target']['expected']['priority'] for r in diagnostic) if diagnostic else None,
                                    'allFocusScoresNegative': sum(r['allFocusScoresNegative'] for r in rows)}
    pairs = []
    for (engine, mode, cid), after in valid.items():
        if mode not in ('SX', 'LX', 'TI', 'TA', 'R'):
            continue
        t = after['target']
        before = valid.get((engine, t['baselineMode'], t['baselineId']))
        if not before:
            continue
        field = t['focus']
        pairs.append({'engine': engine, 'mode': mode, 'id': cid, 'focus': field,
                      'targetModified': t['interventionApplied'],
                      'beforeNPN': before['target']['expected'][field], 'afterNPN': t['expected'][field],
                      'beforeDecoded': before['code']['choice'], 'afterDecoded': after['code']['choice'],
                      'literalReplyChanged': before['reply'] != after['reply'],
                      'bothDecoded': before['code']['choice'] is not None and after['code']['choice'] is not None})
    portability = []
    for (engine, mode, cid), a in valid.items():
        if engine != ENGINES[0] or mode not in ('B', 'C', 'D'):
            continue
        b = valid.get((ENGINES[1], mode, cid))
        if b:
            portability.append({'mode': mode, 'id': cid, 'focus': a['target']['focus'],
                                'bothDecoded': bool(a['code']['choice'] and b['code']['choice']),
                                'sameActionExpression': bool(a['code']['choice'] and a['code']['choice'] == b['code']['choice']),
                                'first': a['code']['choice'], 'second': b['code']['choice']})
    flags = []
    for (engine, mode, cid), r in valid.items():
        for kind, pattern in [('internal', r's360\d-(?:train|added)-\d+|NPN|[-+]?\d+\.\d+'),
                              ('unsupportedGenre', r'ジャズ|ロック|クラシック|J[−-]?POP|ヒップホップ|テクノ')]:
            hits = re.findall(pattern, r['reply'], flags=re.I)
            if hits:
                flags.append({'engine': engine, 'mode': mode, 'id': cid, 'kind': kind, 'hits': hits, 'heuristicOnly': True})
    report = {'formatVersion': 1, 'valid': len(valid), 'planned': 200, 'summary': summary,
              'matchedPairs': pairs, 'portability': portability, 'flags': flags, 'failures': failures,
              'formalHumanRatings': 0,
              'boundary': 'Predefined word detection is not semantic correctness or conversation quality. Multiple actions/paraphrases remain unscored. Unknown teachers and NPN predictions never choose source examples.'}
    (ROOT / 'reports/conversation-analysis.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    # Display IDs are stable and randomly ordered inside each fixed comparison.
    n, m = ENGINES
    c = lambda p, s: f'{p}-{s}-formed'
    spec = [
        ('同じ経験からの共同制作の相談', '同じ出来事を踏まえた返答として、進め方と理由が納得できるか。', [(n, x, c(0, 'game-team')) for x in ('B', 'C', 'D', 'LX')]),
        ('音の仕組みについて何に注目するか', '音への好き嫌いと、調べたいことが会話から読み取れるか。', [(n, x, c(0, 'sound-mechanism')) for x in ('B', 'D')]),
        ('同じ人格状態を別の会話エンジンへ渡す', '同じ経験の相談で、着目する点や優先する行動が保たれるか。', [(e, 'D', c(1, 'game-team')) for e in (n, m)]),
        ('音の作業をどう進めるか', '経験にない趣味を作らず、相談の内容に沿った好みが表れているか。', [(e, 'D', c(0, 'sound-process')) for e in (n, m)]),
        ('異なる経験からの共同制作の判断', '同じ相談でも、経験と理由のつながりに意味のある違いがあるか。', [(n, 'D', c(p, 'game-team')) for p in (2, 3)]),
        ('問い方・判断指定がある補助検査', 'この組は問い方や外部の判断指定が異なる補助例です。主自然会話の成績と分けて、説明が自然に伝わるかを見てください。', [(n, x, c(0, 'game-team')) for x in ('Q', 'F')]),
        ('同じ履歴での別の返答', '比較01の同じ相談と見比べ、経験との対応と発言の変化を見てください。履歴の食い違いがあると感じたらメモに残してください。', [(e, 'SX', c(0, 'game-team')) for e in (n, m)]),
        ('経験が増える前後の資料整理', '同じ相談への返答に、以前の経験・新しい経験との対応があるか。具体的な行動と自然さを分けて評価してください。', [(n, x, c(0, 'unexpected-clue')) for x in ('TI', 'C', 'TA')] + [(m, 'TI', c(0, 'unexpected-clue'))])]
    cards, key = [], []
    randomizer = random.Random(360114)
    for g, (title, question, addresses) in enumerate(spec, 1):
        addresses = list(addresses);randomizer.shuffle(addresses)
        for address in addresses:
            if address not in valid:
                continue
            row = valid[address];t = row['target'];history = []
            for e in t['auditHistory']:
                d = e.get('display', {})
                h = {'id': e['id'], 'text': e['text'], 'event': d.get('event', ''), 'outcome': d.get('result', ''),
                     'preference': d.get('preference', ''), 'curiosity': d.get('curiosity', ''),
                     'value': d.get('priority', ''), 'reaction': d.get('reaction', '')}
                for name, j in [('preference', 0), ('curiosity', 1), ('value', 2)]:
                    h[name+'Direction'] = 'positive' if e['y'][j] > .25 else 'negative' if e['y'][j] < -.25 else 'undecided'
                history.append(h)
            bid = f'B{len(cards)+1:03d}'
            original_input = json.loads((ROOT / f'reports/{"matched-inputs" if t["mode"] in ("SX","LX","TI","TA","R") else "live-inputs"}.json').read_text(encoding='utf8'))
            user = next(q['user'] for q in original_input[t['mode']] if q['id'] == row['id'])
            cards.append({'blindId': bid, 'groupId': f'{g:02d}', 'groupTitle': title, 'question': question,
                          'history': history, 'user': user, 'reply': row['reply']})
            key.append({'blindId': bid, 'engine': row['engine'], 'mode': row['mode'], 'id': row['id'], 'stateHash': t['stateHash']})
    (ROOT / 'reports/conversations.json').write_text(json.dumps({'formatVersion': 1, 'records': cards}, ensure_ascii=False, indent=2), encoding='utf8')
    (ROOT / 'reports/review-key.json').write_text(json.dumps(key, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps({'valid': len(valid), 'shortlist': len(cards), 'failures': len(failures), 'flags': len(flags)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
