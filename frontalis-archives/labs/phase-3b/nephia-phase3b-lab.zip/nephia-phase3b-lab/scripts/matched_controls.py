"""Exploratory controls: change only one state inside the complete batch."""
import copy
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
inputs = json.loads((ROOT / 'reports/live-inputs.json').read_text(encoding='utf8'))
targets = json.loads((ROOT / 'reports/live-targets-evaluation-only.json').read_text(encoding='utf8'))
lookup = {(t['mode'], t['id']): t for t in targets}
output = {'SX': [], 'LX': [], 'TI': [], 'TA': [], 'R': []}
evaluation = []


def add(mode, rows, changed, source_mode, source_id):
    """Keep case IDs, user, partner case and full histories identical to baseline."""
    base_mode = 'C' if mode in ('TI', 'TA') else 'D'
    source = next(r for r in inputs[source_mode] if r['id'] == source_id)
    for index, original in enumerate(rows):
        row = copy.deepcopy(original)
        target = copy.deepcopy(lookup[(base_mode, row['id'])])
        target.update(mode=mode, baselineMode=base_mode, baselineId=row['id'], interventionApplied=index == changed)
        if index == changed:
            row['externalState'] = copy.deepcopy(source['externalState'])
            replacement = lookup[(source_mode, source_id)]
            for field in ('expected', 'npnScores', 'stateHash', 'teacherChoice', 'teacherScores'):
                target[field] = copy.deepcopy(replacement[field])
            if mode in ('TI', 'TA'):
                target['stage'] = replacement['stage']
                target['auditHistory'] = copy.deepcopy(replacement['auditHistory'])
                target['sourceStateHash'] = replacement['sourceStateHash']
        assert {k:v for k,v in row.items() if k != 'externalState'} == {k:v for k,v in original.items() if k != 'externalState'}
        output[mode].append(row)
        evaluation.append(target)


add('SX', inputs['D'][0:2], 1, 'S', '0-sound-mechanism-formed')
add('SX', inputs['D'][2:4], 0, 'S', '0-game-team-formed')
for person in range(4):
    add('LX', inputs['D'][person*4+2:person*4+4], 0, 'L', f'{person}-game-team-formed')
for mode, stage in [('TI', 'initial'), ('TA', 'added')]:
    add(mode, inputs['C'][2:4], 1, 'T', f'0-unexpected-clue-{stage}')
# Repeat exact original D batches: a small stochastic variability reference.
for row in inputs['D'][:4]:
    output['R'].append(copy.deepcopy(row))
    t = copy.deepcopy(lookup[('D', row['id'])]);t.update(mode='R',baselineMode='D',baselineId=row['id'],interventionApplied=False)
    evaluation.append(t)
for name, value in [('matched-inputs', output), ('matched-targets-evaluation-only', evaluation)]:
    path = ROOT / 'reports' / (name + '.json')
    if path.exists():raise ValueError('Matched controls already frozen.')
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf8')
print(json.dumps({'additionalPerModel': sum(map(len, output.values())), 'modes': {k:len(v) for k,v in output.items()}}))
