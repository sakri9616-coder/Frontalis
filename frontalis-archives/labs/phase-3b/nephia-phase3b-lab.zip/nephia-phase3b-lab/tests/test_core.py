import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from p3b.data import records
from p3b.model import fit, predict, refit, transition, digest
from p3b.store import Store, validate
from p3b.review import internal_leakage


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.rows = records(3501, 0, 'linear', 'train', 48)
        self.model = fit(self.rows, 'linear', None, None)
        self.temp = tempfile.TemporaryDirectory(dir=ROOT / 'runtime')
        self.addCleanup(self.temp.cleanup)

    def test_training_rejects_unverified_sources(self):
        for field, value in [('origin', 'model'), ('signal', 'generated_choice'), ('signal', 'praise'), ('owner', 'user'), ('confidence', .1), ('accepted', False)]:
            rows = copy.deepcopy(self.rows); rows[0][field] = value
            with self.subTest(field=field, value=value), self.assertRaises(ValueError): fit(rows, 'linear', None, None)

    def test_duplicate_experience_rejected(self):
        with self.assertRaises(ValueError): fit(self.rows + self.rows[:1], 'linear', None, None)

    def test_nonfinite_observation_rejected(self):
        self.rows[0]['y'][0] = float('nan')
        with self.assertRaises(ValueError): fit(self.rows, 'linear', None, None)

    def test_person_name_and_text_do_not_set_weights(self):
        rows = copy.deepcopy(self.rows)
        for e in rows: e['id'] += '-renamed'; e['text'] = '別の文'; e['hiddenLabel'] = 'ignored'
        self.assertEqual(self.model['weights'], refit(self.model, rows)['weights'])

    def test_preference_change_preserves_other_heads(self):
        rows = copy.deepcopy(self.rows); rows[0]['y'][0] *= -1
        rows[0]['observations']['選好'] = rows[0]['y'][0]
        new = refit(self.model, rows)
        np.testing.assert_array_equal(np.asarray(new['weights'])[:, 1:], np.asarray(self.model['weights'])[:, 1:])

    def test_unrelated_domain_preserved(self):
        new = refit(self.model, self.rows + records(3501, 0, 'linear', 'added', 12, domain_only=0))
        np.testing.assert_allclose(predict(new, [[.5]*6], [3]), predict(self.model, [[.5]*6], [3]), atol=1e-12)

    def test_order_independent_long_heads(self):
        np.testing.assert_allclose(refit(self.model, self.rows[::-1])['weights'], self.model['weights'], atol=1e-12)

    def test_short_state_is_separate_and_recovers(self):
        m = transition(self.model, [.7]*6, 0, 1); decayed = transition(m, elapsed=10)
        self.assertEqual(m['weights'], decayed['weights'])
        self.assertLess(np.linalg.norm(decayed['shortState']), np.linalg.norm(m['shortState']))

    def test_negative_elapsed_rejected(self):
        with self.assertRaises(ValueError): transition(self.model, elapsed=-1)

    def test_learning_preserves_current_short_state(self):
        m = transition(self.model, [.7]*6, 0, 1)
        updated = refit(m, self.rows + records(3501, 0, 'linear', 'added', 12, domain_only=0))
        self.assertEqual(updated['shortState'], m['shortState'])
        self.assertEqual(updated['time'], m['time'])
        self.assertEqual(updated['transitions'], m['transitions'])

    def test_actual_neural_snapshot_inference(self):
        model = json.loads((ROOT / 'models/live-p0.json').read_text(encoding='utf8'))
        validate(model)
        self.assertEqual(predict(model, [[.4]*6], [0]).shape, (1, 5))

    def test_shared_initial_neural_heads_have_same_output(self):
        initial = json.loads((ROOT / 'models/initial-common.json').read_text(encoding='utf8'))
        validate(initial)
        self.assertEqual(initial['experiences'], [])
        for domain in range(4): np.testing.assert_array_equal(predict(initial, [[.8]*6], [domain]), [[0, 0, 0, 0, .5]])

    def test_internal_candidate_letters_next_to_japanese_are_flagged(self):
        self.assertEqual(internal_leakage('私はaに傾く。bの案もある。'), ['a', 'b'])
        self.assertEqual(internal_leakage('慣れた静かな弦の曲を聴きたい。'), [])

    def test_save_restart_restore_rollback(self):
        store = Store(Path(self.temp.name) / 'a'); store.commit(self.model)
        m = transition(self.model, [.7]*6, 0, 1); store.commit(m, 'reaction', 0)
        restarted = Store(Path(self.temp.name) / 'a'); self.assertEqual(restarted.load(), m)
        restored = Store(Path(self.temp.name) / 'b'); restored.restore(restarted.export()); self.assertEqual(restored.load(), m)
        self.assertEqual(restored.rollback(0, 1), 2); self.assertEqual(restored.load(), self.model)
        self.assertEqual(restored._read()['generations'][2]['parent'], 1)

    def test_restore_does_not_overwrite_existing(self):
        store = Store(Path(self.temp.name) / 'a'); store.commit(self.model)
        with self.assertRaises(ValueError): store.restore(store.export())

    def test_empty_export_restores_to_empty_store(self):
        original = Store(Path(self.temp.name) / 'empty-original')
        restored = Store(Path(self.temp.name) / 'empty-restored')
        restored.restore(original.export())
        self.assertEqual(restored.export(), original.export())
        self.assertIsNone(restored._read()['head'])

    def test_stale_update_rejected(self):
        store = Store(Path(self.temp.name) / 'a'); store.commit(self.model)
        with self.assertRaises(ValueError): store.commit(self.model, expected_head=None)

    def test_hash_corruption_rejected(self):
        store = Store(Path(self.temp.name) / 'a'); store.commit(self.model)
        file = store.directory / (digest(self.model) + '.json')
        value = json.loads(file.read_text()); value['payload']['shortState'][0] = .7
        file.write_text(json.dumps(value))
        with self.assertRaises(ValueError): store.load()

    def test_provenance_corruption_rejected(self):
        m = copy.deepcopy(self.model); m['experiences'][0]['text'] = 'changed'
        with self.assertRaises(ValueError): validate(m)

    def test_parameter_shape_corruption_rejected(self):
        m = copy.deepcopy(self.model); m['weights'] = [[0, 0, 0, 0, .5]]
        with self.assertRaises(ValueError): validate(m)

    def test_invalid_query_rejected(self):
        with self.assertRaises(ValueError): predict(self.model, [[2]*6], [0])

    def test_negative_intensity_observation_rejected(self):
        self.rows[0]['y'][4] = -.001
        with self.assertRaises(ValueError): fit(self.rows, 'linear', None, None)

    def test_signed_heads_are_unchanged_by_intensity_fix(self):
        raw = fit(self.rows, 'linear', bounded=False)
        query = np.random.default_rng(10).uniform(-1, 1, (128, 6)); domains = np.arange(128) % 4
        np.testing.assert_array_equal(predict(self.model, query, domains)[:, :4], predict(raw, query, domains)[:, :4])

    def test_every_method_has_nonnegative_intensity_before_clipping(self):
        query = np.random.default_rng(33).uniform(-1, 1, (256, 6)); domains = np.arange(256) % 4
        shared = json.loads((ROOT / 'models/shared.json').read_text(encoding='utf8'))
        old = json.loads((ROOT / 'models/frozen-phase35.json').read_text(encoding='utf8'))
        for kind in ('linear', 'quadratic', 'memory', 'adapted', 'frozen'):
            with self.subTest(kind=kind):
                m = fit(self.rows, kind, shared, old)
                result = predict(m, query, domains)
                self.assertTrue(np.all((result[:, 4] >= 0) & (result[:, 4] <= 1)))

    def test_semantic_schema_mismatch_rejected(self):
        self.rows[0]['semanticSchema'] = 'old-meaning'
        with self.assertRaises(ValueError): fit(self.rows, 'linear', None, None)

    def test_fractional_domain_rejected(self):
        with self.assertRaises(ValueError): predict(self.model, [[.1]*6], [.5])

    def test_training_validation_overlap_rejected(self):
        from p3b.model import select
        with self.assertRaises(ValueError): select(self.rows, self.rows[:4], 'linear')

    def test_negative_short_intensity_rejected(self):
        self.model['shortState'][1] = -.1
        with self.assertRaises(ValueError): validate(self.model)

    def test_old_unbounded_diagnostic_cannot_be_saved_as_canonical(self):
        m = fit(self.rows, 'linear', bounded=False)
        with self.assertRaises(ValueError): validate(m)

    def test_named_observation_disagreement_rejected(self):
        self.rows[0]['observations']['好奇心'] *= -1
        with self.assertRaises(ValueError): fit(self.rows, 'linear')

    def test_shared_nonfinite_parameters_rejected(self):
        m = json.loads((ROOT / 'models/live-p0.json').read_text(encoding='utf8'))
        m['shared']['weights']['0.bias'][0] = float('nan')
        with self.assertRaises(ValueError): validate(m)

    def test_frozen_legacy_encoder_without_dimension_metadata_restores(self):
        m = json.loads((ROOT / 'models/3601-context-p0-Phase35_frozen16.json').read_text(encoding='utf8'))
        m['old'].pop('latentDim', None)
        validate(m)
        store = Store(Path(self.temp.name) / 'frozen'); store.commit(m)
        np.testing.assert_array_equal(predict(store.load(), [[.2]*6], [1]), predict(m, [[.2]*6], [1]))

    def test_new_os_process_prediction(self):
        file = Path(self.temp.name) / 'state.json'; file.write_text(json.dumps(self.model), encoding='utf8')
        query = {'owner': 'nephia', 'x': [[.4]*6], 'domain': [0]}
        env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONUTF8': '1'}
        p = subprocess.run([sys.executable, str(ROOT / 'scripts/infer.py'), str(file)], input=json.dumps(query), capture_output=True, text=True, encoding='utf8', env=env, check=True)
        np.testing.assert_array_equal(json.loads(p.stdout)['prediction'], predict(self.model, query['x'], query['domain']))


if __name__ == '__main__':
    (ROOT / 'runtime').mkdir(exist_ok=True)
    unittest.main()

