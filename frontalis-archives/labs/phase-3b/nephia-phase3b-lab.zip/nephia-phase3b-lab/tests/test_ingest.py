import copy
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from p3b.ingest import accept_proposal, content_hash, SIGNALS
from p3b.data import SEMANTIC_AXES


class AcceptanceTests(unittest.TestCase):
    def setUp(self):
        self.event = {'id': 'synthetic-confirmed', 'text': '架空の作業で比較を試した。自分の確定記録は、好きだが調べる関心は薄い。', 'origin': 'synthetic'}
        self.proposal = {'owner': 'nephia', 'domain': 0,
                         'features': {k: {'value': .2, 'sourceQuote': '比較を試した'} for k in SEMANTIC_AXES},
                         'assessments': {k: {'value': .2, 'sourceQuote': '自分の確定記録', 'actor': 'nephia', 'basis': 'confirmed-own-record'} for k in SIGNALS}}
        self.review = {'approved': True, 'eventId': self.event['id'], 'reviewer': 'synthetic-test-reviewer',
                       'authority': 'research-human-equivalent', 'confirmedDomain': True,
                       'confirmedFeatures': {k: True for k in SEMANTIC_AXES},
                       'confirmedAssessments': {k: True for k in SIGNALS}}
        self.bind()

    def bind(self, proposal=None):
        self.review.update(eventHash=content_hash(self.event), proposalHash=content_hash(proposal or self.proposal))

    def test_provenance_preserved(self):
        row = accept_proposal(self.event, self.proposal, self.review)
        self.assertEqual(row['sourceEvent'], self.event)
        self.assertEqual(len(row['interpretationProvenance']), 11)

    def test_generated_proposal_cannot_approve_itself(self):
        with self.assertRaises(ValueError): accept_proposal(self.event, self.proposal, {'approved': True, 'authority': 'llm'})

    def test_missing_signal_pending(self):
        del self.proposal['assessments']['curiosity']
        self.bind()
        with self.assertRaises(ValueError): accept_proposal(self.event, self.proposal, self.review)

    def test_user_and_model_ratings_rejected(self):
        for actor, basis in [('user', 'confirmed-own-record'), ('nephia', 'model-inferred'), ('nephia', 'praise'), ('nephia', 'unverified-self-report')]:
            p = copy.deepcopy(self.proposal);p['assessments']['priority'].update(actor=actor, basis=basis)
            self.bind(p)
            with self.subTest(actor=actor,basis=basis), self.assertRaises(ValueError): accept_proposal(self.event, p, self.review)

    def test_unknown_quote_and_review_rejected(self):
        self.proposal['features']['novelty']['sourceQuote'] = '原文にない好み'
        self.bind()
        with self.assertRaises(ValueError): accept_proposal(self.event, self.proposal, self.review)

    def test_negative_intensity_rejected(self):
        self.proposal['assessments']['intensity']['value'] = -.1
        self.bind()
        with self.assertRaises(ValueError): accept_proposal(self.event, self.proposal, self.review)

    def test_self_report_is_not_verified_by_event_alone(self):
        self.review['confirmedAssessments']['preference'] = False
        with self.assertRaises(ValueError): accept_proposal(self.event, self.proposal, self.review)

    def test_approved_proposal_cannot_be_changed(self):
        self.proposal['features']['novelty']['value'] = -.9
        with self.assertRaises(ValueError): accept_proposal(self.event, self.proposal, self.review)

    def test_event_text_cannot_be_changed_after_approval(self):
        self.event['text'] += ' 後から追加した推測。'
        with self.assertRaises(ValueError): accept_proposal(self.event, self.proposal, self.review)
