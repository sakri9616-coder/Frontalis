import importlib.util
import unittest
from pathlib import Path

spec = importlib.util.spec_from_file_location('conversation_surface', Path(__file__).resolve().parents[1] / 'scripts/analyze.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class SurfaceTests(unittest.TestCase):
    target = {'aliases': [['切り貼り'], ['波形']], 'options': ['慣れた加工', '仕組みの比較']}

    def test_one_expression(self):
        self.assertEqual(module.decode('波形を見てみたい。', self.target)['choice'], '仕組みの比較')

    def test_mixed_actions_not_scored(self):
        self.assertIsNone(module.decode('波形を見た後で切り貼りもする。', self.target)['choice'])

    def test_negative_mention_not_positive(self):
        self.assertIsNone(module.decode('波形を見るのは避けたい。', self.target)['choice'])

    def test_paraphrase_remains_unscored(self):
        self.assertIsNone(module.decode('見慣れた方法で整えるかな。', self.target)['choice'])

    def test_npn_target_not_used_to_decode(self):
        other = {**self.target, 'expected': {'priority': '慣れた加工'}}
        self.assertEqual(module.decode('波形を見たい。', other), module.decode('波形を見たい。', self.target))
