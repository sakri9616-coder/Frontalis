"""Preregistered CPU comparisons; test labels never enter model selection."""
import copy
import json
import sys
import time
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.dont_write_bytecode = True
from p3b.data import records, teacher, FUNCTIONS
from p3b.model import arrays, shared_train, select, predict, refit, fit, digest, representation

METHODS = {'linear': 'linear', 'quadratic': 'quadratic', 'memory': 'memory',
           'NPN_adapted8': 'adapted', 'Phase35_frozen16': 'frozen'}
SEEDS = (3601, 3602, 3603)
CONDITIONS = ('linear', 'nonlinear', 'context')


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8')


def metrics(pred, actual, domains):
    opposite = (actual[:, 0] < -.15) & (actual[:, 1] > .15)
    ranks = [[], [], []]
    for domain in range(4):
        idx = np.flatnonzero(domains == domain); left, right = idx[::2], idx[1::2]
        left = left[:len(right)]
        for head in range(3):
            ranks[head].extend(((pred[left, head] > pred[right, head]) ==
                                (actual[left, head] > actual[right, head])).tolist())
    return {'mse': float(np.mean((pred - actual)**2)),
            'functionMSE': np.mean((pred - actual)**2, axis=0).tolist(),
            'oppositeCases': int(opposite.sum()),
            'oppositeSignAccuracy': float(np.mean((pred[opposite, 0] < 0) & (pred[opposite, 1] > 0))) if opposite.any() else None,
            'withinDomainPairRankAgreement': [float(np.mean(v)) for v in ranks],
            'negativeIntensityCount': int((pred[:, 4] < 0).sum()),
            'intensityRange': [float(pred[:, 4].min()), float(pred[:, 4].max())]}


def main():
    start = time.perf_counter(); rows = []; curves = []; saved = {}; information = []
    frozen_copy = ROOT / 'models/frozen-phase35.json'
    frozen_source = frozen_copy if frozen_copy.exists() else ROOT.parent / 'nephia-phase35-lab/models/shared-3501.json'
    old = json.loads(frozen_source.read_text(encoding='utf8'))
    save(ROOT / 'models/frozen-phase35.json', old)
    raw_decoder = []
    for seed in SEEDS:
        shared = shared_train(seed, 8); save(ROOT / f'models/shared-{seed}.json', shared)
        if seed == SEEDS[0]: save(ROOT / 'models/shared.json', shared)
        for condition in CONDITIONS:
            for person in range(4):
                train = records(seed, person, condition, 'train', 48)
                val = records(seed, person, condition, 'validation', 16)
                test = records(seed, person, condition, 'test', 96)
                splitsets = [set(e['id'] for e in split) for split in (train, val, test)]
                assert not splitsets[0] & splitsets[1] and not splitsets[0] & splitsets[2] and not splitsets[1] & splitsets[2]
                folder = ROOT / f'data/{seed}-{condition}/series-{person}'
                for filename, split in [('train.json', train), ('validation.json', val), ('evaluation-only.json', test)]:
                    save(folder / filename, split)
                x, d, y = arrays(test); models = {}
                for method, kind in METHODS.items():
                    model = select(train, val, kind, shared, old); models[method] = model
                    prediction = predict(model, x, d)
                    save(ROOT / f'models/{seed}-{condition}-p{person}-{method}.json', model)
                    rows.append({'seed': seed, 'condition': condition, 'person': person, 'method': method,
                                 **metrics(prediction, y, d), 'prediction': prediction.tolist(),
                                 'config': model['validationSelection']['config']})
                    for count in (0, 8, 24, 48):
                        curve_model = refit(model, train[:count])
                        curves.append({'seed': seed, 'condition': condition, 'person': person, 'method': method,
                                       'experienceCount': count, **metrics(predict(curve_model, x, d), y, d)})
                    if kind != 'memory':
                        raw = fit(train, kind, shared, old, model['regularization'], bounded=False)
                        rp = predict(raw, x, d)
                        raw_decoder.append({'seed': seed, 'condition': condition, 'person': person, 'method': method,
                            'signedHeadsMaxChange': float(np.max(np.abs(rp[:, :4] - prediction[:, :4]))),
                            'rawNegativeCount': int((rp[:, 4] < 0).sum()), 'rawIntensityMSE': float(np.mean((rp[:, 4] - y[:, 4])**2)),
                            'boundedNegativeCount': int((prediction[:, 4] < 0).sum()),
                            'boundedIntensityMSE': float(np.mean((prediction[:, 4] - y[:, 4])**2))})
                if person == 0:
                    hx, hd, _ = arrays(train)
                    for method in ('Phase35_frozen16', 'NPN_adapted8'):
                        m = models[method]
                        h = representation(m['kind'], m['shared'], hx, hd, m['old'])
                        q = representation(m['kind'], m['shared'], x, d, m['old'])
                        decoder = np.linalg.solve(h.T @ h + .03 * np.eye(h.shape[1]), h.T @ hx)
                        information.append({'seed': seed, 'condition': condition, 'method': method,
                                            'unseenInputReconstructionMSE': float(np.mean((q @ decoder - x)**2))})
                if seed == SEEDS[0] and condition == 'context':
                    saved[person] = models
                    save(ROOT / f'models/live-p{person}.json', models['NPN_adapted8'])
                    save(ROOT / f'data/live-p{person}.json', train)
            print(json.dumps({'seed': seed, 'condition': condition, 'complete': True}), flush=True)
    summary = {}
    for condition in CONDITIONS:
        summary[condition] = {}
        for method in METHODS:
            selected = [r for r in rows if r['condition'] == condition and r['method'] == method]
            count = sum(r['oppositeCases'] for r in selected)
            summary[condition][method] = {
                'mse': float(np.mean([r['mse'] for r in selected])),
                'functionMSE': np.mean([r['functionMSE'] for r in selected], axis=0).tolist(),
                'withinDomainPairRankAgreement': np.mean([r['withinDomainPairRankAgreement'] for r in selected], axis=0).tolist(),
                'oppositeCases': count,
                'oppositeSignAccuracy': sum(r['oppositeCases'] * (r['oppositeSignAccuracy'] or 0) for r in selected) / max(count, 1)}
    interventions = []; causal = []; baseline_predictions = []; semantics = []
    for person in range(4):
        models = saved[person]; original = models['NPN_adapted8']['experiences']
        x, d, y = arrays(records(SEEDS[0], person, 'context', 'test', 96))
        baseline_predictions.append(predict(models['NPN_adapted8'], x, d))
        ids = [i for i, e in enumerate(original) if e['domain'] == 0][:3]
        removal = [e for i, e in enumerate(original) if i not in ids]
        correction = copy.deepcopy(original)
        for i in ids:
            correction[i]['y'][0] *= -1
            correction[i]['text'] += '研究用訂正：好き嫌いの記録だけを反転した。'
            if 'observations' in correction[i]: correction[i]['observations']['選好'] = correction[i]['y'][0]
        exchange = copy.deepcopy(original)
        for i in ids:
            exchange[i] = copy.deepcopy(saved[(person + 1) % 4]['NPN_adapted8']['experiences'][i])
            exchange[i]['sourceIntervention'] = 'experience-exchange'
        added = records(SEEDS[0], person, 'context', 'added', 24, updated=True, domain_only=2)
        unrelated = records(SEEDS[0], person, 'context', 'irrelevant', 12, domain_only=0)
        variants = {'remove_sound': removal, 'correct_preference': correction, 'exchange_sound': exchange,
                    'reverse_order': list(reversed(original)), 'add_exploration': original + added,
                    'add_unrelated_sound': original + unrelated}
        new_truth = teacher(SEEDS[0], person, 'context', x, d, updated=True)
        for method, model in models.items():
            before = predict(model, x, d)
            for name, experiences in variants.items():
                new = refit(model, experiences); after = predict(new, x, d); delta = after - before
                result = {'person': person, 'method': method, 'intervention': name,
                          'beforeStateHash': digest(model), 'afterStateHash': digest(new),
                          'meanAbsoluteChange': float(np.mean(np.abs(delta))),
                          'domainFunctionChange': {str(i): np.mean(np.abs(delta[d == i]), axis=0).tolist() for i in range(4)},
                          'domainFunctionMSEBefore': {str(i): np.mean((before[d == i] - y[d == i])**2, axis=0).tolist() for i in range(4)},
                          'domainFunctionMSEAfterOriginalTeacher': {str(i): np.mean((after[d == i] - y[d == i])**2, axis=0).tolist() for i in range(4)}}
                if name == 'add_exploration':
                    changed = np.abs(new_truth - y) > .15
                    result.update({'changedTargetBeforeMSE': float(np.mean((before[changed] - new_truth[changed])**2)),
                                   'changedTargetAfterMSE': float(np.mean((after[changed] - new_truth[changed])**2)),
                                   'retainedMeanChange': float(np.mean(np.abs(delta[~changed]))),
                                   'correctDeltaDirection': float(np.mean(np.sign(delta[changed]) == np.sign((new_truth - y)[changed])))})
                interventions.append(result)
                if method == 'NPN_adapted8':
                    save(ROOT / f'models/interventions/p{person}-{name}.json', new)
                    if person == 0 and name == 'add_exploration': save(ROOT / 'models/live-p0-added.json', new)
                    if person == 0 and name == 'add_unrelated_sound': save(ROOT / 'models/live-p0-unrelated.json', new)
        model = models['NPN_adapted8']; base = predict(model, x, d)
        paraphrase = copy.deepcopy(original)
        for e in paraphrase: e['text'] = '別の言い方に置き換えた研究用の同一経験。' + e['text']
        unchanged = refit(model, paraphrase)
        # Meaning annotations are a separate input. This is NOT an automatic
        # understanding test: its purpose is to expose dependence on annotations.
        changed_meaning = copy.deepcopy(original)
        for i in ids: changed_meaning[i]['x'][1] *= -1
        altered = refit(model, changed_meaning)
        semantics.append({'person': person,
                          'textOnlyMaxPredictionChange': float(np.max(np.abs(predict(unchanged, x, d) - base))),
                          'annotationOnlyMeanPredictionChange': float(np.mean(np.abs(predict(altered, x, d) - base))),
                          'limitation': 'Text is not encoded by the learner; semantic annotation changes are externally supplied.'})
        if person == 0:
            probe = np.array([[.6, .8, -.4, .4, -.7, -.2]])
            reference = predict(model, probe, [0])[0]
            for i, e in enumerate(original):
                after = predict(refit(model, original[:i] + original[i + 1:]), probe, [0])[0]
                effect = reference - after
                causal.append({'experienceId': e['id'], 'sameDomain': e['domain'] == 0,
                              'featureDistance': float(np.linalg.norm(probe[0] - e['x'])),
                              'leaveOneOutEffect': effect.tolist(), 'effectNorm': float(np.linalg.norm(effect))})
    initial = refit(saved[0]['NPN_adapted8'], [])
    save(ROOT / 'models/initial-common.json', initial)
    all_inter_person = [float(np.mean(np.abs(baseline_predictions[i] - baseline_predictions[j])))
                        for i in range(4) for j in range(i)]
    learning_summary = {c: {m: {str(n): float(np.mean([r['mse'] for r in curves if r['condition'] == c and
                                                   r['method'] == m and r['experienceCount'] == n]))
                               for n in (0, 8, 24, 48)} for m in METHODS} for c in CONDITIONS}
    report = {'formatVersion': 1, 'protocol': '3 seeds x 3 teacher conditions x 4 series; train48 validation16 test96',
              'functions': list(FUNCTIONS), 'summary': summary, 'rows': rows,
              'learningCurves': learning_summary, 'formationRows': curves, 'interventions': interventions,
              'causalContributions': causal, 'semanticControls': semantics,
              'informationRetention': information, 'intensityDecoderAblation': raw_decoder,
              'interPersonaMeanDistance': float(np.mean(all_inter_person)),
              'initialOutput': [0, 0, 0, 0, .5], 'initialShortState': [0, 0],
              'initialIntensityNote': '0.5 is a no-data neutral decoder value, not a learned reaction.',
              'elapsedSeconds': time.perf_counter() - start,
              'limits': ['The six semantic annotations are supplied by the synthetic environment, not learned from text.',
                         'Separate domain blocks prevent unrelated-domain drift by construction, but provide no cross-domain transfer.',
                         'Formation prefixes use the fixed validation-selected setting from the 48-experience run.',
                         'Frozen16 versus adapted8 changes latent dimension as well as pretraining; it is not an isolated transfer test.',
                         'Thirty-six runs are repetitions of four series, not thirty-six independently observed people.']}
    save(ROOT / 'reports/numeric.json', report)
    print(json.dumps({'summary': summary, 'seconds': report['elapsedSeconds']}), flush=True)


if __name__ == '__main__': main()
