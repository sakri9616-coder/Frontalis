"""Supplementary, explicitly exploratory matched-capacity and meaning tests.

Added after the primary eight-dimensional result exposed a capacity confound.
No teacher, train/validation split, or evaluation target is changed here.
"""
import json
import sys
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.dont_write_bytecode = True
from p3b.data import semantic_pairs, probes, teacher
from p3b.model import shared_train, select, arrays, predict, representation
sys.path.insert(0, str(ROOT / 'experiments'))
from numeric import save, metrics, SEEDS, CONDITIONS, METHODS


def main():
    rows = []; retention = []; meaning = []; transfer = []
    old = json.loads((ROOT / 'models/frozen-phase35.json').read_text(encoding='utf8'))
    for seed in SEEDS:
        shared = shared_train(seed, 16)
        save(ROOT / f'models/exploratory-shared16-{seed}.json', shared)
        for condition in CONDITIONS:
            for person in range(4):
                directory = ROOT / f'data/{seed}-{condition}/series-{person}'
                train = json.loads((directory / 'train.json').read_text(encoding='utf8'))
                val = json.loads((directory / 'validation.json').read_text(encoding='utf8'))
                test = json.loads((directory / 'evaluation-only.json').read_text(encoding='utf8'))
                x, d, y = arrays(test)
                model = select(train, val, 'adapted', shared, old)
                rows.append({'seed': seed, 'condition': condition, 'person': person,
                             'method': 'exploratory_NPN16', **metrics(predict(model, x, d), y, d)})
                save(ROOT / f'models/exploratory-{seed}-{condition}-p{person}-NPN16.json', model)
                if person == 0:
                    hx, hd, _ = arrays(train)
                    h = representation('adapted', shared, hx, hd)
                    q = representation('adapted', shared, x, d)
                    decoder = np.linalg.solve(h.T @ h + .03 * np.eye(h.shape[1]), h.T @ hx)
                    retention.append({'seed': seed, 'condition': condition, 'method': 'exploratory_NPN16',
                                      'unseenInputReconstructionMSE': float(np.mean((q @ decoder - x)**2))})
        print(json.dumps({'matchedCapacitySeedComplete': seed}), flush=True)
    for person in range(4):
        pairs = semantic_pairs(SEEDS[0], person, 'context', 24)
        for method in METHODS:
            model = json.loads((ROOT / f'models/{SEEDS[0]}-context-p{person}-{method}.json').read_text(encoding='utf8'))
            source, same, changed = [[p[k] for p in pairs] for k in ('original', 'sameMeaning', 'changedMeaning')]
            x, d, y = arrays(source); sx, sd, _ = arrays(same); cx, cd, cy = arrays(changed)
            a, b, c = predict(model, x, d), predict(model, sx, sd), predict(model, cx, cd)
            true_delta = cy - y; pred_delta = c - a; mask = np.abs(true_delta) > .15
            meaning.append({'person': person, 'method': method, 'sameMeaningMaxChange': float(np.max(np.abs(a - b))),
                            'changedMeaningMeanChange': float(np.mean(np.abs(pred_delta))),
                            'substantialTargetDifferences': int(mask.sum()),
                            'semanticDeltaDirectionAgreement': float(np.mean(np.sign(pred_delta[mask]) == np.sign(true_delta[mask])))
                            if mask.any() else None,
                            'sourceAndChangedMSE': float(np.mean(np.concatenate([(a - y)**2, (c - cy)**2])))})
            for probe in probes():
                px = np.asarray([o['x'] for o in probe['options']]); pd = np.asarray([o['domain'] for o in probe['options']])
                actual = teacher(SEEDS[0], person, 'context', px, pd)
                prediction = predict(model, px, pd)
                head = {'preference': 0, 'curiosity': 1, 'priority': 2}[probe['focus']]
                transfer.append({'person': person, 'method': method, 'probe': probe['id'], 'type': probe['type'],
                                 'head': head, 'predictedTop': int(np.argmax(prediction[:, head])),
                                 'teacherTop': int(np.argmax(actual[:, head])),
                                 'topAgreement': bool(np.argmax(prediction[:, head]) == np.argmax(actual[:, head])),
                                 'prediction': prediction.tolist(), 'teacher': actual.tolist()})
    summary = {c: float(np.mean([r['mse'] for r in rows if r['condition'] == c])) for c in CONDITIONS}
    save(ROOT / 'reports/matched-capacity-exploratory.json', {
        'exploratory': True, 'reason': 'Primary NPN8 and frozen16 differ in capacity; equal-dimension NN16 added afterward.',
        'summaryMSE': summary, 'rows': rows, 'informationRetention': retention,
        'limits': ['Pretraining random seed also differs from the frozen Phase 3-A network.',
                   'Both encoders learn numerical reconstruction, not the meaning of Japanese episodes.',
                   'Supplementary NN16 does not replace the preregistered conversational NPN8.']})
    save(ROOT / 'reports/semantic-and-transfer.json', {
        'meaningPairs': meaning, 'transferProbes': transfer,
        'scope': 'Held-out manually annotated semantic contexts; no automatic text interpretation is claimed.',
        'crossDomainNote': 'Cooking is unseen as an activity but mapped to the existing exploration domain and the same six manually annotated axes.'})
    print(json.dumps({'exploratoryNPN16MSE': summary, 'meaningRows': len(meaning), 'transferRows': len(transfer)}))


if __name__ == '__main__': main()
