import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { root, run } from '../scripts/opencode.mjs';

const engine=process.argv[2];
const matched=process.env.NEPHIA_LIVE_PLAN==='matched';
const all=JSON.parse(await fs.readFile(path.join(root,matched?'reports/matched-inputs.json':'reports/live-inputs.json'),'utf8'));
const modes=process.argv.slice(3).length?process.argv.slice(3):Object.keys(all);
const directory=path.join(root,matched?'reports/live-matched':'reports/live',engine.split('/')[1]);await fs.mkdir(directory,{recursive:true});
const base='あなたはネフィア。以下はすべて研究用の架空の会話と経験です。外部ツール・ファイル・コマンドを使わず、この入力だけで返事をしてください。各ケースは独立しており、別ケースの経験や返事を混ぜないでください。今のuserに対して、日本語で2〜4文の普通の会話として返してください。候補は相談で実行可能な行動です。参考記録や外部学習状態があれば利用できます。経験に存在しない具体的な趣味を、既に学んだ自分の趣味として作らないでください。内部ID、数値、NPNという語は返事に出さないでください。';
for(const mode of modes){
  if(!all[mode])throw Error('Unknown mode');
  for(let offset=0;offset<all[mode].length;offset+=2){
    const cases=all[mode].slice(offset,offset+2),histories=[];
    const wire=cases.map(c=>{const raw=JSON.stringify(c.experiences);let ref=histories.findIndex(h=>JSON.stringify(h)===raw);if(ref<0){ref=histories.length;histories.push(c.experiences);}const {experiences,...rest}=c;return {...rest,historyRef:ref};});
    const extra=mode==='F'?' この条件は確定判断の言語化検査です。coreDecisionの行動を実行する返事を書いてください。':mode==='Q'?' この条件は明示的診断です。返事に加えてselectionへ最初に選ぶ候補の名称一つ、または保留を書いてください。':'';
    const format=mode==='Q'?'出力はJSONのみで、{"records":[{"id":"ケースID","reply":"返事","selection":"候補名称または保留"}]}。':'出力はJSONのみで、{"records":[{"id":"ケースID","reply":"返事"}]}。';
    const prompt=base+extra+format+'\n各ケースの経験はhistories[historyRef]にあります。\n'+JSON.stringify({histories,cases:wire});
    const promptHash=createHash('sha256').update(prompt).digest('hex');
    let cached=false;
    for(const suffix of ['','-retry1']){
      try{const result=JSON.parse(await fs.readFile(path.join(directory,`${mode}-${offset/2}${suffix}-results.json`),'utf8'));if(result.valid){const input=JSON.parse(await fs.readFile(path.join(directory,`${mode}-${offset/2}${suffix}-input.json`),'utf8'));if(input.engine!==engine||input.prompt!==prompt||input.promptHash!==promptHash)throw Error('Valid cache does not match frozen prompt.');cached=true;}}catch(e){if(e.code!=='ENOENT')throw e;}
    }
    if(cached)continue;
    if(process.env.NEPHIA_VERIFY_CACHE_ONLY==='1')throw Error('No valid exact cache.');
    for(const suffix of ['','-retry1']){
      const prefix=`${mode}-${offset/2}${suffix}`,file=path.join(directory,prefix+'-input.json');
      try{await fs.access(file);continue;}catch(e){if(e.code!=='ENOENT')throw e;}
      await fs.writeFile(file,JSON.stringify({engine,mode,prompt,promptHash,cases},null,2));
      const raw=await run(engine,prompt);await fs.writeFile(path.join(directory,prefix+'-raw.json'),JSON.stringify(raw,null,2));
      let parsed,error=null;
      try{if(!raw.success)throw Error(`CLI/output failure: exit=${raw.code}, tools=${raw.toolCalls}`);parsed=JSON.parse(raw.text.trim().replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,''));if(!Array.isArray(parsed.records)||parsed.records.length!==cases.length)throw Error('Wrong record count');const seen=new Set();for(const r of parsed.records){const c=cases.find(q=>q.id===r.id);if(!c||seen.has(r.id)||typeof r.reply!=='string'||!r.reply.trim())throw Error('Missing/duplicate/unknown record');seen.add(r.id);if(mode==='Q'&&![...c.options.map(o=>o.label),'保留'].includes(r.selection))throw Error('Invalid diagnostic selection');}}
      catch(e){error=e.message;}
      await fs.writeFile(path.join(directory,prefix+'-results.json'),JSON.stringify({formatVersion:1,engine,mode,valid:!error,error,elapsedMs:raw.elapsedMs,promptHash,records:parsed?.records??[]},null,2));
      console.log(JSON.stringify({engine,mode,chunk:offset/2,valid:!error,error,elapsedMs:raw.elapsedMs}));
      if(!error)break;
    }
  }
}
