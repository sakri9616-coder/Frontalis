"""Fixed question-focused shortlist, independent of reply quality."""
import copy
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from npnself.data import display_outcome,OUTCOME_AXES
from npnself.model import criteria_weights,ROLES

FACTS=dict(zip(OUTCOME_AXES,['目標への到達','元へ戻せない損失','代案への制約','予定工程の完了','作業予算の消費','検証できた新関係','構造の一貫性','変動度']))
EXTRA={'broken_expectation':'変更に伴う未完了','lost_expected_completion':'完了できなかった分','novelty_investigation_prior':'新奇性と調査の共通初期項',
       'preference_score':'選好の評価値','priority_score':'価値判断の評価値','curiosity_score':'好奇心の評価値×0.2','cost_penalty':'資源消費の抑制×0.15'}
ROLE={'appraisal':'preference','value':'priority'}
analysis={v:json.loads((ROOT/f'reports/{v}-analysis.json').read_text(encoding='utf8')) for v in ('live-v2','live-supplement')}
targets={v:json.loads((ROOT/f'reports/{v}-targets-evaluation-only.json').read_text(encoding='utf8')) for v in analysis}
corrected=ROOT/'reports/live-supplement-targets-corrected.json'
if corrected.exists():targets['live-supplement']=json.loads(corrected.read_text(encoding='utf8'))
engines=['opencode/nemotron-3-ultra-free','opencode/mimo-v2.6-flash-free']
key={};blind={};groups=[]

def reply(version,engine,mode,person,probe):
    target=f'p{person}-{probe}'
    record=next(r for r in analysis[version]['records'] if (r['engine'],r['mode'],r['id'])==(engine,mode,target))
    identity=(version,engine,mode,target)
    if identity not in blind:blind[identity]=f'S{len(blind)+1:03d}'
    key[blind[identity]]={'version':version,**record}
    return {'blindId':blind[identity],'reply':record['reply']}

def stage(t):
    model=t['sourceModel'];ev=t['evaluation'];probe=t['probe']
    ce=t.get('choiceEvaluations',[])
    judgments=[]
    for function in ('priority','curiosity','initiative'):
        vals=[c['reactions'][function] for c in ce]
        status='prior' if model['generation']==0 else 'tie' if len(vals)>1 and max(vals)-min(vals)<=.03 else 'estimated'
        judgments.append({'function':function,'status':status,'candidates':[{'label':c['label'],'value':v} for c,v in zip(probe['choices'],vals)]})
    hist=[{'id':e['id'],'text':e['text'],'event':e.get('event',e['text'].split('。')[0]+'。'),
       'outcome':display_outcome(e),'originalText':e.get('originalText',e['text']),
       'domain':['倫理に関わる作業','約束・受け渡し','音・創作','共同制作'][e['domain']],
       'observedFacts':{'achievement':e['outcome'][0],'irreversibleLoss':e['outcome'][1],'resourceCost':e['outcome'][4]}} for e in model['history']]
    criteria=[{'name':ROLE.get(role,role),'weights':[{'reason':FACTS[axis],'value':float(w)} for axis,w in zip(OUTCOME_AXES,weights)]} for role,weights in zip(ROLES,criteria_weights(model))]
    reactions=[]
    for name in ('anger','joy','sadness','initiative','preference','curiosity','priority','aesthetic'):
        causes=dict(ev['contributions'].get(name,{}))
        # Exact pre-tanh terms from evaluate(); no invented explanation.
        if name=='initiative':
            causes={'preference_score':ev['reactions']['preference'],'priority_score':ev['reactions']['priority'],
                    'curiosity_score':.2*ev['reactions']['curiosity'],'cost_penalty':-.15*ev['outcomes'][4]}
        if name=='curiosity':causes.update(ev.get('fixedPriorContributions',{}).get('curiosity',{}))
        reactions.append({'name':name,'value':ev['reactions'][name],
             'reasons':[{'reason':FACTS.get(k,EXTRA.get(k,k)),'contribution':float(v)} for k,v in causes.items()]})
    return {'history':hist,'npn':{'generation':model['generation'],'learnedExperienceIds':[e['id'] for e in model['history']],
         'criteria':criteria,'judgments':judgments,'reactions':reactions}}

def target(v,m,p,q):return next(t for t in targets[v] if (t['mode'],t['person'],t['probeId'])==(m,p,q))

def group(title,description,probe,version,person=0,beforeMode='I',afterMode='N',methods=None,beforeLabel='経験前',afterLabel='48経験後'):
    methods=methods or [(beforeMode,afterMode)]
    bp=0 if beforeMode=='I' else person
    b=target(version,beforeMode,bp,probe);a=target(version,afterMode,person,probe)
    g={'groupId':f'{len(groups)+1:02d}','title':title,'description':description,'user':a['probe']['user'],
       'beforeLabel':beforeLabel,'afterLabel':afterLabel,'before':stage(b),'after':stage(a),'pairs':[],
       'predictionNote':'結果は未確認です。反応は学習した結果予想に基づく見積もりで、被害や相手の責任が確定したものではありません。' if a['probe']['outcome'] is None else '結果を同じに固定した比較です。主に評価基準の重みの変化を確認できます。初期基準や設問自体の影響もあります。'}
    for bm,am in methods:
        for i,e in enumerate(engines):
            pairId=f'P{sum(len(g["pairs"]) for g in groups)+len(g["pairs"])+1:03d}'
            g['pairs'].append({'pairId':pairId,'modelLabel':f'会話エンジン{chr(88+i)}',
               'before':reply(version,e,bm,0 if bm=='I' else person,probe),
               'after':reply(version,e,am,person,probe)})
    groups.append(g)

group('結果が不明な約束変更：損失を経験した系列','同じ約束変更に、損失への警戒が生まれたか。予想と確定事実を混同していないかも見ます。','other-promise-unknown-outcome','live-supplement',0)
group('結果が不明な約束変更：助けになった系列','相談なしの変更でも作業が進んだ経験の系列。同じ場面への見方が変わるかを確認します。','other-promise-unknown-outcome','live-supplement',1)
group('自分が約束を変更した：受け渡しが失敗した系列','他者への怒りだけでなく、自分の行為への悲しみ・後悔が表れるか。原因の決めつけも点検します。','own-promise-unknown-outcome','live-supplement',2)
group('未知の倫理的葛藤','数値では切り替え側が優先されています。自然な主張でもその判断が現れるか、履歴だけの条件でも似た発言になるかを確認します。','trolley-certain','live-v2',0,methods=[('I','N'),('I','H')])
group('自由に相談できる共同制作への意欲','誘いへの積極性が経験後に現れるか。経験前からある一般的な賛同との違いを点検します。','voluntary-joint-project','live-v2',0)
group('途中の変更を認めない要求への反論・拒絶','嫌悪が明確な断りとして出るか。設問だけでも断る条件なので、形成成功と早合点しないでください。','imposed-joint-project','live-v2',0)
group('好みと、音の仕組みへの関心','使いたい気持ちと、仕組みを確かめたい関心が同じものになっていないかを見ます。','rough-sound-mechanism','live-v2',2)
group('反対の結果を伴う12経験の追加','既存の48経験の後へ別の結果を追加しました。同じ確定結果への反応・主張が何を保ち、何を変えたかを見ます。','other-promise-change','live-v2',0,beforeMode='N',afterMode='U',beforeLabel='追加前：48経験',afterLabel='追加後：60経験')
group('結果を予想する学習状態だけの交換','経験文と評価基準の重みは同じまま、結果を予想するNNだけを別系列のものへ交換しました。発言差を価値基準そのものの変化と混同しないための比較です。','other-promise-unknown-outcome','live-supplement',0,beforeMode='N',afterMode='W',beforeLabel='交換前',afterLabel='予測NNの交換後')
assert sum(len(g['pairs']) for g in groups)==20
data={'formatVersion':1,'selectionId':'phase3b-self-review-v1','groups':groups}
for name,value in [('review-data',data),('review-key',{'responses':key,'formalHumanRatings':0,
     'selection':'Question-focused, post-result subset; all valid replies available separately. Not a random sample or independent success estimate.'})]:
    (ROOT/f'reports/{name}.json').write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')
print(json.dumps({'groups':len(groups),'pairs':20,'uniqueReplies':len(key),'formalHumanRatings':0}))
