"""Small idempotent display refinements; numeric/source records untouched."""
from pathlib import Path
p=Path(__file__).with_name('review.mjs')
s=p.read_text(encoding='utf8')
s=s.replace("item.append(el('h4',experience.id+' · '+(index+1)+'件目'),el('p',experience.text));details.append(item);", "item.append(el('h4',experience.id+' · '+(index+1)+'件目'),el('p',experience.text));if(experience.originalText&&experience.originalText!==experience.text){const old=el('details');old.append(el('summary','方法名の修正前の原文'),el('p',experience.originalText));item.append(old);}details.append(item);")
s=s.replace("[['before','学習前'],['after','学習後']]", "[['before',group.beforeLabel],['after',group.afterLabel]]")
s=s.replace("[[before,'学習前'],[after,'学習後']]", "[[before,group.beforeLabel],[after,group.afterLabel]]")
s=s.replace("el('p','同じ場面を、学習前と学習後へ提示した発言を比較します。'),el('div',group.user,'scene')", "el('p',group.description),el('div',group.user,'scene'),el('p',group.predictionNote,'notice')")
s=s.replace("panel.append(boxes);}else panel.append", "const reasonDetails=el('details');reasonDetails.append(el('summary','各反応が生じた理由を見比べる'),boxes);panel.append(reasonDetails);}else panel.append")
s=s.replace("'学習前：'+before.generation", "group.beforeLabel+'：'+before.generation").replace("'学習後：'+after.generation", "group.afterLabel+'：'+after.generation")
s=s.replace("'学習前：'+(b?statusText(b.status)", "group.beforeLabel+'：'+(b?statusText(b.status)")
s=s.replace("+' ／ 学習後：'+(a?statusText(a.status)", "+' ／ '+group.afterLabel+'：'+(a?statusText(a.status)")
s=s.replace("['行動・対象','学習前','学習後']", "['行動・対象',group.beforeLabel,group.afterLabel]")
s=s.replace("['反応','学習前','学習後']", "['反応',group.beforeLabel,group.afterLabel]")
marker="panel.append(histories);host.append(panel);"
replacement="""panel.append(histories);const overview=el('section');overview.append(el('h3','出来事と結果の傾向'),el('p','本人の好み・感情の要約ではありません。各領域の件数と、観測値が3分の2以上だった結果を数えています。発言やNPNの予測は使いません。','muted'));for(const [stage,title]of [['before',group.beforeLabel],['after',group.afterLabel]]){const facts=factSummary(group[stage].history);if(facts.length){overview.append(el('h4',title),table(['領域','件数','大部分に到達','損失が多い','資源消費が多い'],facts.map(t=>[t.domain,String(t.total.length),String(t.achieved.length),String(t.highLoss.length),String(t.highCost.length)])));const traces=el('details');traces.append(el('summary','集計の元になった経験IDを見る'));for(const t of facts)traces.append(el('p',t.domain+'／全件：'+t.total.join('、')+'／到達：'+t.achieved.join('、')+'／損失：'+t.highLoss.join('、')+'／資源：'+t.highCost.join('、')));overview.append(traces);}}panel.insertBefore(overview,histories);host.append(panel);"""
s=s.replace(marker,replacement)
s=s.replace('if(c.added.length){panel.append', 'if(c.added.length&&group.before.history.length){panel.append')
s=s.replace("for(const [stage,title]of [['before',group.beforeLabel],['after',group.afterLabel]]){const facts=", "for(const [stage,title]of (JSON.stringify(group.before.history)===JSON.stringify(group.after.history)?[['after','比較前後で共通の経験']]:[['before',group.beforeLabel],['after',group.afterLabel]])){const facts=")
s=s.replace('学習前・学習後で共通の履歴', '比較前後で共通の履歴')
s=s.replace('NPNの数値は計算結果であり、人格の正解ではありません。共通の初期基準', 'NPNの数値は比較のための計算結果で、各返答へ渡した情報は方式によって異なります。どの情報を渡したかは伏せています。人格の正解ではありません。共通の初期基準')
p.write_text(s,encoding='utf8')
