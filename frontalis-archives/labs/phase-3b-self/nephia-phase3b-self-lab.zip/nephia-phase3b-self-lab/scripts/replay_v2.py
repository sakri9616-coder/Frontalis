"""Replay corrected source metadata into separate states, preserving all weights."""
import json
import sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from npnself.data_v2 import stream,additional
from npnself.model import init,update,evaluate,digest
from npnself.store import validate


def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf8') as file:
        json.dump(value,file,ensure_ascii=False,indent=2,allow_nan=False)


checked=[]
for series in range(4):
    state=init(3711)
    rows=stream(3711,series)
    for e in rows:state=update(state,e)
    old=json.loads((ROOT/f'models/live-p{series}.json').read_text(encoding='utf8'))
    for key in ('world','criteriaLogits','shortReaction','optimizer','generation'):
        assert state[key]==old[key],(series,key)
    validate(state)
    save(ROOT/f'data/v2/series-{series}.json',rows)
    save(ROOT/f'models/v2/live-p{series}.json',state)
    checked.append({'series':series,'oldHash':digest(old),'newHash':digest(state),
                    'numericalParametersExactlyEqual':True,'sourceLedgerChanged':old['ledgerHash']!=state['ledgerHash']})
    if series==0:
        for kind,name in [('reversal','additional-p0'),('unrelated','unrelated-p0')]:
            new=state
            for e in additional(3711,0,kind):new=update(new,e)
            previous=json.loads((ROOT/f'models/{name}.json').read_text(encoding='utf8'))
            for key in ('world','criteriaLogits','shortReaction','optimizer','generation'):
                assert new[key]==previous[key],(name,key)
            validate(new);save(ROOT/f'models/v2/{name}.json',new)
save(ROOT/'reports/v2-state-verification.json',{'series':checked,'appendedStatesExactlyEqual':True,
    'scope':'Narrative-only revision; objective facts, train order, initial state and all numerical parameters unchanged. Old states retained.'})
print(json.dumps({'replayedSeries':4,'appendedStates':2,'allNumericalParametersExactlyEqual':True}))
