"""Non-LLM regression checks, reports their actual exit codes/counts."""
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
env={**os.environ,'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1','NEPHIA_VERIFY_CACHE_ONLY':'1'}
jobs=[('new-core',ROOT,[sys.executable,'-m','unittest','discover','-s','tests','-v']),
      ('new-ui',ROOT,['D:/node.exe','scripts/test_review.cjs']),
      ('prior-core',ROOT.parent/'nephia-phase3b-lab',[sys.executable,'-m','unittest','discover','-s','tests','-v']),
      ('prior-ui',ROOT.parent/'nephia-phase3b-lab',['D:/node.exe','scripts/test_review.cjs'])]
for version in ('live-v2','live-supplement'):
    for engine in ('opencode/nemotron-3-ultra-free','opencode/mimo-v2.6-flash-free'):
        jobs.append((version+'-'+engine.split('/')[1],ROOT,['D:/node.exe','experiments/live.mjs',engine]))
results=[]
for name,cwd,args in jobs:
    jobenv=dict(env)
    if name.startswith('live-'):jobenv['NEPHIA_LIVE_PLAN']='live-supplement' if name.startswith('live-supplement') else 'live-v2'
    t=time.perf_counter();r=subprocess.run(args,cwd=cwd,env=jobenv,capture_output=True,text=True,encoding='utf8')
    output=r.stdout+r.stderr
    count=re.search(r'Ran (\d+) tests?|\n(\d+) tests passed',output)
    results.append({'name':name,'command':args,'cwd':str(cwd),'exitCode':r.returncode,
           'tests':int(next(v for v in count.groups() if v)) if count else None,
           'elapsedSeconds':time.perf_counter()-t,'output':output})
    print(json.dumps({k:v for k,v in results[-1].items() if k not in ('command','cwd','output')}),flush=True)
(ROOT/'reports/test-verification.json').write_text(json.dumps({'externalCalls':0,'jobs':results},ensure_ascii=False,indent=2),encoding='utf8')
assert all(r['exitCode']==0 for r in results)
