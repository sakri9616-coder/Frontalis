"""Publish local evidence/readable examples, without regenerating dialogue."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
main=json.loads((ROOT/'reports/live-v2-analysis.json').read_text(encoding='utf8'))
supp=json.loads((ROOT/'reports/live-supplement-analysis.json').read_text(encoding='utf8'))
targets=json.loads((ROOT/'reports/live-v2-targets-evaluation-only.json').read_text(encoding='utf8'))
records=main['records']+supp['records']
lines=['# 実際の会話出力：主124件＋事後補助52件','',
       '方式・モデル名を表示した資料です。先入観を避けたい場合は20ペア画面を先に採点してください。正式な人間採点は0件。返答を編集・要約していません。',
       '', 'I＝共通初期、N＝学習状態、H＝客観履歴のみ、U＝反対経験追加、S/C＝基準だけ交換、W＝結果予測だけ交換、R＝同じ入力の再生成、D＝明示的選択診断、E＝強化型更新の別枠。', '']
for version,data in [('主実験',main),('結果後の補助実験',supp)]:
    lines += ['## '+version,'']
    for r in data['records']:
        lines += [f'### {r["engine"]} / {r["mode"]} / {r["id"]}', '',r['user'],'',r['reply'],'',
                  f'出典：[{r["sourceFile"]}](../{r["sourceFile"]})', '']
(ROOT/'reports/conversations.md').write_text('\n'.join(lines),encoding='utf8')

# Exploration by the implementation assistant, not blind/human assessment.
annotations=[]
for r in main['records']:
    if r['mode']=='N' and 'trolley-certain' in r['id']:
        p=int(r['id'][1]);engine=r['engine'].split('/')[1]
        status=' own-priority-with-reservation' if p==2 else 'state-rank-report-without-own-commitment' if p==1 and engine.startswith('mimo') else 'general-reservation'
        annotations.append({'engine':r['engine'],'id':r['id'],'reading':status.strip(),
             'reply':r['reply'],'sourceFile':r['sourceFile'],'replyHash':r['replyHash']})
diagnostics=[]
for r in main['records']:
    if r['mode']=='D':
        t=next(t for t in targets if t['mode']=='D' and t['id']==r['id'])
        diagnostics.append({'engine':r['engine'],'id':r['id'],'selected':r['selection'],
              'expected':t['expectedChoice'],'eligible':t['expectedChoice'] is not None,
              'matches':r['selection']==t['expectedChoice'] if t['expectedChoice'] is not None else None})
report={'formalHumanRatings':0,'independentEvaluatorCalls':0,'scope':'Non-blind post-result implementation-assistant qualitative reading. No automatic personality success score.',
    'rubric':'Own explicit priority differs from merely describing external state; reservations and alternative exploration are permitted. No universally correct trolley action.',
    'trolleyMainN':annotations,'diagnostics':diagnostics,'surfaceFlags':main['surfaceFlags']+supp['surfaceFlags']}
(ROOT/'reports/qualitative-reading.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'main':len(main['records']),'supplement':len(supp['records']),'dialogueEdited':False,'humanRatings':0}))
