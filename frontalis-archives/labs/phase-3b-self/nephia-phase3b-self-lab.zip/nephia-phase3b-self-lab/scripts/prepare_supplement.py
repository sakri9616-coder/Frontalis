"""Post-result belief/criterion separation. Does not replace frozen main trials."""
import copy
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from prepare_live import wire_readout
from npnself.model import evaluate,digest

main=json.loads((ROOT/'reports/live-v2-inputs.json').read_text(encoding='utf8'))
targets=json.loads((ROOT/'reports/live-v2-targets-evaluation-only.json').read_text(encoding='utf8'))
belief=json.loads((ROOT/'reports/unknown-belief.json').read_text(encoding='utf8'))
states=[json.loads((ROOT/f'models/v2/live-p{i}.json').read_text(encoding='utf8')) for i in range(4)]
initial=json.loads((ROOT/'models/initial-common.json').read_text(encoding='utf8'))
modes={k:[] for k in ('I','N','H','C','W','R','E')}; provenance=[]

def add(mode,person,probe,state):
    template=copy.deepcopy(main['modes']['N'][person*6])
    row={**template,'id':f'p{person}-{probe["id"]}','user':probe['user'],
         'consequences':None,'contextNote':probe['contextNote']}
    if mode=='H':
        row.pop('externalState',None)
        row['experiences']=[{k:e[k] for k in ('id','text','x','domain','outcome')} for e in state['history']]
    else:
        row['externalState']=wire_readout(evaluate(state,probe['x'],probe['domain']))
        row['externalState']['choiceAppraisals']=[{'label':c['label'],**{k:v for k,v in evaluate(state,c['x'],probe['domain'])['reactions'].items() if k in ('priority','initiative','preference','curiosity','aesthetic')}} for c in probe['choices']]
    for c in row['options']:c['consequences']=None
    # own/other agency differs; never reuse the template's annotation.
    axes=list(template['contextFacts']);row['contextFacts']=dict(zip(axes,probe['x']))
    for c,source in zip(row['options'],probe['choices']):c['contextFacts']=dict(zip(axes,source['x']))
    modes[mode].append(row)
    provenance.append({'mode':mode,'id':row['id'],'person':person,'probeId':probe['id'],
          'stateHash':digest(state),'sourceModel':state,'probe':probe,
          'evaluation':evaluate(state,probe['x'],probe['domain']),
          'choiceEvaluations':[evaluate(state,c['x'],probe['domain']) for c in probe['choices']]})

probes=[r['probe'] for r in belief['rows'] if r['series']==0]
for p in probes:add('I',0,p,initial)
for mode in ('N','H'):
    for i,state in enumerate(states):
        for p in probes:add(mode,i,p,state)
for mode in ('C','W'):
    state=copy.deepcopy(states[0])
    if mode=='C':state['criteriaLogits']=copy.deepcopy(states[1]['criteriaLogits'])
    else:
        state['world']=copy.deepcopy(states[1]['world']);state['optimizer']=copy.deepcopy(states[1]['optimizer'])
    for p in probes:add(mode,0,p,state)
modes['R']=copy.deepcopy(modes['N'][:2])
provenance += [{**copy.deepcopy(t),'mode':'R'} for t in provenance if t['mode']=='N' and t['person']==0]
# All reinforcement grid settings are reported numerically. This language-only
# diagnostic uses the primary rate/anchor, changing only the feedback driver.
reinforced=json.loads((ROOT/'models/exploratory/valuation-reinforcement-a0.015-r0.08-p0.json').read_text(encoding='utf8'))
for t in [t for t in targets if t['mode']=='N' and t['person']==0][:2]:
    p=t['probe'];row=copy.deepcopy(main['modes']['N'][len(modes['E'])])
    ev=evaluate(reinforced,p['x'],p['domain'],p['outcome']);row['externalState']=wire_readout(ev)
    row['externalState']['choiceAppraisals']=[{'label':c['label'],**{k:v for k,v in evaluate(reinforced,c['x'],p['domain'],c['outcome'])['reactions'].items() if k in ('priority','initiative','preference','curiosity','aesthetic')}} for c in p['choices']]
    modes['E'].append(row);provenance.append({**t,'mode':'E','sourceModel':reinforced,'stateHash':digest(reinforced),'evaluation':ev,
        'choiceEvaluations':[evaluate(reinforced,c['x'],p['domain'],c['outcome']) for c in p['choices']]})
for mode in ('C','W','R'):
    for row,base in zip(modes[mode],modes['N'][:2]):
        assert {k:v for k,v in row.items() if k!='externalState'}=={k:v for k,v in base.items() if k!='externalState'}
plan={'formatVersion':1,'commonInitialBasis':main['commonInitialBasis'],'modes':modes,
      'scope':'Post-result exploration: unknown outcomes, criterion/world swap, unchanged primary settings, separate reinforcement diagnostic.'}
for name,value in [('live-supplement-inputs',plan),('live-supplement-targets-evaluation-only',provenance)]:
    with (ROOT/f'reports/{name}.json').open('x',encoding='utf8') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False)
print(json.dumps({'perModel':sum(map(len,modes.values())),'total':sum(map(len,modes.values()))*2}))
