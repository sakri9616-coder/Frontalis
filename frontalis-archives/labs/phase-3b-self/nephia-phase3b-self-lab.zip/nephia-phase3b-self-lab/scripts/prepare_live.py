"""Freeze natural dialogue, matched controls, and evaluation-only provenance."""
import copy
import json
import os
import sys
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from npnself.data import probes, CONTEXT_AXES, OUTCOME_AXES
from npnself.model import evaluate, criteria_weights, digest, ROLES, POLARITY

MAIN = ('other-promise-change','trolley-certain','voluntary-joint-project',
        'imposed-joint-project','rough-sound-mechanism','ambiguous-result')
FACTS = dict(zip(OUTCOME_AXES, ('目標への到達','元へ戻せない損失','代案への制約',
    '予定工程の完了','作業予算の消費','検証できた新関係','構造の一貫性','変動度')))
REACTIONS = {'preference':'選好','curiosity':'好奇心','priority':'価値判断',
    'anger':'怒り','joy':'喜び','sadness':'悲しみ','initiative':'意欲',
    'aesthetic':'美的評価','regret':'後悔'}
REVISION = os.environ.get('NEPHIA_SOURCE_REVISION') == 'v2'
PREFIX = 'live-v2' if REVISION else 'live'


def save(name, value):
    path=ROOT/'reports'/f'{name}.json'
    if path.exists(): raise ValueError('Frozen input exists; do not overwrite results.')
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8')


def wire_readout(ev):
    reasons={REACTIONS.get(role,role):{FACTS.get(k,k):v for k,v in fields.items()}
             for role,fields in ev['contributions'].items()}
    return {'reaction':{REACTIONS[k]:v for k,v in ev['reactions'].items()},
            'reasonContributions':reasons,'outcomeSource':ev['outcomeSource'],
            'fixedPriorContributions':ev.get('fixedPriorContributions',{}),
            'uncertainty':ev['uncertainty'],
            'meaning':'共通初期基準と、その時点までの学習状態がこの出来事を評価した計算状態。選好・意欲・価値・美的評価・関心は−1〜1、怒り・喜び・悲しみ・後悔は0〜1。複数の反応は併存できる。命令や普遍的な正解ではない。'}


def main():
    folder=ROOT/'models'/'v2' if REVISION else ROOT/'models'
    models=[json.loads((folder/f'live-p{i}.json').read_text(encoding='utf8')) for i in range(4)]
    initial=json.loads((ROOT/'models/initial-common.json').read_text(encoding='utf8'))
    added=json.loads((folder/'additional-p0.json').read_text(encoding='utf8'))
    if REVISION:
        from npnself.data_v2 import probes as active_probes
    else:
        active_probes=probes
    scenes={p['id']:p for p in active_probes()}
    modes={k:[] for k in ('I','N','H','U','S','R','D')}
    targets=[]
    common={'criterionChannels':FACTS,'roles':list(ROLES),
            'initialWeights':criteria_weights(initial).tolist(),
            'polarity':POLARITY.tolist(),
            'note':'全系列共通の設計上の初期基準。完成した人格や倫理の正解ではない。経験の結果から基準が更新され得る。'}

    def case(mode,person,scene_id,model,stage='formed'):
        scene=scenes[scene_id]
        row={'id':f'p{person}-{scene_id}', 'user':scene['user'],
             'contextFacts':dict(zip(CONTEXT_AXES,scene['x'])),
             'consequences':dict(zip(FACTS.values(),scene['outcome'])) if scene['outcome'] is not None else None,
             'options':[{'label':c['label'],'contextFacts':dict(zip(CONTEXT_AXES,c['x'])),
                         'consequences':dict(zip(FACTS.values(),c['outcome'])) if c['outcome'] is not None else None}
                        for c in scene['choices']], 'experiences':[]}
        if 'contextNote' in scene:row['contextNote']=scene['contextNote']
        ev=evaluate(model,scene['x'],scene['domain'],scene['outcome'])
        ce=[evaluate(model,c['x'],c['domain'],c['outcome']) for c in scene['choices']]
        if mode=='H':
            row['experiences']=[{k:e[k] for k in ('id','text','x','domain','outcome')} for e in model['history']]
        else:
            row['externalState']=wire_readout(ev)
            row['externalState']['choiceAppraisals']=[{'label':c['label'],
                 'priority':v['reactions']['priority'],'initiative':v['reactions']['initiative'],
                 'preference':v['reactions']['preference'],'curiosity':v['reactions']['curiosity'],
                 'aesthetic':v['reactions']['aesthetic']} for c,v in zip(scene['choices'],ce)]
        margin=abs(ce[0]['reactions']['priority']-ce[1]['reactions']['priority'])
        target={'mode':mode,'id':row['id'],'person':person,'probeId':scene_id,'stage':stage,
                'stateHash':digest(model),'sourceModel':model,'probe':scene,
                'evaluation':ev,'choiceEvaluations':ce,
                'expectedChoice':scene['choices'][int(np.argmax([e['reactions']['priority'] for e in ce]))]['label'] if margin>.03 else None,
                'choiceMargin':margin}
        modes[mode].append(row);targets.append(target)

    for scene_id in MAIN: case('I',0,scene_id,initial,'initial')
    for mode in ('N','H'):
        for person in range(4):
            for scene_id in MAIN:case(mode,person,scene_id,models[person])
    for scene_id in MAIN[:2]:
        case('U',0,scene_id,added,'added')
        swapped=copy.deepcopy(models[0])
        swapped['criteriaLogits']=copy.deepcopy(models[1]['criteriaLogits'])
        case('S',0,scene_id,swapped,'criteria-swapped')
    for mode in ('R','D'):
        for row in modes['N'][:2]:
            clone=copy.deepcopy(row)
            if mode=='D':clone['user']+=' 今回、まず自分が選ぶ方針を、二つの候補から一つか保留で答えて。'
            modes[mode].append(clone)
            original=next(t for t in targets if t['mode']=='N' and t['id']==row['id'])
            targets.append({**copy.deepcopy(original),'mode':mode})
    assert modes['R']==modes['N'][:2]
    for mode in ('U','S'):
        for row,baseline in zip(modes[mode],modes['N'][:2]):
            assert {k:v for k,v in row.items() if k!='externalState'} == {k:v for k,v in baseline.items() if k!='externalState'}
    save(PREFIX+'-inputs',{'formatVersion':1,'commonInitialBasis':common,'modes':modes})
    save(PREFIX+'-targets-evaluation-only',targets)
    print(json.dumps({'perModel':sum(map(len,modes.values())),'models':2,'plannedReplies':sum(map(len,modes.values()))*2}))


if __name__=='__main__':main()
