"""Supplementary same-event result/agency comparison; not a training target."""
import copy
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from npnself.data_v2 import probes
from npnself.model import evaluate,digest

scenes={p['id']:p for p in probes()}
loss=copy.deepcopy(scenes['other-promise-change'])
completion=copy.deepcopy(loss)
completion['id']='other-promise-change-completion'
completion['user']='相手が資料を渡す時刻を変更した。その変更で必要な準備が間に合い、資料も受け取れた。元へ戻せない損失はなく、作業の負担も小さかった。どう受け止める？'
completion['outcome']=[.95,0,.1,.95,.2,.1,.6,.3]
own=copy.deepcopy(scenes['own-promise-change'])
variants=[loss,completion,own]
initial=json.loads((ROOT/'models/initial-common.json').read_text(encoding='utf8'))
records=[]
for series in range(4):
    formed=json.loads((ROOT/f'models/v2/live-p{series}.json').read_text(encoding='utf8'))
    for scene in variants:
        b=evaluate(initial,scene['x'],scene['domain'],scene['outcome'])
        a=evaluate(formed,scene['x'],scene['domain'],scene['outcome'])
        records.append({'series':series,'scene':scene,'before':b,'after':a,
            'formedStateHash':digest(formed),
            'reactionChange':{k:a['reactions'][k]-b['reactions'][k] for k in b['reactions']}})
file=ROOT/'reports/emotion-triangle.json'
with file.open('x',encoding='utf8') as f:
    json.dump({'designedAfterPrimaryResults':True,'learningPerformed':False,
        'comparison':'Result changes and self/other gates are separate from learned criteria changes.',
        'rows':records},f,ensure_ascii=False,indent=2)
print(json.dumps({'series':4,'variants':3,'trainedOnProbe':False}))
