"""Correct evaluation-only E metadata; frozen prompts/replies stay unchanged."""
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from npnself.model import evaluate
original=ROOT/'reports/live-supplement-targets-evaluation-only.json'
data=json.loads(original.read_text(encoding='utf8'))
for t in data:
    if t['mode']=='E':
        t['choiceEvaluations']=[evaluate(t['sourceModel'],c['x'],t['probe']['domain'],c['outcome']) for c in t['probe']['choices']]
        t['metadataCorrection']='E choiceEvaluations recomputed from the recorded reinforced state. Prompt choiceAppraisals were already correct. Original file retained.'
with (ROOT/'reports/live-supplement-targets-corrected.json').open('x',encoding='utf8') as f:json.dump(data,f,ensure_ascii=False,indent=2)
print('Corrected 2 E evaluation records; no prompt, reply or model changed.')
