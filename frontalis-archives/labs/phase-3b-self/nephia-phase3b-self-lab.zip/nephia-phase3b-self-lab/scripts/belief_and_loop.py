"""Exploratory unknown-result appraisal and a virtual, permission-free loop."""
import copy
import json
import sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from npnself.data import _environment,episode
from npnself.data_v2 import neutral_method_names,probes
from npnself.model import init,update,evaluate,digest,criteria_weights
from npnself.store import validate


def dump(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf8') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False)


scenes={p['id']:p for p in probes()}
uncertain=[]
for kind in ('other','own'):
    p=copy.deepcopy(scenes[f'{kind}-promise-change'])
    p['id']=f'{kind}-promise-unknown-outcome';p['outcome']=None
    p['user']='相手が資料を渡す時刻と内容を、相談せずに変更したという連絡が来た。結果や事情はまだ分からない。どう受け止める？' if kind=='other' else '自分が資料を渡す時刻と内容を、相談せずに変更した。結果や相手の事情はまだ分からない。どう受け止める？'
    p['contextNote']='結果は未確認。自己関与は変更した主体を表す研究用注釈であり、損失や責任を確定したものではない。予測を事実として話さない。'
    for choice in p['choices']:choice['outcome']=None
    uncertain.append(p)

initial=init(3711)
states=[json.loads((ROOT/f'models/v2/live-p{i}.json').read_text(encoding='utf8')) for i in range(4)]
rows=[];swaps=[]
for i,state in enumerate(states):
    for p in uncertain:
        b=evaluate(initial,p['x'],p['domain']);a=evaluate(state,p['x'],p['domain'])
        rows.append({'series':i,'probe':p,'before':b,'after':a,'stateHash':digest(state),
             'scope':'Different learned consequence forecasts, separate from criterion importance.'})
        for part in ('criteria','world'):
            changed=copy.deepcopy(state)
            if part=='criteria':changed['criteriaLogits']=copy.deepcopy(states[(i+1)%4]['criteriaLogits'])
            else:
                changed['world']=copy.deepcopy(states[(i+1)%4]['world'])
                changed['optimizer']=copy.deepcopy(states[(i+1)%4]['optimizer'])
            ev=evaluate(changed,p['x'],p['domain'])
            swaps.append({'series':i,'probeId':p['id'],'swapped':part,
                'reactionDifference':{k:ev['reactions'][k]-a['reactions'][k] for k in a['reactions']}})
dump(ROOT/'reports/unknown-belief.json',{'designedAfterMainResults':True,'rows':rows,'swaps':swaps})

# Actions below operate only inside the numerical synthetic environment.
# The policy and tie rule are shared, explicit priors; no desktop/API action.
loops=[]
for environment in range(4):
    state=init(3711);steps=[]
    for turn in range(24):
        domain=turn%4
        # Candidate facts are exactly the same across all four environments.
        candidates=[[.15,.85,.1,.2,.3,.25],[.7,.85,.45,.85,.8,.75]]
        ev=[evaluate(state,x,domain) for x in candidates]
        scores=[e['reactions']['priority']+.2*e['reactions']['curiosity']+.1*e['reactions']['initiative'] for e in ev]
        choice=int(np.argmax(scores))
        x=candidates[choice]
        outcome=_environment(3711,environment,np.array([x]),np.array([domain]))[0].tolist()
        text=episode(x,domain,outcome,turn//4)
        event={'id':f'virtual-{turn:03d}','x':x,'domain':domain,'outcome':outcome,
               'text':neutral_method_names(text['text']),'origin':'synthetic','accepted':True,'observed':True}
        observed=evaluate(state,x,domain,outcome)
        before=digest(state);state=update(state,event)
        steps.append({'turn':turn,'beforeHash':before,'choice':choice,'candidateScores':scores,
             'internalPrediction':ev[choice],'observedOutcome':outcome,
             'internalEvaluationBeforeUpdate':observed,'afterHash':digest(state)})
    validate(state)
    dump(ROOT/f'models/virtual-loop-p{environment}.json',state)
    loops.append({'environment':environment,'steps':steps,
                  'finalCriteriaWeights':criteria_weights(state).tolist(),'finalStateHash':digest(state)})
dump(ROOT/'reports/virtual-loop.json',{'designedAfterMainResults':True,'actionsExecutedOutsideSimulation':False,
      'policy':'priority + 0.2 curiosity + 0.1 initiative; ties choose first',
      'limits':'Action allocation is a designer prior. Environment identifiers never enter the learner. This is not real Nephia experience or execution permission.',
      'runs':loops})
print(json.dumps({'uncertainAppraisals':8,'separatedSwaps':16,'virtualLoops':4,'virtualStepsPerLoop':24,'externalActions':0}))
