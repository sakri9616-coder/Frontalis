"""Check model exchange, readouts and source links without external calls."""
import json
import sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from npnself.model import evaluate,digest
from npnself.store import validate
checks={'exactModelSwapPrompts':0,'readoutsRecomputed':0,'sourceNarratives':0,'storedModels':0}
states=[json.loads(p.read_text(encoding='utf8')) for p in (ROOT/'models/v2').glob('*.json')]
for state in states:validate(state);checks['storedModels']+=1
for version in ('live-v2','live-supplement'):
    analysis=json.loads((ROOT/f'reports/{version}-analysis.json').read_text(encoding='utf8'))
    assert not analysis['missing']
    a={(r['mode'],r['id']):r['promptHash'] for r in analysis['records'] if 'nemotron' in r['engine']}
    b={(r['mode'],r['id']):r['promptHash'] for r in analysis['records'] if 'mimo' in r['engine']}
    assert a==b;checks['exactModelSwapPrompts']+=len(a)
    path=ROOT/f'reports/{version}-targets-evaluation-only.json'
    corrected=ROOT/'reports/live-supplement-targets-corrected.json'
    if version=='live-supplement' and corrected.exists():path=corrected
    for t in json.loads(path.read_text(encoding='utf8')):
        assert digest(t['sourceModel'])==t['stateHash']
        ev=evaluate(t['sourceModel'],t['probe']['x'],t['probe']['domain'],t['probe']['outcome'])
        for k,v in ev['reactions'].items():assert np.isclose(v,t['evaluation']['reactions'][k],atol=1e-12)
        for c,ce in zip(t['probe']['choices'],t['choiceEvaluations']):
            actual=evaluate(t['sourceModel'],c['x'],t['probe']['domain'],c['outcome'])
            assert actual['reactions']==ce['reactions']
        checks['readoutsRecomputed']+=1
display=json.loads((ROOT/'reports/review-data.json').read_text(encoding='utf8'))
for group in display['groups']:
    for stage in ('before','after'):
        rows=group[stage]['history'];assert len(rows)==len(group[stage]['npn']['learnedExperienceIds'])
        for row in rows:
            candidates=[e for m in states for e in m['history'] if e['id']==row['id']]
            assert any(e['text']==row['text'] and e.get('originalText',e['text'])==row['originalText'] for e in candidates)
            checks['sourceNarratives']+=1
result={'checks':checks,'allPassed':True,'formalHumanRatings':0,'externalCalls':0}
(ROOT/'reports/evidence-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(result,ensure_ascii=False))
