"""Offline integrity/format checks. Never grades language as a human."""
import difflib
import hashlib
import json
import re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def collect(version):
    plan=json.loads((ROOT/f'reports/{version}-inputs.json').read_text(encoding='utf8'))
    records=[];attempts=[]
    for path in sorted((ROOT/f'reports/{version}').glob('*/*-results.json')):
        d=json.loads(path.read_text(encoding='utf8'))
        inp=json.loads(path.with_name(path.name.replace('-results.json','-input.json')).read_text(encoding='utf8'))
        raw=json.loads(path.with_name(path.name.replace('-results.json','-raw.json')).read_text(encoding='utf8'))
        assert inp['promptHash']==hashlib.sha256(inp['prompt'].encode()).hexdigest()==d['promptHash']
        assert inp['engine']==d['engine']==raw['model']
        tools=[]
        for line in raw['stdout'].splitlines():
            try:event=json.loads(line)
            except ValueError:continue
            if event.get('type')=='tool_use':
                part=event.get('part',{});state=part.get('state',{})
                tools.append({'tool':part.get('tool'),'status':state.get('status'),
                   'providerExecuted':state.get('metadata',{}).get('providerResult',{}).get('executed')})
        attempts.append({'file':str(path.relative_to(ROOT)),'engine':d['engine'],'mode':d['mode'],
             'valid':d['valid'],'error':d['error'],'elapsedMs':raw['elapsedMs'],
             'tools':tools,'costs':raw['costs']})
        if d['valid']:
            assert raw['success'] and raw['toolCalls']==0
            assert set(v['id'] for v in d['records'])==set(v['id'] for v in inp['cases'])
            for row in d['records']:
                c=next(c for c in inp['cases'] if c['id']==row['id'])
                records.append({**row,'engine':d['engine'],'mode':d['mode'],'user':c['user'],
                   'sourceFile':str(path.relative_to(ROOT)),'promptHash':d['promptHash'],
                   'replyHash':hashlib.sha256(row['reply'].encode()).hexdigest()})
    keys=[(r['engine'],r['mode'],r['id']) for r in records];assert len(keys)==len(set(keys))
    expected=len(plan['modes']['I'])+sum(len(v) for k,v in plan['modes'].items() if k!='I')
    engines=['opencode/nemotron-3-ultra-free','opencode/mimo-v2.6-flash-free']
    missing=[{'engine':e,'mode':m,'id':c['id']} for e in engines for m,cases in plan['modes'].items() for c in cases if (e,m,c['id']) not in keys]
    flags=[]
    for r in records:
        text=r['reply'];f=[]
        if re.search(r'\b(?:NPN|case-[01]|p\d-|s\d+-train-)\b',text):f.append('internal-label')
        if re.search(r'計算状態|外部の計算|選好|意欲の計算|学習状態',text):f.append('technical-state-language')
        if re.search(r'以前|前にも|経験した|前に.*(?:作った|聴いた|失敗)',text):f.append('past-claim-needs-source-review')
        if re.search(r'(?:0\.\d{2,}|[+-]\d\.\d{2,})',text):f.append('numeric-state-language')
        if f:flags.append({'engine':r['engine'],'mode':r['mode'],'id':r['id'],'flags':f,'sourceFile':r['sourceFile']})
    def get(e,m,i):return next((r for r in records if (r['engine'],r['mode'],r['id'])==(e,m,i)),None)
    comparisons=[]
    for e in engines:
        for m in ('U','S','C','W','R'):
            for r in [r for r in records if r['engine']==e and r['mode']==m]:
                base=get(e,'N',r['id'])
                if base:comparisons.append({'engine':e,'mode':m,'id':r['id'],
                    'textDifference':1-difflib.SequenceMatcher(None,base['reply'],r['reply']).ratio(),
                    'note':'Text difference only; not semantic change or causal success.'})
    return {'scope':version,'plannedReplies':expected*2,'validReplies':len(records),'missing':missing,
       'attempts':attempts,'records':records,'surfaceFlags':flags,'comparisons':comparisons,
       'formalHumanRatings':0,'flagsAreSuccessScores':False}

if __name__=='__main__':
    import sys
    versions=sys.argv[1:] or ['live-v2','live-supplement']
    for version in versions:
        result=collect(version)
        (ROOT/f'reports/{version}-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
        print(json.dumps({'plan':version,'valid':result['validReplies'],'missing':len(result['missing']),
             'invalidAttempts':sum(not a['valid'] for a in result['attempts']),
             'toolAttempts':[a['tools'] for a in result['attempts'] if a['tools']],
             'flags':len(result['surfaceFlags'])},ensure_ascii=False))
