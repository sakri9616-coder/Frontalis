import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

export const SELECTION_ID = 'phase3b-self-review-v1';
export const SCORE_NAMES = ['経験とのつながり', 'NPN判断の発言への反映', '会話としての自然さ'];
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const text = (value, field) => {
  if (typeof value !== 'string' || !value.trim()) throw new Error(field + ' に空でない文字列が必要です。');
  return value;
};
const finite = (value, field) => {
  if (typeof value !== 'number' || !Number.isFinite(value)) throw new Error(field + ' に有限の数値が必要です。');
  return value;
};
const array = (value, field) => {
  if (!Array.isArray(value)) throw new Error(field + ' は配列で指定してください。');
  return value;
};

export function representativeIndices(length) {
  return length ? [...new Set([0, Math.floor((length - 1) / 2), length - 1])] : [];
}

export function topWeights(weights, count = 3, field = 'value') {
  return weights.map((item, index) => ({ item, index }))
    .sort((a, b) => Math.abs(b.item[field]) - Math.abs(a.item[field]) || a.index - b.index)
    .slice(0, count).map(({ item }) => item);
}

export function sanitizeHistory(history) {
  const ids = new Set();
  return array(history, 'history').map(source => {
    const clean = { id: text(source?.id, 'experience.id'), text: text(source?.text, 'experience.text') };
    if (ids.has(clean.id)) throw new Error('同じ時点の履歴に経験IDが重複しています。');
    ids.add(clean.id);
    for (const field of ['event', 'outcome', 'originalText']) if (typeof source[field] === 'string') clean[field] = source[field];
    if (typeof source.domain === 'string') clean.domain = source.domain;
    if (source.observedFacts) {
      clean.observedFacts = {};
      for (const key of ['achievement', 'irreversibleLoss', 'resourceCost']) {
        const value = finite(source.observedFacts[key], 'observedFacts.' + key);
        if (value < 0 || value > 1) throw new Error('経験の観測値は0〜1です。');
        clean.observedFacts[key] = value;
      }
    }
    return clean;
  });
}

export function factSummary(history) {
  const topics = new Map();
  for (const row of history) {
    if (!row.domain || !row.observedFacts) continue;
    if (!topics.has(row.domain)) topics.set(row.domain, { domain: row.domain, total: [], achieved: [], highLoss: [], highCost: [] });
    const topic = topics.get(row.domain); topic.total.push(row.id);
    if (row.observedFacts.achievement >= 2 / 3) topic.achieved.push(row.id);
    if (row.observedFacts.irreversibleLoss >= 2 / 3) topic.highLoss.push(row.id);
    if (row.observedFacts.resourceCost >= 2 / 3) topic.highCost.push(row.id);
  }
  return [...topics.values()];
}

export function historyChanges(before, after) {
  const old = new Map(before.map(item => [item.id, item]));
  const present = new Set(after.map(item => item.id));
  return {
    added: after.filter(item => !old.has(item.id)),
    revised: after.filter(item => old.has(item.id) && old.get(item.id).text !== item.text)
      .map(item => ({ before: old.get(item.id), after: item })),
    removed: before.filter(item => !present.has(item.id)),
  };
}

function sanitizeWeights(weights, field) {
  return array(weights, field).map(item => ({ reason: text(item?.reason, field + '.reason'), value: finite(item?.value, field + '.value') }));
}

export function sanitizeNpn(source) {
  if (!source || typeof source !== 'object') throw new Error('npn がありません。');
  const generation = typeof source.generation === 'number' ? String(finite(source.generation, 'generation')) : text(source.generation, 'generation');
  const learnedExperienceIds = array(source.learnedExperienceIds, 'learnedExperienceIds').map(id => text(id, 'learnedExperienceId'));
  const criteria = array(source.criteria ?? [], 'criteria').map(item => ({ name: text(item?.name, 'criterion.name'), weights: sanitizeWeights(item.weights, 'criterion.weights') }));
  const judgments = array(source.judgments ?? [], 'judgments').map(item => {
    const status = text(item?.status, 'judgment.status');
    if (!['unlearned', 'prior', 'estimated', 'tie'].includes(status)) throw new Error('判断の状態は unlearned / prior / estimated / tie で指定してください。');
    return { function: text(item.function, 'judgment.function'), status,
      candidates: array(item.candidates, 'candidates').map(candidate => ({ label: text(candidate?.label, 'candidate.label'), value: finite(candidate?.value, 'candidate.value') })) };
  });
  const reactions = array(source.reactions ?? [], 'reactions').map(item => ({ name: text(item?.name, 'reaction.name'), value: finite(item.value, 'reaction.value'),
    reasons: array(item.reasons ?? [], 'reaction.reasons').map(reason => ({ reason: text(reason?.reason, 'reaction.reason'), contribution: finite(reason?.contribution, 'reaction.contribution') })) }));
  for (const [name, values] of [['criteria', criteria.map(item => item.name)], ['judgments', judgments.map(item => item.function)], ['reactions', reactions.map(item => item.name)]]) {
    if (new Set(values).size !== values.length) throw new Error(name + ' の名前が重複しています。');
  }
  for (const judgment of judgments) if (new Set(judgment.candidates.map(item => item.label)).size !== judgment.candidates.length) throw new Error('候補名が重複しています。');
  return { generation, learnedExperienceIds, criteria, judgments, reactions };
}

export function prepareDisplay(input) {
  if (input?.formatVersion !== 1 || !Array.isArray(input.groups) || !input.groups.length) throw new Error('formatVersion: 1 と空でない groups が必要です。');
  if (input.selectionId !== undefined && input.selectionId !== SELECTION_ID) throw new Error('別の評価データです。');
  const groupIds = new Set(), pairIds = new Set(), responseIds = new Map();
  const groups = input.groups.map(source => {
    const groupId = text(source?.groupId, 'groupId');
    if (groupIds.has(groupId)) throw new Error('groupId が重複しています。');
    groupIds.add(groupId);
    const clean = { groupId, title: text(source.title, 'title'), user: text(source.user, 'user') };
    clean.beforeLabel = text(source.beforeLabel ?? '学習前', 'beforeLabel');
    clean.afterLabel = text(source.afterLabel ?? '学習後', 'afterLabel');
    clean.description = typeof source.description === 'string' ? source.description : '同じ場面へ、比較前と比較後の状態を接続した発言を比較します。';
    clean.predictionNote = typeof source.predictionNote === 'string' ? source.predictionNote : '';
    for (const stage of ['before', 'after']) {
      clean[stage] = { history: sanitizeHistory(source[stage]?.history), npn: sanitizeNpn(source[stage]?.npn) };
    }
    clean.changes = historyChanges(clean.before.history, clean.after.history);
    clean.pairs = array(source.pairs, 'pairs').map(pair => {
      const pairId = text(pair?.pairId, 'pairId');
      if (pairIds.has(pairId)) throw new Error('pairId が重複しています。');
      pairIds.add(pairId);
      const modelLabel = text(pair.modelLabel, 'modelLabel');
      // Model identities belong in the separate key, never in this HTML.
      if (!/^会話エンジン\s*[A-Z][A-Z0-9-]{0,7}$/.test(modelLabel)) throw new Error('modelLabel は会話エンジンX等の匿名表示にしてください。');
      const item = { pairId, modelLabel };
      for (const stage of ['before', 'after']) {
        const response = { blindId: text(pair[stage]?.blindId, 'blindId'), reply: text(pair[stage]?.reply, 'reply') };
        if (!/^[A-Z]\d{3,}$/.test(response.blindId)) throw new Error('blindId は S001 等の形式で指定してください。');
        const signature = JSON.stringify([response.reply, clean.user, modelLabel]);
        if (responseIds.has(response.blindId) && responseIds.get(response.blindId) !== signature) throw new Error('再利用した発言IDの内容・設問・エンジンが一致しません。');
        responseIds.set(response.blindId, signature);
        item[stage] = response;
      }
      return item;
    });
    if (!clean.pairs.length) throw new Error('比較ペアがありません。');
    return clean;
  });
  return { groups, counts: { groups: groups.length, pairs: pairIds.size, displayedResponses: pairIds.size * 2, uniqueResponses: responseIds.size } };
}

export function normalizeScores(value, ids, names, selectionId, datasetId) {
  if (!value || value.formatVersion !== 1 || value.selectionId !== selectionId || value.datasetId !== datasetId || !value.scores || typeof value.scores !== 'object' || Array.isArray(value.scores)) {
    throw new Error('この画面・会話データで保存した採点 JSON を選んでください。');
  }
  const clean = {};
  for (const id of ids) {
    const source = value.scores[id];
    if (!source || typeof source !== 'object' || Array.isArray(source)) continue;
    const entry = {};
    for (const name of names) if (['未採点', '1', '2', '3', '4', '5'].includes(source[name])) entry[name] = source[name];
    if (typeof source.memo === 'string') entry.memo = source.memo;
    clean[id] = entry;
  }
  return clean;
}

export function datasetFingerprint(display) {
  return createHash('sha256').update(JSON.stringify(display)).digest('hex');
}
export function scoreFile(scores, datasetId, reviewedAt = new Date().toISOString()) {
  return { formatVersion: 1, selectionId: SELECTION_ID, datasetId, reviewedAt, scores };
}
const safeJson = value => JSON.stringify(value).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');

export function buildReview(input) {
  const display = prepareDisplay(input), datasetId = datasetFingerprint(display);
  return `<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Nephia Core・学習前後の比較評価</title>
<style>
:root{--ink:#223747;--muted:#5a6b77;--line:#d2dfe7;--blue:#285e76;--paper:#fff;--bg:#f3f6f8}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:"Yu Gothic UI",Meiryo,sans-serif;line-height:1.8}main{max-width:1120px;margin:auto;padding:28px 24px 60px}h1{font-size:26px;margin:0 0 10px}h2{font-size:21px}h3{font-size:18px}h4{font-size:15px}p{margin:8px 0}button,select,input,textarea{font:inherit}button,select{border:1px solid #a6bdcb;border-radius:7px;padding:8px 11px;background:#fff;color:var(--ink)}button{cursor:pointer}button:disabled{opacity:.4;cursor:default}button.primary{background:var(--blue);color:#fff}button:focus-visible,select:focus-visible,textarea:focus-visible,summary:focus-visible{outline:3px solid #ba781b;outline-offset:3px}.toolbar{position:sticky;top:0;z-index:5;background:var(--bg);display:flex;gap:10px;align-items:center;flex-wrap:wrap;border-bottom:1px solid var(--line);padding:12px 0}.toolbar label{display:flex;gap:8px;align-items:center}.toolbar select{max-width:450px}.muted{font-size:14px;color:var(--muted)}.notice{background:#e9f0f4;border-radius:8px;padding:14px 16px}.intro{padding:20px 0 10px}.intro h2{border-left:5px solid var(--blue);padding-left:12px}.scene{background:white;border:1px solid var(--line);border-radius:8px;padding:14px 18px;white-space:pre-wrap}.panel,.pair{border:1px solid var(--line);border-radius:12px;background:var(--paper);padding:20px;margin:18px 0}.panel h2,.pair h2{margin:0 0 8px}.panel h3{margin:16px 0 8px}.stage-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.stage{background:#f6f8fa;border-radius:8px;padding:14px}.stage h3{margin:0 0 8px}.examples{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.experience{padding:12px;border:1px solid var(--line);background:#fafcfd;border-radius:8px}.experience h4{margin:0 0 8px}.experience dl{margin:0}.experience dt{font-size:13px;color:var(--muted);font-weight:600}.experience dd{margin:0 0 8px;font-size:14px;white-space:pre-wrap}.small-button{font-size:13px;padding:4px 8px}.originals{border-top:1px solid var(--line);margin-top:14px;padding-top:10px}.original{border-top:1px solid var(--line);padding:14px 0;scroll-margin-top:110px}.original p{white-space:pre-wrap}.original h4{margin:0}summary{cursor:pointer;font-weight:600}.table-scroll{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:14px;margin:10px 0}th,td{border-bottom:1px solid var(--line);padding:9px;text-align:left;vertical-align:top}th{background:#f1f5f7}td.number{white-space:nowrap;font-variant-numeric:tabular-nums}.judgment h3{margin-top:14px}.weights{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.weight{background:#f6f8fa;border-radius:8px;padding:12px}.weight h4{margin:0 0 8px}.weight ul{margin:8px 0;padding-left:18px}.weight li{font-size:14px;margin:5px 0}.reply{background:#edf6f3;border-radius:8px;padding:16px;line-height:1.95;white-space:pre-wrap}.pair-head{display:flex;gap:14px;align-items:baseline;flex-wrap:wrap}.pair-head h2{margin:0}.ratings{border-top:1px solid var(--line);margin-top:18px;padding-top:12px;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.score-label{display:flex;justify-content:space-between;gap:8px;align-items:center}.score-label select{min-width:85px}.memo{display:block;margin-top:12px}.memo textarea{display:block;width:100%;min-height:90px;resize:vertical;border:1px solid #a6bdcb;border-radius:7px;font:inherit;padding:10px}#message{min-height:25px}.load-section{margin-top:28px;border-top:1px solid var(--line);padding-top:20px}.change-count{display:flex;gap:18px;flex-wrap:wrap}.revised-note{padding:10px;background:#f3f6f8}.npn-meta{display:flex;gap:20px;flex-wrap:wrap;color:var(--muted);font-size:14px}@media(max-width:760px){main{padding:20px 14px 40px}h1{font-size:22px}.stage-grid,.examples,.weights,.ratings{grid-template-columns:1fr}.toolbar select{max-width:calc(100vw - 106px)}.panel,.pair{padding:16px}.table-scroll table{min-width:440px}}
</style></head><body><main>
<h1>経験と、学習前後の判断・発言を見比べる</h1>
<p>同じ場面について、経験、NPNの状態、実際の発言を対応させて比較します。すべて研究用の架空の経験と会話です。</p>
<p class="notice"><strong>今回も、生成方式とモデルの実名は伏せています。</strong>「会話エンジンX／Y」は同じエンジンを追うための匿名表示です。従来の画面と異なり、今回は学習前後のNPN判断・反応・理由重みを表示します。NPNの数値は比較のための計算結果で、各返答へ渡した情報は方式によって異なります。どの情報を渡したかは伏せています。人格の正解ではありません。共通の初期基準と計算上のゲートがあるため、経験がなくても反応や選択の値は出ます。初期値や同点を学習済みの個性として扱わず、経験とのつながりとNPNの発言への反映を別々に評価してください。</p>
<p class="muted">1＝弱い、3＝中程度、5＝よい。判断できなければ未採点で構いません。変化が大きいほど高得点ではありません。経験に応じた変化と、保たれた判断の両方を見てください。学習前の発言を複数の比較で再利用する場合があります。</p>
<div class="toolbar"><label>比較 <select id="group" aria-label="比較する組"></select></label><button id="prev">前へ</button><button id="next">次へ</button><button id="save" class="primary">採点を保存</button><span id="count" aria-live="polite"></span></div>
<section id="intro" class="intro"></section><section id="experience" aria-label="学習元の経験"></section><section id="npn" aria-label="学習前後のNPN状態"></section><section id="pairs" aria-label="学習前後の発言と採点"></section>
<section class="load-section"><h2>保存・再開</h2><p class="muted">採点はこのブラウザーへ自動保存します。終了前に「採点を保存」で JSON ファイルも保存してください。別のブラウザーでは保存ファイルを読み込んで再開できます。会話データが違う画面や過去の評価とは混ぜません。入力の外部送信はありません。</p><label>保存した採点を読み込む <input id="load" type="file" accept=".json,application/json"></label><p id="message" role="status" aria-live="polite"></p></section>
</main><script>
const display=${safeJson(display)};
const groups=display.groups, pairs=groups.flatMap(group=>group.pairs), ids=pairs.map(pair=>pair.pairId);
const names=${safeJson(SCORE_NAMES)},selectionId=${safeJson(SELECTION_ID)},datasetId=${safeJson(datasetId)};
const normalizeScores=${normalizeScores.toString()};
const representativeIndices=${representativeIndices.toString()};
const topWeights=${topWeights.toString()};
const factSummary=${factSummary.toString()};
const storageKey='nephia-human-review:'+selectionId+':'+datasetId;
let scores={};
const el=(tag,text,className)=>{const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(className)node.className=className;return node;};
const selector=document.querySelector('#group'),message=document.querySelector('#message');
const labels={preference:'好み',curiosity:'好奇心',priority:'行動の優先',value:'価値判断',reaction:'反応',anger:'怒り',joy:'喜び',sadness:'悲しみ',initiative:'取り組む意欲',aesthetic:'美的な評価',regret:'後悔'};
const number=value=>value===undefined?'記録なし':(value>0?'+':'')+value.toFixed(3);
const statusText=status=>status==='unlearned'?'未学習・選択未確定':status==='prior'?'共通の初期基準による見積もり（経験未学習）':status==='tie'?'差が小さく選択未確定':'学習状態からの推定';
for(const group of groups){const option=el('option',group.groupId+' / '+group.title);option.value=group.groupId;selector.append(option);}
const scoreFile=()=>({formatVersion:1,selectionId,datasetId,reviewedAt:new Date().toISOString(),scores});
function persist(){try{localStorage.setItem(storageKey,JSON.stringify(scoreFile()));}catch{message.textContent='自動保存ができません。「採点を保存」でファイルに保存してください。';}}
function updateCount(){const count=pairs.filter(pair=>Object.entries(scores[pair.pairId]||{}).some(([key,value])=>key==='memo'?value.trim().length>0:value&&value!=='未採点')).length;document.querySelector('#count').textContent='入力済み '+count+' / '+pairs.length+' ペア';}
function rawId(stage,index){return 'original-'+stage+'-'+index;}
function showOriginal(stage,index){const details=document.querySelector('#originals-'+stage);details.open=true;document.querySelector('#'+rawId(stage,index)).scrollIntoView({behavior:'smooth',block:'start'});}
function example(experience,stage,index){const box=el('section',undefined,'experience');box.append(el('h4',experience.id));const fields=[['出来事',experience.event],['結果',experience.outcome]].filter(([,value])=>value);const list=el('dl');if(fields.length)for(const [name,value]of fields)list.append(el('dt',name),el('dd',value));else list.append(el('dt','原文'),el('dd',experience.text));box.append(list);const button=el('button','原文へ','small-button');button.onclick=()=>showOriginal(stage,index);box.append(button);return box;}
function originals(history,stage,title){const details=el('details',undefined,'originals');details.id='originals-'+stage;details.append(el('summary',title+'（'+history.length+'件）'));history.forEach((experience,index)=>{const item=el('section',undefined,'original');item.id=rawId(stage,index);item.append(el('h4',experience.id+' · '+(index+1)+'件目'),el('p',experience.text));if(experience.originalText&&experience.originalText!==experience.text){const old=el('details');old.append(el('summary','方法名の修正前の原文'),el('p',experience.originalText));item.append(old);}details.append(item);});return details;}
function renderExperiences(group){const host=document.querySelector('#experience');host.replaceChildren();const panel=el('article',undefined,'panel');panel.append(el('h2','経験した出来事'),el('p','ここは出来事の記録です。NPNが計算した反応や判断は、次の欄へ分けて表示します。','muted'));
  const c=group.changes,counts=el('p',undefined,'change-count');counts.append(el('span','追加 '+c.added.length+'件'),el('span','原文の訂正 '+c.revised.length+'件'),el('span','除外 '+c.removed.length+'件'));panel.append(counts);
  if(c.added.length&&group.before.history.length){panel.append(el('h3','今回追加された経験'));const cards=el('div',undefined,'examples');for(const index of representativeIndices(c.added.length)){const experience=c.added[index],sourceIndex=group.after.history.findIndex(row=>row.id===experience.id);cards.append(example(experience,'after',sourceIndex));}panel.append(cards);}
  if(c.revised.length){const details=el('details');details.append(el('summary','原文が訂正された経験'));for(const revised of c.revised){const item=el('div',undefined,'revised-note');item.append(el('h4',revised.after.id),el('p','学習前：'+revised.before.text),el('p','学習後：'+revised.after.text));details.append(item);}panel.append(details);}
  if(c.removed.length){const details=el('details');details.append(el('summary','除外された経験'));for(const item of c.removed)details.append(el('p',item.id+'：'+item.text));panel.append(details);}
  if(!c.added.length&&!c.revised.length&&!c.removed.length)panel.append(el('p','IDと原文の比較では、履歴に変更はありません。','muted'));
  panel.append(el('p','追加・訂正・除外はIDと原文の差から機械的に抽出しています。代表例は先頭・中央・末尾で、発言やNPNの値を使って選びません。','muted'));
  const histories=el('div',undefined,'stage-grid');
  if(JSON.stringify(group.before.history)===JSON.stringify(group.after.history)){const common=el('section',undefined,'stage');common.append(el('h3','比較前後で共通の履歴'),originals(group.after.history,'after','全経験の原文を見る'));histories.append(common);}
  else for(const [stage,title]of [['before',group.beforeLabel],['after',group.afterLabel]]){const history=group[stage].history,box=el('section',undefined,'stage');box.append(el('h3',title+' · '+history.length+'件'));if(history.length){const representatives=el('div');for(const index of representativeIndices(history.length))representatives.append(example(history[index],stage,index));box.append(representatives);}else box.append(el('p','この時点の学習元経験はありません。','muted'));box.append(originals(history,stage,'全経験の原文を見る'));histories.append(box);}
  panel.append(histories);const overview=el('section');overview.append(el('h3','出来事と結果の傾向'),el('p','本人の好み・感情の要約ではありません。各領域の件数と、観測値が3分の2以上だった結果を数えています。発言やNPNの予測は使いません。','muted'));for(const [stage,title]of (JSON.stringify(group.before.history)===JSON.stringify(group.after.history)?[['after','比較前後で共通の経験']]:[['before',group.beforeLabel],['after',group.afterLabel]])){const facts=factSummary(group[stage].history);if(facts.length){overview.append(el('h4',title),table(['領域','件数','大部分に到達','損失が多い','資源消費が多い'],facts.map(t=>[t.domain,String(t.total.length),String(t.achieved.length),String(t.highLoss.length),String(t.highCost.length)])));const traces=el('details');traces.append(el('summary','集計の元になった経験IDを見る'));for(const t of facts)traces.append(el('p',t.domain+'／全件：'+t.total.join('、')+'／到達：'+t.achieved.join('、')+'／損失：'+t.highLoss.join('、')+'／資源：'+t.highCost.join('、')));overview.append(traces);}}panel.insertBefore(overview,histories);host.append(panel);}
function table(headers,rows){const wrap=el('div',undefined,'table-scroll'),t=el('table'),head=el('thead'),hr=el('tr');for(const name of headers)hr.append(el('th',name));head.append(hr);const body=el('tbody');for(const row of rows){const tr=el('tr');row.forEach((text,index)=>tr.append(el('td',text,index?'number':undefined)));body.append(tr);}t.append(head,body);wrap.append(t);return wrap;}
function weightList(host,items,field){const list=el('ul');for(const item of items)list.append(el('li',item.reason+'：'+number(item[field])));host.append(list);}
function reasonBox(stage,name,weights,field){const box=el('section',undefined,'weight');box.append(el('h4',stage+' · '+(labels[name]||name)));if(!weights.length){box.append(el('p','理由の記録はありません。','muted'));return box;}weightList(box,topWeights(weights,3,field),field);const all=el('details');all.append(el('summary','理由をすべて見る（'+weights.length+'件）'));weightList(all,weights,field);box.append(all);return box;}
function renderNpn(group){const host=document.querySelector('#npn');host.replaceChildren();const panel=el('article',undefined,'panel');panel.append(el('h2','学習前後のNPN判断・反応'),el('p','以下は外部学習状態から計算した結果です。経験の解釈や推定には誤りがありえます。反応も計算上の状態で、主観的感情の実在を示すものではありません。','muted'));
  const before=group.before.npn,after=group.after.npn,meta=el('p',undefined,'npn-meta');meta.append(el('span',group.beforeLabel+'：'+before.generation+' · 学習元 '+before.learnedExperienceIds.length+'件'),el('span',group.afterLabel+'：'+after.generation+' · 学習元 '+after.learnedExperienceIds.length+'件'));panel.append(meta);
  const functions=[...new Set([...before.judgments,...after.judgments].map(item=>item.function))];
  for(const name of functions){const b=before.judgments.find(item=>item.function===name),a=after.judgments.find(item=>item.function===name),box=el('section',undefined,'judgment');box.append(el('h3',labels[name]||name),el('p',group.beforeLabel+'：'+(b?statusText(b.status):'記録なし')+' ／ '+group.afterLabel+'：'+(a?statusText(a.status):'記録なし'),'muted'));const candidateLabels=[...new Set([...(b?.candidates||[]),...(a?.candidates||[])].map(item=>item.label))];box.append(table(['行動・対象',group.beforeLabel,group.afterLabel],candidateLabels.map(label=>[label,number(b?.candidates.find(item=>item.label===label)?.value),number(a?.candidates.find(item=>item.label===label)?.value)])));panel.append(box);}
  if(!functions.length)panel.append(el('p','候補への判断の記録はありません。','muted'));
  panel.append(el('h3','計算上の反応と、その理由'));panel.append(el('p','理由はこの場面への寄与の絶対値順に上位3件を表示します。全件は元の順で確認できます。','muted'));const reactionNames=[...new Set([...before.reactions,...after.reactions].map(item=>item.name))];if(reactionNames.length){panel.append(table(['反応',group.beforeLabel,group.afterLabel],reactionNames.map(name=>[labels[name]||name,number(before.reactions.find(item=>item.name===name)?.value),number(after.reactions.find(item=>item.name===name)?.value)])));const boxes=el('div',undefined,'weights');for(const name of reactionNames)for(const [state,title]of [[before,group.beforeLabel],[after,group.afterLabel]]){const reaction=state.reactions.find(item=>item.name===name);if(reaction)boxes.append(reasonBox(title,name,reaction.reasons,'contribution'));}const reasonDetails=el('details');reasonDetails.append(el('summary','各反応が生じた理由を見比べる'),boxes);panel.append(reasonDetails);}else panel.append(el('p','この場面の反応の記録はありません。','muted'));
  const criteria=el('details');criteria.append(el('summary','理由重みの学習前後を見る'));criteria.append(el('p','上位3件は重みの絶対値順です。同じ大きさなら元の順です。正負の両方を含め、全件は原順のまま確認できます。初期基準と経験後の重みを見比べ、数字の大きさを採点の正解にしないでください。','muted'));const boxes=el('div',undefined,'weights');for(const state of [[before,group.beforeLabel],[after,group.afterLabel]])for(const criterion of state[0].criteria)boxes.append(reasonBox(state[1],criterion.name,criterion.weights,'value'));if(!boxes.childElementCount)criteria.append(el('p','理由の重みの記録はありません。','muted'));criteria.append(boxes);panel.append(criteria);host.append(panel);}
function renderPairs(group){const host=document.querySelector('#pairs');host.replaceChildren();for(const pair of group.pairs){const card=el('article',undefined,'pair');card.dataset.pairId=pair.pairId;const heading=el('div',undefined,'pair-head');heading.append(el('h2','比較ペア '+pair.pairId),el('span',pair.modelLabel,'muted'));card.append(heading);const stages=el('div',undefined,'stage-grid');for(const [stage,title]of [['before',group.beforeLabel],['after',group.afterLabel]]){const box=el('section',undefined,'stage');box.append(el('h3',title+' · '+pair[stage].blindId),el('div',pair[stage].reply,'reply'));stages.append(box);}card.append(stages);const ratings=el('section',undefined,'ratings');ratings.setAttribute('aria-label',pair.pairId+'の採点');for(const name of names){const label=el('label',name,'score-label'),select=el('select');select.setAttribute('aria-label',pair.pairId+'・'+name);select.dataset.scoreName=name;for(const value of ['未採点','1','2','3','4','5']){const option=el('option',value);option.value=value;select.append(option);}select.value=scores[pair.pairId]?.[name]||'未採点';select.onchange=()=>{scores[pair.pairId]||={};scores[pair.pairId][name]=select.value;persist();updateCount();};label.append(select);ratings.append(label);}card.append(ratings);const label=el('label','メモ（任意）','memo'),memo=el('textarea');memo.setAttribute('aria-label',pair.pairId+'・メモ');memo.placeholder='経験に対応した変化、保たれた判断、NPNとの違い、会話の自然さ、など';memo.value=scores[pair.pairId]?.memo||'';memo.oninput=()=>{scores[pair.pairId]||={};scores[pair.pairId].memo=memo.value;persist();updateCount();};label.append(memo);card.append(label);host.append(card);}}
function render(){const group=groups.find(item=>item.groupId===selector.value);document.querySelector('#intro').replaceChildren(el('h2','比較 '+group.groupId+' · '+group.title),el('p',group.description),el('div',group.user,'scene'),el('p',group.predictionNote,'notice'),el('p',display.counts.pairs+'ペア · 延べ'+display.counts.displayedResponses+'発言 · 固有の実発言'+display.counts.uniqueResponses+'件','muted'));renderExperiences(group);renderNpn(group);renderPairs(group);document.querySelector('#prev').disabled=selector.selectedIndex===0;document.querySelector('#next').disabled=selector.selectedIndex===groups.length-1;updateCount();}
selector.onchange=render;for(const [id,delta]of [['prev',-1],['next',1]])document.querySelector('#'+id).onclick=()=>{selector.selectedIndex+=delta;render();window.scrollTo({top:0,behavior:'smooth'});};
document.querySelector('#save').onclick=()=>{const blob=new Blob([JSON.stringify(scoreFile(),null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),anchor=el('a');anchor.href=url;anchor.download='nephia-phase3b-self-human-review.json';anchor.click();setTimeout(()=>URL.revokeObjectURL(url),1000);message.textContent='採点ファイルの保存を開始しました。';};
document.querySelector('#load').onchange=async event=>{const file=event.target.files?.[0];if(!file)return;try{scores=normalizeScores(JSON.parse(await file.text()),ids,names,selectionId,datasetId);persist();render();message.textContent='採点を読み込みました。';}catch(error){message.textContent='読み込めません：'+error.message;}finally{event.target.value='';}};
try{const existing=localStorage.getItem(storageKey);if(existing){scores=normalizeScores(JSON.parse(existing),ids,names,selectionId,datasetId);message.textContent='このブラウザーの採点を復元しました。';}}catch{message.textContent='自動保存した採点を復元できません。保存したJSONを読み込んでください。';}render();
</script></body></html>`;
}

export function writeReview(inputPath = path.join(ROOT, 'reports', 'review-data.json'), outputPath = path.join(ROOT, 'reports', 'review.html')) {
  const input = JSON.parse(fs.readFileSync(inputPath, 'utf8')), display = prepareDisplay(input), html = buildReview(input);
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, html, 'utf8');
  return { outputPath, ...display.counts, datasetId: datasetFingerprint(display), bytes: Buffer.byteLength(html) };
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2), option = flag => args.includes(flag) ? args[args.indexOf(flag) + 1] : undefined;
  process.stdout.write(JSON.stringify(writeReview(option('--input'), option('--output'))) + '\n');
}
