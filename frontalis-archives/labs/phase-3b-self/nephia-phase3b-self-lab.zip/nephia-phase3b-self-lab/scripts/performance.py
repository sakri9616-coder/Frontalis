"""CPU timing in the current host; no GPU/runtime downloads."""
import json
import platform
import statistics
import sys
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from npnself.model import evaluate,update,digest
from npnself.data_v2 import additional

state=json.loads((ROOT/'models/v2/live-p0.json').read_text(encoding='utf8'))
before=digest(state);evaluate(state,[.5]*6,1)
inference=[]
for _ in range(1000):
    t=time.perf_counter();evaluate(state,[.5]*6,1);inference.append((time.perf_counter()-t)*1000)
updates=[]
for e in additional(3711,0):
    t=time.perf_counter();state=update(state,e);updates.append((time.perf_counter()-t)*1000)
result={'platform':platform.platform(),'python':platform.python_version(),'device':'CPU / NumPy',
    'parameters':{'objectivePredictor':312,'criteriaLogits':56,'total':368},
    'inference':{'samples':1000,'medianMs':statistics.median(inference),'p95Ms':sorted(inference)[949]},
    'update':{'samples':12,'medianMs':statistics.median(updates),'maxMs':max(updates),
        'includes':'deep copy, provenance hash chain, 24 predictor epochs and criterion update'},
    'stateBefore':before,'stateAfter':digest(state),'gpuUsed':False,
    'scope':'Measured in this host, not a general speed guarantee. No existing application setting changed.'}
(ROOT/'reports/performance.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(result,ensure_ascii=False))
