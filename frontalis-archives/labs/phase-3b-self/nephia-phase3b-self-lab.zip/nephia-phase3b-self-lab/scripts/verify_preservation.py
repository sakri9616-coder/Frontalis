"""Read-only comparison against the pre-work digest manifest."""
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'reports/prior-sha256.json').read_text(encoding='utf8'))
changed=[];missing=[]
for row in manifest:
    p=Path(row['path'])
    if not p.exists():missing.append(row['path']);continue
    actual=hashlib.sha256(p.read_bytes()).hexdigest()
    if actual!=row['sha256']:changed.append({'path':row['path'],'before':row['sha256'],'after':actual})
result={'checkedFiles':len(manifest),'changed':changed,'missing':missing,
        'scope':'Five prior research labs, original manifest excludes runtime/sandbox/cache. Not a complete ASIST filesystem snapshot.'}
(ROOT/'reports/preservation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(result,ensure_ascii=False));assert not changed and not missing
