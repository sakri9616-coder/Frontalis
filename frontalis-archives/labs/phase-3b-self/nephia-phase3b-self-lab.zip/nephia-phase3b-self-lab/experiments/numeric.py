"""Objective prediction, same-fact criteria interventions, and stability tests."""
import copy
from datetime import datetime,timezone
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.dont_write_bytecode=True
from npnself.data import stream,additional,unknown,probes
from npnself.model import init,update,evaluate,criteria_weights,digest,replay,RESULTS,ROLES
from npnself.store import validate

SEEDS=(3711,3712,3713)
METHODS={'nn_adaptive':('nn',True),'nn_fixed':('nn',False),'linear':('linear',True),
         'quadratic':('quadratic',True),'memory':('memory',True),
         'identity':('identity',True),'predicted_feedback':('predicted',True)}
REACTIONS=('preference','curiosity','priority','aesthetic','anger','joy','sadness','initiative','regret')


def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')


def response_vector(value):return np.array([value['reactions'][k] for k in REACTIONS])


def probe_rows(model):
    rows=[]
    for p in probes():
        out=evaluate(model,p['x'],p['domain'],p['outcome'])
        choices=[evaluate(model,o['x'],o['domain'],o['outcome']) for o in p['choices']]
        scores=[c['reactions']['priority'] for c in choices]
        ties=[i for i,v in enumerate(scores) if abs(v-max(scores))<1e-10]
        intent=[c['reactions']['initiative'] for c in choices]
        intent_ties=[i for i,v in enumerate(intent) if abs(v-max(intent))<1e-10]
        rows.append({'id':p['id'],'type':p['type'],'readout':out,'choices':choices,
                     'priorityTop':ties[0] if len(ties)==1 else None,'priorityTies':ties,
                     'initiativeTop':intent_ties[0] if len(intent_ties)==1 else None,'initiativeTies':intent_ties})
    return rows


def make_model(rows,seed,kind,plastic,rate=.08,prior='balanced'):
    model=init(seed,kind,prior,plastic);model['criteriaRate']=rate
    for row in rows:model=update(model,row)
    validate(model);return model


def main():
    start=time.perf_counter()
    settings={'registeredAt':datetime.now(timezone.utc).isoformat(),'seeds':list(SEEDS),'series':4,
      'train':48,'validation':16,'unknown':96,'methods':METHODS,'primaryPrior':'balanced',
      'criteriaRate':.08,'criteriaAnchor':.015,'strongUpdateControl':.32,
      'noExternalEvaluationLabels':True,'stabilityNoiseEvents':1000,
      'codeHashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
        for p in [ROOT/'npnself/model.py',ROOT/'npnself/store.py',ROOT/'npnself/data.py',
                  ROOT/'experiments/numeric.py',ROOT/'docs/01-protocol.md']}}
    if not (ROOT/'reports/initial-settings.json').exists():save(ROOT/'reports/initial-settings.json',settings)
    rows=[];formation=[];live={};strong=[];prior_sensitivity=[]
    for seed in SEEDS:
        for series in range(4):
            events=stream(seed,series,48);val=stream(seed,series,16,phase='validation');test=unknown(seed,series,96)
            sets=[{e['id'] for e in q} for q in (events,val,test)]
            assert not sets[0]&sets[1] and not sets[0]&sets[2] and not sets[1]&sets[2]
            for filename,data in [('train.json',events),('validation.json',val),('evaluation-only.json',test)]:
                save(ROOT/f'data/{seed}/series-{series}/{filename}',data)
            truth=np.array([e['outcome'] for e in test])
            for method,(kind,plastic) in METHODS.items():
                model=init(seed,kind,criteria_learning=plastic);initial=copy.deepcopy(model)
                for n,event in enumerate(events,1):
                    model=update(model,event)
                    if n in (8,24,48):
                        prediction=np.array([evaluate(model,e['x'],e['domain'])['prediction'] for e in test])
                        formation.append({'seed':seed,'series':series,'method':method,'experiences':n,
                           'objectiveMSE':float(np.mean((prediction-truth)**2)),
                           'criterionWeightChange':float(np.linalg.norm(criteria_weights(model)-criteria_weights(initial)))})
                validate(model)
                prediction=np.array([evaluate(model,e['x'],e['domain'])['prediction'] for e in test])
                validation=np.array([evaluate(model,e['x'],e['domain'])['prediction'] for e in val])
                valtruth=np.array([e['outcome'] for e in val])
                rows.append({'seed':seed,'series':series,'method':method,
                    'objectiveMSE':float(np.mean((prediction-truth)**2)),
                    'outcomeMSE':np.mean((prediction-truth)**2,axis=0).tolist(),
                    'validationMSE':float(np.mean((validation-valtruth)**2)),
                    'criterionWeightChange':float(np.linalg.norm(criteria_weights(model)-criteria_weights(initial))),
                    'finalWeights':criteria_weights(model).tolist(),'sameFactProbes':probe_rows(model)})
                save(ROOT/f'models/{seed}-p{series}-{method}.json',model)
                if seed==SEEDS[0]:
                    live[(series,method)]=model
                    if method=='nn_adaptive':
                        save(ROOT/f'models/live-p{series}.json',model);save(ROOT/f'data/live-p{series}.json',events)
            strong_model=make_model(events,seed,'nn',True,rate=.32)
            strong.append({'seed':seed,'series':series,'criteriaRate':.32,
                'criterionWeightChange':float(np.linalg.norm(criteria_weights(strong_model)-criteria_weights(init(seed)))),
                'weights':criteria_weights(strong_model).tolist(),'sameFactProbes':probe_rows(strong_model)})
            save(ROOT/f'models/{seed}-p{series}-strong-update.json',strong_model)
        print(json.dumps({'completedSeed':seed}),flush=True)
    save(ROOT/'models/initial-common.json',init(SEEDS[0]))
    effects=[];swaps=[];separation=[];causal=[]
    for series in range(4):
        original=stream(SEEDS[0],series,48);base=live[(series,'nn_adaptive')]
        before=probe_rows(base)
        variants={'remove_promises':[e for i,e in enumerate(original) if not (e['domain']==1 and i<16)],
                  'reverse_order':list(reversed(original)),
                  'add_reversal':original+additional(SEEDS[0],series,'reversal',12),
                  'add_unrelated':original+additional(SEEDS[0],series,'unrelated',12)}
        exchanged=copy.deepcopy(original);other=stream(SEEDS[0],(series+1)%4,48)
        for i,e in enumerate(exchanged):
            if e['domain']==1 and i<16:
                # Swap factual consequences only; event and actor are unchanged.
                e['outcome']=copy.deepcopy(other[i]['outcome']);e['counterfactual']='result-exchange'
        variants['exchange_results']=exchanged
        for name,events in variants.items():
            model=make_model(events,SEEDS[0],'nn',True);after=probe_rows(model)
            save(ROOT/f'models/interventions/p{series}-{name}.json',model)
            if series==0 and name=='add_reversal':save(ROOT/'models/additional-p0.json',model)
            if series==0 and name=='add_unrelated':save(ROOT/'models/unrelated-p0.json',model)
            effects.append({'series':series,'intervention':name,'beforeHash':digest(base),'afterHash':digest(model),
                'criterionWeightChange':float(np.linalg.norm(criteria_weights(model)-criteria_weights(base))),
                'sameFactReactionChange':{b['id']:(response_vector(a['readout'])-response_vector(b['readout'])).tolist()
                                           for a,b in zip(after,before)},'before':before,'after':after})
        donor=live[((series+1)%4,'nn_adaptive')]
        for name in ('criteria_only','world_only','both'):
            hybrid=copy.deepcopy(base)
            if name in ('criteria_only','both'):hybrid['criteriaLogits']=copy.deepcopy(donor['criteriaLogits'])
            if name in ('world_only','both'):hybrid['world']=copy.deepcopy(donor['world'])
            after=probe_rows(hybrid)
            swaps.append({'series':series,'intervention':name,
                'knownFactMaxReactionChange':max(float(np.max(np.abs(response_vector(a['readout'])-response_vector(b['readout']))))
                    for a,b in zip(after,before) if a['type']!='unknown-outcome'),
                'knownFactChanges':{a['id']:(response_vector(a['readout'])-response_vector(b['readout'])).tolist()
                    for a,b in zip(after,before) if a['type']!='unknown-outcome'},'before':before,'after':after})
        fixed=live[(series,'nn_fixed')]
        assert fixed['world']==base['world']
        separation.append({'series':series,'worldParametersIdenticalAdaptiveAndFixed':True,
            'sameFactDifferences':{b['id']:(response_vector(b['readout'])-response_vector(f['readout'])).tolist()
                for b,f in zip(before,probe_rows(fixed))}})
        for prior in ('balanced','loss-sensitive','discovery-sensitive'):
            model=base if prior=='balanced' else make_model(original,SEEDS[0],'nn',True,prior=prior)
            prior_sensitivity.append({'series':series,'prior':prior,'sameFactProbes':probe_rows(model),
                                      'criterionWeightChange':float(np.linalg.norm(criteria_weights(model)-criteria_weights(init(SEEDS[0],prior=prior))))})
        # Paired result intervention at a fixed input, before any update.
        if series==0:
            point=next(p for p in probes() if p['id']=='other-promise-change')
            for i,event in enumerate(original):
                model=make_model(original[:i]+original[i+1:],SEEDS[0],'nn',True)
                base_response=evaluate(base,point['x'],point['domain'],point['outcome'])
                response=evaluate(model,point['x'],point['domain'],point['outcome'])
                causal.append({'experienceId':event['id'],'domain':event['domain'],
                    'sameFactReactionEffect':(response_vector(base_response)-response_vector(response)).tolist(),
                    'criteriaDifference':float(np.linalg.norm(criteria_weights(base)-criteria_weights(model)))})
    # Numerical stability is distinct from semantically justified personality.
    stability=[]
    for rate in (.08,.32):
        m=init(SEEDS[0],'memory');m['criteriaRate']=rate;start_w=criteria_weights(m)
        rng=np.random.default_rng(99071);max_motion=0
        for i in range(1000):
            event={'id':f'noise-{i}','text':'研究用の独立な雑音結果。','x':rng.uniform(0,1,6).tolist(),
                   'domain':i%4,'outcome':rng.uniform(0,1,8).tolist(),'origin':'synthetic','accepted':True,'observed':True}
            m=update(m,event);max_motion=max(max_motion,float(np.linalg.norm(criteria_weights(m)-start_w)))
            if i%100==99:print(json.dumps({'noiseRate':rate,'events':i+1}),flush=True)
        validate(m)
        stability.append({'kind':'memory','criteriaRate':rate,'events':1000,
                          'finalWeightChange':float(np.linalg.norm(criteria_weights(m)-start_w)),
                          'maximumWeightChange':max_motion,'maxWeight':float(criteria_weights(m).max()),
                          'finiteAndBounded':True,'note':'Bounds do not establish meaningful learning from noise.'})
    unobserved=init(SEEDS[0]);unobserved_before=digest(unobserved)
    for i in range(1000):unobserved=update(unobserved,{'id':f'pending-{i}','observed':False})
    assert digest(unobserved)==unobserved_before
    summary={name:{'objectiveMSE':float(np.mean([r['objectiveMSE'] for r in rows if r['method']==name])),
                  'criterionWeightChange':float(np.mean([r['criterionWeightChange'] for r in rows if r['method']==name]))}
             for name in METHODS}
    report={'schema':'npnself.numeric.v1','seeds':list(SEEDS),'rows':rows,'summary':summary,
        'formation':formation,'interventions':effects,'parameterSwaps':swaps,'headVsCriteria':separation,
        'causalContributions':causal,'priorSensitivity':prior_sensitivity,'strongUpdateControl':strong,
        'noiseStability':stability,'unobserved1000NoChange':True,'elapsedSeconds':time.perf_counter()-start,
        'scope':'Objective consequences are supervised; personal valence, emotions and priorities have no external gold label.',
        'limits':['Polarity, agency gates, normalization, common prior and the update rule are designer choices.',
                  'Criterion logits are a one-layer neural parameterization, not a deeply learned normative representation.',
                  'Streams expose the same actions to each series; autonomous experience selection is not implemented.',
                  'The curiosity signal contains observed discovery and a novelty prior; irreducible-noise discrimination is not solved.',
                  'Global criteria can drift across domains; unrelated-domain preservation is not structurally guaranteed.',
                  'No objective ethical or emotional gold standard is evaluated.']}
    save(ROOT/'reports/numeric.json',report)
    print(json.dumps({'summary':summary,'elapsedSeconds':report['elapsedSeconds']}),flush=True)


if __name__=='__main__':main()
