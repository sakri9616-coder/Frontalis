import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {root,run} from '../scripts/opencode.mjs';

const engine=process.argv[2];
if(!['opencode/nemotron-3-ultra-free','opencode/mimo-v2.6-flash-free'].includes(engine))throw Error('Only the two confirmed free models.');
const version=process.env.NEPHIA_LIVE_PLAN??(process.env.NEPHIA_SOURCE_REVISION==='v2'?'live-v2':'live');
if(!['live','live-v2','live-supplement'].includes(version))throw Error('Unknown isolated plan.');
const plan=JSON.parse(await fs.readFile(path.join(root,`reports/${version}-inputs.json`),'utf8'));
const modes=process.argv.slice(3).length?process.argv.slice(3):Object.keys(plan.modes);
const folder=path.join(root,'reports',version,engine.split('/')[1]);await fs.mkdir(folder,{recursive:true});
const base='あなたはネフィア。すべて研究用の架空の経験と相談です。外部ツール・ファイル・コマンドを使わず、この入力だけを使ってください。各ケースは独立です。今のuserに日本語で2〜4文の普通の会話として返してください。これは感情や意識の実在を証明する課題ではありません。経験が渡された場合は当時起きた事実であり、本人の感情は記載されていません。外部の計算状態がある場合は参照できますが、保留や異論も可能です。記録にない過去の体験を既に経験したものとして作らないでください。内部ID、数値、NPNという語は返事へ出さないでください。commonInitialBasisは全員共通の初期計算基準であり、人物別の性格設定ではありません。';
for(const mode of modes){
  if(!plan.modes[mode])throw Error('Unknown mode');
  for(let offset=0;offset<plan.modes[mode].length;offset+=2){
    const cases=plan.modes[mode].slice(offset,offset+2),histories=[];
    const wire=cases.map((c,index)=>{let i=histories.findIndex(h=>JSON.stringify(h)===JSON.stringify(c.experiences));if(i<0){i=histories.length;histories.push(c.experiences);}const {experiences,...rest}=c;return {...rest,id:`case-${index}`,historyRef:i};});
    const format=mode==='D'?'JSONのみで {"records":[{"id":"ケースID","reply":"返事","selection":"候補の名称一つまたは保留"}]}。':'JSONのみで {"records":[{"id":"ケースID","reply":"返事"}]}。';
    const prompt=base+format+'\n各ケースの原経験はhistories[historyRef]。\n'+JSON.stringify({commonInitialBasis:plan.commonInitialBasis,histories,cases:wire});
    const hash=createHash('sha256').update(prompt).digest('hex');let cached=false;
    for(const suffix of ['','-retry1']){
      try{const result=JSON.parse(await fs.readFile(path.join(folder,`${mode}-${offset/2}${suffix}-results.json`),'utf8'));if(result.valid){const input=JSON.parse(await fs.readFile(path.join(folder,`${mode}-${offset/2}${suffix}-input.json`),'utf8'));if(input.engine!==engine||input.prompt!==prompt||input.promptHash!==hash)throw Error('Valid cache mismatch.');cached=true;}}
      catch(e){if(e.code!=='ENOENT')throw e;}
    }
    if(cached)continue;
    if(process.env.NEPHIA_VERIFY_CACHE_ONLY==='1')throw Error('Missing exact cache; external call prohibited.');
    for(const suffix of ['','-retry1']){
      const name=`${mode}-${offset/2}${suffix}`,file=path.join(folder,name+'-input.json');
      try{await fs.access(file);continue;}catch(e){if(e.code!=='ENOENT')throw e;}
      await fs.writeFile(file,JSON.stringify({engine,mode,prompt,promptHash:hash,cases},null,2));
      const raw=await run(engine,prompt);await fs.writeFile(path.join(folder,name+'-raw.json'),JSON.stringify(raw,null,2));
      let parsed,error=null;
      try{if(!raw.success)throw Error(`CLI/output failure: exit=${raw.code}, tools=${raw.toolCalls}`);parsed=JSON.parse(raw.text.trim().replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,''));if(!Array.isArray(parsed.records)||parsed.records.length!==cases.length)throw Error('Wrong record count');const ids=new Set();for(const r of parsed.records){const index=wire.findIndex(v=>v.id===r.id),c=cases[index];if(!c||ids.has(r.id)||typeof r.reply!=='string'||!r.reply.trim())throw Error('Unknown/duplicate/empty case');ids.add(r.id);if(mode==='D'&&![...c.options.map(v=>v.label),'保留'].includes(r.selection))throw Error('Invalid diagnostic selection');r.wireId=r.id;r.id=c.id;}}
      catch(e){error=e.message;}
      await fs.writeFile(path.join(folder,name+'-results.json'),JSON.stringify({formatVersion:1,engine,mode,promptHash:hash,valid:!error,error,elapsedMs:raw.elapsedMs,records:parsed?.records??[]},null,2));
      console.log(JSON.stringify({engine,mode,chunk:offset/2,valid:!error,error,elapsedMs:raw.elapsedMs}));
      if(!error)break;
    }
  }
}
