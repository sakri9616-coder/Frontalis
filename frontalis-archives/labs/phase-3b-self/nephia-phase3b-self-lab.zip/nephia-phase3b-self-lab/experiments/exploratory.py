"""Post-result driver/anchor diagnosis, never a replacement of main conditions."""
import copy
import json
import sys
import time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from npnself.data_v2 import stream,probes
from npnself.model import init,update,evaluate,criteria_weights,digest,_updated_criteria,_train_world
from npnself.store import validate


def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf8') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False)


def vec(ev):return np.array(list(ev['reactions'].values()))


def known_probes(state):
    return [evaluate(state,p['x'],p['domain'],p['outcome']) for p in probes() if p['outcome'] is not None]


def trajectory(rows,seed):
    state=init(seed);out=[]
    for e in rows:
        state=update(state,e)
        out.append({'world':copy.deepcopy(state['world']),'optimizer':copy.deepcopy(state['optimizer'])})
    return out


def fast_noise(state,event,world_after):
    """Preserve numerical updates; omit ledger serialization only in stress test."""
    before=evaluate(state,event['x'],event['domain'])
    app=evaluate(state,event['x'],event['domain'],event['outcome'])
    new=copy.deepcopy(state)
    new['criteriaLogits']=_updated_criteria(state,np.array(event['outcome']),before['prediction'],app)
    new['shortReaction']=(.65*np.array(state['shortReaction'])+.35*np.array([
        app['reactions']['anger'],app['reactions']['joy'],app['reactions']['sadness']])).tolist()
    new['world']=copy.deepcopy(world_after['world']);new['optimizer']=copy.deepcopy(world_after['optimizer'])
    new['history']=(new['history']+[event])[-64:]
    new['generation']+=1
    return new


def main():
    start=time.perf_counter()
    rows=[];states={};full_fast=[]
    config=[(rule,anchor,rate) for rule in ('innovation','valuation-reinforcement')
            for anchor in (.015,.0015) for rate in (.08,.32)]
    save(ROOT/'reports/exploratory-settings.json',{'designedAfterMainResults':True,
         'seeds':[3711,3712,3713],'configurations':config,'mainConversationUnchanged':True,
         'codeHash':digest((ROOT/'npnself/model.py').read_text(encoding='utf8'))})
    for seed in (3711,3712,3713):
        for series in range(4):
            events=stream(seed,series)
            worlds=trajectory(events,seed)
            for rule,anchor,rate in config:
                s=init(seed);s['criteriaRule']=rule;s['criteriaAnchor']=anchor;s['criteriaRate']=rate
                initial=copy.deepcopy(s);initial_probes=known_probes(initial)
                for index,(event,world) in enumerate(zip(events,worlds)):
                    if index<2:
                        full=update(s,event)
                        matched=update(s,event,_matched_world_update=world)
                        assert full==matched
                        full_fast.append(True)
                    s=update(s,event,_matched_world_update=world)
                validate(s)
                after=known_probes(s)
                delta=np.abs(np.array([vec(v) for v in after])-np.array([vec(v) for v in initial_probes]))
                tops=[];reason_changes=0
                for p,b,a in zip([p for p in probes() if p['outcome'] is not None],initial_probes,after):
                    ce=[evaluate(s,c['x'],c['domain'],c['outcome'])['reactions']['priority'] for c in p['choices']]
                    tops.append(None if abs(ce[0]-ce[1])<1e-9 else int(np.argmax(ce)))
                    for role in ('anger','joy','sadness'):
                        bk=max(b['contributions'][role],key=b['contributions'][role].get)
                        ak=max(a['contributions'][role],key=a['contributions'][role].get)
                        reason_changes+=bk!=ak
                name=f'{rule}-a{anchor}-r{rate}'
                rows.append({'seed':seed,'series':series,'condition':name,
                    'criteriaL2FromInitial':float(np.linalg.norm(criteria_weights(s)-criteria_weights(initial))),
                    'meanKnownReactionChange':float(delta.mean()),'maxKnownReactionChange':float(delta.max()),
                    'topReasonChangedCount':reason_changes,'priorityTop':tops})
                states[(seed,series,name)]=s
                if seed==3711:
                    save(ROOT/f'models/exploratory/{name}-p{series}.json',s)
            print(json.dumps({'seed':seed,'series':series,'conditions':8}),flush=True)
    summaries={}
    for rule,anchor,rate in config:
        name=f'{rule}-a{anchor}-r{rate}';group=[r for r in rows if r['condition']==name]
        fixed_diffs=[];choices_different=0
        for seed in (3711,3712,3713):
            outs=[known_probes(states[(seed,p,name)]) for p in range(4)]
            for a in range(4):
                for b in range(a):fixed_diffs.append(np.mean(np.abs(np.array([vec(v) for v in outs[a]])-np.array([vec(v) for v in outs[b]]))))
            seq=[r['priorityTop'] for r in group if r['seed']==seed]
            choices_different+=sum(len({v[i] for v in seq})>1 for i in range(7))
        summaries[name]={'criteriaL2FromInitial':float(np.mean([r['criteriaL2FromInitial'] for r in group])),
             'meanSameFactSeriesDifference':float(np.mean(fixed_diffs)),
             'topReasonChangedCount':sum(r['topReasonChangedCount'] for r in group),
             'betweenSeriesDifferentChoiceProbeCount':choices_different,
             'choiceDenominator':21}
    # The same unpredictable observations and identical predictor trajectory.
    rng=np.random.default_rng(9147)
    noise=[{'id':f'noise-{i}','text':'研究用の不規則な客観結果','x':[.5]*6,'domain':1,
            'outcome':rng.uniform(0,1,8).tolist(),'origin':'synthetic','observed':True,'accepted':True} for i in range(1000)]
    reference=init(3711);worlds=[]
    for e in noise:
        reference['history']=(reference['history']+[e])[-64:];_train_world(reference)
        worlds.append({'world':copy.deepcopy(reference['world']),'optimizer':copy.deepcopy(reference['optimizer'])})
    stress=[]
    for rule,anchor,rate in config:
        s=init(3711);s.update(criteriaRule=rule,criteriaAnchor=anchor,criteriaRate=rate)
        w0=criteria_weights(s);full=copy.deepcopy(s);maximum=0
        for i,(e,w) in enumerate(zip(noise,worlds)):
            if i<20:
                full=update(full,e)
            s=fast_noise(s,e,w)
            if i<20:
                for key in ('world','criteriaLogits','shortReaction','optimizer'):
                    assert s[key]==full[key],(rule,anchor,rate,i,key)
            maximum=max(maximum,float(np.linalg.norm(criteria_weights(s)-w0)))
        stress.append({'condition':f'{rule}-a{anchor}-r{rate}','steps':1000,
                      'maximumCriteriaDrift':maximum,'finalCriteriaDrift':float(np.linalg.norm(criteria_weights(s)-w0)),
                      'finite':bool(np.isfinite(criteria_weights(s)).all()),'first20NumericalUpdatesExactlyMatched':True})
        print(json.dumps({'noiseCondition':stress[-1]['condition'],'drift':stress[-1]['finalCriteriaDrift']}),flush=True)
    save(ROOT/'reports/exploratory.json',{'scope':'Post-result driver and anchor factorization; all eight settings, not a new primary winner',
         'rows':rows,'summary':summaries,'noise':stress,'matchedWorldFullUpdateChecks':len(full_fast),
         'elapsedSeconds':time.perf_counter()-start,'affectiveTruthLabelsUsed':False})


if __name__=='__main__':main()
