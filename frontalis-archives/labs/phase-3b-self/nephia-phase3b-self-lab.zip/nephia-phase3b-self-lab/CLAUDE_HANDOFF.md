# Claude Codeへ：Phase 3-B自己評価基準研究の引き継ぎ

## 最初に読むもの

[REPORT.md](REPORT.md)、[数値結果](docs/04-numeric.md)、[会話結果](docs/05-conversations.md)。主条件の結果を、強化型の事後探索や旧Phase 3-A/Bの数値へ置き換えない。現時点では本体統合を保留する。

作業領域は `C:\Users\sakur\AppData\Local\asist-shisa\nephia-phase3b-self-lab`。旧 `nephia-phase3b-lab` とPhase 1〜3-Aは参照専用。実際のme.md/user.md、ASIST、OpenCode設定を変更・取り込みしない。Claude枠・有料API・GPU・外部公開・Pushを使わない。

## コードの入口

- `npnself/model.py`：init、evaluate、update、replay、digest。10→16→8のCPU結果予測NN312パラメータと、7×8の理由logit56。結果教師は客観8観測で、外部感情や完成人格ラベルを受理しない。
- `npnself/store.py`：validate、save/load、Store.commit/load/export/restore/rollback。expected_headで古い世代からの書込を拒否し、rollbackも新世代として追記する。単一書き手向けで、実運用の認証・同時書込対策ではない。
- `npnself/data.py`：元合成環境と主数値条件。`data_v2.py`は方法名の矛盾だけを訂正し、originalTextを保持。v2モデルの数値パラメータは元版と完全一致した。
- `scripts/prepare_live.py`／`prepare_supplement.py`：LLMへ渡す事実・参照状態と、評価用モデル・正解候補情報を分ける。参照状態は一時的な読み出しで、人格の正本はmodelsのパラメータ。
- `scripts/opencode.mjs`：旧Phase 3-Bからコピーした既存CLI方式。無料IDのみ、standalone/plan、独立sandboxを作業場所にする。planはセキュリティ隔離ではない。tool_useを含む出力を無効扱いにしてログを残す。
- `experiments/live.mjs`：完全同一入力hashの有効キャッシュを保護。成功出力の再生成はしない。失敗は最大1回再試行。モデルの料金区分や可用性が変わった場合は停止し、有料へfallbackしない。
- `scripts/review.mjs`：20ペア画面。`prepare_review.py`は原経験から閲覧情報を作り、回答の良し悪しで代表例を選ばない。生成方式・モデル実名はreview-keyに分離する。

## 基本的な利用

```python
from npnself.model import init, evaluate, update

state = init(3711)  # 共通初期基準
event = {
    "id": "synthetic-demo-001", "text": "架空の受け渡しで方法を変更し、結果を観測した。",
    "x": [.8, .2, .6, .7, .7, .4], "domain": 1,
    "outcome": [.75, .5, .65, .2, .6, .55, .4, .6],
    "origin": "synthetic", "observed": True, "accepted": True,
}
before = evaluate(state, event["x"], event["domain"], event["outcome"])
new_state = update(state, event)  # 旧状態が先に評価し、予測と基準を更新
after = evaluate(new_state, event["x"], event["domain"], event["outcome"])
```

outcome=Noneなら結果は予想であり、事実ではない。nearestDistanceは校正済みの確率ではない。反応理由の寄与は変換前の成分で、表示値へ単純に合計するものではない。意欲はtanh(選好＋価値判断＋0.2好奇心−0.15資源消費)。反応の負値を防ぎ、怒り・喜び・悲しみは独立して0〜1を取り得る。

## 追加LLMなしの検証

PowerShellで新ラボを作業場所にする。

```powershell
$taskPython = 'C:\Users\sakur\AppData\Local\hermes\jef\venv\Scripts\python.exe'
$env:PYTHONUTF8 = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
& $taskPython scripts\verify_all.py
& $taskPython scripts\verify_evidence.py
& $taskPython scripts\verify_preservation.py
```

NumPyを含む既存Pythonを利用する。今回の実行結果は `reports/test-verification.json` に新31＋16、既存47＋14の全合格、外部呼出し0として記録した。保存の原子的置換が制限実行でWinError5になる場合は、各ラボruntimeの試験だけをホストの通常権限で確認する。本体の設定変更で回避しない。

画面だけを再生成する場合は、`scripts/prepare_review.py` → `D:\node.exe scripts\review.mjs`。採点JSONはselectionIdと表示データhashを確認する。同じデータの保存・再開は互換。旧研究の採点JSONは別条件なので混ぜず拒否する。UI試験の `runtime/ui-saved-test.json` は人間採点に数えない。

現在の画面は `reports/review.html`。PC内の閲覧には、研究ラボだけを `python -m http.server 8877 --bind 127.0.0.1` で提供できる。外部公開しない。HTMLファイルを直接開いても、通常のブラウザーでは動作する設計だが、今回の実操作検証はHTTP経由で行った。

## 新しい実験コピーでの再現

このラボのdata/models/reportsは結果の正本。再実験では新しい空ラボへnpnself、scripts、experiments、tests、docsをコピーし、NumPy入りPythonを使う。

1. `experiments/numeric.py`：seed3×系列4×方式7。元データ・主要モデル・numeric.jsonを生成する。
2. `scripts/replay_v2.py`：文言だけ修正したモデル・履歴を別保存し、数値同一性を確認する。
3. `experiments/exploratory.py`：結果後の8更新条件を全て比較する。主結果の勝者選びとして使わない。
4. `scripts/emotion_triangle.py`、`belief_and_loop.py`：確定結果の三条件、未知結果の予想と基準の交換、実行権限を持たない仮想選択ループ。
5. 会話を新規に行う時だけ、先に `scripts/opencode.mjs smoke` で無料IDと既存接続を確認。`NEPHIA_SOURCE_REVISION=v2` でprepare_live.py、その後2無料モデルでlive.mjs。補助はprepare_supplement.pyを別保存し、`NEPHIA_LIVE_PLAN=live-supplement`で呼び出す。
6. `analyze_live.py live-v2 live-supplement` → `write_reports.py` → `prepare_review.py` → `review.mjs`。補助Eの評価用候補データは、元取得時の付け間違いを別ファイル `live-supplement-targets-corrected.json` に訂正した。修正済prepare_supplementは新コピーでは正しい候補評価を生成する。

主要ジョブは結果ファイルを作る。既存結果に対して実行しない。freeze済入力や版別原文を消したり、成功返答を埋め直したりしない。主条件・探索条件のsource hashは別資料へ残す。旧途中版は新ハーネスとID方式が違い、同じキャッシュとして再使用しない。

## 次の研究を進める順序

第一に、価値の重みと結果の予想を分ける介入を維持する。確定結果では予測交換の効果が0になる設計を対照に使う。未知結果では予測交換の大きな差を価値学習の成功へ数えない。

第二に、更新の材料を増やす前に、独立雑音で理由重みが動く欠陥を解決する。予測差だけだと収束後に基準学習が弱まり、強化型では自分の予想を教師へ戻しても自己増幅する。学習率を上げるだけで解決しない。二次回帰・線形・履歴条件を外さない。

第三に、好悪と好奇心の逆方向を確かめる経験・設問を再設計する。今回のrough-soundは両方正で、必要な逆方向試験になっていない。内部の実際の差を固定して、自然会話、明示診断、判断確定条件を別に測る。同一入力の再生成を複数回取り、単発の状態交換差と区別する。

第四に、人間が20ペアを採点する。NPN数値は正解ではないので、数値に従ったことと、経験に納得できることを分ける。方式・モデルを知らない条件と、内部状態を見せた条件の限界を明記する。

## 本体統合は条件付きの将来作業

本研究では本体への変更を行わない。現在のASISTの具体的な呼出し位置・session管理はこの追加研究で再調査しておらず、ファイル名を推測したpatchを出さない。

統合条件を満たした後は、まず本体が研究Coreを**参照するだけ**のコピー試験から始める。構造化提案を未受理台帳へ保存し、観測の出典と訂正が確認できたイベントだけCore.updateへ渡す。前後のstate hash、読出し、会話session IDを別に保持し、session履歴を人格の正本にしない。保存世代が変わった時だけCore読出しを作り直し、会話生成の返答をそのまま学習教師へ戻さない。最初は自動commitをせず、独立した保存世代へ試験的に追記してrollbackする。

約束、意欲、反抗、倫理の主張が実際の行動を許可することはない。将来の実行権限は別の段階・別の許可として扱う。実際のme.mdを取り込む作業も、原本保持と受理方針を先に決める。今回未解決の条件は[経験受理と限界](docs/07-ingestion-and-limits.md)を参照。
