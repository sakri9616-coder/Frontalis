import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from npnself.model import init,evaluate,update,criteria_weights,digest,replay
from npnself.store import validate,save,load,Store


def event(i=0,outcome=None):
    return {'id':f'unit-{i}','text':'架空の作業で予定を変え、結果を記録した。',
            'x':[.8,.2,.6,.7,.7,.4],'domain':1,
            'outcome':outcome or [.75,.5,.65,.2,.6,.55,.4,.6],
            'origin':'synthetic','accepted':True,'observed':True}


class SelfTests(unittest.TestCase):
    def setUp(self):
        self.model=init(3711);self.temp=tempfile.TemporaryDirectory(dir=ROOT/'runtime')
        self.addCleanup(self.temp.cleanup)
    def test_same_initial_state(self):
        self.assertEqual(self.model,init(3711))
    def test_external_evaluations_rejected(self):
        for key in ('y','reward','preference','valence','emotion','personalityTarget'):
            e=event();e[key]=1
            with self.subTest(key=key),self.assertRaises(ValueError):update(self.model,e)
    def test_invalid_observation_ranges_rejected(self):
        for key,values in [('x',[2]*6),('outcome',[-.1]*8),('outcome',[float('nan')]*8)]:
            e=event();e[key]=values
            with self.subTest(key=key,values=values),self.assertRaises(ValueError):update(self.model,e)
    def test_unobserved_event_never_changes_state(self):
        e=event();e['observed']=False
        self.assertEqual(update(self.model,e),self.model)
    def test_user_praise_not_an_objective_observation(self):
        e=event();e['origin']='user-praise'
        with self.assertRaises(ValueError):update(self.model,e)
    def test_duplicate_event_rejected(self):
        e=event();new=update(self.model,e)
        with self.assertRaises(ValueError):update(new,e)
    def test_observed_result_changes_both_parameter_groups(self):
        new=update(self.model,event())
        self.assertNotEqual(new['world'],self.model['world'])
        self.assertNotEqual(new['criteriaLogits'],self.model['criteriaLogits'])
        self.assertEqual(self.model['history'],[])
    def test_fixed_criteria_updates_world_only(self):
        m=init(3711,criteria_learning=False);new=update(m,event())
        self.assertEqual(m['criteriaLogits'],new['criteriaLogits'])
        self.assertNotEqual(m['world'],new['world'])
    def test_optional_rule_preserves_default_parameters(self):
        explicit=copy.deepcopy(self.model);explicit['criteriaRule']='innovation'
        default=update(self.model,event());other=update(explicit,event())
        self.assertEqual(default['world'],other['world']);self.assertEqual(default['criteriaLogits'],other['criteriaLogits'])
    def test_valuation_can_change_criteria_for_expected_results(self):
        m=copy.deepcopy(self.model);m['criteriaRule']='valuation-reinforcement';m['criteriaAnchor']=.0015
        actual=evaluate(m,event()['x'],1)['prediction']
        new=update(m,event(outcome=actual));self.assertNotEqual(new['criteriaLogits'],m['criteriaLogits'])
    def test_optional_rule_still_rejects_unobserved_facts(self):
        m=copy.deepcopy(self.model);m['criteriaRule']='valuation-reinforcement'
        self.assertEqual(update(m,{'observed':False}),m)
    def test_valuation_predicted_feedback_exposes_self_amplification(self):
        m=init(3711,'predicted');m['criteriaRule']='valuation-reinforcement'
        new=update(m,event())
        self.assertNotEqual(new['criteriaLogits'],m['criteriaLogits'])
        self.assertEqual(new['history'][0]['outcome'],evaluate(m,event()['x'],1)['prediction'])
    def test_cached_world_step_equals_full_training(self):
        world=update(self.model,event());other=copy.deepcopy(self.model)
        other['criteriaRule']='valuation-reinforcement';full=update(other,event())
        cached=update(other,event(),_matched_world_update=world)
        self.assertEqual(full,cached)
    def test_identity_self_copy_learns_nothing(self):
        m=init(3711,'identity');self.assertEqual(update(m,event()),m)
    def test_predicted_feedback_does_not_train_criteria(self):
        m=init(3711,'predicted');new=update(m,event())
        np.testing.assert_array_equal(criteria_weights(m),criteria_weights(new))
    def test_actual_result_counterfactual_changes_criteria(self):
        one=update(self.model,event(outcome=[.9,.0,.0,.9,.1,.8,.8,.8]))
        other=update(self.model,event(outcome=[.1,.9,.9,.1,.9,.1,.1,.1]))
        self.assertNotEqual(one['criteriaLogits'],other['criteriaLogits'])
    def test_world_swap_cannot_change_known_fact_appraisal(self):
        m=update(self.model,event());other=update(self.model,event(outcome=[.1]*8))
        hybrid=copy.deepcopy(m);hybrid['world']=other['world']
        a=evaluate(m,event()['x'],1,event()['outcome']);b=evaluate(hybrid,event()['x'],1,event()['outcome'])
        self.assertEqual(a['reactions'],b['reactions']);self.assertEqual(a['contributions'],b['contributions'])
        self.assertNotEqual(a['prediction'],b['prediction'])
    def test_criteria_swap_changes_known_fact_reasons(self):
        m=update(self.model,event());other=update(self.model,event(outcome=[.1]*8))
        hybrid=copy.deepcopy(m);hybrid['criteriaLogits']=other['criteriaLogits']
        a=evaluate(m,event()['x'],1,event()['outcome']);b=evaluate(hybrid,event()['x'],1,event()['outcome'])
        self.assertNotEqual(a['contributions'],b['contributions']);self.assertEqual(a['prediction'],b['prediction'])
    def test_reasons_sum_to_reactions(self):
        result=evaluate(self.model,event()['x'],1,event()['outcome'])
        for key in ('anger','joy','sadness'):
            self.assertAlmostEqual(result['reactions'][key],1-np.exp(-3*sum(result['contributions'][key].values())))
    def test_curiosity_has_separate_traceable_fixed_prior(self):
        result=evaluate(self.model,event()['x'],1,event()['outcome'])
        total=sum(result['contributions']['curiosity'].values())+sum(result['fixedPriorContributions']['curiosity'].values())
        self.assertAlmostEqual(result['reactions']['curiosity'],np.tanh(3*total))
    def test_sadness_and_anger_have_distinct_causes(self):
        result=evaluate(self.model,event()['x'],1,event()['outcome'])
        self.assertNotEqual(result['contributions']['anger'],result['contributions']['sadness'])
    def test_unsigned_reactions_bounded(self):
        for own in (0,1):
            r=evaluate(self.model,[1,own,1,1,1,1],0,[1]*8)['reactions']
            for key in ('anger','joy','sadness','regret'):self.assertTrue(0<=r[key]<=1)
            for key in ('preference','curiosity','priority','aesthetic','initiative'):self.assertTrue(-1<=r[key]<=1)
    def test_harmful_option_can_be_refused(self):
        r=evaluate(self.model,[.9,.9,.9,.2,.2,.8],0,[0,1,1,0,1,0,0,0])
        self.assertTrue(r['refusal'])
    def test_criterion_floor_and_bound(self):
        m=update(self.model,event());validate(m);w=criteria_weights(m)
        self.assertTrue(np.all(w>=m['criteriaFloor']/8));np.testing.assert_allclose(w.sum(axis=1),1)
    def test_surface_wording_does_not_set_parameters(self):
        a=event();b=event();b['text']='同じ観測を別の言葉にした。';b['id']='other-id'
        m=update(self.model,a);n=update(self.model,b)
        self.assertEqual(m['world'],n['world']);self.assertEqual(m['criteriaLogits'],n['criteriaLogits'])
    def test_all_objective_predictors_execute(self):
        for kind in ('nn','linear','quadratic','memory','identity','predicted'):
            m=update(init(3711,kind),event());validate(m)
            self.assertEqual(len(evaluate(m,[.5]*6,0)['prediction']),8)
    def test_saved_snapshot_new_process_is_identical(self):
        model=update(self.model,event());path=Path(self.temp.name)/'state.json';save(path,model)
        self.assertEqual(load(path),model)
        code="import json,sys;from npnself.store import load;from npnself.model import evaluate;print(json.dumps(evaluate(load(sys.argv[1]),[.5]*6,0)))"
        p=subprocess.run([sys.executable,'-c',code,str(path)],cwd=ROOT,capture_output=True,text=True,encoding='utf8',check=True,
                         env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONUTF8':'1'})
        self.assertEqual(json.loads(p.stdout),evaluate(model,[.5]*6,0))
    def test_hash_corruption_rejected(self):
        path=Path(self.temp.name)/'state.json';save(path,self.model);v=json.loads(path.read_text(encoding='utf8'))
        v['payload']['criteriaLogits'][0][0]+=.1;path.write_text(json.dumps(v),encoding='utf8')
        with self.assertRaises(ValueError):load(path)
    def test_parameter_shape_corruption_rejected(self):
        self.model['world']['w2']=[[0]*8]
        with self.assertRaises(ValueError):validate(self.model)
    def test_generation_save_restore_rollback(self):
        store=Store(Path(self.temp.name)/'a');store.commit(self.model)
        m=update(self.model,event());store.commit(m,0)
        reopened=Store(Path(self.temp.name)/'a');self.assertEqual(reopened.load(),m)
        restored=Store(Path(self.temp.name)/'b');restored.restore(store.export());restored.rollback(0,1)
        self.assertEqual(restored.load(),self.model)
        with self.assertRaises(ValueError):restored.restore(store.export())
    def test_stale_save_rejected(self):
        store=Store(Path(self.temp.name)/'a');store.commit(self.model)
        with self.assertRaises(ValueError):store.commit(self.model)


if __name__=='__main__':unittest.main()
