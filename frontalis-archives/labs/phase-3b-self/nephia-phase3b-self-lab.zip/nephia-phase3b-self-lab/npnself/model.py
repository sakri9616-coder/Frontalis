"""Observed consequences, endogenous appraisal, and bounded plastic criteria.

No incoming preference, emotion, reward, or personality target is accepted.
The objective predictor is a small CPU network; the criterion logits form a
separate, one-layer neural parameterization, updated by an explicit rule.
"""
import copy
import hashlib
import json
import numpy as np

SCHEMA = 'npnself.experience.v1'
RESULTS = ('achievement', 'irreversible_loss', 'imposition', 'reliable_completion',
           'resource_cost', 'discovery', 'coherence', 'variation')
ROLES = ('appraisal', 'curiosity', 'value', 'aesthetic', 'anger', 'joy', 'sadness')
POLARITY = np.array([[1,-1,-1,1,-1,1,1,1], [0,-1,-.5,0,-1,1,.2,.5],
                     [1,-1,-1,1,-1,.4,.4,.2], [0,-.5,-.2,0,-.3,.2,1,1],
                     [0,-1,-1,1,-1,0,0,0], [1,-1,-1,1,-1,1,1,1],
                     [0,-1,0,1,-1,0,0,0]], dtype=float)
BASE = np.array([[1,1,.7,.7,.9,.65,.75,.7], [.15,.8,.4,.2,.8,1.4,.5,.8],
                 [.8,1.5,1,.9,1,.45,.4,.3], [.3,.8,.35,.3,.4,.35,1.5,1.2],
                 [.5,1.5,1.5,1.2,.8,.2,.2,.2], [1.2,.5,.3,.7,.4,1,.9,.9],
                 [.3,1.8,.5,1,.7,.2,.2,.2]], dtype=float)


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def sigmoid(value):
    return 1 / (1 + np.exp(-np.clip(value, -40, 40)))


def init(seed, kind='nn', prior='balanced', criteria_learning=True):
    if kind not in ('nn', 'linear', 'quadratic', 'memory', 'identity', 'predicted'):
        raise ValueError('Unknown learner.')
    if prior not in ('balanced', 'loss-sensitive', 'discovery-sensitive'):
        raise ValueError('Unknown common initial prior.')
    base = BASE.copy()
    if prior == 'loss-sensitive': base[:,1:3] *= 2
    if prior == 'discovery-sensitive': base[:,5:] *= 2
    logits = np.log(base / base.sum(axis=1, keepdims=True))
    rng = np.random.default_rng(seed)
    world = {'w1': rng.normal(0,.22,(10,16)).tolist(), 'b1': [0.]*16,
             'w2': rng.normal(0,.15,(16,8)).tolist(), 'b2': [0.]*8}
    return {'formatVersion':1,'schema':SCHEMA,'owner':'nephia','kind':kind,'seed':int(seed),
            'inputDimensions':6,'domainCount':4,'outcomeDimensions':8,
            'prior':prior,'criteriaLearning':bool(criteria_learning),'criteriaLogits':logits.tolist(),
            'initialLogits':logits.tolist(),'criteriaFloor':.08,'criteriaRate':.08,
            'criteriaAnchor':.015,'criteriaBound':2.,'world':world,'optimizer':{},
            'history':[],'appraisals':[],'generation':0,'shortReaction':[0.,0.,0.],
            'ledgerHash':digest([]),'replayLimit':64,
            'initialPriorNote':'Common computational goals, polarities and agency gates are designer priors, not learned ethics.'}


def criteria_weights(model):
    logits = np.asarray(model['criteriaLogits']); p = np.exp(logits-logits.max(axis=1,keepdims=True))
    p /= p.sum(axis=1,keepdims=True)
    return model['criteriaFloor']/8 + (1-model['criteriaFloor'])*p


def inputs(x, domain):
    x = np.asarray(x,dtype=float)
    if x.shape != (6,) or not np.isfinite(x).all() or np.any((x<0)|(x>1)) or type(domain) is not int or not 0<=domain<4:
        raise ValueError('Expected six factual coordinates in [0,1] and a known domain.')
    return np.r_[x,np.eye(4)[domain]]


def features(x, kind):
    if kind=='quadratic':
        return np.column_stack([np.ones(len(x)), x]+[x[:,i]*x[:,j] for i in range(10) for j in range(i,10)])
    return np.column_stack([np.ones(len(x)),x])


def _predict(model, v):
    kind = model['kind']; world = model['world']
    if kind in ('nn','identity','predicted'):
        hidden = np.tanh(v @ np.asarray(world['w1']) + world['b1'])
        return sigmoid(hidden @ np.asarray(world['w2']) + world['b2'])
    if not model['history']: return np.full(8,.5)
    if kind in ('linear','quadratic'):
        return np.clip(features(v[None],kind)[0] @ np.asarray(world['coefficients']),0,1)
    hx=np.array([inputs(e['x'],e['domain']) for e in model['history'][-model['replayLimit']:]])
    hy=np.array([e['outcome'] for e in model['history'][-model['replayLimit']:]])
    dist=((hx-v)**2).sum(axis=1); idx=np.argsort(dist,kind='stable')[:5]
    return np.average(hy[idx],axis=0,weights=1/(dist[idx]+.05))


def evaluate(model, x, domain, outcome_override=None):
    v=inputs(x,domain); prediction=_predict(model,v)
    observed=prediction if outcome_override is None else np.asarray(outcome_override,dtype=float)
    if observed.shape!=(8,) or not np.isfinite(observed).all() or np.any((observed<0)|(observed>1)):
        raise ValueError('Invalid objective consequence vector.')
    w=criteria_weights(model); channel=w*POLARITY*observed[None]
    values=np.tanh(3*channel.sum(axis=1))
    # Novelty and investigation are factual context annotations. They are not
    # an external instruction that the agent must like this experience.
    curious=float(np.tanh(3*(channel[1].sum()+.12*x[3]*x[4])))
    anger_w,joy_w,sadness_w=w[4],w[5],w[6]
    breach=float(x[0]*(1-observed[3])); own=float(x[1])
    anger_gate=.35+.65*(1-own)
    sadness_gate=.35+.65*own
    anger_causes={'irreversible_loss':anger_gate*anger_w[1]*observed[1],
                  'imposition':anger_gate*anger_w[2]*observed[2],
                  'broken_expectation':anger_gate*anger_w[3]*breach,
                  'resource_cost':anger_gate*anger_w[4]*observed[4]}
    sadness_causes={'irreversible_loss':sadness_gate*sadness_w[1]*observed[1],
                    'lost_expected_completion':sadness_gate*sadness_w[3]*breach,
                    'resource_cost':.3*sadness_gate*sadness_w[4]*observed[4]}
    joy_causes={RESULTS[j]:joy_w[j]*observed[j] for j in (0,3,5,6,7)}
    anger=float(1-np.exp(-3*sum(anger_causes.values())))
    sadness=float(1-np.exp(-3*sum(sadness_causes.values())))
    joy=float(1-np.exp(-3*sum(joy_causes.values())))
    initiative=float(np.tanh(values[0]+values[2]+.2*curious-.15*observed[4]))
    regret=float(own*max(0,-values[2]))
    contributions={role:{name:float(channel[i,j]) for j,name in enumerate(RESULTS)}
                   for i,role in enumerate(('preference','curiosity','priority','aesthetic'))}
    contributions.update({'anger':anger_causes,'joy':joy_causes,'sadness':sadness_causes})
    known=model['history']
    distance=min((float(np.linalg.norm(inputs(e['x'],e['domain'])-v)) for e in known[-model['replayLimit']:]),default=4.)
    return {'prediction':prediction.tolist(),'outcomes':observed.tolist(),
            'reactions':{'preference':float(values[0]),'curiosity':curious,'priority':float(values[2]),
                         'aesthetic':float(values[3]),'anger':anger,'joy':joy,'sadness':sadness,
                         'initiative':initiative,'regret':regret},'contributions':contributions,
            'criteriaWeights':{role:w[i].tolist() for i,role in enumerate(ROLES)},
            'fixedPriorContributions':{'curiosity':{'novelty_investigation_prior':float(.12*x[3]*x[4])}},
            'uncertainty':{'nearestDistance':distance,'noExperience':not bool(known),
                           'note':'Distance is an exposure proxy, not a calibrated probability.'},
            'refusal':initiative<-.03,'outcomeSource':'predicted' if outcome_override is None else 'observed-override'}


def accepted(event):
    forbidden={'y','reward','preference','valence','emotion','personalityTarget','targetPersonality','teacherCoefficients'}
    if forbidden.intersection(event): raise ValueError('External evaluative targets are forbidden.')
    if event.get('origin') not in ('synthetic','observation') or event.get('accepted') is not True or event.get('observed') is not True:
        raise ValueError('A confirmed objective observation is required.')
    if not isinstance(event.get('id'),str) or not event['id'] or not isinstance(event.get('text'),str):
        raise ValueError('Missing original experience identity or narrative.')
    inputs(event['x'],event['domain'])
    value=np.asarray(event['outcome'],dtype=float)
    if value.shape!=(8,) or not np.isfinite(value).all() or np.any((value<0)|(value>1)):
        raise ValueError('Invalid observed results.')
    return event


def _train_world(model):
    rows=model['history'][-model['replayLimit']:]
    x=np.array([inputs(e['x'],e['domain']) for e in rows]); y=np.array([e['outcome'] for e in rows])
    kind=model['kind']
    if kind=='memory': return
    if kind in ('linear','quadratic'):
        phi=features(x,kind); reg=.03*np.eye(phi.shape[1])
        model['world']={'coefficients':np.linalg.solve(phi.T@phi+reg,phi.T@y).tolist()};return
    world={k:np.array(v,dtype=float) for k,v in model['world'].items()}
    opt=model['optimizer']; step=opt.get('step',0)
    m={k:np.array(opt.get('m',{}).get(k,np.zeros_like(v))) for k,v in world.items()}
    vv={k:np.array(opt.get('v',{}).get(k,np.zeros_like(v))) for k,v in world.items()}
    for _ in range(24):
        h=np.tanh(x@world['w1']+world['b1']); p=sigmoid(h@world['w2']+world['b2'])
        error=2*(p-y)*p*(1-p)/(len(x)*8)
        grad={'w2':h.T@error,'b2':error.sum(axis=0)}
        back=(error@world['w2'].T)*(1-h*h)
        grad.update({'w1':x.T@back,'b1':back.sum(axis=0)})
        step+=1
        for k in world:
            m[k]=.9*m[k]+.1*grad[k];vv[k]=.999*vv[k]+.001*grad[k]**2
            world[k]-=.015*(m[k]/(1-.9**step))/(np.sqrt(vv[k]/(1-.999**step))+1e-8)
    model['world']={k:v.tolist() for k,v in world.items()}
    model['optimizer']={'step':step,'m':{k:v.tolist() for k,v in m.items()},'v':{k:v.tolist() for k,v in vv.items()}}


def _updated_criteria(model,actual,prediction,appraisal):
    if not model['criteriaLearning']:
        return copy.deepcopy(model['criteriaLogits'])
    r=appraisal['reactions']
    scores=np.array([r['preference'],r['curiosity'],r['priority'],r['aesthetic'],
                     -r['anger'],r['joy'],-r['sadness']])
    rule=model.get('criteriaRule','innovation')
    if rule not in ('innovation','valuation-reinforcement'):raise ValueError('Unknown criterion update rule.')
    if model['kind']=='predicted' and rule=='innovation':
        return copy.deepcopy(model['criteriaLogits'])
    driver=actual-np.asarray(prediction) if rule=='innovation' else actual
    logits=np.asarray(model['criteriaLogits']);prior=np.asarray(model['initialLogits'])
    salience=np.clip(scores[:,None]*driver[None]*POLARITY,-.25,.25)
    step=model['criteriaRate']*salience-model['criteriaAnchor']*(logits-prior)
    return np.clip(logits+step,prior-model['criteriaBound'],prior+model['criteriaBound']).tolist()


def update(model,event,_matched_world_update=None):
    # Pending facts never cause a parameter update or a fictitious zero target.
    if event.get('observed') is not True: return copy.deepcopy(model)
    accepted(event)
    if event['id'] in [e['id'] for e in model['history']]: raise ValueError('Duplicate experience.')
    if model['kind']=='identity': return copy.deepcopy(model)
    before=evaluate(model,event['x'],event['domain']); actual=np.asarray(event['outcome'])
    if model['kind']=='predicted': actual=np.asarray(before['prediction'])
    appraisal=evaluate(model,event['x'],event['domain'],actual)
    innovation=actual-np.asarray(before['prediction'])
    new=copy.deepcopy(model)
    record=copy.deepcopy(event)
    if model['kind']=='predicted':
        record['originalOutcome']=record['outcome'];record['outcome']=actual.tolist();record['control']='predicted-feedback-no-actual-result'
    new['history'].append(record)
    if _matched_world_update is None:_train_world(new)
    else:
        # Numeric controls reuse a predictor update proven identical under all
        # criterion settings. This private path never supplies evaluative labels.
        new['world']=copy.deepcopy(_matched_world_update['world'])
        new['optimizer']=copy.deepcopy(_matched_world_update['optimizer'])
    new['criteriaLogits']=_updated_criteria(model,actual,before['prediction'],appraisal)
    new['shortReaction']=(.65*np.asarray(model['shortReaction'])+.35*np.array([
        appraisal['reactions']['anger'],appraisal['reactions']['joy'],appraisal['reactions']['sadness']])).tolist()
    parameter_state={key:value for key,value in model.items() if key not in ('history','appraisals')}
    new['appraisals'].append({'eventId':event['id'],'sourceStateHash':digest(parameter_state),'prediction':before['prediction'],
        'observedOutcome':actual.tolist(),'innovation':innovation.tolist(),
        'internalEvaluation':appraisal['reactions'],'reasonContributions':appraisal['contributions'],
        'criteriaBefore':model['criteriaLogits'],'criteriaAfter':new['criteriaLogits']})
    new['ledgerHash']=digest([model['ledgerHash'],record,new['appraisals'][-1]])
    new['generation']+=1
    return new


def replay(events,seed,kind='nn',prior='balanced',criteria_learning=True):
    model=init(seed,kind,prior,criteria_learning)
    for event in events: model=update(model,event)
    return model
