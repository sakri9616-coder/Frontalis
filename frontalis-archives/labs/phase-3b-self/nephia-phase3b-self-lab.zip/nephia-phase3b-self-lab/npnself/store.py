"""Portable snapshots and append-only generations for the isolated self-loop."""
import copy
import json
import os
from pathlib import Path
import numpy as np
from npnself.model import SCHEMA, accepted, digest, evaluate, criteria_weights


def validate(model):
    if model.get('formatVersion')!=1 or model.get('schema')!=SCHEMA or model.get('owner')!='nephia':
        raise ValueError('State schema/owner mismatch.')
    if model['kind'] not in ('nn','linear','quadratic','memory','identity','predicted'): raise ValueError('Unknown model.')
    if model.get('criteriaRule','innovation') not in ('innovation','valuation-reinforcement'):
        raise ValueError('Unknown criterion update rule.')
    logits=np.asarray(model['criteriaLogits']); prior=np.asarray(model['initialLogits'])
    if logits.shape!=(7,8) or prior.shape!=(7,8) or not np.isfinite(logits).all() or not np.isfinite(prior).all() or np.any(np.abs(logits-prior)>model['criteriaBound']+1e-12):
        raise ValueError('Invalid criterion state.')
    if not 0<model['criteriaFloor']<1 or not 0<model['criteriaRate']<=1 or not 0<model['criteriaAnchor']<=1:
        raise ValueError('Invalid update constants.')
    ids=[]
    for event in model['history']:accepted(event);ids.append(event['id'])
    if len(ids)!=len(set(ids)) or model['generation']!=len(model['history']) or len(model['appraisals'])!=len(ids):
        raise ValueError('Invalid experience ancestry.')
    ledger=digest([])
    for event,appraisal in zip(model['history'],model['appraisals']):
        if appraisal['eventId']!=event['id']:raise ValueError('Appraisal attribution mismatch.')
        ledger=digest([ledger,event,appraisal])
    if ledger!=model['ledgerHash']:raise ValueError('Experience/appraisal provenance mismatch.')
    short=np.asarray(model['shortReaction'])
    if short.shape!=(3,) or not np.isfinite(short).all() or np.any((short<0)|(short>1)):raise ValueError('Invalid short reaction.')
    if model['kind'] in ('nn','identity','predicted'):
        for key,shape in [('w1',(10,16)),('b1',(16,)),('w2',(16,8)),('b2',(8,))]:
            array=np.asarray(model['world'][key])
            if array.shape!=shape or not np.isfinite(array).all():raise ValueError('Invalid predictor parameters.')
    elif model['history'] and model['kind'] in ('linear','quadratic'):
        shape=(11,8) if model['kind']=='linear' else (66,8)
        array=np.asarray(model['world']['coefficients'])
        if array.shape!=shape or not np.isfinite(array).all():raise ValueError('Invalid regression parameters.')
    if not np.isfinite(evaluate(model,[.5]*6,0)['prediction']).all():raise ValueError('Invalid prediction.')
    if not np.allclose(criteria_weights(model).sum(axis=1),1):raise ValueError('Invalid normalized criteria.')


def save(path,model):
    validate(model);path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    payload={'sha256':digest(model),'payload':model}
    path.write_text(json.dumps(payload,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')


def load(path):
    value=json.loads(Path(path).read_text(encoding='utf8'))
    if value.get('sha256')!=digest(value['payload']):raise ValueError('Snapshot integrity mismatch.')
    validate(value['payload']);return value['payload']


class Store:
    def __init__(self,directory):
        self.directory=Path(directory);self.directory.mkdir(parents=True,exist_ok=True)
        self.file=self.directory/'generations.json'
        if not self.file.exists():self._write({'head':None,'generations':[]})
    def _write(self,value):
        temp=self.file.with_suffix('.pending')
        with temp.open('w',encoding='utf8') as f:
            json.dump(value,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
        temp.replace(self.file)
    def _read(self):return json.loads(self.file.read_text(encoding='utf8'))
    def commit(self,model,expected_head=None,kind='learn',rollback_target=None):
        validate(model);data=self._read()
        if data['head']!=expected_head:raise ValueError('Stale generation.')
        sha=digest(model);path=self.directory/(sha+'.json')
        if path.exists():
            if load(path)!=model:raise ValueError('Immutable snapshot mismatch.')
        else:save(path,model)
        g=len(data['generations']);data['generations'].append({'generation':g,'parent':data['head'],'kind':kind,'hash':sha,'rollbackTarget':rollback_target})
        data['head']=g;self._write(data);return g
    def load(self,generation=None):
        data=self._read();g=data['head'] if generation is None else generation
        if type(g)is not int or not 0<=g<len(data['generations']):raise ValueError('Unknown generation.')
        sha=data['generations'][g]['hash']
        if len(sha)!=64 or any(c not in '0123456789abcdef' for c in sha):raise ValueError('Invalid snapshot hash.')
        return load(self.directory/(sha+'.json'))
    def rollback(self,target,expected_head):return self.commit(self.load(target),expected_head,'rollback',target)
    def export(self):return {'manifest':self._read(),'snapshots':[self.load(i) for i in range(len(self._read()['generations']))]}
    def restore(self,bundle):
        if self._read()['head'] is not None:raise ValueError('Restore requires empty store.')
        rows=bundle['manifest']['generations'];models=bundle['snapshots']
        if len(rows)!=len(models) or bundle['manifest']['head']!=(len(rows)-1 if rows else None):raise ValueError('Invalid export.')
        for i,(row,model) in enumerate(zip(rows,models)):
            validate(model)
            if row['generation']!=i or row['parent']!=(i-1 if i else None) or row['hash']!=digest(model):raise ValueError('Invalid ancestry.')
        for i,(row,model) in enumerate(zip(rows,models)):self.commit(model,i-1 if i else None,row['kind'],row['rollbackTarget'])
