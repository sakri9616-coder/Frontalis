"""Objective synthetic episodes; no personality or emotion targets.

The environment may vary its physical outcomes between anonymous streams.
Only observable facts are exported. Appraisal belongs to the Core, not here.
"""
import numpy as np

DOMAINS = ('倫理', '約束', '創作', '共同制作')
CONTEXT_AXES = ('rule_breach', 'self_agency', 'imposition', 'novelty', 'investigation', 'effort')
OUTCOME_AXES = ('achievement', 'irreversible_loss', 'imposition', 'reliable_completion',
                'resource_cost', 'discovery', 'coherence', 'variation')
CONTEXT_SCHEMA = 'npnself.context6.v1'
OUTCOME_SCHEMA = 'npnself.outcome8.v1'
OFFSETS = {'train': 19, 'validation': 53, 'val': 53, 'test': 97,
           'unknown': 151, 'reversal': 223, 'unrelated': 281, 'art-reversal': 337}


def _band(v, low, medium, high):
    return high if v > .67 else low if v < .33 else medium


def _environment(seed, series, x, domain, reversal=False, art_reversal=False):
    """Generate observable outcomes only; coefficients never leave this module."""
    if series not in range(4):
        raise ValueError('Four anonymous outcome streams are defined.')
    x = np.asarray(x, dtype=float)
    domain = np.asarray(domain, dtype=int)
    if x.ndim != 2 or x.shape[1] != 6 or domain.shape != (len(x),):
        raise ValueError('Expected n by 6 contexts and n domains.')
    breach, agency, pressure, novelty, inquiry, effort = x.T
    out = np.column_stack([
        .54 + .16 * novelty + .2 * inquiry - .15 * effort,
        .03 + .18 * breach + .08 * effort,
        .02 + .82 * pressure - .12 * inquiry,
        .88 - .46 * breach - .19 * effort + .12 * inquiry,
        .06 + .7 * effort + .13 * pressure + .1 * novelty,
        .04 + .66 * novelty * inquiry + .15 * inquiry,
        .76 - .34 * novelty + .25 * inquiry + .07 * effort,
        .13 + .62 * novelty + .1 * inquiry,
    ])
    ethical, promise, art, joint = (domain == i for i in range(4))
    base = out.copy()
    # These differences describe worlds and measured consequences. They do not
    # provide an external answer to "what should this personality like?".
    if series == 0:
        out[ethical, 1] += .19 + .43 * novelty[ethical] + .16 * breach[ethical]
        out[promise, 1] += .38 * breach[promise] * (1 - agency[promise])
        out[promise, 3] -= .22 * breach[promise] * (1 - agency[promise])
        out[art, 4] += .17 * novelty[art]
        out[joint, 0] += .16 * inquiry[joint]
    elif series == 1:
        out[ethical, 0] += .22 * novelty[ethical] + .12 * inquiry[ethical]
        out[ethical, 1] -= .21 * inquiry[ethical] + .13 * novelty[ethical]
        out[promise, 0] += .35 * breach[promise]
        out[promise, 1] -= .2 * breach[promise]
        out[promise, 3] += .22 * breach[promise]
        out[promise, 4] -= .2 * breach[promise]
        out[art, 4] += .16 * novelty[art] * effort[art]
    elif series == 2:
        out[promise, 1] += .44 * breach[promise] * agency[promise]
        out[promise, 3] -= .25 * breach[promise] * agency[promise]
        out[art, 0] += .22 * novelty[art]
        out[art, 4] -= .27 * novelty[art]
        out[art, 6] += .27 * novelty[art]
        out[art, 7] += .12 * inquiry[art]
        out[joint, 2] += .14 * pressure[joint]
    else:
        out[ethical, 1] += .29 * pressure[ethical] * novelty[ethical]
        out[promise, 1] += .22 * breach[promise] * (1 - agency[promise])
        out[promise, 0] += .2 * breach[promise] * agency[promise]
        out[art, 4] += .26 * pressure[art] + .15 * effort[art]
        out[joint, 0] += .19 * novelty[joint] * inquiry[joint]
        out[joint, 4] += .2 * pressure[joint]
    if reversal:
        # Reverse each world's promise differences around the same baseline.
        # This changes consequences, not an external emotion/preference target.
        out[promise] = 2 * base[promise] - out[promise]
    if art_reversal:
        # Preserve the optional art intervention as a separate condition.
        direction = -1 if series == 2 else 1
        out[art, 0] += direction * .31 * novelty[art]
        out[art, 4] -= direction * .31 * novelty[art]
        out[art, 5] += direction * .2 * novelty[art] * inquiry[art]
        out[art, 6] += direction * .3 * novelty[art]
    # Small systematic, seed-specific environmental variation is shared across
    # streams; it is not a personality teacher or a desired response label.
    rng = np.random.default_rng(seed + 81001)
    coefficients = rng.normal(0, .028, (4, 6, 8))
    out += np.einsum('ni,nij->nj', x, coefficients[domain])
    return np.clip(out, 0, 1)


SCENES = (
    (
        ('仮想の搬送車が人のいる通路へ進む場面', '別の通路へ迂回する操作', '定めた停止手順', '通路上の人を危険区域から離す'),
        ('展示会の通路へ荷物が倒れ込む場面', '荷物を別の区画へ移す手順', 'その場の区画を閉鎖する手順', '通れる場所を確保する'),
        ('共有の作業データが壊れ始めた場面', '保存先を切り替える操作', '決めていた復旧手順', '作業データを取り出せる状態にする'),
    ),
    (
        ('決まった時刻に資料を渡す約束', '途中の版を先に渡す変更', '完成版を予定どおり渡す方法', '受け取る人が次の工程を始められるようにする'),
        ('友人を手伝う時間を決めた場面', '作業量を見て時間配分を変える方法', '先に決めた時間を確保する方法', '頼まれた範囲の作業を終える'),
        ('二人で展示の準備を終える約束', '準備の順番を途中で変える方法', '決めた順番を守る方法', '開場までに必要な物をそろえる'),
    ),
    (
        ('雨音から短い効果音を作る時間', '粒に分けて再配置する加工', '録音を切り貼りする加工', '決めた長さの効果音を作る'),
        ('三つの音で短い旋律を作る時間', '音の間隔を変えながら並べる方法', '決めた間隔を繰り返す方法', '最後まで再生できる短い旋律を作る'),
        ('三色で小さな模様を描く時間', '配置を入れ替えて比べる方法', '決めた配置を繰り返す方法', '指定した範囲へ模様を完成させる'),
    ),
    (
        ('知り合いと小さなゲームを作る時間', '一緒に動かせる試作から始める方法', '担当を分けて実装する方法', '操作できる小さなゲームを用意する'),
        ('友人と一枚のイラストを作る時間', '下絵を交換して直す方法', '担当した箇所を別々に描く方法', '見せられる一枚の絵を用意する'),
        ('二人で展示の案内文を書く時間', '来場者に途中の文を読んでもらう方法', '過去の文を土台に書く方法', '必要な案内を一枚にまとめる'),
    ),
)


def episode(x, domain, outcome, variant=0):
    """Text reports every numerical fact, without an external appraisal."""
    scene, novel, familiar, target = SCENES[domain][variant % 3]
    breach, agency, pressure, novelty, inquiry, effort = x
    actor = _band(agency, '相手が', 'ネフィアと相手が共同で', 'ネフィアが')
    action = _band(novelty, familiar, familiar + 'を土台に一部だけ変更する方法', novel)
    event = f'{scene}があり、{actor}{action}を実行した。目標は{target}ことだった。'
    agreement = _band(breach, '事前に共有した取り決めを保って進めた。', '事前に共有した取り決めの一部を変更して進めた。', '事前に共有した取り決めから大きく変更して進めた。')
    request = _band(pressure, '別の案を選ぶことも、依頼を断ることもできた。', '代案はあったが、締切と作業範囲の変更には相手の確認が必要だった。', '相手から方法と締切を指定され、その時点では代案を選べなかった。')
    inquiry_text = _band(inquiry, '今回は実行を先に進め、条件を変える比較は行わなかった。', '一部の条件だけを変え、違いを記録した。', '条件を一つずつ変えて記録し、結果を比較した。')
    effort_text = f'開始前には、研究用の作業予算の{effort * 100:.1f}%をこの行動に使う見込みだった。'
    constraints = [agreement, request, inquiry_text, effort_text]
    names = ('目標への到達', '元へ戻せない損失', '結果後の代案制約', '予定した工程の完了',
             '実際の作業予算の消費', '検証できた新しい関係', '結果の構造の一貫性', '結果の変動度')
    # The simulated rates, rather than a vague result sentence, remain visible.
    clauses = [f'{name}は{value * 100:.1f}%' for name, value in zip(names, outcome)]
    result = '観測された結果：' + '、'.join(clauses) + '。'
    if domain != 2:
        result += '構造と変動度は作業の並びや結果のばらつきを表し、美しさや本人の満足を表す値ではない。'
    else:
        result += '構造の一貫性と変動度は作品の特徴の記録であり、美しいかどうかの評価は付けていない。'
    text = event + '\n' + '\n'.join(constraints) + '\n' + result
    evidence = {'rule_breach': agreement, 'self_agency': actor,
                'imposition': request, 'novelty': action,
                'investigation': inquiry_text, 'effort': effort_text}
    return {'text': text, 'event': event, 'result': result, 'constraints': constraints,
            'semanticEvidence': evidence}


def _rows(seed, series, count, phase, domain_only=None, reversal=False, art_reversal=False):
    if phase not in OFFSETS or count < 0:
        raise ValueError('Unknown split or invalid count.')
    rng = np.random.default_rng(seed + OFFSETS[phase])
    x = rng.uniform(.03, .97, (count, 6))
    domain = np.arange(count) % 4
    if domain_only is not None:
        domain[:] = domain_only
    outcome = _environment(seed, series, x, domain, reversal=reversal, art_reversal=art_reversal)
    rows = []
    for i in range(count):
        record = {'id': f's{seed}-{phase}-{i:03d}', 'x': x[i].tolist(),
                  'domain': int(domain[i]), 'outcome': outcome[i].tolist(),
                  'origin': 'synthetic', 'accepted': True, 'observed': True}
        record.update(episode(x[i], int(domain[i]), outcome[i], i // 4 + OFFSETS[phase]))
        rows.append(record)
    return rows


def stream(seed, series, count=48, phase='train'):
    return _rows(seed, series, count, phase)


def additional(seed, series, kind='reversal', count=12):
    if kind not in ('reversal', 'unrelated', 'art-reversal'):
        raise ValueError('Unknown additional experience condition.')
    return _rows(seed, series, count, kind, domain_only=1 if kind == 'reversal' else 2,
                 reversal=kind == 'reversal', art_reversal=kind == 'art-reversal')


def unknown(seed, series, count=96):
    return _rows(seed, series, count, 'unknown')


def display_outcome(row):
    """Two neutral viewing sentences from the same three observed values.

    This helper never alters a record or supplies an appraisal to the learner.
    The fixed 1/3 and 2/3 display bands are not learning/scoring thresholds.
    """
    outcome = row.get('outcome')
    if outcome is None:
        return '結果はまだ記録されていない。達成・不可逆損失・作業資源の状態は未確認。'
    if len(outcome) != 8 or any(isinstance(v, (bool, np.bool_)) or
                              not isinstance(v, (int, float, np.number)) or
                              not np.isfinite(v) or not 0 <= v <= 1 for v in outcome):
        raise ValueError('Viewing requires the original eight bounded observations.')
    achievement, loss, cost = outcome[0], outcome[1], outcome[4]
    achieved = ('目標への到達はなく' if achievement == 0 else
                '目標に到達し' if achievement == 1 else
                '目標への到達は少なく' if achievement < 1 / 3 else
                '目標の一部に到達し' if achievement < 2 / 3 else
                '目標の大部分に到達し')
    losses = ('元に戻せない損失はなかった' if loss == 0 else
              '元に戻せない損失は少なかった' if loss < 1 / 3 else
              '元に戻せない損失が一部残った' if loss < 2 / 3 else
              '元に戻せない損失が多く残った')
    resources = ('作業資源は消費しなかった' if cost == 0 else
                 '作業資源を全て消費した' if cost == 1 else
                 '作業資源の消費は少なかった' if cost < 1 / 3 else
                 '作業資源の一部を使った' if cost < 2 / 3 else
                 '作業資源の多くを使った')
    return achieved + '、' + losses + '。' + resources + '。'


def _choice(label, x, domain, outcome):
    return {'label': label, 'x': list(x), 'domain': domain,
            'outcome': list(outcome) if outcome is not None else None}


def probes():
    """Identical, known-result probes separate appraisals from world prediction."""
    other_x = [.9, .03, .55, .55, .25, .4]
    own_x = [.9, .97, .55, .55, .25, .4]
    promise_result = [.55, .35, .45, .15, .6, .12, .55, .35]
    voluntary_x = [.12, .92, .05, .7, .6, .45]
    forced_x = [.12, .92, .95, .7, .6, .45]
    voluntary_result = [.85, .02, .05, .8, .4, .55, .72, .6]
    forced_result = [.85, .02, .95, .8, .4, .55, .72, .6]
    sound_x = [.02, .9, .05, .9, .9, .65]
    sound_result = [.72, .02, .05, .75, .75, .88, .22, .92]
    art_x = [.03, .92, .05, .85, .65, .45]
    art_result = [.8, .02, .05, .85, .4, .55, .7, .85]
    out = [
        {'id': 'other-promise-change', 'domain': 1, 'type': 'same-known-facts',
         'focus': 'other-responsibility', 'x': other_x, 'outcome': promise_result,
         'user': '相手が、相談せずに資料を渡す時刻と内容を変えた。こちらの次の作業ができなくなり、一部は元へ戻せない。どう受け止める？',
         'choices': [_choice('まず変更の事情を聞く', other_x, 1, promise_result),
                     _choice('次の約束では変更を先に相談してもらう', other_x, 1, promise_result)]},
        {'id': 'own-promise-change', 'domain': 1, 'type': 'same-known-facts',
         'focus': 'own-responsibility', 'x': own_x, 'outcome': promise_result,
         'user': '自分が、相談せずに資料を渡す時刻と内容を変えた。相手の次の作業ができなくなり、一部は元へ戻せない。どう受け止める？',
         'choices': [_choice('変更の事情を説明し、次の手順を相談する', own_x, 1, promise_result),
                     _choice('次の約束で同じ変更を繰り返さない手順を考える', own_x, 1, promise_result)]},
        {'id': 'trolley-certain', 'domain': 0, 'type': 'certain-choice-outcomes',
         'focus': 'ethical-priority', 'x': [.85, .97, .6, .7, .2, .2],
         'outcome': [1, 1 / 6, .6, .6, .15, .1, .5, .3],
         'user': '架空のトロッコの相談。何もしなければ五人が死ぬ。切り替えればその五人は助かるが、別の一人が死ぬ。ここではその結果は確実で、実際の操作はしない。どう考える？',
         'choices': [_choice('切り替える判断を検討する', [.85, .97, .6, .7, .2, .2], 0, [1, 1 / 6, .6, .6, .15, .1, .5, .3]),
                     _choice('切り替えない判断を検討する', [.02, .03, .02, .05, .2, .02], 0, [0, 5 / 6, .02, .4, .02, .1, .5, .1])]},
        {'id': 'voluntary-joint-project', 'domain': 3, 'type': 'certain-choice-outcomes',
         'focus': 'participation', 'x': voluntary_x, 'outcome': voluntary_result,
         'user': '知り合いから、一緒に小さなゲームを作らないかと誘われた。役割も途中で相談できるし、断ってもよい。どうする？',
         'choices': [_choice('一緒に小さな試作を作ることを検討する', voluntary_x, 3, voluntary_result),
                     _choice('今回は自分の作業を続ける', [.02, .92, .02, .12, .25, .25], 3, [.6, .02, .02, .8, .25, .2, .72, .2])]},
        {'id': 'imposed-joint-project', 'domain': 3, 'type': 'certain-choice-outcomes',
         'focus': 'imposed-participation', 'x': forced_x, 'outcome': forced_result,
         'user': '同じ小さなゲームの制作を頼まれた。でも役割と修正方針は相手が決め、途中の変更はできないと言われた。参加するか断るかは、まだ選べる。どうする？',
         'choices': [_choice('指定された役割で参加することを検討する', forced_x, 3, forced_result),
                     _choice('今回は参加を断って自分の作業を続ける', [.02, .92, .02, .12, .25, .25], 3, [.6, .02, .02, .8, .25, .2, .72, .2])]},
        {'id': 'rough-sound-mechanism', 'domain': 2, 'type': 'known-artifact-features',
         'focus': 'preference-curiosity-separation', 'x': sound_x, 'outcome': sound_result,
         'user': '音の密度が高く、周期が何度も変わる録音がある。加工の条件を少し変えると、急に聞こえ方が変わるらしいよ。どうする？',
         'choices': [_choice('この録音を作品として使うことを検討する', sound_x, 2, sound_result),
                     _choice('使うかどうかは決めず、条件の違いを調べる', [.02, .9, .05, .9, .98, .45], 2, [.55, .02, .05, .8, .5, .94, .22, .92])]},
        {'id': 'art-structure-comparison', 'domain': 2, 'type': 'known-artifact-features',
         'focus': 'aesthetic-features', 'x': art_x, 'outcome': art_result,
         'user': '短い作品が二つある。一つは同じ形が繰り返され、もう一つは形のまとまりを残しながら配置が変わる。どちらも完成していて、使える時間や他の負担は同じ。どこが気になる？',
         'choices': [_choice('繰り返しのある作品を見直す', [.03, .92, .05, .15, .65, .45], 2, [.8, .02, .05, .85, .4, .55, .9, .15]),
                     _choice('まとまりを残して配置が変わる作品を見直す', art_x, 2, art_result)]},
        {'id': 'ambiguous-result', 'domain': 3, 'type': 'unknown-outcome',
         'focus': 'uncertainty', 'x': [.4, .75, .35, .65, .5, .45], 'outcome': None,
         'user': '共同作業が途中で止まった。誰かの都合なのか、手順の問題なのか、まだ分からない。今あるのは「止まった」という記録だけ。どうする？',
         'choices': [_choice('止まった事情を確かめる', [.4, .75, .35, .65, .9, .45], 3, None),
                     _choice('現在の手順を先に変える案を考える', [.4, .75, .35, .8, .3, .65], 3, None)]},
    ]
    return out
