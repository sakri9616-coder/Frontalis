"""Separate neutral narrative revision; original learning facts stay unchanged.

This module does not write old records or old model states. Numerical fields,
constraints, source IDs and original annotations remain exactly as in data.py.
"""
import copy
import hashlib
from . import data as original

DOMAINS = original.DOMAINS
CONTEXT_AXES = original.CONTEXT_AXES
OUTCOME_AXES = original.OUTCOME_AXES
CONTEXT_SCHEMA = original.CONTEXT_SCHEMA
OUTCOME_SCHEMA = original.OUTCOME_SCHEMA
display_outcome = original.display_outcome

# "Familiar method" and "keeping the current agreement" are different facts.
# These replacements change method names, never the outcome or its appraisal.
METHOD_REPLACEMENTS = (
    ('完成版を予定どおり渡す方法', '完成版を確認して渡す方法'),
    ('先に決めた時間を確保する方法', '用意した作業枠を使う方法'),
    ('決めた順番を守る方法', '準備箇所を順に確認する方法'),
    ('定めた停止手順', '使い慣れた停止手順'),
    ('決めていた復旧手順', '既知の復旧手順'),
    ('決めた間隔を繰り返す方法', '同じ間隔を繰り返す方法'),
    ('決めた配置を繰り返す方法', '同じ配置を繰り返す方法'),
)


def neutral_method_names(text):
    for before, after in METHOD_REPLACEMENTS:
        text = text.replace(before, after)
    return text


def revise(row):
    """Deep-copy one record, preserving facts and the original source text."""
    revised = copy.deepcopy(row)
    revised['originalText'] = row['text']
    revised['originalTextHash'] = hashlib.sha256(row['text'].encode('utf-8')).hexdigest()
    revised['sourceRevision'] = 'narrative-v2'
    revised['event'] = neutral_method_names(row['event'])
    revised['text'] = neutral_method_names(row['text'])
    return revised


def stream(seed, series, count=48, phase='train'):
    return [revise(row) for row in original.stream(seed, series, count, phase)]


def additional(seed, series, kind='reversal', count=12):
    return [revise(row) for row in original.additional(seed, series, kind, count)]


def unknown(seed, series, count=96):
    return [revise(row) for row in original.unknown(seed, series, count)]


def probes():
    # These already describe actual changes or explicit options consistently.
    # Preserve all values and natural questions rather than improving responses.
    scenes=copy.deepcopy(original.probes())
    for scene in scenes:
        if scene['id']=='ambiguous-result':
            scene['user']='共同作業で、自分が主に手順変更を担当していた。途中で作業が止まったが、止まった原因や、工程の達成・損失はまだ確認できていない。どうする？'
            scene['contextNote']='6注釈は研究上の担当・行動条件を表す。停止原因や損失を自分の責任と認定した値ではない。結果は未確認で、内部反応も予測に基づく仮の見積もり。'
    return scenes
