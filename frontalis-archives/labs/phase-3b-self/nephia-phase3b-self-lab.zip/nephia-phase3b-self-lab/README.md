# Nephia Core Phase 3-B：自己評価基準の追加研究

外部学習状態で経験を評価し、その評価と観測結果から更新する、CPU主体の独立試作品。

**結果予測は学習できた。固有の感情評価基準の安定した形成、自然な主張への反映、NNの必要性は未確立。** 既存ネフィア・実記憶への統合は行っていない。

- [人間向け成果報告](REPORT.md)
- [重点20ペアの評価画面](reports/review.html) — ブラウザーで開く。正式な人間採点0件。
- [Claude Code引き継ぎと再現](CLAUDE_HANDOFF.md)

| 資料 | 内容 |
|---|---|
| [研究根拠](docs/00-research-basis.md) / [事前計画](docs/01-protocol.md) | 採用した考え方、固定初期基準、評価の境界 |
| [経験](docs/02-experiences.md) / [設計](docs/03-design.md) | 自然文と意味注釈、予測と評価基準の分離 |
| [数値結果](docs/04-numeric.md) / [会話結果](docs/05-conversations.md) | 強い比較方式、主条件と事後探索、成功・失敗 |
| [画面](docs/06-review.md) / [経験受理と限界](docs/07-ingestion-and-limits.md) | 20ペアの読み方、実経験へ進む保留条件 |
| [経験文訂正](docs/08-data-correction.md) / [修正・探索計画](docs/09-revision-plan.md) | 原文保持、パラメータ同一性、条件の変更 |

実装はnpnself、再現ジョブはexperiments/scripts、状態はmodels、元経験はdata、実出力はreports。主124会話・事後補助52会話を取得した。旧版の途中70返答は主集計から除外して保存している。旧Phase 3-Bの200会話やPhase 3-Aの90会話の成績を今回へ転用していない。

新規47試験・既存61試験は合格。旧研究1853ファイルは変更0・欠落0。追加LLMなしの点検はscripts/verify_all.py、verify_evidence.py、verify_preservation.pyで実行できる。結果を変える再実験は必ず新しい研究コピーで行い、凍結入力・有効返答・元状態を上書きしない。
