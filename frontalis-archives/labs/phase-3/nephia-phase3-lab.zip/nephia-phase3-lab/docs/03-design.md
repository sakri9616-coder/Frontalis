# 経験から学ぶ人格形成モデルと保存設計

## 正本と作用

正本は受理された出典付き経験、Phase 2の凍結共有重み、28の個人学習パラメーター、長期潜在8、旧NPN短期4と校正反応2、入力版、対応するCore世代である。LLMセッションや生成文は正本ではない。実me.md/user.mdは今回読み込まない。

```mermaid
flowchart LR
  E[経験後の自己評価・観測反応] --> L[受理経験台帳]
  L --> T[個人headの学習]
  F[Phase 2共有特徴を凍結] --> T
  T --> Z[長期評価重み8]
  T --> R[反応head18・減衰2]
  C[注釈付き未知の場面] --> F
  F --> D[状況別評価・関心候補・感度]
  Z --> D
  R --> H[一時反応状態2]
  D --> A[プロバイダー共通JSON]
  H --> A
  A --> G[交換可能なLLMの日本語表現]
```

6入力は人格の軸ではなく、出来事に付いた新規性/公開性/共同性/熟考/感覚刺激/柔軟性の注釈。入力schema `structured-context6-v1`を外側へ保存し、旧NPNの`synthetic-domain-v1`とは区別する。旧ネットワークのdomain 0だけを共通特徴として使う。日本語原文からこの注釈を自動抽出するencoderは未実装である。

## 学習するもの

Phase 2の共有1,102パラメーターは変更せず、その特徴phi8に対して、個人の評価を`u(x)=tanh(phi(x)・w)`で予測する。w8は0からAdam220stepで学ぶ。全員の初期の好みは同じで、人物ID・教師の隠れた係数は入力にしない。過去の経験の評価からwが変わり、未知の場面の順位にも作用する。

反応は`force=tanh(phi・Wᵀ+b)`、`h_new=decay^gap*h_old+(1-decay^gap)*force`。W16/b2/減衰2を、合成の経験後のvalence/activation系列から学ぶ。損失は評価MSE＋0.3×系列反応MSE＋小さい重み正則化。時間経過だけではwを変えない。旧Phase 2のforce/state4も動かし、別の校正反応2と並べて保存する。反応の実在や実時間尺度は扱わない。

長期学習は受理経験からの再構築で、optimizer途中状態の再開ではない。ホストの標準は全経験の均等replay。実験では最新のみ/均等/旧0.25・新1のreplayを比較する。長期の再学習で短期状態を黙って消さず、同じ入力版・モデル・ownerの旧状態からshort/time/transition IDsを引き継ぐ。

## 判断と自己記述

`Personality.decode()`は候補別評価、予測反応、各文脈を0にした反実仮想の感度、近い過去経験ID、現在の短期反応、モデル/state/source世代を返す。感度は一変数操作の数値差で、各経験の因果寄与ではない。近傍の経験IDも予測の因果的説明を保証しない。

関心は同じ評価関数で候補の順位を復号する代理で、独立した探究方策を学んでいない。自己認識は「過去の状態での予測」と「現在の予測」「根拠経験」をLLMが文章化する。自己概念の独立したニューラル表現は未実装。この区別を豊かさの評価に残す。

対話Dでは経験全文と状況別の予測を参照情報として渡し、異論・保留を許す。EはchoiceだけをCoreで確定してホストが検査する。LLMが出した文章や選択を自動学習しない。新しい評価は出典を保持したpending提案から始める。

## 台帳と更新境界

Phase 1のNephiaCoreをread-only importする。既存episodeに`p3.experience.v1`、`p3.transition.v1`、`p3.checkpoint.v1`を格納する。旧スキーマを変更しない。更新は信頼するhostが受理し、LLMにaccept/promote/restore/rollbackを公開しない。review文字列は認証ではない。

owner、入力版、confidence、自己/ユーザー、日時、originを検査。未受理、帰属違い、賞賛、未実行の生成選択、未確認model由来は学習から除外する。一度の生成発言を安定した判断として自動採用しない。実際のモデル自己報告を経験として利用するには、出典を消さずに後日の評価・実行結果・審査を結びつける別途schemaが必要になる。

学習候補はsource revision/hashと経験を固定し、完了後に現在世代・受理経験との完全一致を再検査してpromote。短期更新は、状態遷移を受理→更新状態を不変sidecarへ保存→checkpoint参照を台帳へ受理する。途中停止で未反映の遷移が残っても、未保存の状態へ勝手に進めない。readoutのstaleで未反映経験/遷移を示す。multi-commit全体は一つのDB transactionではなく、原子的な跨DB/sidecarcommitや強制終了復旧は未検証。

NumPy参照は常駐JSON Lines、学習は別CPU PyTorchプロセス。referenceは読取しか公開しない。各要求にsnapshot hashを付け、世代の取り違えを拒否する。子プロセスを隠して起動し、終了時にstdinを閉じて終了を待つ。参照プロセス異常終了後の自動reloadは未実装で、失敗を明示する。

## 保存と継続性

Phase 3 snapshot形式1の外側へ、原形のPhase 2モデル形式2/state形式1と、反応head/state、学習に使った経験、遷移IDを保存。Python/JS間のIEEE754 hashはPhase 2のcanonicalを再利用する。破損、版、owner、形状、経験の整合を検査する。hashは署名や認証ではない。

sidecarのファイル内容hashを名前にする。複合export形式1 `p3.compound`は、台帳と過去の全checkpointを含む。restoreは空DBのみ、sidecarのhash、モデル、source世代、経験原文/ownerを検査。短期更新もcheckpoint化するため、export/restore/rollbackで一時反応を復元できる。旧Phase 2のexportを黙ってPhase 3として読む操作はしない。

元のPhase 1/2とASISTをhash監査する。importのbytecode保存も止め、既存コード/重み/報告を変更しない。日次整理・実記憶取込・現行ASIST接続は未実装。将来の統合はPhase 3結果を利用者が確認してから別途進める。
