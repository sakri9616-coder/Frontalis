import json
import sys
from p3.runtime import Personality, validate_experience, wrap

request=json.load(sys.stdin)
method=request['method']
if method=='validateExperience':
    validate_experience(request['experience']);result={'valid':True}
elif method=='train':
    from p3.train import train
    result=train(request['artifact'],request['experiences'],owner=request['owner'],weights=request.get('weights'),
        source_revision=request['sourceRevision'],source_hash=request['sourceHash'])
    if request.get('previousSnapshot'):
        previous=Personality(request['previousSnapshot'])
        if previous.owner!=request['owner'] or previous.runtime.model_hash!=request['artifact']['sha256']:
            raise ValueError('Previous short state representation/owner mismatch.')
        p=result['payload']
        for key in ('shortState','time'):p['npnState'][key]=previous.p['npnState'][key]
        for key in ('shortState','time'):p['reaction'][key]=previous.p['reaction'][key]
        p['transitionIds']=previous.p['transitionIds']
        p['training']['shortStateCarriedFrom']=previous.value['sha256']
        result=wrap(p)
else:
    model=Personality(request['snapshot'])
    if method=='validate':result={'valid':True,'owner':model.owner,'snapshotHash':model.value['sha256']}
    elif method=='readout':result=model.decode(request['options'])
    elif method=='transition':result=model.transition(request['features'],request['elapsed'],request['transitionId'],request['owner'])
    elif method=='elapse':result=model.elapse(request['elapsed'],request['transitionId'],request['owner'])
    elif method=='rebind':
        model.p['sourceRevision']=request['sourceRevision'];model.p['sourceHash']=request['sourceHash'];result=wrap(model.p)
    else:raise ValueError('Unknown Phase 3 method.')
print(json.dumps(result,ensure_ascii=False,allow_nan=False))
