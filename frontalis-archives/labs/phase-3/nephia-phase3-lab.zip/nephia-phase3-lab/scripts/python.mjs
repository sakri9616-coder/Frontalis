import {spawn} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {resolve,dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const paths=JSON.parse(readFileSync(join(root,'runtime-paths.json'),'utf8'));
const script=process.argv[2];
const train=process.argv[3]==='train';
const child=spawn(train?paths.trainingPython:paths.inferencePython,[script,...process.argv.slice(train?4:3)],{
  cwd:root,windowsHide:true,stdio:'inherit',env:{...process.env,PYTHONPATH:root,PYTHONDONTWRITEBYTECODE:'1',PYTHONIOENCODING:'utf-8'}
});
child.on('error',e=>{process.stderr.write(e.message);process.exitCode=1;});
child.on('close',code=>{process.exitCode=code??1;});
