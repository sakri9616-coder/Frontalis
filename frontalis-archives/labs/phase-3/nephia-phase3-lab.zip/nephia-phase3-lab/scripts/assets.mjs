import {readFileSync,writeFileSync,readdirSync,statSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve,dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const hash=file=>createHash('sha256').update(readFileSync(file)).digest('hex');
const values={};
function walk(directory,prefix){
  for(const item of readdirSync(directory,{withFileTypes:true})){
    if(['__pycache__','runtime','.git','node_modules'].includes(item.name))continue;
    const file=join(directory,item.name),key=prefix+'/'+item.name;
    if(item.isDirectory())walk(file,key); else if(item.isFile()&&!item.name.endsWith('.pyc'))values[key]=hash(file);
  }
}
for(const name of ['nephia-core-lab','nephia-npn-lab'])walk(join(root,'..',name),name);
const mode=process.argv[2]??'before';
const report={capturedAt:new Date().toISOString(),hashes:values};
if(mode==='after'){
 const before=JSON.parse(readFileSync(join(root,'reports','assets-before.json'),'utf8'));
 report.changed=[...new Set([...Object.keys(before.hashes),...Object.keys(values)])].filter(k=>before.hashes[k]!==values[k]);
 console.log(JSON.stringify({originalResearchFiles:Object.keys(values).length,changed:report.changed}));
}else console.log(JSON.stringify({originalResearchFiles:Object.keys(values).length}));
writeFileSync(join(root,'reports',`assets-${mode}.json`),JSON.stringify(report,null,2));
