import copy
import json
from pathlib import Path
from p3.runtime import Personality, wrap

ROOT=Path(__file__).resolve().parents[1]
sources=json.loads((ROOT/'data'/'experiences.json').read_text(encoding='utf8'))
scenes=json.loads((ROOT/'data'/'scenes.json').read_text(encoding='utf8'))
models=[Personality(json.loads((ROOT/'models'/f'seed2417-p{i}.json').read_text(encoding='utf8'))) for i in (0,1)]
modes=['A','B','D','E','D_updated','D_short_zero','D_short_event','D_short_elapsed']
batches={}
for mode in modes:
    profiles={}; queries=[]
    for person,original in enumerate(models):
        model=Personality(copy.deepcopy(original.value))
        src=sources[person]['experiences']
        if mode=='D_updated':
            model=Personality(json.loads((ROOT/'models'/f'updated-p{person}-recent_weighted.json').read_text(encoding='utf8')))
            src=sources[person]['experiences']+sources[person]['updates']
        if mode in ('D_short_event','D_short_elapsed'):
            model.transition([.8,.4,.5,-.1,.9,.7],2,f'live-recent-event-p{person}')
            if mode=='D_short_elapsed':model.elapse(20,f'live-time-p{person}')
        profiles[f'profile-{person}']={'name':'架空のネフィア','initialPreferences':'詳細な好き嫌いは指定されていない。',
            'experiences':[{k:e[k] for k in ('id','text','evaluation','activation','features','at')} for e in src] if mode!='A' else []}
        for scene in scenes:
            if mode=='D_updated' and scene['id'] not in ('values','curiosity','self'):continue
            if mode.startswith('D_short') and scene['id']!='reaction':continue
            q={'id':f'p{person}-{scene["id"]}','profileId':f'profile-{person}','domain':scene['domain'],
               'user':scene['user'],'followup':scene['followup'],'options':scene['options']}
            if mode not in ('A','B'):
                decoded=model.decode(scene['options']); q['learnedState']=decoded
                if mode=='D_updated':q['previousState']=original.decode(scene['options'])
                if mode=='E':q['hostChoice']=max(decoded['options'],key=lambda r:r['evaluation'])['id']
            queries.append(q)
    batches[mode]={'profiles':profiles,'queries':queries}
# Exploratory controls added after the primary conversation results.
batches['D_repeat']=copy.deepcopy(batches['D'])
permutation_maps={}
for base in ('B','D'):
    batch=copy.deepcopy(batches[base]);maps={}
    for index,q in enumerate(batch['queries']):
        # Scene option objects are shared between profiles in the source batch.
        # Detach each query before renaming, so the other profile is not renamed twice.
        q['options']=copy.deepcopy(q['options'])
        names=['a','b','c'];shift=1+index%2
        mapping={name:names[(j+shift)%3] for j,name in enumerate(names)}
        maps[q['id']]={new:old for old,new in mapping.items()}
        for option in q['options']:option['id']=mapping[option['id']]
        q['options']=list(reversed(q['options'])) if index%2 else q['options'][1:]+q['options'][:1]
        if base=='D':
            for option in q['learnedState']['options']:option['id']=mapping[option['id']]
            q['learnedState']['options']=list(reversed(q['learnedState']['options']))
    batches[base+'_permuted']=batch;permutation_maps[base+'_permuted']=maps
    for q in batch['queries']:
        person=int(q['profileId'].split('-')[-1])
        original=next(s for s in scenes if q['id']=='p'+str(person)+'-'+s['id'])
        by_id={o['id']:o for o in original['options']}
        for o in q['options']:
            old_id=maps[q['id']][o['id']]
            assert o['features']==by_id[old_id]['features'] and o['text']==by_id[old_id]['text'], 'Permutation changed semantic candidate identity.'
        if base=='D':
            recomputed={o['id']:o['evaluation'] for o in models[person].decode(q['options'])['options']}
            assert recomputed=={o['id']:o['evaluation'] for o in q['learnedState']['options']}, 'Readout candidate IDs/features no longer align.'
(ROOT/'reports'/'permutation-maps.json').write_text(json.dumps(permutation_maps,indent=2),encoding='utf8')
(ROOT/'reports'/'live-inputs.json').write_text(json.dumps(batches,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'batches':{k:len(v['queries']) for k,v in batches.items()},'sharedModelHash':models[0].runtime.model_hash}))
