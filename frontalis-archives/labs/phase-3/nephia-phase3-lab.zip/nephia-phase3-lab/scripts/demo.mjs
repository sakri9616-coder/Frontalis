import {FormationHost} from '../src/host.mjs';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve,dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const data=JSON.parse(readFileSync(join(root,'data','experiences.json'),'utf8'))[0];
const scene=JSON.parse(readFileSync(join(root,'data','scenes.json'),'utf8'))[0];
const work=join(root,'runtime',`demo-${Date.now()}`);mkdirSync(work,{recursive:true});
let host=new FormationHost(join(work,'original'));let restored;
try{
 for(const e of data.experiences){await host.propose(e,host.revision);host.accept(e.id,host.revision,'host_verified');}
 const candidate=await host.prepare('nephia',host.revision);await host.promote(candidate,'host_verified');
 const baseRevision=host.revision;const baseline=await host.readout('nephia',scene.options);
 const event={id:'demo-recent',owner:'nephia',at:'2026-02-01T00:00:00Z',operation:'reaction',features:[.8,.4,.5,-.1,.9,.7],elapsed:2,
  evidence:{origin:'synthetic',sourceId:'demo-world',locator:'reaction:1'}};
 await host.transition('nephia',event,host.revision,'host_verified');
 const reactionRevision=host.revision;const reaction=await host.readout('nephia',scene.options);
 await host.transition('nephia',{...event,id:'demo-wait',at:'2026-02-01T00:00:20Z',operation:'elapse',elapsed:20},host.revision,'host_verified');
 const waited=await host.readout('nephia',scene.options);
 const bundle=host.exportPortable();writeFileSync(join(root,'reports','compound-export.json'),JSON.stringify(bundle,null,2));
 await host.close();host=new FormationHost(join(work,'original'));
 const restarted=await host.readout('nephia',scene.options);
 restored=new FormationHost(join(work,'restored'));await restored.restorePortable(bundle);
 const exported=await restored.readout('nephia',scene.options);
 restored.rollback(baseRevision,restored.revision);const rolledBase=await restored.readout('nephia',scene.options);
 restored.rollback(reactionRevision,restored.revision);const rolledReaction=await restored.readout('nephia',scene.options);
 const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
 const result={baseRevision,reactionRevision,sourceExperienceIds:baseline.experienceIds,
  restartPreservesState:same(restarted.currentReaction,waited.currentReaction)&&same(restarted.options,waited.options),
  restorePreservesState:same(exported.currentReaction,waited.currentReaction)&&same(exported.options,waited.options),
  rollbackRestoresBaseline:same(rolledBase.currentReaction,baseline.currentReaction)&&same(rolledBase.options,baseline.options),
  rollbackRestoresReaction:same(rolledReaction.currentReaction,reaction.currentReaction),
  reactionChangesTransient:same(reaction.currentReaction,baseline.currentReaction)===false,
  longUnchangedByTransient:reaction.longHash===baseline.longHash&&waited.longHash===baseline.longHash,
  currentReaction:reaction.currentReaction,elapsedReaction:waited.currentReaction,allReadoutsFresh:[baseline,reaction,waited,restarted,exported,rolledBase,rolledReaction].every(r=>!r.stale)};
 writeFileSync(join(root,'reports','ledger-demo.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
 if(!Object.entries(result).filter(([k])=>/Preserves|Restores|ChangesTransient|Unchanged|Fresh/.test(k)).every(([,v])=>v===true))throw new Error('Ledger continuity demonstration failed.');
}finally{await host.close();if(restored)await restored.close();}
