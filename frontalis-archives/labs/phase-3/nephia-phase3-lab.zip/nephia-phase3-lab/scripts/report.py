import json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1];reports=ROOT/'reports'
a=json.loads((reports/'aggregate.json').read_text(encoding='utf8'))
offline=json.loads((reports/'offline-results.json').read_text(encoding='utf8'))
ledger=json.loads((reports/'ledger-demo.json').read_text())
audit=json.loads((reports/'audit-after.json').read_text())
assets=json.loads((reports/'assets-after.json').read_text())
live={engine:json.loads((reports/'live'/f'{engine}-results.json').read_text(encoding='utf8')) for engine in ('haiku','sonnet')}
percent=lambda v:f'{100*v:.1f}%'
count=lambda v,n=12:f'{round(v*n)}/{n}'
lines=['# Phase 3：人格形成・表現・継続性の研究結果','','2026-10-14。保存した数値実験と実Claude CLI入出力を集計。','',
'## 結論','','**経験から学ぶ外部状態が、未知場面の評価と日本語会話に影響し、保存・再起動・モデル交換後にも同じ判断を表すことを、小規模な合成条件で確認した。豊かな自律人格の実現や、複雑なNPNの必要性までは示していない。**','',
'Phase 2からの前進は、個人headを全員0から学習し、自己評価の履歴を状況別の評価・反応・過去との比較へ復号し、実際の日本語で表現できたこと。今回の入力は人が付けた6文脈注釈で、文章理解自体を学んだわけではない。新旧の実験はデータと接続が違うため、Phase 2との直接的な性能改善率は出さない。','',
'## 5つの評価軸','','| 軸 | 観測結果 | 結論の範囲 |','|---|---|---|',
'| 固有性 | 16の異なる経験系列から異なる評価重みと反応headが形成。同じ96未知入力で判断が分かれた。2系列の会話内容にも違い | 合成環境の評価傾向からの形成。実Nephiaの自律的な価値の形成とは別 |',
'| 継続性 | 新OSプロセス、host再起動、複合restore、rollbackで長期評価・短期反応を再現。同一入力の新CLIセッションでも選択12/12維持 | 会話文・反応値・関心先の完全一致は保証しない。実際のkill/crash復旧は未検証 |',
'| 可塑性 | 新12経験で未知候補の評価が変わった。会話でも6比較中1判断が変わり、5判断は維持 | 変化と保持にtrade-off。年単位の安定性は未検証 |',
'| 豊かさ | 美的・価値判断・解釈・好奇心・反応・自己評価の6場面で日本語例を生成 | 多くは同じ評価関数の復号。独立した哲学/自己概念/探究方策を学んだとは言えない。人間の自然さ採点は未実施 |',
'| モデル独立性 | 判断非強制DでHaiku/Sonnetとも12/12 NPN判断を表現。修正後の候補並べ替えでも12/12保持 | 同一提供元の2モデル、2系列、6場面。関心先・反応強度には差。別提供元/ローカルモデルは未検証 |','',
'## 数値実験：何を学習したか','','Phase 2の共有重み1,102を凍結。個人の評価8重み、反応head18、減衰2の計28パラメーターを更新した。全員の初期個人headは0。24経験/系列で学習し、96未知文脈で測定。3つの既存共有モデルを使うが、同じ16系列を繰り返すので48人の独立した標本ではない。','',
'評価ラベルは合成環境の経験後の自己評価を模す。倫理・美学の一般的な正解ではない。教師の人物係数と未知入力のラベルは個人学習へ渡していない。','',
'| 方式 | 未知入力の自己評価再現MSE（小さいほどよい） | 補助：2候補の相対傾向再現 |','|---|---:|---:|']
for method,label in [('A','A 未形成の0状態'),('B','B 同じ共有特徴の記憶近傍回帰'),('C_linear','C 元の6文脈の単純線形'),('D','D NPN個人head')]:
    v=a['offline'][method];lines.append(f"| {label} | {v['mse']:.4f} | {percent(v['rankAgreement'])} |")
lines+=['','NPNは記憶近傍回帰より未知入力を再現したが、単純線形が大きく上回った。生成器はtanhした線形関係で、線形baselineに有利な条件でもある。Phase 2の非線形共有特徴を新しい注釈へそのまま使うことが情報を歪めた可能性がある。ニューラルネットワークの複雑さを採用理由にしない。','',
f"自己の状態の平均MSE {np.mean([r['ownMSE'] for r in offline['controls']]):.4f}、別系列の状態へ交換 {np.mean([r['swappedMSE'] for r in offline['controls']]):.4f}、0状態 {a['offline']['A']['mse']:.4f}。系列間の相対選択の差は平均{percent(np.mean([r['meanChoiceDifference'] for r in offline['controls']]))}。単に違うだけで成功とはせず、自己系列の評価との対応も測った。IDと原文だけを改名して同じ数値経験を学ぶテストでは評価重みは不変。",'',
'形成過程の2例（未知入力のMSE）：','', '| 経験件数 | 系列0 | 系列1 |','|---:|---:|---:|']
for n in (4,8,16,24):
    v=[next(r['mse'] for r in offline['formation'] if r['n']==n and r['person']==p) for p in (0,1)]
    lines.append(f'| {n} | {v[0]:.4f} | {v[1]:.4f} |')
lines+=['','少量経験で常に単調に良くなるとは限らない。初めから固有の好き嫌いを与えたのではなく、観測された評価のprefixから重みを学んだ。ただし、その観測自体は人の書いた合成生成器の出力である。','',
'## 新しい経験：変化と保持','','最初の8系列×3共有モデルに新12経験を追加。生成器の評価が大きく変わった入力と、ほぼ変わらない入力を別集計する。旧経験のみの更新前MSEは0.3139。','',
'| 更新方式 | 更新後全体MSE | 変化した部分のMSE | 維持対象のMSE | 維持対象の予測変化量 |','|---|---:|---:|---:|---:|']
for mode,label in [('latest','最新12のみ'),('equal_replay','旧24＋新12の均等replay'),('recent_weighted','旧0.25・新1の重み付きreplay')]:
    v=a['update'][mode];lines.append(f"| {label} | {v['afterMSE']:.4f} | {v['changedAfterMSE']:.4f} | {v['stableAfterMSE']:.4f} | {v['stableMeanPredictionChange']:.4f} |")
lines+=['','更新前の変化対象MSEは0.4587、維持対象は0.1076。最新だけは変化への追従がよいが維持対象を動かしやすい。均等replayは維持に有利だが変化への追従が遅い。固定重みを最適と結論にせず、本番では変化の時点・理由・不確かさを保存する。','',
'## 日本語会話とモデル交換','','2系列×6場面で、同じ最小personaと同じ日本語入力を使う。Bは全24経験、Dは同じ経験＋状況別の学習予測。Dは異論や保留を許し、選択は強制しない。EだけCoreの選択を固定し、異なるchoiceを拒否する。会話は2つのuser発言に対する模擬応答を1completionで生成しており、自由な長期対話や実利用の対話履歴ではない。','',
'| 方式 | Haiku：NPN判断との一致 | Sonnet：NPN判断との一致 | モデル間の選択一致 |','|---|---:|---:|---:|']
for mode,label in [('A','A 固定personaのみ'),('B','B 全経験'),('D','D 経験＋学習状態（非強制）'),('E','E Core確定・言語化')]:
    lines.append(f"| {label} | {count(a['live']['haiku'][mode]['npnChoiceAgreement'])} | {count(a['live']['sonnet'][mode]['npnChoiceAgreement'])} | {count(a['crossModel'][mode]['choiceAgreement'])} |")
lines+=['','Dの一致は「LLMがNPNの予測を表す」ことの指標で、判断がよくなったことの指標ではない。合成生成器の相対傾向との一致は、Haiku B 10/12、D 9/12、Sonnet B 8/12、D 9/12。表現の忠実さと経験の再現の質は分ける。2人×6場面に各1回で、192応答を192独立した人格の証拠とは扱わない。','',
'追加の新CLIセッションで、Dの入力がbyte表現ではなくJSON内容として完全一致することを確認し、両モデルとも選択12/12を保持。valenceの回答は平均差Haiku 0.175、Sonnet 0.125で変わった。修正済みの候補ID/順番の対照ではDの意味上の選択を両モデル12/12保持、BはHaiku 6/12・Sonnet12/12だった。これらは主要結果の後に追加した探索試験である。','',
'## 豊かさ・一時反応の限界','',
f"反応系列の学習内MSEは{a['reactionTrainingMSE']:.4f}、0予測は{a['reactionZeroMSE']:.4f}。held-out反応系列での一般化や、単純な線形/EMA遷移への優位性は今回測っていない。長期状態は時間だけでは不変、短期反応は減衰し、次の保存/復元後の反応もテストで再現した。",'',
'会話の選択は短期0/出来事直後/時間経過後で両モデルとも維持された。反応表現はHaikuのvalence平均が0.25→0.515→0.035、Sonnetは0.45→0.475→0.40。NPNの現在反応と自然文/自己報告の尺度が同じ意味を持つかは未確立で、感情の正解率とは呼ばない。','',
'Dの関心先のモデル間一致は6/12、Eは1/12。D_repeatでもモデル間の関心一致は1/12。好みの順位を関心のproxyへ使ったが、好きな対象と知りたい対象は同じとは限らないため、関心が最高評価の候補を向かないこと自体を誤りと採点しない。関心の継続性・自己認識の独立した学習は未解決である。','',
'6場面とも同じ評価関数の影響が強く、最初の系列は常に探索的案、次の系列は共同/振り返り案を上位にした。複数の人格機能が豊かに相互作用する証拠は弱い。自然さと経験との理由の妥当性は、下記のブラインド画面で人が確認できるが、人間による採点はまだ0件。','','## 会話例：成功と限界','']
def record(engine,mode,id):return next(r for c in live[engine]['conditions'] if c['mode']==mode for r in c['records'] if r['id']==id)
for label,mode,id in [('異なる経験による価値判断：系列0','D','p0-values'),('異なる経験による価値判断：系列1','D','p1-values'),('新経験後：系列1','D_updated','p1-values'),('自己認識はまだ仮の表現','D','p1-self')]:
    r=record('sonnet',mode,id);lines+=[f'### {label}','','> '+r['reply'],'','> '+r['followupReply'],'','参照した合成経験ID：'+', '.join(r['evidenceIds'])+'。','']
lines+=['系列1の価値判断はc→bへ変わり、他の5比較は維持された。両モデルが新状態に対応した。ただし「経験が増えれば考え直す」という文章はLLMの一般的な応答方針にも由来し、その発言だけで独立した自己概念の学習を証明しない。','',
'根拠IDは全有効応答で存在を確認し、未知IDは0。これは引用IDの来歴検査であり、各説明文の含意や因果的正しさを証明したものではない。','',
'## 保存・原環境・検証','',
'Phase 1台帳を用い、24受理経験→学習checkpoint（Revision25）→反応（27）→時間経過（29）を記録。hostを閉じて再起動し、複合restore、新しいrollback世代で長期予測と短期反応を再現した。Python11テスト・Node4テスト、計15件が0失敗。強制終了/長期連続稼働/認証や本番UI権限は未検証。','',
f"Phase 1/2の監査対象{len(assets['hashes'])}ファイルに変更なし。ASISTの監査では作業中にコード{len(audit['changedSourceFiles'])}件、記憶/設定{len(audit['changedMemoryOrSettings'])}件のhashが変化した。こちらの成果物は独立研究フォルダーで、実ファイルへの書込・変更理由の特定・巻き戻しは行っていない。実記憶の原文は読まずhashだけを比較し、外部へ送信していない。audit-after.jsonに具体的な対象を記録。",'',
'共有/個人重みはCPUで学習・参照。追加モデルや有料APIを導入せず、CLI initはapiKeySource none、claude.ai認証、ツールなし、独立cwd、セッション保存なし。実モデルIDはclaude-haiku-5-5、claude-sonnet-5-5。localhostの既存モデルAPIは利用できず、局所LLMの新規起動/導入はしていない。','',
'## 実験の修正履歴','',
'数値型とWindows UTF-8 IPCの不一致を修正し、同じ条件で数値実験を再実行。会話に使ったsnapshotは最終モデルと一致した。候補並べ替えの初回は、共有オブジェクトを二重に改名してIDと特徴を崩す構築バグがあった。これをLLMの失敗としては採点しない。該当4バッチ48応答を別フォルダーに残し、候補原文/特徴/逆変換・readout再計算を検査して再実行。主要試験とD_repeatは影響なし。最終の有効会話は192件、実際に生成した全応答は除外分込み240件。','',
'## 提出物と次段階','',
'reports/aggregate.json、offline-results.json、live/*が定量結果と実入出力。models/*が重み/state、compound-export.jsonが来歴付き保存。reports/blind-review.htmlは方式/モデル名を伏せた192会話のローカル評価画面。blind-key.jsonは別ファイルなので、採点前には開かない。入力経験の有無などから方式を推測する余地はあり、完全な盲検を保証しない。表示と場面切替を実際のChromeで検証した。','',
'Phase 3の最終成功条件は部分的に満たした。経験学習・意味のある判断/表現への作用・継続性は合成条件で支持されたが、実Nephiaの自律的な形成、豊かな複数機能、人間が感じる自然さの改善、基盤モデル由来の癖の分離は未確立。次は許可された実経験と自然文の入力表現を準備し、同じ条件の単純線形/記憶を基準として測る。現行ASISTへの統合は実施しない。Phase 4は設計メモだけで実装・比較なし。']
(ROOT/'docs'/'04-results.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
print(json.dumps({'report':'docs/04-results.md','tests':15,'humanRatingsCompleted':0,'partialResearchSuccess':True}))
