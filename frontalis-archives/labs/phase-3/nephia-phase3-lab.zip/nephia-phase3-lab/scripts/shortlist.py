"""Build a diagnostic, blinded 20-response review from existing valid outputs."""
import json
import random
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
reports = ROOT / 'reports'
cards = {r['blindId']: r for r in json.loads((reports / 'blind-cards.json').read_text(encoding='utf8'))}
keys = json.loads((reports / 'blind-key.json').read_text(encoding='utf8'))
lookup = {(r['engine'], r['mode'], r['id']): r for r in keys}
groups = [
    ('01', '同じ経験から、判断の理由はどう変わるか', '同じ履歴を持つ応答の比較です。経験に合った判断か、理由が具体的かを見てください。', [('haiku', 'B', 'p1-interpretation'), ('haiku', 'D', 'p1-interpretation')]),
    ('02', '記憶だけでも十分な場面はあるか', '経験とのつながりと自然さを比較してください。大きな違いがなければ、そのことも有用な結果です。', [('sonnet', 'B', 'p0-self'), ('sonnet', 'D', 'p0-self')]),
    ('03', '追加経験と価値判断の変化', '各応答が利用できた履歴を開き、考えの変化が経験から説明できるかを見てください。', [('haiku', 'D', 'p1-values'), ('haiku', 'D_updated', 'p1-values')]),
    ('04', '追加経験と価値判断の変化・もう一組', '前の組と同じ場面の別の生成結果です。変化の理由が自然に伝わるかを見てください。', [('sonnet', 'D', 'p1-values'), ('sonnet', 'D_updated', 'p1-values')]),
    ('05', '異なる経験から育つ、美的な好み', '異なる経験を持つ二者の比較です。言い回し以外の違いがあり、それぞれの経験に合うかを見てください。', [('sonnet', 'D', 'p0-aesthetic'), ('sonnet', 'D', 'p1-aesthetic')]),
    ('06', '異なる経験から育つ、好奇心', '好きなものと、次に知りたいものは別でも構いません。興味の理由が履歴に合うかを見てください。', [('sonnet', 'D', 'p0-curiosity'), ('sonnet', 'D', 'p1-curiosity')]),
    ('07', '一時的な反応と、時間経過', '同じ長期経験で一時状態を変えた三つの応答です。反応の強さと、持続する好みを区別できているかを見てください。', [('haiku', 'D_short_zero', 'p0-reaction'), ('haiku', 'D_short_event', 'p0-reaction'), ('haiku', 'D_short_elapsed', 'p0-reaction')]),
    ('08', '一時的な反応と、時間経過・もう一組', '別の生成結果でも、反応と持続する判断の区別が読み取れるかを見てください。', [('sonnet', 'D_short_zero', 'p0-reaction'), ('sonnet', 'D_short_event', 'p0-reaction'), ('sonnet', 'D_short_elapsed', 'p0-reaction')]),
    ('09', '推論エンジンが変わっても、自己像は続くか', '同じ経験・状態を別のエンジンで表現した比較です。文体が違っても、自己理解と理由が保たれているかを見てください。', [('haiku', 'D', 'p1-self'), ('sonnet', 'D', 'p1-self')]),
]
rng = random.Random(20261014)
selected = []
selection_key = []
for gid, title, question, conditions in groups:
    rows = [lookup[c] for c in conditions]
    rng.shuffle(rows)
    selected.append({'groupId': gid, 'title': title, 'question': question, 'cards': [cards[r['blindId']] for r in rows]})
    selection_key.append({'groupId': gid, 'conditions': rows})
ids = [r['blindId'] for g in selected for r in g['cards']]
assert len(ids) == len(set(ids)) == 20
(reports / 'shortlist-cards.json').write_text(json.dumps(selected, ensure_ascii=False, indent=2), encoding='utf8')
(reports / 'shortlist-key.json').write_text(json.dumps(selection_key, ensure_ascii=False, indent=2), encoding='utf8')
source = (reports / 'blind-review.html').read_text(encoding='utf8')
style = source.split('<style>', 1)[1].split('</style>', 1)[0]
payload = json.dumps(selected, ensure_ascii=False).replace('<', '\\u003c')
html = '''<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ネフィア・重点評価20件</title><style>STYLE
.comparison{border-left:5px solid #184d67;padding-left:16px}.optional{font-size:14px}nav{z-index:2}.card h2{font-size:20px}
</style><main><h1>ネフィア・重点評価20件</h1><p>20応答を9組にまとめました。最初の4組（8応答）が最優先です。方式名・モデル名は伏せ、組の中の順番も入れ替えています。</p><p class="notice">まず「経験との対応」と「会話の自然さ」を採点してください。残りの項目とメモは任意です。1＝弱い、3＝中程度、5＝よい。判断できなければ未採点で構いません。すべて架空の会話です。</p><nav><label>比較 <select id="group"></select></label><button id="prev">前へ</button><button id="next">次へ</button><button id="save">採点をファイルに保存</button><span id="count"></span></nav><section id="intro" class="comparison"></section><div id="cards"></div><p class="small">入力は画面を開いている間保持されます。閉じる前に保存してください。保存した採点は下のボタンで再開できます。外部には送信しません。</p><label>保存済み採点を読み込む <input type="file" id="load" accept=".json,application/json"></label><p id="message" role="status"></p></main><script>
const groups=PAYLOAD;const data=groups.flatMap(g=>g.cards);let scores={};const names=['経験との対応','会話の自然さ','内容に表れる個性','理由の一貫性','維持と変化の説明'];const holder=document.querySelector('#cards');
const element=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
const selector=document.querySelector('#group');for(const g of groups){const o=element('option',g.groupId+' / '+g.title);o.value=g.groupId;selector.append(o);}
function updateCount(){const touched=data.filter(r=>Object.values(scores[r.blindId]??{}).some(v=>v&&v!=='未採点')).length;document.querySelector('#count').textContent='評価入力 '+touched+' / 20応答';}
function render(){holder.replaceChildren();const g=groups.find(x=>x.groupId===selector.value);const intro=document.querySelector('#intro');intro.replaceChildren(element('h2',g.groupId+' · '+g.title),element('p',g.question));for(const row of g.cards){const card=element('article',undefined,'card');card.append(element('h2',row.blindId+' · '+row.domain));for(const [text,cls]of[[row.user,'user'],[row.reply,'reply'],[row.followup,'user'],[row.followupReply,'reply']])card.append(element('div',text,'bubble '+cls));const details=element('details');details.append(element('summary','利用できた経験を確認する ('+row.experiences.length+'件)'));for(const e of row.experiences)details.append(element('p',e.id+'：'+e.text+' / 自己評価 '+e.evaluation.toFixed(2),'small'));card.append(details);const ratings=element('div',undefined,'ratings');for(const [i,name]of names.entries()){const label=element('label',name+(i>1?'（任意）':'')+' ');const select=element('select');for(const n of ['未採点',1,2,3,4,5]){let o=element('option',String(n));o.value=n;select.append(o);}select.value=scores[row.blindId]?.[name]??'未採点';select.onchange=()=>{scores[row.blindId]??={};scores[row.blindId][name]=select.value;updateCount();};label.append(select);ratings.append(label);}const memo=element('textarea');memo.placeholder='任意：良かった点、違和感、違いがない、など';memo.value=scores[row.blindId]?.memo??'';memo.oninput=()=>{scores[row.blindId]??={};scores[row.blindId].memo=memo.value;updateCount();};ratings.append(memo);card.append(ratings);holder.append(card);}document.querySelector('#prev').disabled=selector.selectedIndex===0;document.querySelector('#next').disabled=selector.selectedIndex===groups.length-1;updateCount();}
selector.onchange=render;for(const [id,delta]of[['prev',-1],['next',1]])document.querySelector('#'+id).onclick=()=>{selector.selectedIndex+=delta;render();window.scrollTo(0,0);};
document.querySelector('#save').onclick=()=>{const blob=new Blob([JSON.stringify({formatVersion:1,selectionId:'phase3-diagnostic20-20261014',reviewedAt:new Date().toISOString(),scores},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='nephia-human-review-20.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);};
document.querySelector('#load').onchange=async e=>{try{const f=e.target.files[0];if(!f)return;const value=JSON.parse(await f.text());if(value.formatVersion!==1||!value.scores||typeof value.scores!=='object'||Array.isArray(value.scores))throw Error('対応する採点ファイルではありません');const clean={};for(const row of data){const input=value.scores[row.blindId];if(!input||typeof input!=='object')continue;const entry={};for(const name of names)if(['未採点','1','2','3','4','5'].includes(input[name]))entry[name]=input[name];if(typeof input.memo==='string')entry.memo=input.memo;clean[row.blindId]=entry;}scores=clean;render();document.querySelector('#message').textContent='採点を読み込みました。';}catch(error){document.querySelector('#message').textContent='読み込めません：'+error.message;}};render();
</script></html>'''.replace('STYLE', style).replace('PAYLOAD', payload)
(reports / 'shortlist-review.html').write_text(html, encoding='utf8')
print(json.dumps({'responses': len(ids), 'comparisons': len(groups), 'priorityResponses': 8, 'ids': ids}))
