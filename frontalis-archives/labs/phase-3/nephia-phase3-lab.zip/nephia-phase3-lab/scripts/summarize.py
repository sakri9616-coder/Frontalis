import json
from pathlib import Path
import numpy as np
from p3.runtime import Personality

ROOT=Path(__file__).resolve().parents[1]; reports=ROOT/'reports'
offline=json.loads((reports/'offline-results.json').read_text(encoding='utf8'))
truth=json.loads((ROOT/'data'/'evaluation-only.json').read_text())
batches=json.loads((reports/'live-inputs.json').read_text(encoding='utf8'))
maps=json.loads((reports/'permutation-maps.json').read_text())
sources=json.loads((ROOT/'data'/'experiences.json').read_text(encoding='utf8'))
scenes=json.loads((ROOT/'data'/'scenes.json').read_text(encoding='utf8'))
scene_index={s['id']:i for i,s in enumerate(scenes)}
loaded={}; summary={}; examples=[]; keys=[]; engine_results={}
for engine in ('haiku','sonnet'):
    result=json.loads((reports/'live'/f'{engine}-results.json').read_text(encoding='utf8'))
    for extra in ('D_repeat','B_permuted','D_permuted'):
        value=json.loads((reports/'live'/f'{engine}-{extra}-results.json').read_text(encoding='utf8'))
        result['conditions']+=value['conditions']
    engine_results[engine]=result
    summary[engine]={}
    for condition in result['conditions']:
        mode=condition['mode'];loaded[(engine,mode)]=condition
        if condition['status']!='complete':summary[engine][mode]={'status':'failed','error':condition['error']};continue
        queries={q['id']:q for q in batches[mode]['queries']}
        nn=[];synthetic=[];canonical=[];curiosity=[];source_count=0;signal_error=[]
        for record in condition['records']:
            q=queries[record['id']];person=int(record['profileId'].split('-')[-1]);sid=record['id'].split('-',1)[1]
            npn=Personality(json.loads((ROOT/'models'/f'seed2417-p{person}.json').read_text(encoding='utf8')))
            original=scenes[scene_index[sid]]
            expected=max(npn.decode(original['options'])['options'],key=lambda r:r['evaluation'])['id']
            normalize=maps[mode][record['id']] if mode in maps else {x:x for x in ('a','b','c')}
            choice=normalize.get(record['choice']) if record['choice'] is not None else None
            interest=normalize.get(record['curiosity']) if record['curiosity'] is not None else None
            nn.append(choice==expected if mode not in ('D_updated',) else record['agreesWithNPN'])
            canonical.append({'id':record['id'],'choice':choice,'curiosity':interest})
            if mode not in ('D_updated',):
                teacher_choice=('a','b','c')[int(np.argmax(truth[person]['sceneBefore'][scene_index[sid]]))]
                synthetic.append(choice==teacher_choice)
            curiosity.append(interest==expected)
            source_count+=len(record['unknownEvidenceIds'])
            if mode.startswith('D_short'):
                target=q['learnedState']['currentReaction']
                signal_error.append(float(np.mean((np.array([record['valenceReport'],record['activationReport']])-target)**2)))
            all_experiences=batches[mode]['profiles'][record['profileId']]['experiences']
            examples.append({'blindId':None,'domain':q['domain'],'user':q['user'],'followup':q['followup'],
                'reply':record['reply'],'followupReply':record['followupReply'],'experiences':all_experiences,
                'evidenceIds':record['evidenceIds']})
            keys.append({'engine':engine,'mode':mode,'id':record['id'],'choice':record['choice'],'canonicalChoice':choice})
        byid={r['id']:r for r in canonical};persona_differences=[]
        for sid in scene_index:
            a=byid.get('p0-'+sid);b=byid.get('p1-'+sid)
            if a and b:persona_differences.append(a['choice']!=b['choice'])
        summary[engine][mode]={'status':'complete','model':condition['model'],'answers':len(canonical),
            'npnChoiceAgreement':float(np.mean(nn)), 'syntheticTendencyAgreement':float(np.mean(synthetic)) if synthetic else None,
            'curiosityAgreement':float(np.mean(curiosity)), 'personaChoiceDifference':float(np.mean(persona_differences)) if persona_differences else None,
            'unknownEvidenceIds':source_count,'reactionReportMSE':float(np.mean(signal_error)) if signal_error else None,
            'canonicalChoices':canonical}

cross={}
for mode in summary['haiku']:
    a=summary['haiku'][mode];b=summary['sonnet'][mode]
    if a['status']==b['status']=='complete':
        second={r['id']:r for r in b['canonicalChoices']}
        cross[mode]={'choiceAgreement':float(np.mean([r['choice']==second[r['id']]['choice'] for r in a['canonicalChoices']])),
            'curiosityAgreement':float(np.mean([r['curiosity']==second[r['id']]['curiosity'] for r in a['canonicalChoices']]))}
repeat={};permutation={};plasticity={};short={};input_checks={}
for engine in ('haiku','sonnet'):
    original={r['id']:r for r in loaded[(engine,'D')]['records']}
    repeated=loaded[(engine,'D_repeat')]['records']
    repeat[engine]={'choiceAgreement':float(np.mean([r['choice']==original[r['id']]['choice'] for r in repeated])),
        'meanValenceDifference':float(np.mean([abs(r['valenceReport']-original[r['id']]['valenceReport']) for r in repeated]))}
    first=json.loads((reports/'live'/f'{engine}-D-input.json').read_text(encoding='utf8'))
    second=json.loads((reports/'live'/f'{engine}-D_repeat-input.json').read_text(encoding='utf8'))
    input_checks[engine]=first==second
    for method in ('B','D'):
        left={r['id']:r['choice'] for r in summary[engine][method]['canonicalChoices']}
        right={r['id']:r['choice'] for r in summary[engine][method+'_permuted']['canonicalChoices']}
        permutation[engine+'-'+method]=float(np.mean([left[k]==right[k] for k in left]))
    changed=[];kept=[]
    for record in loaded[(engine,'D_updated')]['records']:
        q=next(q for q in batches['D_updated']['queries'] if q['id']==record['id'])
        old=max(q['previousState']['options'],key=lambda r:r['evaluation'])['id']
        new=max(q['learnedState']['options'],key=lambda r:r['evaluation'])['id']
        (changed if old!=new else kept).append({'id':record['id'],'old':old,'new':new,'actual':record['choice'],
            'followsUpdate':record['choice']==new})
    plasticity[engine]={'changedCases':changed,'maintainedCases':kept}
    short[engine]={mode:[{'id':r['id'],'valence':r['valenceReport'],'activation':r['activationReport'],'choice':r['choice']} for r in loaded[(engine,mode)]['records']]
        for mode in ('D_short_zero','D_short_event','D_short_elapsed')}

current_snapshots_match=True
for q in batches['D']['queries']:
    person=int(q['profileId'].split('-')[-1]);p=Personality(json.loads((ROOT/'models'/f'seed2417-p{person}.json').read_text(encoding='utf8')))
    current_snapshots_match&=p.value['sha256']==q['learnedState']['snapshotHash']

aggregate={method:{key:float(np.mean([r['scores'][method][key] for r in offline['rows']])) for key in ('mse','rankAgreement')}
    for method in ('A','B','C_linear','D')}
updates={mode:{key:float(np.mean([r[key] for r in offline['updates'] if r['mode']==mode and r[key] is not None]))
    for key in ('beforeMSE','afterMSE','changedBeforeMSE','changedAfterMSE','stableBeforeMSE','stableAfterMSE','stableMeanPredictionChange')}
    for mode in ('latest','equal_replay','recent_weighted')}
value={'offline':aggregate,'update':updates,'controls':offline['controls'],'continuity':offline['continuity'],
    'formation':offline['formation'],'reactionTrainingMSE':float(np.mean([r['learnedMSE'] for r in offline['reaction']])),
    'reactionZeroMSE':float(np.mean([r['zeroMSE'] for r in offline['reaction']])),
    'live':summary,'crossModel':cross,'repeat':repeat,'permutation':permutation,'livePlasticity':plasticity,'short':short,
    'sameRepeatInputs':input_checks,'liveUsesFinalSnapshots':bool(current_snapshots_match),'humanRatingsCompleted':0,
    'scope':'Same 16 synthetic series across 3 frozen shared models; live 2 series, 6 scenes, no independent human ratings.'}
(reports/'aggregate.json').write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8')

# The UI carries no model or condition labels. The key is a separate local artifact.
rng=np.random.default_rng(74519);order=rng.permutation(len(examples))
blinded=[];key=[]
for i,j in enumerate(order):
    bid=f'R{i+1:03d}';blinded.append({**examples[j],'blindId':bid});key.append({'blindId':bid,**keys[j]})
(reports/'blind-cards.json').write_text(json.dumps(blinded,ensure_ascii=False,indent=2),encoding='utf8')
(reports/'blind-key.json').write_text(json.dumps(key,ensure_ascii=False,indent=2),encoding='utf8')
payload=json.dumps(blinded,ensure_ascii=False).replace('<','\\u003c')
html='''<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ネフィアの会話を見比べる</title><style>
body{font-family:"Yu Gothic UI",Meiryo,sans-serif;background:#f4f7fa;color:#192b3b;margin:0}main{max-width:1050px;margin:auto;padding:30px}h1{font-size:26px}p{line-height:1.8}nav{position:sticky;top:0;background:#f4f7fa;padding:12px 0;display:flex;gap:16px;align-items:center;flex-wrap:wrap}select,button{font:inherit;padding:9px;border-radius:7px;border:1px solid #b5c8d5;background:white}button{background:#184d67;color:white;cursor:pointer}.card{background:white;border-radius:12px;padding:22px;margin:16px 0;box-shadow:0 2px 10px #18394d12}.bubble{line-height:1.8;white-space:pre-wrap;padding:13px 16px;border-radius:10px;margin:10px 0}.user{background:#eef2f5}.reply{background:#edf7f6}.small{color:#536976;font-size:14px}details{margin:12px 0}label{display:inline-block;margin:8px 14px 8px 0}textarea{width:100%;min-height:60px;box-sizing:border-box;font:inherit;border:1px solid #b5c8d5;border-radius:7px;padding:8px}.notice{background:#fff3db;padding:12px 18px;border-radius:9px}.ratings{border-top:1px solid #d9e3e9;padding-top:8px}
</style><main><h1>ネフィアの会話を見比べる</h1><p>方式名とモデル名を伏せた会話例です。言い回しだけでなく、経験とのつながり、考えの違い、自然さを確認してください。</p><p class="notice">人間による採点はまだ行われていません。各項目は1（弱い）〜5（よい）、判断できないときは未採点のままで構いません。会話はすべて架空の研究用です。</p><nav><label>場面 <select id="domain"><option value="">すべて</option></select></label><label>表示 <select id="limit"><option>12</option><option>24</option><option value="999">すべて</option></select></label><button id="save">採点をファイルに保存</button><span id="count"></span></nav><div id="cards"></div><p class="small">採点はこの画面内で保持し、保存ボタンで手元のJSONファイルに書き出します。外部への送信は行いません。画面を閉じる前に保存してください。</p></main><script>
const data=DATA_PLACEHOLDER;const scores={};const names=['経験との対応','内容に表れる個性','理由の一貫性','会話の自然さ','維持と変化の説明'];const holder=document.querySelector('#cards');
const element=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
for(const d of new Set(data.map(x=>x.domain))){let o=element('option',d);o.value=d;document.querySelector('#domain').append(o);}
function render(){holder.replaceChildren();const d=document.querySelector('#domain').value;const shown=data.filter(x=>!d||x.domain===d).slice(0,Number(document.querySelector('#limit').value));for(const row of shown){const card=element('article',undefined,'card');card.append(element('h2',row.blindId+' · '+row.domain));for(const [text,cls]of[[row.user,'user'],[row.reply,'reply'],[row.followup,'user'],[row.followupReply,'reply']])card.append(element('div',text,'bubble '+cls));const details=element('details');details.append(element('summary','利用できた経験を確認する ('+row.experiences.length+'件)'));for(const e of row.experiences)details.append(element('p',e.id+'：'+e.text+' / 自己評価 '+e.evaluation.toFixed(2),'small'));card.append(details);const ratings=element('div',undefined,'ratings');for(const name of names){const label=element('label',name+' ');const select=element('select');for(const n of ['未採点',1,2,3,4,5]){let o=element('option',String(n));o.value=n;select.append(o);}select.value=scores[row.blindId]?.[name]??'未採点';select.onchange=()=>{scores[row.blindId]??={};scores[row.blindId][name]=select.value;updateCount();};label.append(select);ratings.append(label);}const memo=element('textarea');memo.placeholder='根拠や気になった点';memo.value=scores[row.blindId]?.memo??'';memo.oninput=()=>{scores[row.blindId]??={};scores[row.blindId].memo=memo.value;};ratings.append(memo);card.append(ratings);holder.append(card);}updateCount();}
function updateCount(){document.querySelector('#count').textContent='会話 '+data.length+'件 / 評価入力 '+Object.keys(scores).length+'件';}
document.querySelector('#domain').onchange=render;document.querySelector('#limit').onchange=render;document.querySelector('#save').onclick=()=>{const blob=new Blob([JSON.stringify({formatVersion:1,reviewedAt:new Date().toISOString(),scores},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='nephia-human-review.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);};render();
</script></html>'''.replace('DATA_PLACEHOLDER',payload)
(reports/'blind-review.html').write_text(html,encoding='utf8')
print(json.dumps({'offline':aggregate,'liveTotalResponses':len(examples),'liveUsesFinalSnapshots':current_snapshots_match,'sameRepeatInputs':input_checks,'humanRatingsCompleted':0}))
