import json
import sys
from p3.runtime import Personality
loaded={}
for line in sys.stdin:
    req=None
    try:
        if len(line)>600000:raise ValueError('Request too large.')
        req=json.loads(line)
        if req['method']=='load':
            model=Personality(req['snapshot']);loaded[model.owner]=model
            result={'owner':model.owner,'snapshotHash':model.value['sha256']}
        else:
            model=loaded[req['owner']]
            if model.value['sha256']!=req['expectedSnapshotHash']:raise ValueError('Reference generation changed.')
            if req['method']!='readout':raise ValueError('Only readout is exposed by the reference port.')
            result=model.decode(req['options'])
        response={'id':req['id'],'result':result}
    except Exception as e:response={'id':req.get('id') if isinstance(req,dict) else None,'error':str(e)}
    print(json.dumps(response,ensure_ascii=False,allow_nan=False),flush=True)
