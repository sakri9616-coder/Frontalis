# Claude Codeへの引き継ぎ — Phase 3

まずREADME、docs/01-protocol.md、03-design.md、04-results.mdを読んでください。現行ASISTへは未統合です。実装変更と実記憶の利用は、利用者が結果を確認して次の範囲を指定してから進めます。

## 成果物と入口

研究領域は`C:\Users\sakur\AppData\Local\asist-shisa\nephia-phase3-lab`。隣接するnephia-core-lab / nephia-npn-labをread-only importします。3フォルダーを保持してください。新しい入力版はstructured-context6-v1、旧NPNのsynthetic-domain-v1を黙って読み替えないでください。

| ファイル | 実際の役割 |
|---|---|
| p3/train.py | 凍結共有特徴の上で個人28パラメーターを学習。経験評価と反応系列。0から再構築 |
| p3/runtime.py | NumPy参照、候補評価、反応の更新/減衰、状態検査、状況別JSON復号 |
| src/host.mjs | Phase 1台帳、提案/受理、候補学習/promote、短期状態遷移checkpoint、複合export/restore/rollback |
| src/port.mjs / scripts/server.py | 世代hash付き常駐JSON Lines。読取専用 |
| scripts/worker.py | 学習/検査/状態遷移の別プロセス。旧短期状態の引継ぎ |
| experiments/data.py / evaluate.py | 合成24経験/新12/未知96、16系列×3共有モデル。評価ラベルは学習へ渡さない |
| experiments/live.mjs / scripts/prepare-live.py | 日本語会話、モデル交換、再セッション、候補並べ替えの検査済み入力 |
| scripts/summarize.py / report.py | 保存済み結果とブラインド評価画面を再生成。NNの再学習はしない |

ホストの実例はscripts/demo.mjs。呼び出し順は`await propose(e, revision)`→信頼するhostが`accept(id, revision, review)`→`await prepare(owner, revision)`→検査後`await promote(candidate, review)`→`await readout(owner, options)`。一時反応は`await transition(owner, event, revision, review)`で台帳とcheckpointへ保存します。LLMへaccept/promote/transition/restore/rollbackの権限を渡さないでください。

## 再検査

```powershell
cd C:\Users\sakur\AppData\Local\asist-shisa\nephia-phase3-lab
npm test
npm run test:host
npm run demo
npm run summarize
npm run report
```

既存Node24とruntime-paths.jsonの既存Python/CPU PyTorch/NumPyで動きます。追加installは不要。import時のbytecode保存は無効にしています。共有重みの新学習はせず、学習を再実行する場合は成果物をコピーした別領域で`npm run evaluate`。CLI試験は自動test/demoに含まれません。

結果の重要点：NPNは外部状態への判断の忠実さを上げたが、単純線形は未知評価MSE0.0018、NPN0.1320で大きく優位。合成教師の線形性による有利さもある。Dの12/12一致を判断品質や自然さの改善と混同しないでください。関心・反応・自己概念の豊かさはまだ弱く、人間採点0件です。

候補並べ替えの初回は実験構築バグで除外済み。exploratory-before-option-alias-fixを成功/失敗のモデル比較へ混ぜないでください。入力の原文/特徴/ID/readout対応を、今後も送信前に検査します。UTF-8 IPCはencodingを明示してください。

## 次の独立研究

1. reports/blind-review.htmlの人間評価を受け取り、理由の一貫性・自然さ・内容の個性を方式間で比較。ラベルを見ずに先に採点し、blind-keyで後から照合する。人間の採点前に自然さの優位を主張しない。
2. 自然文の文脈注釈/encoderを用意。現在の6値は手作業注釈なので、自由な実会話へ直結しない。固定の文章表現＋記憶/線形を先に比較し、学習する表現に追加価値があるか測る。
3. 独立した関心、葛藤/保留、自己評価の教師が必要か検討。好きなもの＝知りたいものという前提を置かない。単一評価関数の言い換えで豊かな人格と判定しない。
4. 許可された自己経験、ユーザー経験、モデル由来の自己報告、実行結果、後日の評価を分ける。model originを消して学習へ通さない。少数のモデル発言だけでは基盤モデルの癖を分離できない。
5. 時点付きreplay/更新と保持を評価。ホストの標準は均等replayで、会話追加経験実験の重み0.25/1とは異なる。最適重みと呼ばない。
6. actual kill/crash、途中停止した状態遷移の再構築、参照プロセス再起動後のreload、原子的な跨ファイルcommit、データ消去/暗号化、upgrade fixtureを本番前に追加する。

## 将来のASIST接続位置

ASISTコードと実me.md/user.mdは調査中にhashが変わったため、以前のスナップショットへresetせず、現在ソースを再照合してください。こちらは変更していません。

- `asist/src/main/services/brain/turn.ts`：contextNotesを作る箇所、recordInputがnotesを履歴へ保存する箇所、memory injection、buildSystemLayers。ターン開始時のCore revision・snapshotを凍結し、状況別readoutを動的入力の注記へ載せる。後続tool roundとログが同じ世代を使うことを検証する。
- `asist/src/main/services/brain/tools.ts`：toolRegistry/ToolSpecへreadoutとpending経験提案だけを追加する。Claude CLI shimと他ProviderAdapterで実呼び出しを検証する。
- `asist/src/main/services/llm/claude-cli.ts`：sessionKeyはsystem/tools/modelで変化する。動的な人格状態をsystem/toolsへ毎回追加しない。LLMセッションを人格の正本にしない。
- `asist/src/main/services/memory-curation.ts`：この実装は調査中に変更された。日次記憶整理から構造化学習候補を作る案は、現在の責務と保存形式を読み直して設計する。Markdownを整えたことと人格NNが学んだことを別処理にする。

mainがFormationHostを所有し、学習と参照を別プロセスで起動。rendererからDBへ直接触らせない。ElectronのNode SQLite互換とPython同梱方針は未検証。設定には参照中の世代、未反映経験、候補モデル、戻す操作を表示し、学習OFFでも既存会話が動くことを検証する。

実me.mdはこれまでの自己記憶として尊重し、数値モデルで置き換えない。採用済みの自己記述と新しい判断の相違を、根拠付きの仮説・訂正候補として扱う。既存の会話、音声、Spotify等の設定は今回変更していません。

Phase 4はdocs/06-phase4-note.mdの設計メモだけ。圧縮/効率化を、人格の形成と表現の検証に代用しないでください。
