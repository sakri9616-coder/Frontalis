import {spawn} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {resolve,dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const paths=JSON.parse(readFileSync(join(root,'runtime-paths.json'),'utf8'));
export class ReferencePort{
 constructor(){this.child=null;this.pending=new Map();this.serial=0;}
 start(){
  if(this.child)return;
  const child=spawn(paths.inferencePython,[join(root,'scripts','server.py')],{cwd:root,windowsHide:true,stdio:['pipe','pipe','pipe'],
   env:{...process.env,PYTHONPATH:root,PYTHONDONTWRITEBYTECODE:'1',PYTHONIOENCODING:'utf-8'}});
  this.child=child;let buffer='';
  this.closed=new Promise(done=>child.on('close',()=>{this.child=null;this.rejectAll(new Error('Reference process closed.'));done();}));
  child.on('error',e=>this.rejectAll(e));child.stderr.on('data',()=>{});
  child.stdin.on('error',e=>this.rejectAll(e));
  child.stdout.setEncoding('utf8').on('data',value=>{
   buffer+=value;let index;while((index=buffer.indexOf('\n'))>=0){
    const line=buffer.slice(0,index);buffer=buffer.slice(index+1);let response;
    try{response=JSON.parse(line);}catch{this.rejectAll(new Error('Invalid reference JSON.'));continue;}
    const p=this.pending.get(response.id);if(!p)continue;
    clearTimeout(p.timer);this.pending.delete(response.id);if(response.error)p.fail(new Error(response.error));else p.done(response.result);
   }
  });
 }
 rejectAll(e){for(const p of this.pending.values()){clearTimeout(p.timer);p.fail(e);}this.pending.clear();}
 call(request){this.start();return new Promise((done,fail)=>{
  const id=++this.serial;const timer=setTimeout(()=>{this.pending.delete(id);fail(new Error('Reference timeout.'));},30000);
  this.pending.set(id,{done,fail,timer});this.child.stdin.write(JSON.stringify({...request,id})+'\n');
 });}
 async close(){if(this.child){this.child.stdin.end();await this.closed;}}
}
