import {NephiaCore} from '../../nephia-core-lab/src/core.mjs';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {resolve,dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {ReferencePort} from './port.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const paths=JSON.parse(readFileSync(join(root,'runtime-paths.json'),'utf8'));
const hash=value=>createHash('sha256').update(value).digest('hex');
const check=(value,message)=>{if(!value)throw new Error(message);};
function ownerCheck(owner){check(['nephia','user'].includes(owner),'Unknown owner.');}
export function worker(request){return new Promise((done,fail)=>{
 const child=spawn(request.method==='train'?paths.trainingPython:paths.inferencePython,[join(root,'scripts','worker.py')],{
  cwd:root,windowsHide:true,stdio:['pipe','pipe','pipe'],env:{...process.env,PYTHONPATH:root,PYTHONDONTWRITEBYTECODE:'1',PYTHONIOENCODING:'utf-8'}});
 let output='',error='';const timer=setTimeout(()=>{child.kill();fail(new Error('Phase 3 worker timeout.'));},60000);
 child.on('error',e=>{clearTimeout(timer);fail(e);});child.stdin.on('error',e=>{clearTimeout(timer);fail(e);});
 child.stdout.setEncoding('utf8').on('data',s=>{output+=s;});child.stderr.setEncoding('utf8').on('data',s=>{error=(error+s).slice(-1200);});
 child.on('close',code=>{clearTimeout(timer);if(code!==0){fail(new Error(`Worker failed ${code}: ${error}`));return;}try{done(JSON.parse(output));}catch{fail(new Error('Invalid worker JSON.'));}});
 child.stdin.end(JSON.stringify(request));
});}
export class FormationHost{
 constructor(directory){
  this.directory=resolve(directory);mkdirSync(join(this.directory,'checkpoints'),{recursive:true});
  this.core=new NephiaCore(join(this.directory,'core.db'));this.port=new ReferencePort();this.loaded=new Map();
 }
 get revision(){return this.core.revision;}
 async close(){this.core.close();await this.port.close();}
 events(schema){return this.core.activeEvents().map(e=>{try{return JSON.parse(e.text);}catch{return null;}}).filter(e=>e?.schema===schema);}
 async propose(experience,expectedRevision){
  ownerCheck(experience.owner);
  await worker({method:'validateExperience',experience});
  check(this.revision===expectedRevision,'Stale proposal revision.');
  return this.core.propose({id:experience.id,kind:'episode',owner:experience.owner,at:experience.at,evidence:experience.evidence,text:JSON.stringify(experience)},expectedRevision);
 }
 accept(id,revision,review){return this.core.accept(id,revision,review);}
 eligible(owner){ownerCheck(owner);return this.events('p3.experience.v1').filter(e=>e.owner===owner&&e.confidence>=.5&&
  !['generated_choice','user_praise'].includes(e.signal)&&['synthetic','human','observation'].includes(e.evidence.origin));}
 async prepare(owner,expectedRevision){
  ownerCheck(owner);check(expectedRevision===this.revision,'Stale training revision.');
  const experiences=this.eligible(owner);check(experiences.length>0,'No eligible experiences.');
  const artifact=JSON.parse(readFileSync(join(root,'..','nephia-npn-lab','models','trained.json'),'utf8'));
  let previousSnapshot;try{previousSnapshot=this.checkpoint(owner).snapshot;}catch(e){if(!e.message.includes('No active checkpoint'))throw e;}
  const snapshot=await worker({method:'train',artifact,experiences,owner,sourceRevision:expectedRevision,sourceHash:this.core.state().stateHash,previousSnapshot});
  return{expectedRevision,snapshot};
 }
 async promote(candidate,review){
  check(['human_reviewed','host_verified'].includes(review),'Trusted host review required.');
  check(candidate.expectedRevision===this.revision,'Stale checkpoint revision.');
  const p=candidate.snapshot.payload;ownerCheck(p.npnState.owner);
  check(p.sourceRevision===this.revision&&p.sourceHash===this.core.state().stateHash,'Checkpoint lineage mismatch.');
  const owner=p.npnState.owner;
  const activeIds=new Set(this.core.activeEvents().filter(e=>e.owner===owner).map(e=>e.id));
  check([...p.npnState.experienceIds,...p.transitionIds].every(id=>activeIds.has(id)),'Checkpoint missing source.');
  check(JSON.stringify(p.experiences)===JSON.stringify(this.eligible(owner)),'Checkpoint training history mismatch.');
  await worker({method:'validate',snapshot:candidate.snapshot});check(candidate.expectedRevision===this.revision,'Stale checkpoint revision.');
  const raw=JSON.stringify(candidate.snapshot),fileHash=hash(raw),file=join(this.directory,'checkpoints',`${fileHash}.json`);
  if(!existsSync(file))writeFileSync(file,raw,{flag:'wx'});
  const event={id:`p3-checkpoint-${fileHash}`,kind:'episode',owner,at:new Date().toISOString(),
   evidence:{sourceId:p.sourceHash,locator:`core-revision:${p.sourceRevision}`,origin:'observation'},
   text:JSON.stringify({schema:'p3.checkpoint.v1',fileHash,owner,sourceRevision:p.sourceRevision})};
  this.core.propose(event,candidate.expectedRevision);this.core.accept(event.id,candidate.expectedRevision,review);
  return{revision:this.revision,fileHash};
 }
 checkpoint(owner){
  ownerCheck(owner);const reference=this.events('p3.checkpoint.v1').filter(e=>e.owner===owner).at(-1);
  check(reference,'No active checkpoint.');check(/^[a-f0-9]{64}$/.test(reference.fileHash),'Invalid checkpoint path.');
  const raw=readFileSync(join(this.directory,'checkpoints',`${reference.fileHash}.json`),'utf8');check(hash(raw)===reference.fileHash,'Checkpoint file integrity failure.');
  return{snapshot:JSON.parse(raw),reference};
 }
 async readout(owner,options){
  const frozenRevision=this.revision;const {snapshot,reference}=this.checkpoint(owner);
  if(this.loaded.get(owner)!==reference.fileHash){await this.port.call({method:'load',snapshot});this.loaded.set(owner,reference.fileHash);}
  const result=await this.port.call({method:'readout',owner,options,expectedSnapshotHash:snapshot.sha256});
  const transitionIds=this.events('p3.transition.v1').filter(e=>e.owner===owner).map(e=>e.id);
  return{...result,checkpointHash:reference.fileHash,coreRevision:frozenRevision,currentRevision:this.revision,
   stale:frozenRevision!==this.revision||JSON.stringify(result.experienceIds)!==JSON.stringify(this.eligible(owner).map(e=>e.id))||
    JSON.stringify(snapshot.payload.transitionIds)!==JSON.stringify(transitionIds)};
 }
 async transition(owner,event,expectedRevision,review){
  ownerCheck(owner);check(expectedRevision===this.revision,'Stale transition revision.');
  check(event.owner===owner&&['reaction','elapse'].includes(event.operation),'Transition ownership/operation mismatch.');
  check(Number.isFinite(event.elapsed)&&event.elapsed>=0,'Invalid elapsed time.');
  if(event.operation==='reaction')check(Array.isArray(event.features)&&event.features.length===6&&event.features.every(x=>Number.isFinite(x)&&Math.abs(x)<=1),'Invalid transition features.');
  check(['human_reviewed','host_verified'].includes(review),'Trusted host review required.');
  const old=this.checkpoint(owner).snapshot;
  const snapshot=await worker({method:event.operation==='reaction'?'transition':'elapse',snapshot:old,owner,transitionId:event.id,features:event.features,elapsed:event.elapsed});
  check(expectedRevision===this.revision,'Stale transition revision.');
  const record={...event,schema:'p3.transition.v1'};
  this.core.propose({id:event.id,kind:'episode',owner,at:event.at,evidence:event.evidence,text:JSON.stringify(record)},expectedRevision);
  this.core.accept(event.id,expectedRevision,review);
  const transitionRevision=this.revision;
  // Source revision is the accepted transition, before committing its immutable checkpoint.
  const request={method:'rebind',snapshot,sourceRevision:this.revision,sourceHash:this.core.state().stateHash};
  const rebound=await worker(request);
  return this.promote({expectedRevision:transitionRevision,snapshot:rebound},review);
 }
 rollback(target,expected){this.loaded.clear();return this.core.rollback(target,expected);}
 exportPortable(){
  const ledger=this.core.exportPortable();
  const refs=new Set(ledger.events.map(e=>{try{const r=JSON.parse(e.text);return r.schema==='p3.checkpoint.v1'?r.fileHash:null;}catch{return null;}}).filter(Boolean));
  return{formatVersion:1,kind:'p3.compound',ledger,checkpoints:[...refs].map(fileHash=>({fileHash,raw:readFileSync(join(this.directory,'checkpoints',`${fileHash}.json`),'utf8')}))};
 }
 async restorePortable(bundle){
  check(this.revision===0&&this.core.activeEvents().length===0&&this.core.db.prepare('SELECT COUNT(*) AS n FROM proposals').get().n===0,'Restore needs an empty destination.');
  check(bundle.kind==='p3.compound'&&bundle.formatVersion===1,'Unsupported compound format.');
  const refs=new Set(bundle.ledger.events.map(e=>{try{const r=JSON.parse(e.text);return r.schema==='p3.checkpoint.v1'?r.fileHash:null;}catch{return null;}}).filter(Boolean));
  const provided=new Set(bundle.checkpoints.map(c=>c.fileHash));
  check(provided.size===bundle.checkpoints.length&&refs.size===provided.size&&[...refs].every(k=>provided.has(k)),'Missing or duplicate checkpoints.');
  const source=new NephiaCore();
  try{
   source.restorePortable(bundle.ledger);
   for(const c of bundle.checkpoints){
    check(/^[a-f0-9]{64}$/.test(c.fileHash)&&hash(c.raw)===c.fileHash,'Compound file integrity failure.');
    const snapshot=JSON.parse(c.raw);await worker({method:'validate',snapshot});const p=snapshot.payload;
    check(source.revisionRow(p.sourceRevision).digest===p.sourceHash,'Compound source revision mismatch.');
    const sourceIds=JSON.parse(source.revisionRow(p.sourceRevision).ids);
    const sourceEvents=new Map(sourceIds.map(id=>{const row=source.db.prepare('SELECT body FROM events WHERE id=?').get(id);return[id,JSON.parse(row.body)];}));
    check([...p.npnState.experienceIds,...p.transitionIds].every(id=>sourceEvents.get(id)?.owner===p.npnState.owner),'Compound evidence ownership mismatch.');
    for(const experience of p.experiences)check(sourceEvents.get(experience.id)?.text===JSON.stringify(experience),'Compound training evidence mismatch.');
   }
  }finally{source.close();}
  for(const c of bundle.checkpoints){const file=join(this.directory,'checkpoints',`${c.fileHash}.json`);if(!existsSync(file))writeFileSync(file,c.raw,{flag:'wx'});}
  this.loaded.clear();return this.core.restorePortable(bundle.ledger);
 }
}
