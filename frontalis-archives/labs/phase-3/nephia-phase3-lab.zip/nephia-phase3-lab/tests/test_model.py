import copy
import json
import unittest
from pathlib import Path
import numpy as np
from p3.runtime import Personality, eligible, wrap, validate_experience, features
from p3.train import train

ROOT=Path(__file__).resolve().parents[1]

class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.value=json.loads((ROOT/'models'/'seed2417-p0.json').read_text(encoding='utf8'))
        cls.other=json.loads((ROOT/'models'/'seed2417-p1.json').read_text(encoding='utf8'))
        cls.data=json.loads((ROOT/'data'/'experiences.json').read_text(encoding='utf8'))
        cls.scenes=json.loads((ROOT/'data'/'scenes.json').read_text(encoding='utf8'))

    def test_formed_parameters_changed_from_common_zero_initialization(self):
        v=self.value['payload']
        self.assertGreater(np.linalg.norm(v['npnState']['personalWeights']),.05)
        self.assertGreater(np.linalg.norm(v['reaction']['weights']),.05)
        self.assertGreater(np.linalg.norm(v['reaction']['decayLogits']),.01)
        self.assertNotEqual(v['npnState']['personalWeights'],self.other['payload']['npnState']['personalWeights'])
        self.assertEqual(v['training']['initialHead'],[0.]*8)

    def test_model_swap_changes_content_and_reactions_on_the_same_candidates(self):
        a=Personality(self.value);b=Personality(self.other)
        options=np.asarray([o['features'] for s in self.scenes for o in s['options']])
        self.assertGreater(np.mean(np.abs(a.score(options)-b.score(options))),.01)
        self.assertFalse(np.array_equal(a.force(options),b.force(options)))

    def test_fresh_json_roundtrip_preserves_scores_and_next_reaction(self):
        a=Personality(self.value);a.transition([.8,.4,.5,-.1,.9,.7],2,'first')
        b=Personality(json.loads(json.dumps(a.value)))
        self.assertEqual(a.decode(self.scenes[0]['options']),b.decode(self.scenes[0]['options']))
        self.assertEqual(a.transition([-.5,-.3,.1,.8,-.8,-.2],1,'second'),b.transition([-.5,-.3,.1,.8,-.8,-.2],1,'second'))

    def test_time_changes_only_short_states(self):
        model=Personality(self.value);long=model.long_hash
        model.transition([.8,.4,.5,-.1,.9,.7],2,'first')
        before=np.linalg.norm(model.p['reaction']['shortState']);model.elapse(20,'wait')
        self.assertEqual(long,model.long_hash)
        self.assertLess(np.linalg.norm(model.p['reaction']['shortState']),before)

    def test_integrity_shape_ownership_and_versions_are_checked(self):
        corrupt=copy.deepcopy(self.value);corrupt['payload']['reaction']['shortState'][0]=.2
        with self.assertRaisesRegex(ValueError,'integrity'):Personality(corrupt)
        for path,value in [('inputSchema','unknown')]:
            bad=copy.deepcopy(self.value['payload']);bad[path]=value
            with self.assertRaises(ValueError):Personality(wrap(bad))
        bad=copy.deepcopy(self.value['payload']);bad['reaction']['weights']=[[0.]]
        with self.assertRaises(ValueError):Personality(wrap(bad))
        model=Personality(self.value)
        with self.assertRaises(ValueError):model.transition([0.]*6,1,'wrong','user')
        with self.assertRaises(ValueError):model.elapse(-1,'negative')

    def test_nonself_unconfirmed_generated_and_praise_do_not_train_self(self):
        e=self.data[0]['experiences'][0]
        records=[e,{**e,'id':'user','owner':'user','signal':'user_report'},
            {**e,'id':'model','evidence':{**e['evidence'],'origin':'model'}},
            {**e,'id':'praise','signal':'user_praise'}, {**e,'id':'generated','signal':'generated_choice'},
            {**e,'id':'weak','confidence':.1}]
        self.assertEqual([r['id'] for r in eligible(records,'nephia')],[e['id']])

    def test_training_does_not_mutate_shared_model_and_ids_are_not_numeric_inputs(self):
        source=self.data[0]['experiences']
        artifact=copy.deepcopy(self.value['payload']['model']);before=copy.deepcopy(artifact)
        first=train(artifact,source,steps=20)
        renamed=[{**e,'id':'renamed-'+e['id'],'text':'別名をつけただけの同じ数値経験。'} for e in source]
        second=train(artifact,renamed,steps=20)
        self.assertEqual(artifact,before)
        self.assertEqual(first['payload']['npnState']['personalWeights'],second['payload']['npnState']['personalWeights'])

    def test_new_experiences_change_unseen_assessments(self):
        updated=json.loads((ROOT/'models'/'updated-p0-recent_weighted.json').read_text(encoding='utf8'))
        before=Personality(self.value);after=Personality(updated)
        query=json.loads((ROOT/'data'/'probes.json').read_text())['features']
        self.assertNotEqual(before.long_hash,after.long_hash)
        self.assertGreater(float(np.mean(np.abs(before.score(query)-after.score(query)))),.01)

    def test_incorrect_observed_reaction_is_refused(self):
        e=copy.deepcopy(self.data[0]['experiences'][0]);e['reactionObserved']=[float('nan'),0]
        with self.assertRaises(ValueError):validate_experience(e)

    def test_live_candidate_permutations_preserve_text_features_and_readout_identity(self):
        batches=json.loads((ROOT/'reports'/'live-inputs.json').read_text(encoding='utf8'))
        maps=json.loads((ROOT/'reports'/'permutation-maps.json').read_text())
        scenes={s['id']:s for s in self.scenes}
        for mode in ('B_permuted','D_permuted'):
            for q in batches[mode]['queries']:
                person=int(q['profileId'].split('-')[-1]);sid=q['id'].split('-',1)[1]
                original={o['id']:o for o in scenes[sid]['options']}
                for option in q['options']:
                    expected=original[maps[mode][q['id']][option['id']]]
                    self.assertEqual(option['features'],expected['features'])
                    self.assertEqual(option['text'],expected['text'])
                if mode=='D_permuted':
                    value=json.loads((ROOT/'models'/f'seed2417-p{person}.json').read_text(encoding='utf8'))
                    scores=Personality(value).decode(q['options'])['options']
                    self.assertEqual({r['id']:r['evaluation'] for r in scores},
                                     {r['id']:r['evaluation'] for r in q['learnedState']['options']})

    def test_duplicate_candidate_ids_and_accidental_oracle_fields_are_refused(self):
        model=Personality(self.value);option=self.scenes[0]['options'][0]
        with self.assertRaisesRegex(ValueError,'Duplicate'):
            model.decode([option,option])
        with self.assertRaisesRegex(ValueError,'schema'):
            model.decode([{**option,'expected':'a'}])

if __name__=='__main__':unittest.main(verbosity=2)
