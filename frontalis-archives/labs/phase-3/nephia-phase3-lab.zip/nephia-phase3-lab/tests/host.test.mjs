import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,mkdirSync,mkdtempSync} from 'node:fs';
import {join,resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {FormationHost,worker} from '../src/host.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const data=JSON.parse(readFileSync(join(root,'data','experiences.json'),'utf8'))[0];
const options=JSON.parse(readFileSync(join(root,'data','scenes.json'),'utf8'))[0].options;
const bundle=JSON.parse(readFileSync(join(root,'reports','compound-export.json'),'utf8'));
const base=join(root,'runtime','tests');mkdirSync(base,{recursive:true});
const fresh=()=>new FormationHost(mkdtempSync(join(base,'host-')));
test('pending and excluded origins never enter self training',async()=>{
 const host=fresh();try{
  const e=data.experiences[0];await host.propose(e,0);assert.equal(host.eligible('nephia').length,0);
  host.accept(e.id,0,'host_verified');assert.equal(host.eligible('nephia').length,1);
  for(const extra of [{...e,id:'model',evidence:{...e.evidence,origin:'model'}},{...e,id:'praise',signal:'user_praise'},{...e,id:'user',owner:'user',signal:'user_report'}]){
   await host.propose(extra,host.revision);host.accept(extra.id,host.revision,'host_verified');
  }
  assert.equal(host.eligible('nephia').length,1);assert.equal(host.eligible('user').length,1);
 }finally{await host.close();}
});
test('restore reproduces both short state and long predictions and refuses incomplete bundles',async()=>{
 let host=fresh();const directory=host.directory;
 try{
  await assert.rejects(()=>host.restorePortable({...bundle,checkpoints:[]}),/Missing/);assert.equal(host.revision,0);
  const bad=structuredClone(bundle);bad.checkpoints[0].raw+=' ';
  await assert.rejects(()=>host.restorePortable(bad),/integrity/);assert.equal(host.revision,0);
  await host.restorePortable(bundle);const first=await host.readout('nephia',options);
  await host.close();host=new FormationHost(directory);const restarted=await host.readout('nephia',options);
  assert.deepEqual(first,restarted);
  const report=JSON.parse(readFileSync(join(root,'reports','ledger-demo.json'),'utf8'));
  host.rollback(report.baseRevision,host.revision);const base=await host.readout('nephia',options);assert.deepEqual(base.currentReaction,[0,0]);
  host.rollback(report.reactionRevision,host.revision);const reacted=await host.readout('nephia',options);
  assert.deepEqual(reacted.currentReaction,report.currentReaction);assert.equal(reacted.longHash,first.longHash);
 }finally{await host.close();}
});
test('stale checkpoint and wrong-owner transition are refused',async()=>{
 const host=fresh();try{
  await host.restorePortable(bundle);
  await assert.rejects(()=>host.promote({expectedRevision:-1},'host_verified'),/Stale/);
  await assert.rejects(()=>host.transition('nephia',{owner:'user',operation:'elapse'},host.revision,'host_verified'),/ownership/);
 }finally{await host.close();}
});
test('relearning carries the current transient state without changing previous artifacts',async()=>{
 const host=fresh();try{
  await host.restorePortable(bundle);const previous=host.checkpoint('nephia').snapshot;
  const candidate=await host.prepare('nephia',host.revision);
  assert.deepEqual(candidate.snapshot.payload.reaction.shortState,previous.payload.reaction.shortState);
  assert.deepEqual(candidate.snapshot.payload.npnState.shortState,previous.payload.npnState.shortState);
  assert.deepEqual(candidate.snapshot.payload.transitionIds,previous.payload.transitionIds);
  await host.promote(candidate,'host_verified');assert.equal((await host.readout('nephia',options)).stale,false);
 }finally{await host.close();}
});
