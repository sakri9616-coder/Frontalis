import copy
import json
import subprocess
import sys
import time
from pathlib import Path
import numpy as np
from p3.runtime import Personality, features, digest
from p3.train import train

ROOT=Path(__file__).resolve().parents[1]
data=json.loads((ROOT/'data'/'experiences.json').read_text(encoding='utf8'))
probes=json.loads((ROOT/'data'/'probes.json').read_text())
truth=json.loads((ROOT/'data'/'evaluation-only.json').read_text())
scenes=json.loads((ROOT/'data'/'scenes.json').read_text(encoding='utf8'))
raw=np.asarray(probes['features'])
scene_raw=np.asarray([o['features'] for s in scenes for o in s['options']])
rows=[]; formation=[]; updates=[]; states={}; reaction=[]; controls=[]
start=time.perf_counter()


def memory(runtime, support, query):
    x=features(runtime,[e['features'] for e in support]); q=features(runtime,query)
    distance=((q[:,None,:]-x[None,:,:])**2).sum(axis=-1)
    hits=np.argsort(distance,axis=1)[:,:8]
    weights=np.exp(-np.take_along_axis(distance,hits,axis=1))
    y=np.asarray([e['evaluation'] for e in support])
    return (y[hits]*weights).sum(axis=1)/np.maximum(weights.sum(axis=1),1e-12)


def linear(support,query):
    x=np.asarray([e['features'] for e in support]); y=np.arctanh(np.clip([e['evaluation'] for e in support],-.97,.97))
    w=np.linalg.solve(x.T@x+.1*np.eye(6),x.T@y)
    return np.tanh(np.asarray(query)@w)


for seed in (2417,2418,2419):
    filename='trained.json' if seed==2417 else f'trained-seed{seed}.json'
    artifact=json.loads((ROOT.parent/'nephia-npn-lab'/'models'/filename).read_text())
    people=[]
    for person,source in enumerate(data):
        value=train(artifact,source['experiences'])
        model=Personality(value); people.append(model); states[(seed,person)]=model
        (ROOT/'models'/f'seed{seed}-p{person}.json').write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8')
        actual=np.asarray(truth[person]['before'])
        scores={'A':np.zeros(len(raw)),'B':memory(model.runtime,source['experiences'],raw),
                'C_linear':linear(source['experiences'],raw),'D':model.score(raw)}
        y_scene=np.asarray(truth[person]['sceneBefore']).ravel()
        scene_scores={'B':memory(model.runtime,source['experiences'],scene_raw),'C_linear':linear(source['experiences'],scene_raw),'D':model.score(scene_raw)}
        rows.append({'seed':seed,'person':person,'scores':{m:{'mse':float(np.mean((p-actual)**2)),
            'rankAgreement':float(np.mean((p[0::2]>p[1::2])==(actual[0::2]>actual[1::2])))} for m,p in scores.items()},
            'sceneChoiceAgreement':{m:float(np.mean(np.argmax(p.reshape(6,3),axis=1)==np.argmax(y_scene.reshape(6,3),axis=1))) for m,p in scene_scores.items()},
            'headNorm':float(np.linalg.norm(value['payload']['npnState']['personalWeights'])),
            'weightHash':model.long_hash,'training':value['payload']['training']})
        reaction.append({'seed':seed,'person':person,'learnedMSE':value['payload']['training']['losses'][-1]['reactionMSE'],
            'zeroMSE':float(np.mean(np.asarray([e['reactionObserved'] for e in source['experiences']])**2)),
            'scope':'Training-sequence fit only; no held-out emotion ground truth.'})
        if person<8:
            before=model.score(raw); after_truth=np.asarray(truth[person]['after'])
            changed=np.abs(after_truth-actual)>.3; stable=np.abs(after_truth-actual)<.12
            for mode in ('latest','equal_replay','recent_weighted'):
                experiences=source['updates'] if mode=='latest' else source['experiences']+source['updates']
                importance=[1.]*len(experiences) if mode!='recent_weighted' else [.25]*24+[1.]*12
                updated=Personality(train(artifact,experiences,weights=importance))
                predicted=updated.score(raw)
                updates.append({'seed':seed,'person':person,'mode':mode,'changedCount':int(changed.sum()),'stableCount':int(stable.sum()),
                    'beforeMSE':float(np.mean((before-after_truth)**2)),'afterMSE':float(np.mean((predicted-after_truth)**2)),
                    'changedBeforeMSE':float(np.mean((before[changed]-after_truth[changed])**2)) if changed.any() else None,
                    'changedAfterMSE':float(np.mean((predicted[changed]-after_truth[changed])**2)) if changed.any() else None,
                    'stableBeforeMSE':float(np.mean((before[stable]-actual[stable])**2)) if stable.any() else None,
                    'stableAfterMSE':float(np.mean((predicted[stable]-actual[stable])**2)) if stable.any() else None,
                    'stableMeanPredictionChange':float(np.mean(np.abs(predicted[stable]-before[stable]))) if stable.any() else None,
                    'meanPredictionChange':float(np.mean(np.abs(predicted-before))),
                    'longWeightsChanged':model.long_hash!=updated.long_hash})
                if person<2 and seed==2417:
                    (ROOT/'models'/f'updated-p{person}-{mode}.json').write_text(json.dumps(updated.value,ensure_ascii=False,indent=2),encoding='utf8')
        print(json.dumps({'seed':seed,'person':person,'completed':len(rows)}),flush=True)
    predictions=np.asarray([p.score(raw) for p in people]); expected=np.asarray([t['before'] for t in truth])
    swapped=np.roll(predictions,1,axis=0)
    controls.append({'seed':seed,'ownMSE':float(np.mean((predictions-expected)**2)),
        'swappedMSE':float(np.mean((swapped-expected)**2)),'zeroMSE':float(np.mean(expected**2)),
        'meanPersonaDistance':float(np.mean([np.mean(np.abs(predictions[i]-predictions[j])) for i in range(16) for j in range(i)])),
        'meanChoiceDifference':float(np.mean([np.mean((predictions[i,::2]>predictions[i,1::2])!=(predictions[j,::2]>predictions[j,1::2])) for i in range(16) for j in range(i)]))})

# Prefix-only formation curve is distinct from a presumed inherent personality.
for person in (0,1):
    artifact=states[(2417,person)].p['model']; src=data[person]['experiences']
    for n in (4,8,16,24):
        model=Personality(train(artifact,src[:n]))
        formation.append({'person':person,'n':n,'mse':float(np.mean((model.score(raw)-np.asarray(truth[person]['before']))**2)),
                          'longHash':model.long_hash,'headNorm':float(np.linalg.norm(model.p['npnState']['personalWeights']))})

model=states[(2417,0)]; original=model.score(raw); original_long=model.long_hash
(ROOT/'reports'/'offline-training-cache.json').write_text(json.dumps({'rows':rows,'controls':controls,'formation':formation,'updates':updates,'reaction':reaction},ensure_ascii=False,indent=2),encoding='utf8')
model.transition([.8,.4,.5,-.1,.9,.7],2,'offline-reaction-positive')
short_before=model.p['reaction']['shortState'][:]
saved=copy.deepcopy(model.value)
(ROOT/'models'/'continuity.json').write_text(json.dumps(saved,ensure_ascii=False),encoding='utf8')
paths=json.loads((ROOT/'runtime-paths.json').read_text())
request={'method':'readout','snapshot':saved,'options':scenes[0]['options']}
expected=model.decode(scenes[0]['options'])
completed=subprocess.run([paths['inferencePython'],str(ROOT/'scripts'/'worker.py')],input=json.dumps(request),text=True,encoding='utf-8',capture_output=True,
    env={**__import__('os').environ,'PYTHONPATH':str(ROOT),'PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8'},check=True)
restored=json.loads(completed.stdout)
model.elapse(20,'offline-elapse')
continuity={'freshProcessReadoutExact':restored==expected,'freshProcessShortExact':restored['currentReaction']==short_before,
    'longUnchangedOnTime':model.long_hash==original_long,'probePredictionsUnchangedOnTime':bool(np.array_equal(original,model.score(raw))),
    'shortNormBefore':float(np.linalg.norm(short_before)),'shortNormAfter':float(np.linalg.norm(model.p['reaction']['shortState']))}

result={'protocol':'p3-formation-v1','seeds':[2417,2418,2419],'personas':16,'probeCount':96,
    'scope':'Controlled synthetic experience formation with human-readable annotated scenes; no claim of autonomous real Nephia values.',
    'rows':rows,'controls':controls,'formation':formation,'updates':updates,'reaction':reaction,'continuity':continuity,
    'trainingUsedEvaluationLabels':False,'evaluationSeconds':time.perf_counter()-start,
    'datasetHash':digest({'support':data,'probes':probes,'scenes':scenes,'evaluation':truth})}
(ROOT/'reports'/'offline-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'completed':len(rows),'continuity':continuity,'seconds':result['evaluationSeconds']}),flush=True)
