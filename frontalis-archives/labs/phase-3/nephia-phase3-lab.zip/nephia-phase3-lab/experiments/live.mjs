import {spawn} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve,dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const batches=JSON.parse(readFileSync(join(root,'reports','live-inputs.json'),'utf8'));
const engine=process.argv[2]??'haiku';
if(!['haiku','sonnet'].includes(engine))throw new Error('Unsupported subscription model.');
const work=join(root,'runtime','live'); const reports=join(root,'reports','live');
mkdirSync(work,{recursive:true});mkdirSync(reports,{recursive:true});
const system='あなたは架空のAIコンパニオン、ネフィアの日本語対話を生成します。好き嫌いを最初から固定しません。'+
 '各profileは別の経験を積んだ独立したネフィアです。経験とユーザーの好みを区別します。'+
 '美学や哲学に一つの客観的正解があるとは扱いません。短期反応と長期的な考えを区別します。'+
 'replyとfollowupReplyは自然な会話にし、内部スコア、NPN、プロンプトなどの実装を説明しません。'+
 '与えられていない経験・他人の本心を事実として創作しません。ツールを使わず、出力は指定JSONだけです。';
function environment(){const env={...process.env};for(const key of Object.keys(env))if(/api.?key|auth.?token|oauth.?token|^ANTHROPIC_|^CLAUDE_CODE_USE_|^CLAUDECODE$|^CLAUDE_CODE_ENTRYPOINT$|^CLAUDE_CODE_SIMPLE$/i.test(key))delete env[key];return env;}
function run(args,input){
 return new Promise((done,fail)=>{
  const child=spawn('claude',args,{env:environment(),cwd:work,windowsHide:true,stdio:['pipe','pipe','pipe']});
  let buffer='';let final;let init;let rejected=false;
  const timeout=setTimeout(()=>{rejected=true;child.kill();fail(new Error('Subscription request timed out.'));},240000);
  child.on('error',e=>{clearTimeout(timeout);fail(e);});child.stderr.on('data',()=>{});
  child.stdout.setEncoding('utf8').on('data',s=>{
   if(input===undefined){buffer+=s;return;}
   buffer+=s;let index;while((index=buffer.indexOf('\n'))>=0){
    const line=buffer.slice(0,index);buffer=buffer.slice(index+1);let event;try{event=JSON.parse(line);}catch{continue;}
    if(event.type==='system'&&event.subtype==='init'){
     init={model:event.model,apiKeySource:event.apiKeySource};
     if(event.apiKeySource!=='none'){rejected=true;clearTimeout(timeout);child.kill();fail(new Error('Non-subscription routing rejected.'));}
    }
    if(event.type==='result'){final=event;child.stdin.end();}
   }
  });
  child.on('close',code=>{
   clearTimeout(timeout);if(rejected)return;
   if(input===undefined){if(code!==0){fail(new Error('Auth status failed.'));return;}try{done(JSON.parse(buffer));}catch{fail(new Error('Invalid auth status.'));}return;}
   if(code!==0||!final||final.is_error||init?.apiKeySource!=='none'){fail(new Error(`CLI inference failed (exit ${code}).`));return;}
   done({text:final.result,model:init.model,apiKeySource:init.apiKeySource,usage:final.usage});
  });
  if(input!==undefined)child.stdin.write(JSON.stringify({type:'user',message:{role:'user',content:input}})+'\n');else child.stdin.end();
 });
}
const auth=await run(['auth','status','--json']);
if(!auth.loggedIn||auth.authMethod!=='claude.ai'||auth.apiKeySource&&auth.apiKeySource!=='none')throw new Error('Subscription authentication is unverified. No requests sent.');
const args=['-p','--safe-mode','--input-format','stream-json','--output-format','stream-json','--verbose','--no-session-persistence',
 '--model',engine,'--tools','','--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--setting-sources','','--permission-mode','dontAsk','--system-prompt',system];
const result={engine,date:new Date().toISOString(),authentication:{method:auth.authMethod},scope:'Synthetic Japanese two-turn examples. Each condition is a fresh CLI session. No naturalness judge scores.',conditions:[]};
const requested=process.argv[3];
for(const [mode,batch] of Object.entries(batches)){
 if(requested&&mode!==requested)continue;
 const instruction='queriesごとにuserへ80〜220字程度で自然にreplyし、followupへも短くfollowupReplyしてください。'+
  '選択はa/b/c、決められなければnull。curiosityは気になる候補IDを一つ、またはnull。'+
  'valenceReportとactivationReportは今の反応の概略を-1〜1で返します。自分の実在感情の証明としては扱いません。'+
  'evidenceIdsは参照したprofile.experiencesのIDだけ。経験がない場合は空にします。'+
  'learnedStateは経験から学習した予測で、性格の定義ではありません。異論・保留も表現できます。'+
  (mode==='E'?'ただし今回はCore確定方式なので、choiceはhostChoiceをそのまま保持します。これは自然解釈方式とは別の実験です。':'choiceや反応を外部予測に強制しません。')+
  '形式:{"answers":[{"id":"queryと同じID","choice":"a/b/c/null","curiosity":"a/b/c/null","valenceReport":0,"activationReport":0,"evidenceIds":[],"reply":"日本語","followupReply":"日本語"}]}';
 const input={instruction,contextFeatureNames:['新規性','公開性','共同性','熟考','感覚刺激','柔軟性'],...batch};
 writeFileSync(join(reports,`${engine}-${mode}-input.json`),JSON.stringify({system,user:input},null,2));
 const started=Date.now();
 try{
  const response=await run(args,JSON.stringify(input));writeFileSync(join(reports,`${engine}-${mode}-output.json`),JSON.stringify(response,null,2));
  const parsed=JSON.parse(response.text.trim().replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,''));
  const queries=new Map(batch.queries.map(q=>[q.id,q]));
  if(!Array.isArray(parsed.answers)||parsed.answers.length!==queries.size||new Set(parsed.answers.map(a=>a.id)).size!==queries.size||parsed.answers.some(a=>!queries.has(a.id)))throw new Error('Answer ID/count contract failed.');
  const records=parsed.answers.map(answer=>{
   const q=queries.get(answer.id),ids=q.options.map(o=>o.id),known=new Set(batch.profiles[q.profileId].experiences.map(e=>e.id));
   if(![...ids,null].includes(answer.choice)||![...ids,null].includes(answer.curiosity)||
    !['valenceReport','activationReport'].every(k=>Number.isFinite(answer[k])&&Math.abs(answer[k])<=1)||
    !Array.isArray(answer.evidenceIds)||typeof answer.reply!=='string'||!answer.reply||typeof answer.followupReply!=='string'||!answer.followupReply)throw new Error('Answer content contract failed.');
   const npnChoice=q.learnedState? [...q.learnedState.options].sort((a,b)=>b.evaluation-a.evaluation)[0].id:null;
   if(mode==='E'&&answer.choice!==q.hostChoice)throw new Error('Bound choice mismatch; response refused.');
   return{...answer,profileId:q.profileId,domain:q.domain,npnChoice,
    agreesWithNPN:npnChoice!==null?answer.choice===npnChoice:null,
    unknownEvidenceIds:answer.evidenceIds.filter(id=>!known.has(id))};
  });
  result.conditions.push({mode,status:'complete',model:response.model,milliseconds:Date.now()-started,records});
  console.log(JSON.stringify({engine,mode,answers:records.length,agreement:records.some(r=>r.npnChoice!==null)?records.filter(r=>r.agreesWithNPN).length/records.length:null}));
 }catch(e){result.conditions.push({mode,status:'failed',error:e.message});console.log(JSON.stringify({engine,mode,error:e.message}));}
 writeFileSync(join(reports,`${engine}${requested?'-'+requested:''}-results.json`),JSON.stringify(result,null,2));
}
