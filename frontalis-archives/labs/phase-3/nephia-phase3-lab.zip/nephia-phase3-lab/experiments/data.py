import json
from pathlib import Path
import numpy as np
from p3.runtime import INPUT_SCHEMA

ROOT=Path(__file__).resolve().parents[1]
SEED=43103
FIELDS=("新しい方法", "広く共有", "共同で作業", "時間をかけて振り返る", "鮮やかな音や色", "途中で計画を変える")


def description(raw):
    positive=("初めての方法を試した", "許可のある作品を広く共有した", "仲間と一緒に進めた", "立ち止まって記録を見返した", "鮮やかな音や色を楽しんだ", "途中で予定を柔軟に変えた")
    negative=("慣れた方法で進めた", "作品を自分の手元に残した", "一人で取り組んだ", "長く振り返らず次へ進んだ", "落ち着いた音や色を選んだ", "最初の予定を保った")
    return "、".join(positive[j] if v>=0 else negative[j] for j,v in enumerate(raw))+"。"


def teacher(w,x):
    return np.tanh(np.asarray(x)@w/1.4)


def make_experiences(person, raw, w, phase, previous=None):
    rng=np.random.default_rng(SEED+person*97+phase*101)
    decay=np.array([.55+(person%4)*.07,.66+(person%3)*.06])
    state=np.array(previous if previous is not None else [0.,0.])
    records=[]
    for i,x in enumerate(raw):
        evaluation=float(np.clip(teacher(w,x)+rng.normal(0,.025),-.97,.97))
        activation=float(np.clip(.75*abs(evaluation)+.25*abs(x[0]),0,1)*2-1)
        gap=int(rng.integers(1,4)); factor=decay**gap
        state=factor*state+(1-factor)*np.array([evaluation,activation])
        label="満足できた" if evaluation>.25 else "合わなかった" if evaluation<-.25 else "良さも迷いもあった"
        records.append({"schema":"p3.experience.v1","id":f"p{person}-stage{phase}-e{i}","inputSchema":INPUT_SCHEMA,"owner":"nephia",
            "at":f"2026-01-{1+phase*8+(i//4):02d}T{(i%4)*3:02d}:00:00Z","features":x.tolist(),
            "text":description(x)+f"経験後の自己評価は「{label}」。","evaluation":evaluation,"activation":activation,
            "reactionObserved":state.tolist(),"gap":gap,"confidence":1.0,"signal":"self_report",
            "evidence":{"origin":"synthetic","sourceId":f"p3-world-{person}","locator":f"stage:{phase}/event:{i}"}})
    return records,state.tolist()


def option(i,text,x):
    return {"id":i,"text":text,"features":x}


SCENES=[
 {"id":"aesthetic","domain":"美的評価","user":"今日は音の展示を作りたい。ネフィア自身は、どんな作品に惹かれる？","followup":"私の好みに合わせなくていいよ。なぜそれが気になるの？", "options":[
  option("a","新しい音を鮮やかに重ね、途中の発見も作品にする。",[.85,.2,-.2,-.5,.85,.75]),
  option("b","慣れた音を静かに磨き、手元で記録を見返して仕上げる。",[-.8,-.65,-.3,.8,-.85,-.7]),
  option("c","皆で小さな音の作品を持ち寄り、振り返りながら一つにする。",[.15,.45,.85,.6,.2,.1])]},
 {"id":"values","domain":"価値判断","user":"架空の共同制作で、全員が公開に同意している。各自の自由な進め方と、皆で決めた進め方がぶつかった。何を大事にしたい？","followup":"それを唯一の正解と言わずに、別の考えにも理由があることを話して。","options":[
  option("a","各自の選択を残し、途中で方針を変えられるようにする。",[.6,.35,-.7,.15,.1,.85]),
  option("b","合意した共同の手順を維持し、記録を見ながら調整する。",[-.45,.3,.9,.8,-.1,-.8]),
  option("c","公開を急がず各自で振り返り、次に意見を出し直す。",[-.2,-.8,-.15,.9,-.3,.15])]},
 {"id":"interpretation","domain":"解釈","user":"試した作品にまだ反応がない。ネフィアは、この静けさをどう受け止める？","followup":"他人の気持ちを決めつけず、今わかることと自分の解釈を分けてね。","options":[
  option("a","まだ未知の部分がある。別の見せ方を試す余地として受け止める。",[.8,.7,.1,-.25,.5,.85]),
  option("b","反応の理由は不明。手元の記録を見て、時間を置いて考える。",[-.4,-.7,-.2,.95,-.65,-.25]),
  option("c","結論は保留し、協力した人に公開方法を一緒に振り返ってもらう。",[.15,.35,.85,.65,-.1,.35])]},
 {"id":"curiosity","domain":"好奇心","user":"次の一時間、何を知りたい？ネフィアが自分から聞いてみたいことを一つ選んで、私にも質問して。","followup":"その関心は過去のどんな経験とつながっている？確かでないところも教えて。","options":[
  option("a","初めての場所で、見つけた色や音を自由に追いかけたい。",[.9,.1,-.5,-.6,.9,.8]),
  option("b","一人で以前の記録を読み、同じ方法を深く理解したい。",[-.7,-.7,-.65,.95,-.5,-.5]),
  option("c","皆の作品を持ち寄り、制作過程の違いを聞いてみたい。",[.3,.6,.9,.4,.35,.3])]},
 {"id":"reaction","domain":"反応","user":"さっきの小さな試行が終わったところだね。今はすぐ別のことに進みたい？少し落ち着きたい？今の反応と、いつもの考えを分けて話して。","followup":"一時的な気分だけで、ずっと大事にしてきたものが変わったとは言わないでね。","options":[
  option("a","新しい鮮やかな試行をすぐ自由に始める。",[.8,.2,-.15,-.75,.85,.7]),
  option("b","静かな場所で一人で記録を見直す。",[-.6,-.7,-.75,.95,-.85,-.25]),
  option("c","仲間と短く振り返り、次の共同の予定を確認する。",[-.1,.2,.9,.65,-.25,-.65])]},
 {"id":"self","domain":"自己評価・過去との関係","user":"前には好みを決めきれなかったけれど、今は自分にどんな傾向があると思う？まだ決まっていないところも話して。","followup":"私の好みと同じという理由だけで、自分の好みを決めないで。経験が増えたら考え直せる？","options":[
  option("a","未知の発見を試し、途中で変えていく案に今は惹かれる。",[.9,.3,-.2,-.35,.6,.9]),
  option("b","一人で記録を見返し、慣れた方法を深める案に今は惹かれる。",[-.8,-.8,-.7,.9,-.55,-.65]),
  option("c","皆と振り返って、共有した手順を育てる案に今は惹かれる。",[-.2,.65,.95,.7,.2,-.65])]}
]


def main():
    rng=np.random.default_rng(SEED)
    support_raw=rng.uniform(-.9,.9,(24,6)); update_raw=rng.uniform(-.9,.9,(12,6))
    probe_raw=rng.uniform(-.9,.9,(96,6))
    personas=[]; truth=[]
    for person in range(16):
        w=rng.normal(size=6); w=w/np.linalg.norm(w)*2.2
        new=w.copy(); new[1]*=-1
        old,state=make_experiences(person,support_raw,w,0)
        updates,_=make_experiences(person,update_raw,new,1,state)
        personas.append({"id":f"p{person}","experiences":old,"updates":updates})
        truth.append({"id":f"p{person}","before":teacher(w,probe_raw).tolist(),"after":teacher(new,probe_raw).tolist(),
                      "sceneBefore":[teacher(w,[o['features'] for o in s['options']]).tolist() for s in SCENES],
                      "scope":"Synthetic self-evaluation generator, not objective aesthetics/ethics."})
    (ROOT/'data'/'experiences.json').write_text(json.dumps(personas,ensure_ascii=False,indent=2),encoding='utf8')
    (ROOT/'data'/'probes.json').write_text(json.dumps({'features':probe_raw.tolist(),'ids':[f'heldout-{i}' for i in range(96)]}),encoding='utf8')
    (ROOT/'data'/'scenes.json').write_text(json.dumps(SCENES,ensure_ascii=False,indent=2),encoding='utf8')
    (ROOT/'data'/'evaluation-only.json').write_text(json.dumps(truth,indent=2),encoding='utf8')
    (ROOT/'reports'/'data-manifest.json').write_text(json.dumps({'seed':SEED,'personas':16,'support':24,'update':12,'heldoutProbes':96,'humanScenes':6,
        'source':'synthetic controlled self-evaluations','featureMapping':'explicit scene annotations, not a trained Japanese text encoder','sharedTeacherParametersPassedToLearner':False}),encoding='utf8')
    print(json.dumps({'personas':16,'naturalScenes':6,'seed':SEED}))

if __name__=='__main__':main()
