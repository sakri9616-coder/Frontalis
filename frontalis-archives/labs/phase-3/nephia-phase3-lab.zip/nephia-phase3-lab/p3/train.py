import numpy as np
import torch
from torch import nn
from p3.runtime import features, eligible, Phase2Runtime, wrap, INPUT_SCHEMA, HASH_ENCODING

torch.set_num_threads(2)


def train(artifact, experiences, owner="nephia", weights=None, steps=220, source_revision=0, source_hash="offline"):
    accepted = eligible(experiences, owner)
    runtime = Phase2Runtime(artifact)
    phi = torch.tensor(features(runtime, [e["features"] for e in accepted]), dtype=torch.float32)
    evaluations = torch.tensor([e["evaluation"] for e in accepted], dtype=torch.float32)
    observations = torch.tensor([e["reactionObserved"] for e in accepted], dtype=torch.float32)
    gaps = torch.tensor([e["gap"] for e in accepted])
    times = torch.cumsum(gaps,dim=0)
    intervals = (times[:,None]-times[None,:]).clamp_min(0)
    causal = torch.tril(torch.ones(len(accepted),len(accepted)))
    importance = torch.tensor(weights if weights is not None else np.ones(len(accepted)), dtype=torch.float32)
    if importance.shape != evaluations.shape or not torch.isfinite(importance).all() or torch.any(importance <= 0):
        raise ValueError("Invalid replay weights.")
    preference = nn.Parameter(torch.zeros(8))
    reaction_weights = nn.Parameter(torch.zeros(2,8))
    reaction_bias = nn.Parameter(torch.zeros(2))
    decay_logits = nn.Parameter(torch.zeros(2))
    optimizer = torch.optim.Adam([preference, reaction_weights, reaction_bias, decay_logits], lr=.035)
    losses = []
    for step in range(steps):
        optimizer.zero_grad()
        prediction = torch.tanh(phi@preference)
        forces = torch.tanh(phi@reaction_weights.T+reaction_bias)
        decay = torch.sigmoid(decay_logits)
        factors = decay[None,:]**gaps[:,None]
        kernel = decay[None,None,:]**intervals[:,:,None]*causal[:,:,None]
        reactions = (kernel*((1-factors)*forces)[None,:,:]).sum(dim=1)
        loss_preference = (importance*(prediction-evaluations).square()).mean()
        loss_reaction = (importance[:,None]*(reactions-observations).square()).mean()
        regularization = .025*preference.square().mean()+.005*reaction_weights.square().mean()
        loss = loss_preference+.3*loss_reaction+regularization
        loss.backward(); optimizer.step()
        if step in (0,steps-1):
            losses.append({"step": step, "evaluationMSE": float(loss_preference.detach()), "reactionMSE": float(loss_reaction.detach())})
    head = preference.detach().tolist()
    npn_state = {"formatVersion":1,"owner":owner,"modelHash":artifact["sha256"],"encoderVersion":"synthetic-domain-v1",
        "base":[0.0]*8,"personalWeights":head,"longLatent":head,"steps":steps,"experienceIds":[e["id"] for e in accepted],
        "shortState":[0.0]*4,"time":0.0}
    reaction = {"weights":reaction_weights.detach().tolist(),"bias":reaction_bias.detach().tolist(),
        "decayLogits":decay_logits.detach().tolist(),"shortState":[0.0,0.0],"time":0.0}
    return wrap({"formatVersion":1,"hashEncoding":HASH_ENCODING,"inputSchema":INPUT_SCHEMA,"model":artifact,"npnState":npn_state,
        "reaction":reaction,"experiences":accepted,"transitionIds":[],"sourceRevision":source_revision,"sourceHash":source_hash,
        "training":{"steps":steps,"learnedPersonalParameters":28,"sharedWeightsFrozen":True,"initialHead":[0.0]*8,"losses":losses,
                    "importance":importance.tolist(),"scope":"Synthetic observed evaluations and reactions; no query labels used."}})
