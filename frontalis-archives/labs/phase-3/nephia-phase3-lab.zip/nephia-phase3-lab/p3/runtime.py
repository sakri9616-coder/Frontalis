import copy
import json
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT.parent / "nephia-npn-lab"))
from npn.runtime import Runtime as Phase2Runtime
from npn.canonical import digest, HASH_ENCODING

INPUT_SCHEMA = "structured-context6-v1"
FIELDS = ("新規性", "公開性", "共同性", "熟考", "感覚刺激", "柔軟性")


def features(runtime, values):
    values = np.asarray(values, np.float32)
    if values.shape[-1] != 6 or not np.isfinite(values).all() or np.any(np.abs(values) > 1):
        raise ValueError("Invalid context features.")
    return np.asarray(runtime.facets(values/np.sqrt(6), np.zeros(values.shape[:-1], np.int64)), np.float32)


def validate_experience(e):
    if e.get("schema") != "p3.experience.v1" or e.get("inputSchema") != INPUT_SCHEMA:
        raise ValueError("Experience representation mismatch.")
    if e.get("owner") not in ("nephia", "user") or e.get("signal") not in ("self_report", "user_report", "observed_choice", "generated_choice", "user_praise"):
        raise ValueError("Invalid experience owner/signal.")
    if e["signal"] == "self_report" and e["owner"] != "nephia" or e["signal"] == "user_report" and e["owner"] != "user":
        raise ValueError("Experience attribution mismatch.")
    if not isinstance(e.get("text"), str) or not 0 < len(e["text"]) <= 1200:
        raise ValueError("Invalid experience text.")
    raw = np.asarray(e.get("features"))
    if raw.shape != (6,) or not np.isfinite(raw).all() or np.any(np.abs(raw) > 1):
        raise ValueError("Invalid context features.")
    for key in ("evaluation", "activation"):
        if not isinstance(e.get(key), (int, float)) or not np.isfinite(e[key]) or not -1 <= e[key] <= 1:
            raise ValueError("Invalid self evaluation.")
    if not isinstance(e.get("confidence"), (int, float)) or not 0 <= e["confidence"] <= 1:
        raise ValueError("Invalid confidence.")
    if not isinstance(e.get("gap"), (int, float)) or not np.isfinite(e["gap"]) or e["gap"] <= 0:
        raise ValueError("Invalid observed elapsed time.")
    observed=np.asarray(e.get("reactionObserved"))
    if observed.shape!=(2,) or not np.isfinite(observed).all() or np.any(np.abs(observed)>1):
        raise ValueError("Invalid observed reaction.")


def eligible(experiences, owner):
    if owner not in ("nephia", "user"):
        raise ValueError("Unknown owner.")
    for e in experiences:
        validate_experience(e)
    accepted = [e for e in experiences if e["owner"] == owner and e["confidence"] >= .5 and
                e["signal"] not in ("generated_choice", "user_praise") and e["evidence"]["origin"] in ("synthetic", "human", "observation")]
    if not accepted:
        raise ValueError("No eligible personal experience.")
    if len({e["id"] for e in accepted}) != len(accepted):
        raise ValueError("Duplicate personal experience.")
    return accepted


def wrap(payload):
    return {"payload": payload, "sha256": digest(payload)}


class Personality:
    def __init__(self, value):
        p = value["payload"]
        if p.get("formatVersion") != 1 or p.get("hashEncoding") != HASH_ENCODING or value.get("sha256") != digest(p) or p.get("inputSchema") != INPUT_SCHEMA:
            raise ValueError("Phase 3 integrity/version mismatch.")
        self.value = copy.deepcopy(value)
        self.p = self.value["payload"]
        self.runtime = Phase2Runtime(self.p["model"])
        self.runtime.validate_state(self.p["npnState"], self.p["npnState"]["owner"])
        reaction = self.p["reaction"]
        for key, shape in (("weights", (2, 8)), ("bias", (2,)), ("decayLogits", (2,)), ("shortState", (2,))):
            v = np.asarray(reaction[key])
            if v.shape != shape or not np.isfinite(v).all():
                raise ValueError("Invalid learned reaction state.")
        if not np.isfinite(reaction["time"]) or reaction["time"] < 0:
            raise ValueError("Invalid reaction time.")
        ids = self.p["npnState"]["experienceIds"]
        if any(e["owner"] != self.owner for e in self.p["experiences"]) or ids != [e["id"] for e in eligible(self.p["experiences"], self.owner)]:
            raise ValueError("Personal state/source mismatch.")
        if type(self.p["sourceRevision"]) is not int or self.p["sourceRevision"] < 0:
            raise ValueError("Invalid source revision.")
        if len(set(self.p["transitionIds"])) != len(self.p["transitionIds"]):
            raise ValueError("Duplicate transition provenance.")

    @property
    def owner(self):
        return self.p["npnState"]["owner"]

    @property
    def long_hash(self):
        return digest({"npn": self.p["npnState"]["longLatent"], "reactionWeights": self.p["reaction"]["weights"], "reactionBias": self.p["reaction"]["bias"], "decay": self.p["reaction"]["decayLogits"]})

    def score(self, values):
        return np.tanh(features(self.runtime, values) @ np.asarray(self.p["npnState"]["longLatent"], np.float32))

    def force(self, values):
        r = self.p["reaction"]
        return np.tanh(features(self.runtime, values) @ np.asarray(r["weights"]).T + np.asarray(r["bias"]))

    def transition(self, raw, elapsed, transition_id, owner="nephia"):
        if owner != self.owner or not np.isfinite(elapsed) or elapsed < 0 or transition_id in self.p["transitionIds"]:
            raise ValueError("Invalid state transition.")
        r = self.p["reaction"]
        factor = (1/(1+np.exp(-np.asarray(r["decayLogits"])))) ** elapsed
        r["shortState"] = (factor*np.asarray(r["shortState"]) + (1-factor)*self.force(raw)).tolist()
        r["time"] += elapsed
        # Preserve the original Phase 2 reaction state alongside the calibrated Phase 3 state.
        self.p["npnState"], _ = self.runtime.observe_reaction(self.p["npnState"], np.asarray(raw)/np.sqrt(6), 0, elapsed, owner)
        self.p["transitionIds"].append(transition_id)
        self.value = wrap(self.p)
        return self.value

    def elapse(self, elapsed, transition_id, owner="nephia"):
        if owner != self.owner or not np.isfinite(elapsed) or elapsed < 0 or transition_id in self.p["transitionIds"]:
            raise ValueError("Invalid elapsed state transition.")
        r = self.p["reaction"]
        factor = (1/(1+np.exp(-np.asarray(r["decayLogits"])))) ** elapsed
        r["shortState"] = (factor*np.asarray(r["shortState"])).tolist()
        r["time"] += elapsed
        self.p["npnState"] = self.runtime.elapse(self.p["npnState"], elapsed, owner)
        self.p["transitionIds"].append(transition_id)
        self.value = wrap(self.p)
        return self.value

    def decode(self, options):
        if not isinstance(options,list) or not 1<=len(options)<=64:
            raise ValueError("Invalid candidate collection.")
        ids=[]
        for option in options:
            if not isinstance(option,dict) or set(option)!={"id","text","features"}:
                raise ValueError("Candidate schema mismatch.")
            if not isinstance(option["id"],str) or not 0<len(option["id"])<=120 or not isinstance(option["text"],str) or not 0<len(option["text"])<=1200:
                raise ValueError("Invalid candidate identity/text.")
            ids.append(option["id"])
        if len(set(ids))!=len(ids):
            raise ValueError("Duplicate candidate identity.")
        raw = np.asarray([o["features"] for o in options], np.float32)
        scores = self.score(raw)
        history = self.p["experiences"]
        h = features(self.runtime, [e["features"] for e in history])
        q = features(self.runtime, raw)
        similarity = q @ h.T / np.maximum(1e-9, np.linalg.norm(q, axis=1)[:, None]*np.linalg.norm(h, axis=1)[None, :])
        records = []
        for i, option in enumerate(options):
            probes = np.repeat(raw[i:i+1], 6, axis=0)
            for j in range(6):
                probes[j,j] = 0
            contributions = float(scores[i])-self.score(probes)
            records.append({"id": option["id"], "evaluation": float(scores[i]), "predictedReaction": self.force(raw[i]).tolist(),
                            "counterfactualSensitivity": dict(zip(FIELDS, contributions.tolist())),
                            "relatedExperienceIds": [history[j]["id"] for j in np.argsort(-similarity[i])[:3]]})
        return {"owner": self.owner, "snapshotHash": self.value["sha256"], "longHash": self.long_hash,
                "sharedModelHash": self.runtime.model_hash, "inputSchema": INPUT_SCHEMA,
                "options": records, "currentReaction": self.p["reaction"]["shortState"],
                "experienceIds": self.p["npnState"]["experienceIds"], "sourceRevision": self.p["sourceRevision"],
                "uncertainty": "未校正の合成経験に基づく予測。倫理的な正解や固定した性格ではない。"}
