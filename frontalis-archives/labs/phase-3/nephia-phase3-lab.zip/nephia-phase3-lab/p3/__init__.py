"""Phase 3 research overlay. Previous phases are imported read-only."""
