Fresh Phase 3-E reproduction copy. No old models/results/materialized language plans. Run main/stress/diagnostic/performance, then prepare_language.py materialize. See original CLAUDE_HANDOFF.md.
